/*
 * An XML document type.
 * Localname: testregistry
 * Namespace: 
 * Java type: gov.nist.p25.issi.xmlconfig.TestregistryDocument
 *
 * Automatically generated - do not modify.
 */
package gov.nist.p25.issi.xmlconfig.impl;
/**
 * A document containing one testregistry(@) element.
 *
 * This is a complex type.
 */
public class TestregistryDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements gov.nist.p25.issi.xmlconfig.TestregistryDocument
{
    
    public TestregistryDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TESTREGISTRY$0 = 
        new javax.xml.namespace.QName("", "testregistry");
    
    
    /**
     * Gets the "testregistry" element
     */
    public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry getTestregistry()
    {
        synchronized (monitor())
        {
            check_orphaned();
            gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry target = null;
            target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry)get_store().find_element_user(TESTREGISTRY$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "testregistry" element
     */
    public void setTestregistry(gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry testregistry)
    {
        synchronized (monitor())
        {
            check_orphaned();
            gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry target = null;
            target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry)get_store().find_element_user(TESTREGISTRY$0, 0);
            if (target == null)
            {
                target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry)get_store().add_element_user(TESTREGISTRY$0);
            }
            target.set(testregistry);
        }
    }
    
    /**
     * Appends and returns a new empty "testregistry" element
     */
    public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry addNewTestregistry()
    {
        synchronized (monitor())
        {
            check_orphaned();
            gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry target = null;
            target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry)get_store().add_element_user(TESTREGISTRY$0);
            return target;
        }
    }
    /**
     * An XML testregistry(@).
     *
     * This is a complex type.
     */
    public static class TestregistryImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry
    {
        
        public TestregistryImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TESTCASE$0 = 
            new javax.xml.namespace.QName("", "testcase");
        
        
        /**
         * Gets a List of "testcase" elements
         */
        public java.util.List<gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase> getTestcaseList()
        {
            final class TestcaseList extends java.util.AbstractList<gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase>
            {
                public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase get(int i)
                    { return TestregistryImpl.this.getTestcaseArray(i); }
                
                public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase set(int i, gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase o)
                {
                    gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase old = TestregistryImpl.this.getTestcaseArray(i);
                    TestregistryImpl.this.setTestcaseArray(i, o);
                    return old;
                }
                
                public void add(int i, gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase o)
                    { TestregistryImpl.this.insertNewTestcase(i).set(o); }
                
                public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase remove(int i)
                {
                    gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase old = TestregistryImpl.this.getTestcaseArray(i);
                    TestregistryImpl.this.removeTestcase(i);
                    return old;
                }
                
                public int size()
                    { return TestregistryImpl.this.sizeOfTestcaseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new TestcaseList();
            }
        }
        
        /**
         * Gets array of all "testcase" elements
         */
        public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase[] getTestcaseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(TESTCASE$0, targetList);
                gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase[] result = new gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "testcase" element
         */
        public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase getTestcaseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase target = null;
                target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase)get_store().find_element_user(TESTCASE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "testcase" element
         */
        public int sizeOfTestcaseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TESTCASE$0);
            }
        }
        
        /**
         * Sets array of all "testcase" element
         */
        public void setTestcaseArray(gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase[] testcaseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(testcaseArray, TESTCASE$0);
            }
        }
        
        /**
         * Sets ith "testcase" element
         */
        public void setTestcaseArray(int i, gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase testcase)
        {
            synchronized (monitor())
            {
                check_orphaned();
                gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase target = null;
                target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase)get_store().find_element_user(TESTCASE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(testcase);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "testcase" element
         */
        public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase insertNewTestcase(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase target = null;
                target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase)get_store().insert_element_user(TESTCASE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "testcase" element
         */
        public gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase addNewTestcase()
        {
            synchronized (monitor())
            {
                check_orphaned();
                gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase target = null;
                target = (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase)get_store().add_element_user(TESTCASE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "testcase" element
         */
        public void removeTestcase(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TESTCASE$0, i);
            }
        }
        /**
         * An XML testcase(@).
         *
         * This is a complex type.
         */
        public static class TestcaseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase
        {
            
            public TestcaseImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName DESCRIPTION$0 = 
                new javax.xml.namespace.QName("", "description");
            private static final javax.xml.namespace.QName CATEGORY$2 = 
                new javax.xml.namespace.QName("", "category");
            private static final javax.xml.namespace.QName TESTDIRECTORY$4 = 
                new javax.xml.namespace.QName("", "testDirectory");
            private static final javax.xml.namespace.QName TOPOLOGY$6 = 
                new javax.xml.namespace.QName("", "topology");
            private static final javax.xml.namespace.QName TESTNUMBER$8 = 
                new javax.xml.namespace.QName("", "testNumber");
            private static final javax.xml.namespace.QName TESTCLASS$10 = 
                new javax.xml.namespace.QName("", "testClass");
            
            
            /**
             * Gets the "description" element
             */
            public java.lang.String getDescription()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTION$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "description" element
             */
            public org.apache.xmlbeans.XmlString xgetDescription()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "description" element
             */
            public void setDescription(java.lang.String description)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTION$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRIPTION$0);
                    }
                    target.setStringValue(description);
                }
            }
            
            /**
             * Sets (as xml) the "description" element
             */
            public void xsetDescription(org.apache.xmlbeans.XmlString description)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESCRIPTION$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESCRIPTION$0);
                    }
                    target.set(description);
                }
            }
            
            /**
             * Gets the "category" attribute
             */
            public java.lang.String getCategory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(CATEGORY$2);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "category" attribute
             */
            public org.apache.xmlbeans.XmlString xgetCategory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(CATEGORY$2);
                    return target;
                }
            }
            
            /**
             * True if has "category" attribute
             */
            public boolean isSetCategory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().find_attribute_user(CATEGORY$2) != null;
                }
            }
            
            /**
             * Sets the "category" attribute
             */
            public void setCategory(java.lang.String category)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(CATEGORY$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(CATEGORY$2);
                    }
                    target.setStringValue(category);
                }
            }
            
            /**
             * Sets (as xml) the "category" attribute
             */
            public void xsetCategory(org.apache.xmlbeans.XmlString category)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(CATEGORY$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(CATEGORY$2);
                    }
                    target.set(category);
                }
            }
            
            /**
             * Unsets the "category" attribute
             */
            public void unsetCategory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_attribute(CATEGORY$2);
                }
            }
            
            /**
             * Gets the "testDirectory" attribute
             */
            public java.lang.String getTestDirectory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TESTDIRECTORY$4);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "testDirectory" attribute
             */
            public org.apache.xmlbeans.XmlString xgetTestDirectory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TESTDIRECTORY$4);
                    return target;
                }
            }
            
            /**
             * True if has "testDirectory" attribute
             */
            public boolean isSetTestDirectory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().find_attribute_user(TESTDIRECTORY$4) != null;
                }
            }
            
            /**
             * Sets the "testDirectory" attribute
             */
            public void setTestDirectory(java.lang.String testDirectory)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TESTDIRECTORY$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(TESTDIRECTORY$4);
                    }
                    target.setStringValue(testDirectory);
                }
            }
            
            /**
             * Sets (as xml) the "testDirectory" attribute
             */
            public void xsetTestDirectory(org.apache.xmlbeans.XmlString testDirectory)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TESTDIRECTORY$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(TESTDIRECTORY$4);
                    }
                    target.set(testDirectory);
                }
            }
            
            /**
             * Unsets the "testDirectory" attribute
             */
            public void unsetTestDirectory()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_attribute(TESTDIRECTORY$4);
                }
            }
            
            /**
             * Gets the "topology" attribute
             */
            public java.lang.String getTopology()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TOPOLOGY$6);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "topology" attribute
             */
            public org.apache.xmlbeans.XmlString xgetTopology()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TOPOLOGY$6);
                    return target;
                }
            }
            
            /**
             * True if has "topology" attribute
             */
            public boolean isSetTopology()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().find_attribute_user(TOPOLOGY$6) != null;
                }
            }
            
            /**
             * Sets the "topology" attribute
             */
            public void setTopology(java.lang.String topology)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TOPOLOGY$6);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(TOPOLOGY$6);
                    }
                    target.setStringValue(topology);
                }
            }
            
            /**
             * Sets (as xml) the "topology" attribute
             */
            public void xsetTopology(org.apache.xmlbeans.XmlString topology)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TOPOLOGY$6);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(TOPOLOGY$6);
                    }
                    target.set(topology);
                }
            }
            
            /**
             * Unsets the "topology" attribute
             */
            public void unsetTopology()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_attribute(TOPOLOGY$6);
                }
            }
            
            /**
             * Gets the "testNumber" attribute
             */
            public java.lang.String getTestNumber()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TESTNUMBER$8);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "testNumber" attribute
             */
            public org.apache.xmlbeans.XmlString xgetTestNumber()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TESTNUMBER$8);
                    return target;
                }
            }
            
            /**
             * True if has "testNumber" attribute
             */
            public boolean isSetTestNumber()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().find_attribute_user(TESTNUMBER$8) != null;
                }
            }
            
            /**
             * Sets the "testNumber" attribute
             */
            public void setTestNumber(java.lang.String testNumber)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TESTNUMBER$8);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(TESTNUMBER$8);
                    }
                    target.setStringValue(testNumber);
                }
            }
            
            /**
             * Sets (as xml) the "testNumber" attribute
             */
            public void xsetTestNumber(org.apache.xmlbeans.XmlString testNumber)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TESTNUMBER$8);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(TESTNUMBER$8);
                    }
                    target.set(testNumber);
                }
            }
            
            /**
             * Unsets the "testNumber" attribute
             */
            public void unsetTestNumber()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_attribute(TESTNUMBER$8);
                }
            }
            
            /**
             * Gets the "testClass" attribute
             */
            public java.lang.String getTestClass()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TESTCLASS$10);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "testClass" attribute
             */
            public org.apache.xmlbeans.XmlString xgetTestClass()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TESTCLASS$10);
                    return target;
                }
            }
            
            /**
             * True if has "testClass" attribute
             */
            public boolean isSetTestClass()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().find_attribute_user(TESTCLASS$10) != null;
                }
            }
            
            /**
             * Sets the "testClass" attribute
             */
            public void setTestClass(java.lang.String testClass)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(TESTCLASS$10);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(TESTCLASS$10);
                    }
                    target.setStringValue(testClass);
                }
            }
            
            /**
             * Sets (as xml) the "testClass" attribute
             */
            public void xsetTestClass(org.apache.xmlbeans.XmlString testClass)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlString target = null;
                    target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(TESTCLASS$10);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(TESTCLASS$10);
                    }
                    target.set(testClass);
                }
            }
            
            /**
             * Unsets the "testClass" attribute
             */
            public void unsetTestClass()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_attribute(TESTCLASS$10);
                }
            }
        }
    }
}
