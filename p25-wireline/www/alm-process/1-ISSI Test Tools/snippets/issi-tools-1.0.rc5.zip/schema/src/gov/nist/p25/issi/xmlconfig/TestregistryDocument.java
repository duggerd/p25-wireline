/*
 * An XML document type.
 * Localname: testregistry
 * Namespace: 
 * Java type: gov.nist.p25.issi.xmlconfig.TestregistryDocument
 *
 * Automatically generated - do not modify.
 */
package gov.nist.p25.issi.xmlconfig;


/**
 * A document containing one testregistry(@) element.
 *
 * This is a complex type.
 */
public interface TestregistryDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TestregistryDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA5AFEF6199EA0368CE209164BC8A3D88").resolveHandle("testregistryddc8doctype");
    
    /**
     * Gets the "testregistry" element
     */
    gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry getTestregistry();
    
    /**
     * Sets the "testregistry" element
     */
    void setTestregistry(gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry testregistry);
    
    /**
     * Appends and returns a new empty "testregistry" element
     */
    gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry addNewTestregistry();
    
    /**
     * An XML testregistry(@).
     *
     * This is a complex type.
     */
    public interface Testregistry extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Testregistry.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA5AFEF6199EA0368CE209164BC8A3D88").resolveHandle("testregistry5b0delemtype");
        
        /**
         * Gets a List of "testcase" elements
         */
        java.util.List<gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase> getTestcaseList();
        
        /**
         * Gets array of all "testcase" elements
         * @deprecated
         */
        gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase[] getTestcaseArray();
        
        /**
         * Gets ith "testcase" element
         */
        gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase getTestcaseArray(int i);
        
        /**
         * Returns number of "testcase" element
         */
        int sizeOfTestcaseArray();
        
        /**
         * Sets array of all "testcase" element
         */
        void setTestcaseArray(gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase[] testcaseArray);
        
        /**
         * Sets ith "testcase" element
         */
        void setTestcaseArray(int i, gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase testcase);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "testcase" element
         */
        gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase insertNewTestcase(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "testcase" element
         */
        gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase addNewTestcase();
        
        /**
         * Removes the ith "testcase" element
         */
        void removeTestcase(int i);
        
        /**
         * An XML testcase(@).
         *
         * This is a complex type.
         */
        public interface Testcase extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Testcase.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA5AFEF6199EA0368CE209164BC8A3D88").resolveHandle("testcasec7dbelemtype");
            
            /**
             * Gets the "description" element
             */
            java.lang.String getDescription();
            
            /**
             * Gets (as xml) the "description" element
             */
            org.apache.xmlbeans.XmlString xgetDescription();
            
            /**
             * Sets the "description" element
             */
            void setDescription(java.lang.String description);
            
            /**
             * Sets (as xml) the "description" element
             */
            void xsetDescription(org.apache.xmlbeans.XmlString description);
            
            /**
             * Gets the "category" attribute
             */
            java.lang.String getCategory();
            
            /**
             * Gets (as xml) the "category" attribute
             */
            org.apache.xmlbeans.XmlString xgetCategory();
            
            /**
             * True if has "category" attribute
             */
            boolean isSetCategory();
            
            /**
             * Sets the "category" attribute
             */
            void setCategory(java.lang.String category);
            
            /**
             * Sets (as xml) the "category" attribute
             */
            void xsetCategory(org.apache.xmlbeans.XmlString category);
            
            /**
             * Unsets the "category" attribute
             */
            void unsetCategory();
            
            /**
             * Gets the "testDirectory" attribute
             */
            java.lang.String getTestDirectory();
            
            /**
             * Gets (as xml) the "testDirectory" attribute
             */
            org.apache.xmlbeans.XmlString xgetTestDirectory();
            
            /**
             * True if has "testDirectory" attribute
             */
            boolean isSetTestDirectory();
            
            /**
             * Sets the "testDirectory" attribute
             */
            void setTestDirectory(java.lang.String testDirectory);
            
            /**
             * Sets (as xml) the "testDirectory" attribute
             */
            void xsetTestDirectory(org.apache.xmlbeans.XmlString testDirectory);
            
            /**
             * Unsets the "testDirectory" attribute
             */
            void unsetTestDirectory();
            
            /**
             * Gets the "topology" attribute
             */
            java.lang.String getTopology();
            
            /**
             * Gets (as xml) the "topology" attribute
             */
            org.apache.xmlbeans.XmlString xgetTopology();
            
            /**
             * True if has "topology" attribute
             */
            boolean isSetTopology();
            
            /**
             * Sets the "topology" attribute
             */
            void setTopology(java.lang.String topology);
            
            /**
             * Sets (as xml) the "topology" attribute
             */
            void xsetTopology(org.apache.xmlbeans.XmlString topology);
            
            /**
             * Unsets the "topology" attribute
             */
            void unsetTopology();
            
            /**
             * Gets the "testNumber" attribute
             */
            java.lang.String getTestNumber();
            
            /**
             * Gets (as xml) the "testNumber" attribute
             */
            org.apache.xmlbeans.XmlString xgetTestNumber();
            
            /**
             * True if has "testNumber" attribute
             */
            boolean isSetTestNumber();
            
            /**
             * Sets the "testNumber" attribute
             */
            void setTestNumber(java.lang.String testNumber);
            
            /**
             * Sets (as xml) the "testNumber" attribute
             */
            void xsetTestNumber(org.apache.xmlbeans.XmlString testNumber);
            
            /**
             * Unsets the "testNumber" attribute
             */
            void unsetTestNumber();
            
            /**
             * Gets the "testClass" attribute
             */
            java.lang.String getTestClass();
            
            /**
             * Gets (as xml) the "testClass" attribute
             */
            org.apache.xmlbeans.XmlString xgetTestClass();
            
            /**
             * True if has "testClass" attribute
             */
            boolean isSetTestClass();
            
            /**
             * Sets the "testClass" attribute
             */
            void setTestClass(java.lang.String testClass);
            
            /**
             * Sets (as xml) the "testClass" attribute
             */
            void xsetTestClass(org.apache.xmlbeans.XmlString testClass);
            
            /**
             * Unsets the "testClass" attribute
             */
            void unsetTestClass();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase newInstance() {
                  return (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry.Testcase) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry newInstance() {
              return (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (gov.nist.p25.issi.xmlconfig.TestregistryDocument.Testregistry) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument newInstance() {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static gov.nist.p25.issi.xmlconfig.TestregistryDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (gov.nist.p25.issi.xmlconfig.TestregistryDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
