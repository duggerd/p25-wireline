//
package gov.nist.p25.issi.rfss.tester;

import gov.nist.p25.issi.constants.ISSIDtdConstants;
import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.PacketMonitorWebServerAddress;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;

import org.apache.log4j.Logger;

/**
 * This class defines where the web servers that launch the emulated RFSSs live.
 * 
 */
public class ISSITesterConfiguration {

   private static Logger logger = Logger.getLogger(ISSITesterConfiguration.class);

   //public static void showln(String s) { System.out.println(s); }

   private Hashtable<String, DaemonWebServerAddress> addressMap = 
      new Hashtable<String, DaemonWebServerAddress>();
   private HashSet<DaemonWebServerAddress> addresses = new HashSet<DaemonWebServerAddress>();

   // constructor
   public ISSITesterConfiguration() {
   }

   public Collection<EmulatorWebServerAddress> getEmulatorConfigurations() {
      HashSet<EmulatorWebServerAddress> retval = new HashSet<EmulatorWebServerAddress>();
      for (DaemonWebServerAddress da: addresses) {
         if (da.isTesterService()) {
            retval.add(new EmulatorWebServerAddress(da.getIpAddress(), da.getHttpPort()));
         }
      }
      logger.debug("getEmulatorConfigurations():\n"+retval);
      return retval;
   }

   public Collection<PacketMonitorWebServerAddress> getPacketMonitors() {
      HashSet<PacketMonitorWebServerAddress> retval = new HashSet<PacketMonitorWebServerAddress>();
      for (DaemonWebServerAddress da: addresses) {
         if (da.isPacketMonitorService()) {
            retval.add(new PacketMonitorWebServerAddress(da.getIpAddress(), da.getHttpPort()));
         }
      }
      return retval;
   }

   public PacketMonitorWebServerAddress getPacketMonitor(String ipAddress) {
      for (DaemonWebServerAddress da: addresses) {
         if (ipAddress.trim().equals(da.getIpAddress()) && da.isPacketMonitorService()) {
            logger.info("ISSITesterConfiguration: Found configuration for " + ipAddress);
            return new PacketMonitorWebServerAddress(da.getIpAddress(), da.getHttpPort());
         }
      }
      return null;
   }

   public void printPacketMonitorTable() {
      logger.info(getPacketMonitors().toString());
   }

   public String getIpAddressByName(String name) {
      if ( addressMap.get(name) == null) {
         return null;
      }
      else {
         if ( addressMap.get(name) == null) {
            return null;
	 } else { 
            return addressMap.get(name).getIpAddress();
         }
      }
   }

   public DaemonWebServerAddress getDaemonByName(String name) {
      return addressMap.get(name);
   }

   public Collection<DaemonWebServerAddress> getDaemonAddresses() {
      return addresses;
   }

   public Collection<String> getLocalAddresses() {
      HashSet<String> retval = new HashSet<String>();
      for (DaemonWebServerAddress emulatorAddress: addresses) {
         for (int port = (int) (Math.random() * 10000), j = 0; j < 10; j++) {
            String ipStr = emulatorAddress.getIpAddress();
            //showln("getLocalAddresses(): emulatorAddress="+ipStr +" port="+port);
            if (ipStr != null) {
               try {
                  Socket sock = new Socket();
                  sock.bind(new InetSocketAddress( ipStr, port));
                  sock.close();
                  retval.add( ipStr);
                  break;
               } catch (IOException ex) {
                  // ignore 
                  //showln("getLocalAddresses(): ex="+ex);
               }
            }
         }
      }
      logger.info("Local addresses:\n" + retval);
      return retval;
   }

   public Collection<DaemonWebServerAddress> getLocalConfigurations() {
      HashSet<DaemonWebServerAddress> retval = new HashSet<DaemonWebServerAddress>();
      for (DaemonWebServerAddress emulatorAddress: addresses) {
         if (emulatorAddress.getHttpPort() > 0) {
            for (int port = (int) (Math.random() * 10000), j = 0; j < 10; j++) {
               try {
                  Socket sock = new Socket();
                  sock.bind(new InetSocketAddress(emulatorAddress.getIpAddress(), port));
                  sock.close();
                  retval.add(emulatorAddress);
                  break;
               } catch (IOException ex) {
                  // ignore 
                  //showln("getLocalConfigurations(): ex="+ex);
               }
            }
         }
      }
      return retval;
   }

   public void addDaemonWebServerAddress(DaemonWebServerAddress daemonWebServerAddress) {
      addresses.add(daemonWebServerAddress);
      addressMap.put(daemonWebServerAddress.getName(), daemonWebServerAddress);
   }

   public void addReference(String id, DaemonWebServerAddress daemonWebServerAddress) {
      addressMap.put(id, daemonWebServerAddress);
      daemonWebServerAddress.addRefId(id);
   }

   public void removeRefId(String tag) {
      for (DaemonWebServerAddress dwa: addresses) {
         dwa.removeRefId(tag);
      }
      addressMap.remove(tag);      
   }
   
   @Override
   public String toString() {
      StringBuffer sbuf = new StringBuffer();
      sbuf.append("<?xml version=\"1.0\"?>\n");
      sbuf.append("<!DOCTYPE system-topology SYSTEM \"" + 
         ISSIDtdConstants.URL_ISSI_DTD_TESTER_CONFIG + "\">\n");
      sbuf.append("<issi-tester-config>\n");      
      for ( DaemonWebServerAddress dwa: addresses) {
         sbuf.append(dwa.toString());
      }      
      sbuf.append("</issi-tester-config>\n");
      return sbuf.toString();      
   }
}
