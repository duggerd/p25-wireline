//
package gov.nist.p25.issi.message;

import java.io.IOException;
import org.apache.xmlbeans.XmlException;

import gov.nist.p25.issi.constants.IvsDelaysConstants;
import gov.nist.p25.issi.setup.IvsDelaysHelper;
//import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument;
import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays;
//import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsInput;
import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsGcsd;
import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsGmtd;
//import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsStatus;
import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsUcsd;
import gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsUmtd;


public class XmlIvsDelaysSpec
{
   public static void showln(String s) { System.out.println(s); }

   //-------------------------------------------------------------------------
   public static XmlIvsDelays getMeasurementIvsDelays()
      throws XmlException, IOException
   {
      return new XmlIvsDelays(IvsDelaysConstants.SPEC_MEASUREMENTS_FILE);
   }
   public static XmlIvsDelays getUserIvsDelays()
      throws XmlException, IOException
   {
      return new XmlIvsDelays(IvsDelaysConstants.USER_MEASUREMENTS_FILE);
   }

   //-------------------------------------------------------------------------
   public static XmlIvsDelays generateIvsGcsd(boolean isConfirmed) throws Exception
   {
      XmlIvsDelays xmldoc = new XmlIvsDelays();
      IvsDelays ivsDelays = xmldoc.getIvsDelays();

      IvsGcsd ivsGcsd = ivsDelays.addNewIvsGcsd();
      ivsGcsd.setTitle("Performance Specifications for Group Call Setup Delay(GCSD)");
      ivsGcsd.setDiagram("gfx/diagrams/IVS-GCSD.JPG");

      // measured parameters
      gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsGcsd.Parameter gcsdParam;
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg1");
      gcsdParam.setValue(200);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg2");
      gcsdParam.setValue(10);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg3");
      gcsdParam.setValue(10);
      gcsdParam.setMaximum(50);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg4");
      gcsdParam.setValue(60);
      gcsdParam.setMaximum(200);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg5");
      gcsdParam.setValue(10);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg6");
      gcsdParam.setValue(110);
      gcsdParam.setMaximum(350);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg7");
      gcsdParam.setValue(110);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg8");
      gcsdParam.setValue(60);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg9");
      gcsdParam.setValue(60);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg10");
      gcsdParam.setValue(170);
      gcsdParam.setMaximum(550);
      gcsdParam = ivsGcsd.addNewParameter();
      gcsdParam.setKey("Tg11");
      gcsdParam.setValue(220);

      // get external measurements
      IvsDelays extDelays = getMeasurementIvsDelays().getIvsDelays();
      xmldoc.getAllParameters(IvsDelaysConstants.TAG_IVS_GCSD, extDelays);

      // confirmed group call
      IvsDelaysHelper.setGCSDComposite( xmldoc, isConfirmed);

      // comment
      String title = "Performanace Recommendations for ISSI Voice Services";
      String comment = "Performanace specifications based on TIA-102.CACB, April 2007.";
      if( isConfirmed) {
         comment += " Confirmed Group Call.";
      }
      else {
         comment += " Unconfirmed Group Call.";
      }

      xmldoc.setIvsStatusComment( title, comment);
      return xmldoc;
   }

   public static XmlIvsDelays generateIvsGmtd() throws Exception
   {
      XmlIvsDelays xmldoc = new XmlIvsDelays();
      IvsDelays ivsDelays = xmldoc.getIvsDelays();

      IvsGmtd ivsGmtd = ivsDelays.addNewIvsGmtd();
      ivsGmtd.setTitle("Performance Specifications for Group Call Message Transfer Delay(GMTD)");
      ivsGmtd.setDiagram("gfx/diagrams/IVS-GMTD.JPG");

      // measured parameters
      gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsGmtd.Parameter gmtdParam;
      gmtdParam = ivsGmtd.addNewParameter();
      gmtdParam.setKey("Tg_ad1");
      gmtdParam.setValue(200);
      gmtdParam.setMaximum(600);
      gmtdParam = ivsGmtd.addNewParameter();
      gmtdParam.setKey("Tg_ad2");
      gmtdParam.setValue(10);
      gmtdParam.setMaximum(50);
      gmtdParam = ivsGmtd.addNewParameter();
      gmtdParam.setKey("Tg_ad3");
      gmtdParam.setValue(170);

      // get external measurements
      IvsDelays extDelays = getMeasurementIvsDelays().getIvsDelays();
      xmldoc.getAllParameters(IvsDelaysConstants.TAG_IVS_GMTD, extDelays);

      // calculated parameters
      IvsDelaysHelper.setGMTDComposite( xmldoc);

      // comment
      String title = "Performanace Recommendations for ISSI Voice Services";
      String comment = "Performanace specifications based on TIA-102.CACB, April 2007.";
      xmldoc.setIvsStatusComment( title, comment);
      return xmldoc;
   }

   public static XmlIvsDelays generateIvsUcsd(boolean isDirectCall)
      throws Exception
   {
      XmlIvsDelays xmldoc = new XmlIvsDelays();
      IvsDelays ivsDelays = xmldoc.getIvsDelays();

      IvsUcsd ivsUcsd = ivsDelays.addNewIvsUcsd();
      ivsUcsd.setTitle("Performance Specifications for SU-to-SU Call Setup Delay(UCSD)");
      ivsUcsd.setDiagram("gfx/diagrams/IVS-UCSD.JPG");

      // measured parameters
      gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsUcsd.Parameter ucsdParam;
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu1");
      ucsdParam.setValue(170);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu2");
      ucsdParam.setValue(10);
      ucsdParam.setMaximum(30);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu3");
      ucsdParam.setValue(10);
      ucsdParam.setMaximum(30);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu4");
      ucsdParam.setValue(210);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu5");
      ucsdParam.setValue(170);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu6");
      ucsdParam.setValue(60);
      ucsdParam.setMaximum(200);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu7");
      ucsdParam.setValue(10);
      ucsdParam.setMaximum(50);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu8");
      ucsdParam.setValue(10);
      ucsdParam.setMaximum(50);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu9");
      ucsdParam.setValue(290);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu10");
      ucsdParam.setValue(60);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu11");
      ucsdParam.setValue(10);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu12");
      ucsdParam.setValue(10);
      ucsdParam = ivsUcsd.addNewParameter();
      ucsdParam.setKey("Tu13");
      ucsdParam.setValue(240);

      // get external measurements
      IvsDelays extDelays = getMeasurementIvsDelays().getIvsDelays();
      xmldoc.getAllParameters(IvsDelaysConstants.TAG_IVS_UCSD, extDelays);

      // calculated parameters
      IvsDelaysHelper.setUCSDComposite( xmldoc, isDirectCall);

      // comment
      String title = "Performanace Recommendations for ISSI Voice Services";
      String comment = "Performanace specifications based on TIA-102.CACB, April 2007.";
      if( isDirectCall) {
         comment += " Direct Call.";
      }
      else {
         comment += " Availability Check.";
      }
      xmldoc.setIvsStatusComment( title, comment);
      return xmldoc;
   }

   public static XmlIvsDelays generateIvsUmtd() throws Exception
   {
      XmlIvsDelays xmldoc = new XmlIvsDelays();
      IvsDelays ivsDelays = xmldoc.getIvsDelays();

      IvsUmtd ivsUmtd = ivsDelays.addNewIvsUmtd();
      ivsUmtd.setTitle("Performance Specifications for SU-to-SU Call Message Transfer Delay(UMTD)");
      ivsUmtd.setDiagram("gfx/diagrams/IVS-UMTD.JPG");

      // measured parameters
      gov.nist.p25.issi.xmlconfig.IvsDelaysDocument.IvsDelays.IvsUmtd.Parameter umtdParam;
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad1");
      umtdParam.setValue(200);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad2");
      umtdParam.setValue(10);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad3");
      umtdParam.setValue(10);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad4");
      umtdParam.setValue(170);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad5");
      umtdParam.setValue(200);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad6");
      umtdParam.setValue(10);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad7");
      umtdParam.setValue(10);
      umtdParam = ivsUmtd.addNewParameter();
      umtdParam.setKey("Tu_ad8");
      umtdParam.setValue(170);

      // get external measurements
      IvsDelays extDelays = getMeasurementIvsDelays().getIvsDelays();
      xmldoc.getAllParameters(IvsDelaysConstants.TAG_IVS_UMTD, extDelays);

      // calculated parameters
      IvsDelaysHelper.setUMTDComposite( xmldoc);

      // comment
      String title = "Performanace Recommendations for ISSI Voice Services";
      String comment = "Performanace specifications based on TIA-102.CACB, April 2007.";
      xmldoc.setIvsStatusComment( title, comment);
      return xmldoc;
   }

   //=========================================================================
   public static void main(String[] args) throws Exception
   {
      XmlIvsDelays xmldoc;

      // confirmed group call
      xmldoc = XmlIvsDelaysSpec.generateIvsGcsd( true);
      xmldoc.saveIvsDelays("xml/spec-ivs-gcsd.xml");

      xmldoc = XmlIvsDelaysSpec.generateIvsGmtd();
      xmldoc.saveIvsDelays("xml/spec-ivs-gmtd.xml");

      // Direct Call
      xmldoc = XmlIvsDelaysSpec.generateIvsUcsd( true);
      xmldoc.saveIvsDelays("xml/spec-ivs-ucsd.xml");

      xmldoc = XmlIvsDelaysSpec.generateIvsUmtd();
      xmldoc.saveIvsDelays("xml/spec-ivs-umtd.xml");
   }
}
