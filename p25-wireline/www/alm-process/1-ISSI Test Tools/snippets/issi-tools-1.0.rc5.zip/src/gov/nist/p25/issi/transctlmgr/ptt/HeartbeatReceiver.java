//
package gov.nist.p25.issi.transctlmgr.ptt;

import gov.nist.p25.issi.ISSITimer;
import gov.nist.p25.issi.p25payload.*;

import java.util.*;
import org.apache.log4j.Logger;

/**
 * This class handles incoming HEARTBEAT and other PTT packets related to
 * mute/unmute functions. This class also sends PTT MUTE/UNMUTE packets.
 */
public class HeartbeatReceiver {

   /***************************************************************************
    * Variables
    **************************************************************************/

   private HeartbeatListener heartbeatListener;
   
   private String sessionType;

   /** The owning PTT session. */
   private PttSessionInterface pttSession = null;

   
   /** The mute timer task. */
   ReceiveHeartbeatsTimeoutTask receiveHeartbeatsTimeoutTask = null;

   /** The logger for this class. */
   private static Logger logger = Logger.getLogger(HeartbeatReceiver.class);

   /** The collection of packet types this class handles. */
   private static HashSet<PacketType> handledPacketTypes = null;

   static {
      handledPacketTypes = new HashSet<PacketType>();
      handledPacketTypes.add(PacketType.HEARTBEAT);
      handledPacketTypes.add(PacketType.HEARTBEAT_QUERY);
   }

   /***************************************************************************
    * Constructors
    **************************************************************************/
   /**
    * Construct a connection hearbeat receiver (this is not the same as a MUTE
    * transmission heartbeat receiver).
    * 
    * @param pttSession
    *            The owning PTT session.
    */
   HeartbeatReceiver(PttSessionInterface pttSession) {
      logger.debug("creating new Heartbeat receiver " + pttSession.getSessionType());
      this.pttSession = pttSession;
      this.sessionType = pttSession.getSessionType();

      // Set timeout for receiving connection maintenance heartbeats
      receiveHeartbeatsTimeoutTask = new ReceiveHeartbeatsTimeoutTask();
      ISSITimer.getTimer().schedule(receiveHeartbeatsTimeoutTask,
            TimerValues.THEARTBEAT * 4); // See TIA-109.BACA
                                         // Section 7.6.10
   }

   /***************************************************************************
    * Methods
    **************************************************************************/

   /**
    * Handle incoming PTT packets especially HEARTBEAT packets. Check all
    * packets for correct M-bit.
    * 
    * @param p25Payload
    *            The incoming PTT packet.
    */
   void handlePttPacket(P25Payload p25Payload) {
      
      ISSIPacketType issiPacketType = p25Payload.getISSIPacketType();
      PacketType packetType = issiPacketType.getPacketType();
      if (packetType == PacketType.HEARTBEAT) {

         if (heartbeatListener != null)
            heartbeatListener.receivedHeartbeat(issiPacketType.getTransmissionSequenceNumber());
         else 
            logger.debug("No heartbeat listener ");

         if (receiveHeartbeatsTimeoutTask != null) {
            // Reset the timer. TODO: Note that in TIA-109.BACA Section
            // 7.6.10 requires us to reset using the value contained in
            // the Interval field of the message. Here, however, we
            // simply reset to the default.
            receiveHeartbeatsTimeoutTask.cancel();
            receiveHeartbeatsTimeoutTask = new ReceiveHeartbeatsTimeoutTask();
            ISSITimer.getTimer().schedule(receiveHeartbeatsTimeoutTask,
                  TimerValues.THEARTBEAT * 4);
            if (logger.isDebugEnabled())
               logger.debug(sessionType + " received HEARTBEAT.  Resetting heartbeat timeout");
         }

      } else if (packetType == PacketType.HEARTBEAT_QUERY) {

         if (heartbeatListener != null)
            heartbeatListener.receivedHeartbeatQuery(pttSession,
                  issiPacketType.getTransmissionSequenceNumber());

         // Reset the timer. TODO: Note that in TIA-109.BACA Section
         // 7.6.10 requires us to reset using the value contained in
         // the Interval field of the message. Here, however, we
         // simply reset to the default.
         // @mranga -- the interval field is set to 0. This is a bug
         // we need to fix.
         receiveHeartbeatsTimeoutTask.cancel();
         receiveHeartbeatsTimeoutTask = new ReceiveHeartbeatsTimeoutTask();
         ISSITimer.getTimer().schedule(receiveHeartbeatsTimeoutTask,
               TimerValues.THEARTBEAT * 4);

         if (logger.isDebugEnabled())
            logger.debug(pttSession.getSessionType() + " port = " + pttSession.getMyRtpRecvPort()
                  + " received HEARTBEAT QUERY.  Sending heartbeat");

         // Now respond with a HEARTBEAT
         if ( pttSession.getHeartbeatTransmitter() != null) {
            pttSession.getHeartbeatTransmitter().sendHeartbeat();
         } else {
            logger.debug("HeartbeatReceiver: cannot send heartbeat - heartbeat transmitter is null");
         }
      }
   }

   /**
    * Checks if this class handles this packet type.
    * 
    * @param packetType
    *            The packet type to be handled.
    * @return True if handled, false otherwise.
    */
   boolean isPacketTypeHandled(PacketType packetType) {
      return handledPacketTypes.contains(packetType);
   }
   
   /**
    * @param heartbeatTimeoutListener
    *            the heartbeatTimeoutListener to set
    */
   public void setHeartbeatListener(HeartbeatListener heartbeatListener) {
      logger.debug("set heartbeat listener " + this.pttSession.getSessionType());
      this.heartbeatListener = heartbeatListener;
   }

   /***************************************************************************
    * Inner Classes
    **************************************************************************/

   /**
    * This class sets the timeout for receiving CONNECTION MAINTENANCE
    * heartbeats. This class does NOT handle MUTE TRANSMISSION heartbeats.
    * 
    * @see TIA-109.BACA Section 7.6.10
    */
   class ReceiveHeartbeatsTimeoutTask extends TimerTask {

      // If we get here we have timed out waiting for a (connection
      // maintenance) heartbeat.  Note that in Section 7.6.10 of TIA-102.BACA,
      // an RFSS MAY tear down the call segment if it reaches this timeout.
      // Here, however, we simply print a statement that we have reached
      // the timeout and allow other timeouts to terminate the session.
      public void run() {
         if (pttSession.getMyRtpRecvPort() != 0) {
            if (logger.isDebugEnabled())
               logger.debug(sessionType + " REACHED TIMEOUT waiting for HEARTBEAT " + this);
            if (heartbeatListener != null)
               heartbeatListener.heartbeatTimeout(pttSession);
         }
      }
   }
}
