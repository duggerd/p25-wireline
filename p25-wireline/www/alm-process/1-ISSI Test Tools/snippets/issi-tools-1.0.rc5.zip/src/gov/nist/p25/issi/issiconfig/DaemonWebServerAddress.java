//
package gov.nist.p25.issi.issiconfig;

import java.util.Collection;
import java.util.HashSet;

/**
 * This class represents a machine on which an emulator or packet monitor
 * (or both) runs. The emulator is signaled using http.
 */
public class DaemonWebServerAddress implements WebServerAddress {
   private String name;
   private String ipAddress;
   private int httpPort;
   private boolean isMapped;
   private boolean testerService;
   private boolean packetMonitorService;
   private HashSet<String> refId = new HashSet<String>();

   // accessors
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }

   public String getIpAddress() {
      return ipAddress;
   }
   public void setIpAddress(String ipAddress) {
      this.ipAddress = ipAddress;
   }

   public int getHttpPort() {
      return httpPort;
   }
   public void setHttpPort(int httpPort) {
      this.httpPort = httpPort;
   }

   public boolean isMapped() {
      return isMapped;
   }
   public void setMapped(boolean isMapped) {
      this.isMapped = isMapped;
   }

   public boolean isTesterService() {
      return testerService;
   }
   public void setTesterService(boolean testerService) {
      this.testerService = testerService;
   }

   public boolean isPacketMonitorService() {
      return packetMonitorService;
   }
   public void setPacketMonitorService(boolean packetMonitorService) {
      this.packetMonitorService = packetMonitorService;
   }

   public Collection<String> getRefIds() {
      return refId;
   }
   public void addRefId(String tag) {
      refId.add(tag);
   }
   public void removeRefId(String tag) {
      refId.remove(tag);
   }
   
   // constructor
   public DaemonWebServerAddress(String name, String ipAddress, int port,
      boolean isTester, boolean isMonitor) {
      this.ipAddress = ipAddress;
      this.httpPort = port;
      this.name = name;
      this.testerService = isTester;
      this.packetMonitorService = isMonitor;
   }

   public String getHttpControlUrl() {
      return "http://" + ipAddress + ":" + httpPort + "/diets/controller";
   }
   
   @Override
   public String toString() {
      String retval = "<diets-daemon\n" +
         "\tipAddress=\"" + ipAddress + "\"\n" +
         "\thttpPort=\"" + httpPort + "\"\n" +
         "\tname=\"" + name + "\"\n" +
         "\tisConformanceTester=\"" + isTesterService()+ "\"\n" +
         "\tisPacketMonitor=\"" + isPacketMonitorService() + "\"\n" +
         ">\n";
      for ( String tag: refId) {
         retval += "<refid\n" + "\tid=\"" + tag + "\"\n" + "/>\n";
      }
      retval += "</diets-daemon>\n";
      return retval;
   }
}
