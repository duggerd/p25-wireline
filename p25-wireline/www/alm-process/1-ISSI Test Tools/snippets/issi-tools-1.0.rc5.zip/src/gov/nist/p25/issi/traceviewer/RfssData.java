//
package gov.nist.p25.issi.traceviewer;

import gov.nist.p25.issi.issiconfig.RfssConfig;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * This class implements an RFSS node and used to display both
 * SIP and PTT traces.
 * 
 */
public class RfssData implements Comparable<RfssData> {

   /** Radical name. */
   private String id;   
   
   /** IP Address. */
   private String address;
   
   /** Incoming SIP or PTT (RTP) ports. */
   private List<String> ports;

   /** x coordinate. */
   private int x;

   /** y coordinate. */
   private int y;

   /** Size of RFSS image. */
   private Dimension dimension;

   /** Determines if this RFSS is selected on the screen. */
   private boolean selected = false;

   /** The time we receive the RFSS data. */
   private long time;
   private int counter;
   
   /** The rfss configuration if there is one attached to this **/
   private RfssConfig rfssConfig;
   
   /** A set of Sessions retrieved at runtime. */
   private HashSet<PttSessionInfo> pttSessionInfo;


   // accessors
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }

   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }

   public List<String> getPorts() {
      return ports;
   }
   public void setPorts(List<String> ports) {
      this.ports = ports;
   }

   public Dimension getDimension() {
      return dimension;
   }
   public void setDimension(Dimension dimension) {
      this.dimension = dimension;
   }

   public boolean isSelected() {
      return selected;
   }
   public boolean getSelected() {
      return selected;
   }
   public void setSelected(boolean selected) {
      this.selected = selected;
   }

   public long getTime() {
      return time;
   }
   public void setTime(long time, int counter) {
      this.time = time;
      this.counter = counter;
   }

   public int getX() {
      return x;
   }
   public void setX(int x) {
      this.x = x;
   }

   public int getY() {
      return y;
   }
   public void setY(int y) {
      this.y = y;
   }

   public RfssConfig getRfssConfig() {
      return rfssConfig;
   }
   public void setRfssConfig(RfssConfig rfssConfig) {
      this.rfssConfig = rfssConfig;
   }

   public HashSet<PttSessionInfo> getPttSessionInfo() {
      return pttSessionInfo;
   }
   public void setPttSessionInfo(HashSet<PttSessionInfo> pttSessionInfo) {
      this.pttSessionInfo = pttSessionInfo;
   }

   // constructors
   public RfssData(String id, String address, String port) {
      setPorts( new ArrayList<String>());
      setPttSessionInfo( new HashSet<PttSessionInfo>());
      setId(id);
      setAddress(address);
      addPort(port);      
   }

   /**
    * Add a port to the list of ports that have been seen at this Rfss.
    * Note that this is a small list so linear search is fine.
    * 
    * @param portToAdd
    */
   public void addPort(String portToAdd) {
      for ( String p: ports) {
         if (p.equals(portToAdd)) return;
      }
      ports.add(portToAdd);      
   }

   public int compareTo(RfssData rfssData) {
      if (rfssData.getTime() == getTime()) {
         return counter < rfssData.counter? -1 : 1;
      } else {
         return rfssData.getTime() < getTime() ? 1 : -1;
      }
   }
}
