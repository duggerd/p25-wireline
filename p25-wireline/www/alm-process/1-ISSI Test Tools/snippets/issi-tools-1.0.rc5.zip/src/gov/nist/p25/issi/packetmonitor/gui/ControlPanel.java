//
package gov.nist.p25.issi.packetmonitor.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.apache.log4j.Logger;

/**
 * Panel where the control buttons go. This class also talks to the "back end".
 * 
 */
public class ControlPanel extends JPanel implements ActionListener {
   
   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ControlPanel.class);

   private JFrame packetMonitor;
   private MessageInformationPanel msgInfoPanel;
   private PacketMonitorController packetMonitorController;
   private MeasurementTable measurementTable = null;

   private JButton startCaptureButton;
   private JButton fetchTraceButton;
   private JButton evaluateButton;   
   
   // constructor
   public ControlPanel(JFrame packetMonitor, MessageInformationPanel msgInfoPanel,
         PacketMonitorController packetMonitorController, boolean drawTrace)
         throws Exception {

      this.packetMonitor = packetMonitor;
      this.msgInfoPanel = msgInfoPanel;
      this.packetMonitorController = packetMonitorController;
      
      if (packetMonitorController instanceof RemotePacketMonitorController){
         startCaptureButton = new JButton("Start Packet Capture");
         startCaptureButton.addActionListener(this);
      }
      
      fetchTraceButton = new JButton("Fetch Trace");
      evaluateButton = new JButton("Evaluate Trace");

      fetchTraceButton.addActionListener(this);
      evaluateButton.addActionListener(this);
      
      if (packetMonitorController instanceof RemotePacketMonitorController) {
         super.add(startCaptureButton);
         super.add(fetchTraceButton);
         super.add(evaluateButton);
      } else {      
         super.add(evaluateButton);
         fetchTraceButton.doClick();
      }      
   }   
   
   
   public void getSipPttTraces() throws Exception {
      
      boolean errorFlag = packetMonitorController.fetchErrorFlag();
      //System.out.println("getSipPttTraces(): errorFlag="+errorFlag);
      
      if (errorFlag) {
         String errorCause = this.packetMonitorController.fetchErrorString();
         JOptionPane.showConfirmDialog(null, errorCause,
            "Capture Error",
            JOptionPane.ERROR_MESSAGE);
      }
      else {
         String sipTraces = packetMonitorController.fetchSipTraces();
         String pttTraces = packetMonitorController.fetchPttTraces();        
         String result = packetMonitorController.fetchResult();
         //System.out.println("setData(): result="+result);
         
         msgInfoPanel.renderSipPttTraces( sipTraces, pttTraces, null);
         if (measurementTable == null)
            measurementTable = new MeasurementTable(packetMonitor);
         measurementTable.setData(result);
      }
   }

   // implementation of ActionListener
   //--------------------------------------------------------------------
   public void actionPerformed(ActionEvent ae) {
      try {
         if (ae.getSource() == startCaptureButton) {
            packetMonitorController.startCapture();
         }
         else if (ae.getSource() == evaluateButton ) {
            // check the traces and evaluate if they are available
            if (measurementTable == null)
               measurementTable = new MeasurementTable(packetMonitor);
            measurementTable.showTable();
         }
         else if (ae.getSource() == fetchTraceButton) {
            getSipPttTraces();
         }
      }
      catch (Exception ex) {
         logger.error("Error communicating with the monitor", ex);
         JOptionPane.showMessageDialog(null,
            "Error communicating with the monitor",
            "Unexpected Error",
            JOptionPane.ERROR_MESSAGE);
      }
   }
}
