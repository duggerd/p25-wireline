//
package gov.nist.p25.issi.transctlmgr.ptt;

/**
 * Tagging interface for State transition.
 *
 */
public interface PttStateTransition {

}
