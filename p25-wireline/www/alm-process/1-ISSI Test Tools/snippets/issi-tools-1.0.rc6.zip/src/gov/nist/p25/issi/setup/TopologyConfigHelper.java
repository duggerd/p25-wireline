//
package gov.nist.p25.issi.setup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

import org.apache.log4j.Logger;

/**
 * Topology Configuration Helper.
 */
public class TopologyConfigHelper
{
   private static Logger logger = Logger.getLogger(TopologyConfigHelper.class);

   public static void showln(String s) { System.out.println(s); }

   private List<RfssConfigSetup> rfssList;
   private List<GroupConfigSetup> gcsList;
   private List<SuConfigSetup> scsList;
   private List<String> nameList;
   private Map<String,String> nameMap;

   // accessor
   public List<RfssConfigSetup> getRfssConfigSetupList() {
      return rfssList;
   }
   public List<GroupConfigSetup> getGroupConfigSetupList() {
      return gcsList;
   }
   public List<SuConfigSetup> getSuConfigSetupList() {
      return scsList;
   }
   public List<String> getRfssNameList() {
      return nameList;
   }
   public Map<String,String> getRfssNameMap()
   {
      return nameMap;
   }

   // constructor
   public TopologyConfigHelper()
   {
   }

   public List<String> getRfssNameList(TopologyConfig topologyConfig)
   {
      nameList = new ArrayList<String>();
      for (RfssConfig rfssConfig: topologyConfig.getRfssConfigurations())
      {
         String rname = rfssConfig.getRfssName();
         nameList.add( rname);
      }
      return nameList;
   }

   public void buildSetupLists(TopologyConfig topologyConfig)
   {
      HashMap<String,String> nodesMap = new HashMap<String, String>();
      String parent;
      String node;
 
      nameList = new ArrayList<String>();
      rfssList = new ArrayList<RfssConfigSetup>();
      scsList = new ArrayList<SuConfigSetup>();
      gcsList = new ArrayList<GroupConfigSetup>();

      // RFSS Configuration
      for (RfssConfig rfssConfig: topologyConfig.getRfssConfigurations())
      {
         String ipAddress = rfssConfig.getIpAddress();
         int port = rfssConfig.getSipPort();
         String rname = rfssConfig.getRfssName();
         int rid = rfssConfig.getRfssId();
         int wacnId = rfssConfig.getWacnId();
         int systemId = rfssConfig.getSystemId();
         boolean emulated = rfssConfig.isEmulated();

         RfssConfigSetup ep = new RfssConfigSetup(ipAddress,port,rname,
                  rid,systemId,wacnId,emulated);
         ep.setReference( rfssConfig);
         // for swapping
         ep.setTopologyConfig( topologyConfig);

         rfssList.add( ep);
         nameList.add( rname);
         nodesMap.put( rname, "RfssConfig:"+rid);
      }

      // GROUP Configuration
      for (GroupConfig groupConfig: topologyConfig.getGroupConfigurations())
      {
         String rname = groupConfig.getHomeRfss().getRfssName();
         parent = nodesMap.get( rname);
         if( parent==null) continue;

         String gname = groupConfig.getGroupName();
         int gid = groupConfig.getGroupId();
         //int gwacnId =  groupConfig.getSysConfig().getWacnId();
         //int gsystemId = groupConfig.getSysConfig().getSystemId();
         String grfss = groupConfig.getHomeRfss().getRfssName();

         // delay instantiation
         nodesMap.put( gname, "GroupConfig:"+gid);

         boolean firstName = true;
         StringBuffer gsu = new StringBuffer();
         for (Iterator<SuConfig> it= groupConfig.getSubscribers(); it.hasNext();)
         {
            SuConfig suConfig = it.next();

            String sname = suConfig.getSuName();
            int sid = suConfig.getSuId();
            int swacnId = suConfig.getWacnId();
            int ssystemId = suConfig.getSystemId();
            String homeRfss = suConfig.getHomeRfss().getRfssName();
            int homeRfssId = suConfig.getHomeRfss().getRfssId();
            String servRfss = suConfig.getInitialServingRfss().getRfssName();
            boolean emulated = suConfig.isEmulated();

            SuConfigSetup scs = new SuConfigSetup(sname,sid,homeRfss,servRfss,
                  homeRfssId,ssystemId,swacnId,emulated);
            scs.setReference( suConfig);
            scsList.add( scs);

            // group-su
            if( firstName) {
               firstName = false;
            } else {
               gsu.append(",");
            }
            gsu.append(sname);
            nodesMap.put( sname, "SuConfig:"+sid);
         }

         GroupConfigSetup gcs = new GroupConfigSetup(gname,gid,grfss,gsu.toString());
         gcs.setReference( groupConfig);
         gcsList.add( gcs);
      }

      // SU Configuration
      for (SuConfig suConfig: topologyConfig.getSuConfigurations())
      {
         String rname = suConfig.getHomeRfss().getRfssName();
         parent = nodesMap.get( rname);
         if( parent==null) continue;

         String sname = suConfig.getSuName();

         // check if it is in group
         node = nodesMap.get( sname);
         if( node != null) continue;

         int sid = suConfig.getSuId();
         int swacnId = suConfig.getWacnId();
         int ssystemId = suConfig.getSystemId();
         String homeRfss = suConfig.getHomeRfss().getRfssName();
         int homeRfssId = suConfig.getHomeRfss().getRfssId();
         String servRfss = suConfig.getInitialServingRfss().getRfssName();
         boolean emulated = suConfig.isEmulated();

         SuConfigSetup scs = new SuConfigSetup(sname,sid,homeRfss,servRfss,
               homeRfssId,ssystemId,swacnId,emulated);
         scs.setReference( suConfig);
         scsList.add( scs);

         nodesMap.put( rname, "SuConfig:"+sid);
      }
   }

   //------------------------------------------------------------------------
   //------------------------------------------------------------------------
   public Map<String,String> getRfssNameMap( List<RfssConfigSetup> rfssList)
   {
      //showln("getRfssNameMap: rfssList="+rfssList.size());
      Map<String,String> map = new HashMap<String,String>();

      // build RfssName changes map
      if( rfssList != null)
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         RfssConfig rfssConfig = (RfssConfig)rfssSetup.getReference();
         String rname = rfssConfig.getRfssName();

         String newRfssName = rfssSetup.getName();
         if( !rname.equals( newRfssName)) {
            map.put( new String(rname), newRfssName);
         }
      }
      return map;
   }

   //------------------------------------------------------------------------
   public boolean reconcile( List<RfssConfigSetup> rfssList,
      List<GroupConfigSetup> gcsList, List<SuConfigSetup> scsList) 
      throws IllegalArgumentException
   {
      //showln("rfssList="+rfssList.size());
      //showln("gcsList="+gcsList.size());
      //showln("scsList="+scsList.size());

      // process changes in RfssConfig
      if( rfssList != null)
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         RfssConfig rfssConfig = (RfssConfig)rfssSetup.getReference();
         /*
         String rname = rfssConfig.getRfssName();
         String ipAddress = rfssConfig.getIpAddress();
         int port = rfssConfig.getSipPort();
         int rid = rfssConfig.getRfssId();
         int wacnId = rfssConfig.getWacnId();
         int systemId = rfssConfig.getSystemId();
         boolean emulated = rfssConfig.isEmulated();
          */
         rfssConfig.setRfssName( rfssSetup.getName());
         rfssConfig.setIpAddress( rfssSetup.getIpAddress());
         rfssConfig.setSipPort( rfssSetup.getPort());
         rfssConfig.setRfssId( rfssSetup.getId());
         rfssConfig.setWacnId( rfssSetup.getWacnId());
         rfssConfig.setSystemId( rfssSetup.getSystemId());
         rfssConfig.setEmulated( rfssSetup.getEmulated());
      }

      if( gcsList != null)
      for( GroupConfigSetup gcsSetup: gcsList)
      {
         GroupConfig groupConfig = (GroupConfig)gcsSetup.getReference();

         String gname = groupConfig.getGroupName();
         int gid = groupConfig.getGroupId();
         int gwacnId =  groupConfig.getSysConfig().getWacnId();
         int gsystemId = groupConfig.getSysConfig().getSystemId();
         String grfss = groupConfig.getHomeRfss().getRfssName();

         logger.debug("GROUP-homeRfss="+grfss);
         //showln("GROUP-gwacnId="+gwacnId);
         //showln("GROUP-gsystemId="+gsystemId);

         // only homeRfss
         groupConfig.getHomeRfss().setRfssName( gcsSetup.getHomeRfssName());
      }

      if( scsList != null)
      for( SuConfigSetup scsSetup: scsList)
      {
         SuConfig suConfig = (SuConfig)scsSetup.getReference();
         int sid = suConfig.getSuId();
         int swacnId = suConfig.getWacnId();
         int ssystemId = suConfig.getSystemId();
         String homeRfss = suConfig.getHomeRfss().getRfssName();
         int homeRfssId = suConfig.getHomeRfss().getRfssId();
         String servRfss = suConfig.getInitialServingRfss().getRfssName();
         int servRfssId = suConfig.getInitialServingRfss().getRfssId();
         boolean emulated = suConfig.isEmulated();

         logger.debug("SU-homeRfss="+homeRfss);
         logger.debug("SU-servRfss="+servRfss);

         // only SuId, homeRfss and ServingRfss    
         suConfig.setSuId( scsSetup.getId());
         suConfig.getHomeRfss().setRfssName( scsSetup.getHomeRfssName());
         suConfig.getInitialServingRfss().setRfssName( scsSetup.getServingRfssName());
      }
      return true;
   }

   //------------------------------------------------------------------------
   public boolean checkUniqueness( List<RfssConfigSetup> rfssList)
      throws IllegalArgumentException
   {
      HashMap<String,RfssConfigSetup> ipmap = new HashMap<String,RfssConfigSetup>();
      HashMap<String,RfssConfigSetup> idmap = new HashMap<String,RfssConfigSetup>();
      logger.debug("****** checkUniqueness(): START...");
            
      // verify the setup data
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         String ipAddress = rfssSetup.getIpAddress();
         int port = rfssSetup.getPort();

         // ipAddress:port must be unique
         String key = ipAddress +":" + port;
         RfssConfigSetup xrfssSetup = ipmap.get( key);
         if( xrfssSetup == null) {
            ipmap.put( key, rfssSetup);
         } else {
            String msg = "Duplicate IP:port in RfssConfigSetup: "+key;
            logger.debug("checkUniqueness(): "+msg);
            throw new IllegalArgumentException(msg);
         }

         // idString must be unique
	 String idString = rfssSetup.getIdString();
         xrfssSetup = ipmap.get( idString);
         if( xrfssSetup == null) {
            idmap.put( idString, rfssSetup);
         } else {
            String msg = "Duplicate ID in RfssConfigSetup: "+idString;
            logger.debug("checkUniqueness(): "+msg);
            throw new IllegalArgumentException(msg);
         }
      }

      ipmap.clear();
      // rfssName must be unique
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         String rfssName = rfssSetup.getName();
         RfssConfigSetup xrfssSetup = ipmap.get( rfssName);
         if( xrfssSetup == null) {
            ipmap.put( rfssName, rfssSetup);
         } else {
            String msg = "Duplicate rfssName in RfssConfigSetup: "+rfssName;
            logger.debug("checkUniqueness(): "+msg);
            throw new IllegalArgumentException(msg);
         }
      }

      idmap.clear();
      ipmap.clear();
      logger.debug("****** checkUniqueness(): DONE...");
      return true;
   }

   //------------------------------------------------------------------------
   public boolean reconcileTesterConfiguration( ISSITesterConfiguration testerConfig,
      List<RfssConfigSetup> rfssList)
      throws IllegalArgumentException
   {
      // build name map
      nameMap = getRfssNameMap( rfssList);

      // verify setup data first
      checkUniqueness( rfssList);

      // this will modify the RfssConfig stored in the reference
      HashMap<String,RfssConfigSetup> rfssIpMap = new HashMap<String,RfssConfigSetup>();
      HashMap<String,RfssConfigSetup> rfssNameMap = new HashMap<String,RfssConfigSetup>();

      // process changes in RfssConfig
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         RfssConfig rfssConfig = (RfssConfig)rfssSetup.getReference();
         // save a copy
         String rfssName = rfssConfig.getRfssName();
         String ipAddress = rfssConfig.getIpAddress();
         int port = rfssConfig.getSipPort();
         /*
         int rid = rfssConfig.getRfssId();
         int wacnId = rfssConfig.getWacnId();
         int systemId = rfssConfig.getSystemId();
          */
         boolean emulated = rfssConfig.isEmulated();

         // it is safe to update here
         rfssConfig.setRfssName( rfssSetup.getName());
         rfssConfig.setIpAddress( rfssSetup.getIpAddress());
         rfssConfig.setSipPort( rfssSetup.getPort());
         rfssConfig.setRfssId( rfssSetup.getId());
         rfssConfig.setWacnId( rfssSetup.getWacnId());
         rfssConfig.setSystemId( rfssSetup.getSystemId());
         rfssConfig.setEmulated( rfssSetup.getEmulated());

         String newRfssName = rfssSetup.getName();
         String newIpAddress = rfssSetup.getIpAddress();
         int newPort = rfssSetup.getPort();
         boolean newEmulated = rfssSetup.getEmulated();

         // detect rfssName changes
         //---------------------------------
         if( !rfssName.equals( newRfssName)) {
            logger.debug("reconcileTesterConfig: rfssName="+rfssName+" newRfssName="+newRfssName);
            rfssNameMap.put( rfssName, rfssSetup);
         }
         //---------------------------------
         if( !ipAddress.equals( newIpAddress) ) { 
            logger.debug("reconcileTesterConfig: ipAddress="+ipAddress+" newIpAddress="+newIpAddress);
            rfssIpMap.put( ipAddress, rfssSetup);
         }
         else if (port != newPort) {
            // for emulator
            logger.debug("reconcileTesterConfig: EM-ipAddress="+ipAddress);
            rfssIpMap.put( ipAddress+":"+port, rfssSetup);
         }
         if( emulated != newEmulated) {
            logger.debug("reconcileTesterConfig: emulated="+emulated+" newEmulated="+newEmulated);
            rfssIpMap.put( ipAddress, rfssSetup);
         }
      }  // rfssList

      logger.debug("reconcileTesterConfig: rfssIpMap.size="+rfssIpMap.size());
      logger.debug("reconcileTesterConfig: rfssNameMap.size="+rfssNameMap.size());

      // fixup in one-pass 
      //--------------------------------------------------------------------
      for( DaemonWebServerAddress dwsa: testerConfig.getDaemonAddresses()) {
//07/06/2009
         // clear isConformanceTester
	 dwsa.setTesterService( false);

         String ipAddress = dwsa.getIpAddress();
         RfssConfigSetup  rfssSetup = rfssIpMap.get( ipAddress);
         if( rfssSetup != null) {
            logger.debug("reconcileTesterConfig: ipAddress="+ipAddress);
            // fixup ipAddress
            dwsa.setIpAddress( rfssSetup.getIpAddress());

            // fixup isConformanceTester based on RFSS emulated 
            //dwsa.setTesterService( rfssSetup.getEmulated());
            //logger.debug("reconcileTesterConfig(1): FIXUP isConformanceTester="+
            //   rfssSetup.getName()+":"+rfssSetup.getEmulated());
         }

         HashSet<String> tagSet = new HashSet<String>(dwsa.getRefIds());
         for( String tag: tagSet) {
            logger.debug("reconcileTesterConfig: tag="+tag);
            String[] parts = tag.split("\\.");
            if( parts.length==2) {
               rfssSetup = rfssNameMap.get(parts[0]);
               if( rfssSetup != null) {
                  dwsa.removeRefId( tag);
                  String newTag = rfssSetup.getName() +"." +parts[1];
                  logger.debug("reconcileTesterConfig: newTag="+newTag);
                  dwsa.addRefId( newTag);

//07/06/2009
                  //logger.debug("reconcileTesterConfig(2): FIXUP isConformanceTester="+
                  //   rfssSetup.getName()+":"+rfssSetup.getEmulated());
                  //dwsa.setTesterService( rfssSetup.getEmulated());
               }
            }
         }

	 // fixup isConformanceTester on a separate loop
         for( RfssConfigSetup xrfssSetup: rfssList)
         {
            String xipAddress = xrfssSetup.getIpAddress();
            if( xipAddress.equals( dwsa.getIpAddress())) {
               logger.debug("reconcileTesterConfig(3): FIXUP isConformanceTester="+
                  xrfssSetup.getName()+":"+xrfssSetup.getEmulated());
               dwsa.setTesterService( xrfssSetup.getEmulated());
            }
         }
	 
      }  // all-dwsa

      rfssIpMap.clear();
      rfssNameMap.clear();
      logger.debug("reconcileTesterConfig: done...");
      return true;
   }

   //------------------------------------------------------------------------
   public void reconcileAll( ISSITesterConfiguration testerConfig,
      List<RfssConfigSetup> rfssList,
      List<GroupConfigSetup> gcsList, List<SuConfigSetup> scsList) 
      throws IllegalArgumentException
   {
      reconcileTesterConfiguration( testerConfig, rfssList);
      reconcile( rfssList, gcsList, scsList);
   }

   //------------------------------------------------------------------------
   public void reconfigureDaemonTesterService(TopologyConfig topologyConfig,
      ISSITesterConfiguration testerConfig)
   {
      // when user runs a test(3 RFSS), switch to different test(2 RFSS)
      // in the Setup Test,  select Cancel option, then Generate Trace
      // the previous active Daemons needed to be reconfigue(turn off)
      logger.debug("reconfigureDaemonTesterService(): START...");

      // deduce the isConformanceTester from topology
      // it may also need to look at the emulated flag
      List<String> rfssList = getRfssNameList(topologyConfig);
      for( DaemonWebServerAddress dwsa: testerConfig.getDaemonAddresses())
      {
         // clear isConformanceTester
	 dwsa.setTesterService( false);

	 // RFSS Configuration
         for (RfssConfig rfssConfig: topologyConfig.getRfssConfigurations())
         {
            String ipAddress = rfssConfig.getIpAddress();
            logger.debug("reconfigureDaemonTesterService: checking "+ipAddress);
            if( ipAddress.equals( dwsa.getIpAddress())) {
               logger.debug("reconfigureDaemonTesterService: FIXUP isConformanceTester "+
                  ipAddress+":"+rfssConfig.getEmulated());
	       dwsa.setTesterService( rfssConfig.getEmulated());
            }
         }

         /*** old code
         // deduce the isConformanceTester from the refid only
         HashSet<String> tagSet = new HashSet<String>(dwsa.getRefIds());
         for( String tag: tagSet) {
            logger.debug("reconfigureDaemonTesterService: tag="+tag);
            String[] parts = tag.split("\\.");
            if( parts.length==2) {
               for( String rname: rfssList) {
                  if( rname.equals( parts[0])) {
                     logger.debug("reconfigureDaemonTesterService: matched="+rname);
		     // set isCOnformanceTester
                     dwsa.setTesterService(true);
                  }
               }
            }
         }
	  ***/
      }
      logger.debug("reconfigureDaemonTesterService(): DONE...");
   }
   //------------------------------------------------------------------------
}
