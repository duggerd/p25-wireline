//
package gov.nist.p25.common.swing.transform;

import java.awt.Graphics;

public interface GraphicsInterface
{
   public void doGraphics(Graphics g);
}
 
