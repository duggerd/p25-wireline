//
package gov.nist.p25.issi.rfss;

import java.util.EventObject;

import javax.sip.RequestEvent;

/**
 * Call control request event base class. This is the class that the Su sees.
 * 
 */
public abstract class CallControlRequestEvent extends EventObject {
   private static final long serialVersionUID = -1L;

   private RequestEvent requestEvent;

   public CallControlRequestEvent(UnitToUnitCall call, RequestEvent requestEvent) {
      super(call);
      this.requestEvent = requestEvent;
   }

   public RequestEvent getRequestEvent() {
      return requestEvent;
   }

   public UnitToUnitCall getCallSegment() {
      return (UnitToUnitCall) getSource();
   }
}
