/* This software was developed by employees of the National Institute of
 * Standards and Technology (NIST), an agency of the Federal Government.
 * Pursuant to title 15 United States Code Section 105, works of NIST
 * employees are not subject to copyright protection in the United States
 * and are considered to be in the public domain.  As a result, a formal
 * license is not needed to use the software.
 * 
 * The ISSI Emulator is provided by NIST as a service and is expressly
 * provided "AS IS".  NIST MAKES NO WARRANTY OF ANY KIND, EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT
 * AND DATA ACCURACY.  NIST does not warrant or make any representations
 * regarding the use of the software or the results thereof including, but
 * not limited to, the correctness, accuracy, reliability or usefulness of
 * the software.
 * 
 * Permission to use this software is contingent upon your acceptance
 * of the terms of this agreement.
 */
package gov.nist.p25.issi.transctlmgr.ptt;

/**
 * This class implements ISSI link types.
 * 
 * @author mranga@nist.gov
 * @version $Revision: 1.7 $, $Date: 2007/03/29 23:11:44 $
 * @since 1.5
 */
public enum LinkType {
	
	GROUP_SERVING(
			2, "group serving"), 
			
	GROUP_HOME(
			1, "group home"), 
			
	UNIT_TO_UNIT_CALLING_SERVING_TO_CALLING_HOME(
			16, "unit to unit calling serving to calling home"), 
			
	UNIT_TO_UNIT_CALLING_HOME_TO_CALLING_SERVING(
			14, "unit to unit calling home to calling serving"), 
			
	UNIT_TO_UNIT_CALLING_HOME_TO_CALLED_HOME(
			12, "unit to unit calling home to called home"), 
			
	UNIT_TO_UNIT_CALLED_HOME_TO_CALLING_HOME(
			11, "unit to unit called home to calling home"), 
			
	UNIT_TO_UNIT_CALLED_HOME_TO_CALLED_SERVING(
			13, "unit to unit called home to called serving"), 
			
	UNIT_TO_UNIT_CALLED_SERVING_TO_CALLED_HOME(
			15, "called serving to called home");
	
	
	/***************************************************************************
	 * Variables
	 **************************************************************************/
	
	/** The type of link as defined in TIA-102.BACA Section 4.1. */
	private int type;
	
	/** Description of the link type. */
	private String description;
	
	
	/***************************************************************************
	 * Constructors
	 **************************************************************************/
	
	/**
	 * Construct a link type.
	 * @param type The link type as defined in TIA-102.BACA Section 4.1
	 * @param description The description of the link type.
	 * @param tsnIsEven True if even TSN, otherwise false.
	 */
	LinkType(int type, String description) {
		
		this.type = type;
		this.description = description;
		
	}

	
	/***************************************************************************
	 * Methods
	 **************************************************************************/
	
	/**
	 * Get the type of this link.
	 * @return The type of this link.
	 */
	int getValue() {
		
		return type;
		
	}

	
	/**
	 * Get a string representation of this link type.
	 * @return The string representation of this link type.
	 */
	public String toString() {
		
		return description;
		
	}

}
