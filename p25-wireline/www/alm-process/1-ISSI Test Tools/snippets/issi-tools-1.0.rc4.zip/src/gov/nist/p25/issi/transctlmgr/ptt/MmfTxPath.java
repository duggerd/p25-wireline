//
package gov.nist.p25.issi.transctlmgr.ptt;

//import gov.nist.p25.issi.p25payload.PacketType;

/**
 * This class defines Tx paths of an MMF state machine.
 * 
 * @author steveq@nist.gov
 * @version $Revision: 1.6 $, $Date: 2007/07/24 03:20:36 $
 * @since 1.5
 */
class MmfTxPath extends PttPath {

	MmfTxPath(MmfTxState currentState, 
			MmfTxTransition transition, MmfTxState nextState) {
		super(currentState,  transition, nextState);
	}
	
	MmfTxState getCurrentState() {
		return (MmfTxState) currentState;
	}

	MmfTxTransition getTransition() {
		return (MmfTxTransition) transition;
	}
	
	MmfTxState getNextState() {
		return (MmfTxState) nextState;
	}

	
	public String toString() {

		return "\tTx Current State: " + currentState + "\n"
				+ "\tTx Transition: " + transition + "\n"
				+ "\tTx Next State: " + nextState + "\n"
				;
	}
}
