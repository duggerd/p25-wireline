//
package gov.nist.p25.issi.rfss;

import gov.nist.javax.sip.stack.DefaultRouter;
import gov.nist.p25.issi.constants.ISSIConstants;
import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;

import javax.sip.SipException;
import javax.sip.SipStack;
import javax.sip.address.Hop;
import javax.sip.address.Router;
import javax.sip.address.SipURI;
import javax.sip.header.RouteHeader;
import javax.sip.message.Request;

//import org.apache.log4j.Logger;

public class RfssRouter extends DefaultRouter implements Router {

   //private static Logger logger = Logger.getLogger(RfssRouter.class);

   private TopologyConfig topologyConfig;
   private RFSS rfss;

   public RfssRouter(SipStack sipStack, String outboundProxy) {
      super(sipStack, outboundProxy);
   }

   public RfssRouter(TopologyConfig topologyConfig, SipStack sipStack) {
      super(sipStack, null);
   }

   public void setTopologyConfig(TopologyConfig topologyConfig) {
      this.topologyConfig = topologyConfig;
   }
   
   public void setRfss(RFSS rfss) {
      this.rfss = rfss;
   }

   public Hop getNextHop(Request request) throws SipException {
      SipURI requestUri = (SipURI) request.getRequestURI();
      try {
         if (request.getHeader(RouteHeader.NAME) == null) {
            // FromHeader from = (FromHeader)request.getHeader(FromHeader.NAME);
            if (request.getMethod().equals(Request.REGISTER)) {
               return super.getNextHop(request);
            } else if (requestUri.getUserParam().equals(ISSIConstants.TIA_P25_SG)
                  && requestUri.getHost().equals( ISSIConstants.P25DR)) {
               String radicalName = requestUri.getUser();
               GroupConfig groupConfig = topologyConfig.getGroupConfig(radicalName);
               String ipAddress = groupConfig.getHomeRfss().getIpAddress();
               int port = groupConfig.getHomeRfss().getSipPort();
               return new HopImpl(ipAddress, port);

            } else if (requestUri.getUserParam().equals(ISSIConstants.TIA_P25_SG)
                  && request.getMethod().equals(Request.ACK) ) {
               // This ugly hack is here because the ISSI spec is in violation of 
               // RFC 3261.
               String rfssDomainName = requestUri.getHost();
               RfssConfig rfssConfig = topologyConfig.getRfssConfig(rfssDomainName);
               String ipAddress = rfssConfig.getIpAddress();
               int port = rfssConfig.getSipPort();
               requestUri.setHost( ISSIConstants.P25DR);
               return new HopImpl(ipAddress,port);
               
            } else if (requestUri.getUserParam().equals(ISSIConstants.TIA_P25_SU)
                  && requestUri.getHost().equals( ISSIConstants.P25DR)) {
               String radicalName = requestUri.getUser();
               SuConfig suConfig = topologyConfig.getSuConfig(radicalName);
               String host = suConfig.getHomeRfss().getIpAddress();
               int port = suConfig.getHomeRfss().getSipPort();
               return new HopImpl(host, port);

            } else {
               return super.getNextHop(request);
            }

         } else {

            RouteHeader routeHeader = (RouteHeader) request.getHeader(RouteHeader.NAME);
            Hop hop = super.getNextHop(request);
            if (((SipURI) routeHeader.getAddress().getURI()).getParameter("remove") != null) {
               request.removeHeader(RouteHeader.NAME);
            }
            return hop;
         }
      } catch (Exception ex) {
         rfss.logError("Error occured in computing the next hop: ", ex);
         rfss.logError("Request for which this error occured is \n" + request);
         return null;
      }
   }

   public Hop getOutboundProxy() {
      return null;
   }
}
