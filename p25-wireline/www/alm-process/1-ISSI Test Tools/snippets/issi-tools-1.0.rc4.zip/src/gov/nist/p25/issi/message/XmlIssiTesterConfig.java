//
package gov.nist.p25.issi.message;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.xmlbeans.XmlOptions;

import gov.nist.p25.common.util.FileUtility;

import gov.nist.p25.issi.xmlconfig.IssiTesterConfigDocument;
import gov.nist.p25.issi.xmlconfig.IssiTesterConfigDocument.IssiTesterConfig;
import gov.nist.p25.issi.xmlconfig.IssiTesterConfigDocument.IssiTesterConfig.DietsDaemon;
//import gov.nist.p25.issi.xmlconfig.IssiTesterConfigDocument.IssiTesterConfig.DietsDaemon.Refid;


public class XmlIssiTesterConfig
{
   public static void showln(String s) { System.out.println(s); }

   private IssiTesterConfigDocument testerConfigDoc;
   private IssiTesterConfig testerConfig;

   // accessor
   public IssiTesterConfig getIssiTesterConfig() {
      return testerConfig;
   }

   // constructor
   public XmlIssiTesterConfig()
   {
   }

   public IssiTesterConfig loadIssiTesterConfig(String xmlMsg)
      throws Exception
   {
      testerConfigDoc = IssiTesterConfigDocument.Factory.parse(xmlMsg);
      testerConfig = testerConfigDoc.getIssiTesterConfig();
      return testerConfig;   
   }   
   
   public IssiTesterConfig loadIssiTesterConfig(File msgFile)
      throws Exception
   {
      testerConfigDoc = IssiTesterConfigDocument.Factory.parse(msgFile);
      testerConfig = testerConfigDoc.getIssiTesterConfig();
      return testerConfig;   
   }   

   public void saveIssiTesterConfig(String msgFilename)
      throws Exception
   {
      XmlOptions opts = new XmlOptions();
      opts.setSavePrettyPrint();
      opts.setSavePrettyPrintIndent(3);
      //String xml = testerConfigDoc.xmlText(opts);
      //showln("pretty-msgDoc=\n"+xml);
      //
      File msgFile = new File( msgFilename);
      testerConfigDoc.save( msgFile);
   }

   //-------------------------------------------------------------------------
   public boolean reconcileIpAddress( Map<String,String> map)
   {
      boolean mflag = false;

      // diets-daemon.refid.id
      List<DietsDaemon> daemonList = testerConfig.getDietsDaemonList();
      for (DietsDaemon daemon: daemonList)
      {
         String ipAddress = daemon.getIpAddress();
         if( ipAddress != null) {
            String newIp = (String)map.get( ipAddress);
            if( newIp != null) {
                  daemon.setIpAddress( newIp);
                  mflag = true;
            }
         }
      }
      return mflag;
   }

   /***
   // used for unit test only
   //-------------------------------------------------------------------------
   public void generateIssiTesterConfig(String msgFileName)
      throws Exception
   {
      XmlOptions opts = new XmlOptions();
      opts.setSavePrettyPrint();
      opts.setSavePrettyPrintIndent(3);

      //----------------------
      testerConfigDoc = IssiTesterConfigDocument.Factory.newInstance();
      testerConfig = testerConfigDoc.addNewIssiTesterConfig();

      //----------------------
      DietsDaemon daemon = testerConfig.addNewDietsDaemon();
      daemon.setIpAddress("132.163.65.190");
      daemon.setName("daemon2");

      Refid refid = daemon.addNewRefid();
      refid.setId("rfss_2.daemon");

      refid = daemon.addNewRefid();
      refid.setId("rfss_3.daemon");

      refid = daemon.addNewRefid();
      refid.setId("rfss_4.daemon");

      //----------------------
      String xml = testerConfigDoc.xmlText(opts);
      showln("pretty-msgDoc=\n"+xml);
      File msgFile = new File( msgFileName);
      testerConfigDoc.save( msgFile);
   }
     ***/

   //=========================================================================
   public static void main(String[] args) throws Exception
   {
      // Test-1
      String xmlFile = "testerconfig/standalone-configuration.xml";

      // Test-2
      //File msgFile = new File(xmlFile);         
      String xmlMsg = FileUtility.loadFromFileAsString(xmlFile);

      XmlIssiTesterConfig xmldoc = new XmlIssiTesterConfig();
      xmldoc.loadIssiTesterConfig(xmlMsg);

      // test ip changes
      Map<String,String> map = new HashMap<String,String>();
      map.put( "132.163.65.190", "129.163.65.111");

      boolean mflag = xmldoc.reconcileIpAddress( map);
      showln("reconcileIpAddress: mflag="+mflag);
      xmldoc.saveIssiTesterConfig( "logs/standaone-1.xml");
   }
}
