//
package gov.nist.p25.issi.rfss;

import java.util.EventObject;

import javax.sip.ResponseEvent;

public abstract class CallControlResponseEvent extends EventObject {
   private static final long serialVersionUID = -1L;

   protected ResponseEvent responseEvent;

   public CallControlResponseEvent(Object eventObject) {
      super(eventObject);
   }

   protected ResponseEvent getResponseEvent() {
      return responseEvent;
   }

   public int getStatusCode() {
      return responseEvent.getResponse().getStatusCode();
   }
}
