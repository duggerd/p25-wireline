//
package gov.nist.p25.issi.rfss;

import gov.nist.javax.sdp.fields.OriginField;
import gov.nist.p25.issi.constants.ISSIConstants;
import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.p25body.ContentList;
import gov.nist.p25.issi.p25body.SdpContent;
import gov.nist.p25.issi.utils.ProtocolObjects;
import gov.nist.p25.issi.utils.WarningCodes;

import javax.sdp.MediaDescription;
import javax.sdp.SessionDescription;
import javax.sip.InvalidArgumentException;
import javax.sip.address.*;
import javax.sip.header.*;
import javax.sip.message.*;

import java.text.ParseException;
import org.apache.log4j.Logger;

/**
 * This is just a set of rules for stripping and comparing various parts 
 * of the SIP URL.
 */
public class SipUtils {
   
   private static Logger logger = Logger.getLogger(SipUtils.class);

   private static AddressFactory addressFactory = ProtocolObjects.getAddressFactory();
   private static HeaderFactory headerFactory = ProtocolObjects.getHeaderFactory();
   private static MessageFactory messageFactory = ProtocolObjects.getMessageFactory();
   
   //-------------------------------------------------------------------------
   public static SipURI createSipURI(String radicalName, String domainName)
         throws ParseException {
      SipURI sipURI = addressFactory.createSipURI(radicalName, domainName);
      return sipURI;
   }

   /**
    * Creaete and return a SIPUri corresponding to a SU.
    * 
    * @param radicalName --
    *            Radical name for the SU.
    * @return -- the SIP URI corresponding to the SU.
    * @throws ParseException
    */
   public static URI createSUSipURI(String radicalName) throws ParseException {

      SipURI sipUri = createSipURI(radicalName, ISSIConstants.P25DR);
      sipUri.setParameter("user", ISSIConstants.TIA_P25_SU);
      return sipUri;
   }

   /**
    * Create and return a SIP URI corresponding to a group.
    * 
    * @param radicalName --
    *            group radical name.
    * @return -- the SIP URI for the group.
    * @throws ParseException
    */
   public static URI createGroupSipURI(String radicalName)
         throws ParseException {
      SipURI sipUri = createSipURI(radicalName, ISSIConstants.P25DR);
      sipUri.setUserParam(ISSIConstants.TIA_P25_SG);
      return sipUri;
   }

   /**
    * return true if this SipURI is and identifier for a group call.
    * 
    * @param sipURI
    * @return
    */
   public static boolean isP25GroupCall(URI sipURI) {
      // Return true if the SIP URI corresponds to a Group call.
      String userName = ((SipURI) sipURI).getUser();
      return userName != null && userName.equals(ISSIConstants.P25_GROUP_CALL);
   }

   /**
    * Return true if this is a Sip URI for a calling home RFSS.
    * 
    * @param sipURI
    * @return
    */
   public static boolean isCallingHomeRFSS(URI sipURI) {
      // This allows a RFSS to know it should be behave as a calling home
      // RFSS.
      String username = ((SipURI) sipURI).getUser();
      return username != null && username.equals(ISSIConstants.CALLING_HOME_NAME);
   }

   public static boolean isCalledHomeRFSS(URI sipURI) {
      // This allows an RFSS to know it should behave as a called home RFSS.
      String username = ((SipURI) sipURI).getUser();
      return username != null && username.equals(ISSIConstants.CALLED_HOME_NAME);
   }

   public static boolean isSubscriberUnitSipURI(URI sipURI) {
      String userparam = ((SipURI) sipURI).getParameter(ISSIConstants.USER);
      return userparam != null
            && userparam.equalsIgnoreCase(ISSIConstants.TIA_P25_SU);
   }

   public static boolean isGroupSipURI(URI sipURI) {
      String userparam = ((SipURI) sipURI).getParameter(ISSIConstants.USER);
      return userparam != null
            && userparam.equalsIgnoreCase(ISSIConstants.TIA_P25_SG);
   }

   public static String getGroupID(URI sipURI) {
      String gidString = ((SipURI) sipURI).getUser();
      return gidString;
   }

   public static String createTag() {
      return Integer.toString(((int) (Math.random() * 1000)));
   }
   
   public static TimeStampHeader createTimeStampHeader() 
      throws InvalidArgumentException
   {
      TimeStampHeader tsHeader = headerFactory.createTimeStampHeader(0);
      tsHeader.setTime(System.currentTimeMillis());
      return tsHeader;
   }

   /**
    * Create and return an LR parameter route header for outgoing invites to
    * route requests to a given RFSS.
    * 
    * @param rfssConfig --
    *            rfss configuration where we want to route requests.
    * 
    * @return
    * @throws Exception
    */
   public static RouteHeader createRouteToRfss(RfssConfig rfssConfig) {
      try {
         String ipAddress = rfssConfig.getDomainName();
         SipURI homeRfssURI = addressFactory.createSipURI(null, ipAddress);

         // homeRfssURI.setPort(rfssConfig.getPort());
         homeRfssURI.setLrParam();
         Address homeRfssAddress = addressFactory.createAddress(homeRfssURI);
         RouteHeader route = headerFactory.createRouteHeader(homeRfssAddress);
         return route;
      } catch (Exception ex) {
         logger.error("Internal error ", ex);
         throw new RuntimeException("Internal error", ex);
      }
   }

   /**
    * Create a contact address for the SU at the Serving RFSS
    */
   public static ContactHeader createContactHeaderForSU(RfssConfig rfssConfig,
         SuConfig suConfig) {
      try {
         ContactHeader retval = createContactHeaderForRfss(rfssConfig, null);
         SipURI contactURI = (SipURI) retval.getAddress().getURI();
         String radicalName = suConfig.getRadicalName();
         contactURI.setUser(radicalName);
         contactURI.setUserParam(ISSIConstants.TIA_P25_SU);
         Address contactAddress = addressFactory.createAddress(contactURI);
         ContactHeader contactHeader = headerFactory.createContactHeader(contactAddress);
         return contactHeader;
      } catch (Exception ex) {
         logger.error("Internal error ", ex);
         throw new RuntimeException("Internal error", ex);
      }
   }

   public static String getRadicalName(SipURI sipUri) {
      return sipUri.getUser();
   }

   public static SipURI createDomainSipURI(String domainName) throws ParseException {
      return addressFactory.createSipURI(null, domainName);
   }

   public static SipURI createDomainSipURI(RfssConfig rfssConfig) throws ParseException {
      String domainName = rfssConfig.getDomainName();
      return createDomainSipURI(domainName);
   }

   public static ContactHeader createContactHeaderForRfss(
         RfssConfig rfssConfig, String userParam) {
      try {
         SipURI contactURI = SipUtils.createDomainSipURI(rfssConfig);
         Address contactAddress = addressFactory.createAddress(contactURI);
         ContactHeader contactHeader = headerFactory.createContactHeader(contactAddress);
         if (userParam != null)
            contactURI.setUserParam(userParam);
         return contactHeader;
      } catch (Exception ex) {
         logger.error("Internal error ", ex);
         throw new RuntimeException("Internal error", ex);
      }
   }

   /**
    * Create a record route header for this RFSS (this is used when forwarding
    * requests down via a set of RFSSs)
    * 
    * @param rfssConfig
    * @return
    */
   public static RecordRouteHeader createRecordRouteHeaderForRfss(
         RfssConfig rfssConfig) {
      try {
         SipURI contactURI = SipUtils.createDomainSipURI(rfssConfig);
         contactURI.setLrParam();
         Address contactAddress = addressFactory.createAddress(contactURI);
         RecordRouteHeader recordRouteHeader = 
            headerFactory.createRecordRouteHeader(contactAddress);
         return recordRouteHeader;
      } catch (Exception ex) {
         logger.error("Internal error ", ex);
         throw new RuntimeException("Internal error", ex);
      }

   }

   public static WarningHeader checkIncomingRequest(Request request) {
      try {
         ContentTypeHeader contentTypeHeader = (ContentTypeHeader) request
               .getHeader(ContentTypeHeader.NAME);
         if (contentTypeHeader.getContentType().equalsIgnoreCase("multipart")
               && contentTypeHeader.getContentSubType().equalsIgnoreCase("mixed")) {
            String boundary = contentTypeHeader.getParameter("boundary");
            if (boundary == null) {
               WarningHeader warningHeader = headerFactory.createWarningHeader(
                           "RFSS",
                           WarningHeader.MISCELLANEOUS_WARNING,
                           ISSIConstants.WARN_TEXT_MISSING_REQUIRED_PARAMETER);
               return warningHeader;
            }
         }
         return null;

      } catch (Exception ex) {
         logger.fatal("Exception encountered while checking request : " + request);
         logger.fatal("internal error !", ex);
         throw new RuntimeException( "checkIncomingRequest: Internal error occured", ex);
      }
   }

   public static WarningHeader createWarningHeader(RfssConfig rfssConfig,
         WarningCodes warnCode) {
      try {
         WarningHeader warningHeader = ProtocolObjects.headerFactory
               .createWarningHeader(rfssConfig.getDomainName(), warnCode
                     .getWarnCode(), warnCode.getWarnText());
         return warningHeader;
      } catch (Exception ex) {
         logger.error("unexpected exception ", ex);
         throw new RuntimeException("unexpected exception ", ex);
      }
   }

   /**
    * Get the RFSS Domain name from a registered URI.
    * 
    * @param registeredUri
    * @return
    */
   public static String getDomainName(SipURI registeredUri) {
      return registeredUri.getHost();
   }

   public static String getCallIdFromMessage(Message message) {
      return ((CallIdHeader) message.getHeader(CallIdHeader.NAME)).getCallId();
   }

   public static ViaHeader createViaHeaderForRfss(RfssConfig config) {
      try {
         ViaHeader viaHeader = headerFactory.createViaHeader(config.getDomainName(),
               -1, "UDP", null);
         return viaHeader;
      } catch (Exception ex) {
         ex.printStackTrace();
         return null;
      }
   }

   /**
    * Create an error response with the appropriate warning header.
    * 
    * @param request
    * @param warningCode
    * @return
    */
   public static Response createErrorResponse(RfssConfig rfssConfig,
         Request request, WarningCodes warningCode) {
      try {
         Response response = messageFactory.createResponse(warningCode.getRc(), request);
         WarningHeader warnHdr = SipUtils.createWarningHeader(rfssConfig, warningCode);
         response.setHeader(warnHdr);
         addAllowHeaders(response);

         if( warningCode.getRc() == Response.FORBIDDEN) {
            //System.out.println("SipUtils(): createErrorResponse - FORBIDDEN addTag()...");
            SipUtils.addToHeaderTag(response);
         }
         response.setHeader(SipUtils.createTimeStampHeader());
         return response;
      } catch (Exception ex) {
         logger.error("Unexpected exception", ex);
         return null;
      }
   }

   public static ContactHeader createContactHeaderForGroup( GroupConfig calledGroup,
         RfssConfig rfssConfig) throws Exception {
      ContactHeader contact = createContactHeaderForRfss(rfssConfig,
            ISSIConstants.TIA_P25_SG);
      SipURI uri = (SipURI) contact.getAddress().getURI();
      uri.setUser(calledGroup.getRadicalName());
      return contact;
   }

   public static int getPriorityValue(PriorityHeader priorityHeader) {
      if (priorityHeader == null) {
         return 1;
      } else {
         String priorityString = priorityHeader.getPriority();
         String[] strings = priorityString.split(";");
         return Integer.parseInt(strings[0]);
      }
   }

   public static boolean isEmergency(PriorityHeader priorityHeader) {
      if (priorityHeader == null) {
         return false;
      } else {
         String priorityString = priorityHeader.getPriority();
         String[] strings = priorityString.split(";");
         return strings[1].equals("e");
      }
   }

   /**
    * 
    * @param domainName
    * @return
    */
   public static int getRfssId(String domainName) {
      String[] strings = domainName.split("\\.");
      return Integer.parseInt(strings[2], 16);
   }

   /**
    * Add necessary Allow headers to a Message.
    * 
    * @param message --
    *            message to enhance.
    */
   public static void addAllowHeaders(Message message) {
      // per spec - arrange in alphabetical order
      for (String allow : new String[] { Request.ACK, Request.BYE,
            Request.CANCEL, Request.INVITE, Request.REGISTER }) {
         try {
            AllowHeader allowHeader = headerFactory.createAllowHeader(allow);
            message.addHeader(allowHeader);
         } catch (ParseException e) {
            logger.fatal("Unexpected exception", e);
         }
      }

   }
   
   // Add tag to ToHeader
   public static void addToHeaderTag(Message message) throws ParseException {
      ToHeader header = (ToHeader) message.getHeader(ToHeader.NAME);
      if( header != null) {
         header.setTag( createTag());
      }
   }
   
   public static void addToHeaderTagByStatusCode(Response response) 
      throws ParseException {
      ToHeader toHeader = (ToHeader) response.getHeader(ToHeader.NAME);
      // Tag for to header is mandatory in 2xx response.
      if (response.getStatusCode() / 100 == 2) {
         toHeader.setTag( createTag());
      }
   }
   
   public static void addFromHeaderTag(Message message) throws ParseException {
      FromHeader header = (FromHeader) message.getHeader(FromHeader.NAME);
      if( header != null) {
         header.setTag( createTag());
      }
   }   

   /**
    * Extract the host part of the contact address and return it.
    * 
    * @param message
    * @return
    */
   public static String getContactHost(Message message) {
      return ((SipURI) ((ContactHeader) message.getHeader(ContactHeader.NAME))
            .getAddress().getURI()).getHost().toLowerCase();
   }

   public static String getSessionIdFromMessage(Message message) {
      try {
         ContentList contentList = ContentList.getContentListFromMessage(message);
         SdpContent sdpContent = (SdpContent) ContentList.getContentByType(
               contentList, ISSIConstants.APPLICATION, ISSIConstants.SDP);
         if (sdpContent == null)
            return null;
         SessionDescription sdes = sdpContent.getSessionDescription();
         return ((OriginField) sdes.getOrigin()).getSessIdAsString();
      } catch (ParseException ex) {
         logger.fatal("Unexpected exception ", ex);
         return null;
      }

   }

   public static int getMediaPortFromMessage(Message message) throws Exception {
      ContentList contentList = ContentList.getContentListFromMessage(message);
      SdpContent sdpContent = (SdpContent) ContentList.getContentByType(
            contentList, ISSIConstants.APPLICATION, ISSIConstants.SDP);
      if (sdpContent == null)
         throw new Exception("Could not find session description");
      SessionDescription sdes = sdpContent.getSessionDescription();
      MediaDescription mdes = (MediaDescription) sdes.getMediaDescriptions(false).get(0);
      return mdes.getMedia().getMediaPort();
   }

   public static SessionDescription getSessionDescriptionFromMessage(
         Message message) throws Exception {
      ContentList contentList = ContentList.getContentListFromMessage(message);
      SdpContent sdpContent = (SdpContent) ContentList.getContentByType(
            contentList, ISSIConstants.APPLICATION, ISSIConstants.SDP);
      return sdpContent.getSessionDescription();
   }

   public static String getRtpSessionIdFromMessage(Message message)
         throws Exception {
      ContentList contentList = ContentList.getContentListFromMessage(message);
      SdpContent sdpContent = (SdpContent) ContentList.getContentByType(
            contentList, ISSIConstants.APPLICATION, ISSIConstants.SDP);
      return ((OriginField) sdpContent.getSessionDescription().getOrigin())
            .getSessIdAsString();
   }

   public static String getGroupIdFromMessage(Message message) {
      FromHeader fromheader = (FromHeader) message.getHeader(FromHeader.NAME);
      SipURI sipUri = (SipURI) fromheader.getAddress().getURI();
      return getGroupID(sipUri);
   }

   public static int comparePriorityHeaders(PriorityHeader header1, PriorityHeader header2) {
         boolean emergency1 = SipUtils.isEmergency(header1);
         int priority1 = SipUtils.getPriorityValue(header1);
         
         boolean emergency2 = SipUtils.isEmergency(header2);
         int priority2 = SipUtils.getPriorityValue(header2);
         
         logger.debug("isHigherPriority : emergency = " + emergency1
               + " priority = " + priority1 + " currentCallIsEmergency =  "
               + emergency2 + " currentCallPriority = "
               + priority2);

         if (emergency1 == emergency2) {
            if ( priority2 > priority1) return 1;
            else if ( priority2 == priority1) return 0;
            else return -1;
            
         } else if (emergency2) {
            return 1;
         } else {
            return -1;
         }
   }

   public static String getViaHost(Request request) {
      ViaHeader viaHeader = (ViaHeader) request.getHeader(ViaHeader.NAME);
      return viaHeader.getHost();
   }
   
   public static void checkContentLength(Request request) throws InvalidArgumentException {
      
      //System.out.println("checkContentLength(): before fixup request=\n"+request);
      request.setHeader(SipUtils.createTimeStampHeader());
      ContentLengthHeader clHeader = request.getContentLength();
      if( clHeader.getContentLength()==0) {
         request.removeHeader(ContentDispositionHeader.NAME);
         request.removeHeader(MimeVersionHeader.NAME);
      }
      else {
         ContentTypeHeader contentTypeHeader = (ContentTypeHeader) request
            .getHeader(ContentTypeHeader.NAME);
         if ("application".equals(contentTypeHeader.getContentType())) {
            // && "sdp".equals(contentTypeHeader.getContentSubType())) {
            request.removeHeader(MimeVersionHeader.NAME);
         }
         else if ("multipart".equals(contentTypeHeader.getContentType()) &&
               "mixed".equals(contentTypeHeader.getContentSubType())) {
            MimeVersionHeader mv = headerFactory.createMimeVersionHeader(1,0);
            request.addHeader(mv);
         }
         else {
            request.removeHeader(MimeVersionHeader.NAME);           
         }
      }
   }

   //--------------------------------
   public static CallIdHeader createCallIdHeader(RfssConfig rfssConfig)
      throws ParseException
   {
      return headerFactory.createCallIdHeader( createCallId( rfssConfig));
   }
   public static String createCallId(RfssConfig rfssConfig)
   {
      return System.currentTimeMillis() +".1@" +rfssConfig.getDomainName();
   }
}
