package gov.nist.p25.issi.utils;

import javax.sip.message.Response;

/**
 * Encodes the following table:
 * 
 * <pre>
 *    0x0a   ;No RTP Resource;            606 NOT ACCEPTABLE   U2U: The Unit to Unit Call MAY NOT  be set-up due to a lack of RTP resource
 *    0x0b   ;No RF Resource;            606 NOT ACCEPTABLE   U2U: The Unit to Unit Call MAY NOT  be set up due to a lack of RF resource
 *    0x14   ;Calling SU not registered;   403 FORBIDDEN      U2U Call: The Calling Home RFSS detects that the Calling Serving RFSS is not registered for the Calling SUID
 *    0x15   ;Called SU not registered;      403 FORBIDDEN      U2U Call: The Called Home RFSS detects that the Called SUID is not registered
 *    0x16   ;Calling SU not authorized;   403 FORBIDDEN      U2U Call: The Calling Home detects that the Calling SU is not authorized to make this call
 *    0x17   ;Called SU not authorized;      403 FORBIDDEN      U2U Call: The Called Home RFSS detects that the Called SU is not authorized to respond to this call
 *    0x18   ;SU not authorized;            403 FORBIDDEN      Unit registration: The Home RFSS of the SU disallows the registration of this unit 
 *    0x19   ;SG not registered;            403 FORBIDDEN      Group Call: SGs Home RFSS detects that the Serving RFSS is not registered for the SGID
 *    0x1a   ;SG not authorized;            403 FORBIDDEN      Group Registration: The SGs Home RFSS disallows the registration of this group
 *    0x1e   ;Unknown Calling SU;         404 NOT FOUND      U2U Call: the Calling Home RFSS detects the Calling SU is unknown
 *    0x1f   ;Unknown Called SU;            404 NOT FOUND      U2U Call: the Called Home RFSS detects the Called SU is unknown
 *    0x20   ;Unknown Called Home RFSS ID;   404 NOT FOUND      U2U Call: The Calling Home RFSS detects that the RFSS ID of the Called Home RFSS is not known
 *    0x21   ;Unknown target group;         404 NOT FOUND      Group Call and group registration: the Home or the Serving RFSS detects that the SG is unknown
 *    0x22   ;Unknown SU;               404 NOT FOUND      Unit Registration: the Home or the Serving RFSS detects that the SU is unknown
 *    0x28   ;Colliding Call;            603 DECLINE   U2U:    The Call is rejected because the same call is proceeding in the opposite direction
 *                                                 Group Call: Home RFSS (resp. Serving RFSS) rejects the INVITE request from the serving RFSS 
 *                                                 (resp. Home RFSS) because it is already inviting the Serving RFSS
 *    0x29   ;Called SU is busy;            486 BUSY HERE      U2U: The Call is rejected because the Called SU is busy or does not respond.
 *    0x2A   ;Called SU refuses the call;   486 BUSY HERE      U2U: The Call is rejected because the Called SU has cancelled
 *                                                     the call while it was waiting for RF resource availability.
 *    0x50   ;RF resource not available;    183 SESSION PROGRESS   U2U call: the called RFSS has no RF resource 
 *    0x55   ;Query processing in progress;   183 SESSION PROGRESS   Home Query: to inform the Home RFSS that the Serving RFSS is attempting to fulfill the received query request.
 *    0x64   ;Non-ISSI header(s)ignored;    2xx   Any
 *    0x65   ;Manufacturer specific body ignored;    2xx   Any
 * </pre>
 * 
 */

public class WarningCodes {

   public static final WarningCodes NO_RTP_RESOURCE = new WarningCodes(
         0x0a,
         "No RTP Resource", 
         606,
         "U2U: The Unit to Unit Call MAY NOT  be set-up due to a lack of RTP resource");

   public static final WarningCodes NO_RF_RESOURCE = new WarningCodes(
         0x0b,
         "No RF Resource",
         606,
         "U2U: The Unit to Unit Call MAY NOT  be set up due to a lack of RF resource");

   public static final WarningCodes FORBIDDEN_CALLING_SU_NOT_REGISTERED = new WarningCodes(
         0x14, 
         "Calling SU not registered", 
         Response.FORBIDDEN,
         "U2U Call: The Calling Home RFSS detects that the Calling "
               + "Serving RFSS is not registered for the Calling SUID");

   public static final WarningCodes FORBIDDEN_CALLED_SU_NOT_REGISTERED = new WarningCodes(
         0x15,
         "Called SU not registered",
         Response.FORBIDDEN,
         "U2U Call: The Called "
               + "Home RFSS detects that the Called SUID is not registered");

   public static final WarningCodes FORBIDDEN_CALLING_SU_NOT_AUTHORIZED = new WarningCodes(
         0x16,
         "Calling SU not authorized",
         Response.FORBIDDEN,
         "U2U Call: The Called Home "
               + "RFSS detects that the Calling SU is not authorized to respond to this call");

   public static final WarningCodes FORBIDDEN_CALLED_SU_NOT_AUTHORIZED = new WarningCodes(
         0x17,
         "Called SU not authorized",
         Response.FORBIDDEN,
         "U2U Call: The Called Home "
               + "RFSS detects that the Called SU is not authorized to respond to this call");

   public static final WarningCodes CALLING_SU_NOT_FOUND = new WarningCodes(
         0x18, 
         "Unknown Calling SU", 
         Response.NOT_FOUND,
         "U2U Call: the Calling Home RFSS "
               + "detects the Calling SU is unknown");

   public static final WarningCodes FORBIDDEN_SG_NOT_REGISTERED = new WarningCodes(
         0x19, 
         "SG not registered", 
         Response.FORBIDDEN,
         "Group Call: SGs Home RFSS detects"
               + " that the Serving RFSS is not registered for the SGID ");

   public static final WarningCodes FORBIDDEN_SG_NOT_AUTHORIZED = new WarningCodes(
         0x1a, 
         "SG not authorized", 
         Response.FORBIDDEN,
         "Group Registration: The SGs Home "
               + "RFSS disallows the registration of this group");

   public static final WarningCodes NOT_FOUND_UNKNOWN_CALLING_SU = new WarningCodes(
         0x1e, 
         "Unknown Calling SU", 
         Response.NOT_FOUND,
         "U2U Call: the Calling Home RFSS detects "
               + "    the Calling SU is unknown");

   public static final WarningCodes NOT_FOUND_UNKNOWN_CALLED_SU = new WarningCodes(
         0x1f, 
         "Unknown Called SU", 
         Response.NOT_FOUND,
         "U2U Call: the Called Home RFSS "
               + " detects the Called SU is unknown");

   public static final WarningCodes NOT_FOUND_UNKNOWN_CALLED_HOME_RFSS = new WarningCodes(
         0x20,
         "Unknown Called Home RFSS ID",
         Response.NOT_FOUND,
         "U2U Call: The Calling Home "
               + " RFSS detects that the RFSS ID of the Called Home RFSS is not known");

   public static final WarningCodes NOT_FOUND_UNKNOWN_TARGET_GROUP = new WarningCodes(
         0x21, 
         "Unknown target group", 
         Response.NOT_FOUND,
         "Group Call and group registration: the Home or the "
               + "Serving RFSS detects that the SG is unknown");

   public static final WarningCodes NOT_FOUND_UNKNOWN_SU = new WarningCodes(
         0x22, 
         "Unknown SU", 
         Response.NOT_FOUND,
         "Unit Registration: the Home or the Serving"
               + " RFSS detects that the SU is unknown");

   public static final WarningCodes DECLINE_COLLIDING_CALL = new WarningCodes(
         0x28,
         "Colliding Call",
         Response.DECLINE,
         "U2U: The Call is rejected because the same call is "
               + "   proceeding in the opposite direction Group Call: Home RFSS (resp. Serving RFSS) rejects "
               + " the INVITE request from the serving RFSS  (resp. Home RFSS) because it is already "
               + " inviting the Serving RFSS");
   
   public static final WarningCodes FORBIDDEN_PROTECTED_MODE_AUDIO_CANNOT_BE_GRANTED = new WarningCodes(
         0x2B,
         "Protected audio call cannot be granted",
         Response.FORBIDDEN,
         "Protected audio call cannot be granted");
   
   
   public static final WarningCodes FORBIDDEN_UNPROTECTED_MODE_AUDIO_CANNOT_BE_GRANTED = new WarningCodes(
         0x2B,
         "Un-protected audio call cannot be granted",
         Response.FORBIDDEN,
         "Un-protected audio call cannot be granted");


   public static final WarningCodes BUSY_HERE = new WarningCodes(
         0x29,
         "Called SU is busy", 
         Response.BUSY_HERE,
         "U2U: The Call is rejected because the Called SU is busy or does not respond.");

   public static final WarningCodes SESSION_PROGRESS_NO_RF_RESOURCES = new WarningCodes(
         0x50, 
         "RF resource not available", 
         Response.SESSION_PROGRESS,
         "U2U call: the called RFSS has no RF resource");

   public static final WarningCodes SESSION_PROGRESS_QUERY_PROCESSING = new WarningCodes(
         0x55,
         "Query processing in progress",
         Response.SESSION_PROGRESS,
         "Home Query: to inform the Home RFSS that the Serving RFSS is attempting to fulfill the received query request.");

   public static final WarningCodes NON_ISSI_HEADER = new WarningCodes(
         0x64,
         "Non-ISSI header(s)ignored",
         Response.OK,
         "Any");

   public static final WarningCodes FORBIDDEN_PRESENCE_REQUIRED = new WarningCodes(
         0x1b,
         "SU Presence Confirmation required", 
         Response.FORBIDDEN,
         "SU Presence Confirmation is required");

   private int warnCode;
   private int rc;
   private String warnText;
   private String usage;

   WarningCodes(int warnCode, String warnText, int rc, String usage) {
      this.warnCode = warnCode;
      this.rc = rc;
      this.warnText = warnText;
      this.usage = usage;
   }

   public int getWarnCode() {
      return 399;
   }

   public int getRc() {
      return rc;
   }

   public String getWarnText() {
      return "TIA-P25-ISSI-" + Integer.toHexString(warnCode)+ ":" + warnText;
   }

   public String getUsage() {
      return usage;
   }
}
