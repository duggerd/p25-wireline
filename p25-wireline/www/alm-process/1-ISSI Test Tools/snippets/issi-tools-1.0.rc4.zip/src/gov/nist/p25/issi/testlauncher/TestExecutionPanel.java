//
package gov.nist.p25.issi.testlauncher;


import gov.nist.p25.common.util.FileUtility;

import gov.nist.p25.issi.constants.DietsConfigProperties;
import gov.nist.p25.issi.constants.ISSIDtdConstants;
import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.GlobalTopologyParser;
import gov.nist.p25.issi.issiconfig.SystemTopologyParser;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfigParser;
import gov.nist.p25.issi.message.ConformanceTestConfigManager;
import gov.nist.p25.issi.message.XmlGlobalTopology;
import gov.nist.p25.issi.message.XmlPttmessages;
import gov.nist.p25.issi.message.XmlSystemTopology;
import gov.nist.p25.issi.rfss.tester.TestScript;
import gov.nist.p25.issi.rfss.tester.TestScriptParser;

import gov.nist.p25.issi.setup.TestConfigControlDialog;
import gov.nist.p25.issi.setup.TopologyConfigHelper;
import gov.nist.p25.issi.traceviewer.MessageData;
import gov.nist.p25.issi.traceviewer.PttSessionInfo;
//import gov.nist.p25.issi.traceviewer.PttTraceLoader;
import gov.nist.p25.issi.traceviewer.RfssData;
import gov.nist.p25.issi.traceviewer.RfssRuntimeDataParser;
import gov.nist.p25.issi.traceviewer.SipTraceLoader;
import gov.nist.p25.issi.traceviewer.TestLayoutPanel;
import gov.nist.p25.issi.traceviewer.TraceLogTextPane;
import gov.nist.p25.issi.traceviewer.TracePanel;

import gov.nist.p25.issi.xmlconfig.PttmessagesDocument.Pttmessages;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane; 
//import javax.swing.JTextPane;
import javax.swing.border.TitledBorder;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

/**
 * Test execution panel.
 *
 */
public class TestExecutionPanel extends JPanel 
      implements MouseListener, ActionListener {

   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(TestExecutionPanel.class);

   public static void showln(String s) { System.out.println(s); }

   // public static final int TEST_TIMEOUT = ISSITesterConstants.TEST_RUNS_FOR +
   // 5 * 1000;
   public static final int TEST_TIMEOUT = ISSITesterConstants.TEST_RUNS_FOR;
   
   public static SimpleAttributeSet ERROR_MESSAGE_TEXT = new SimpleAttributeSet();
   public static SimpleAttributeSet STACK_TRACE_TEXT = new SimpleAttributeSet();
   public static SimpleAttributeSet INFO_TEXT = new SimpleAttributeSet();
   public static SimpleAttributeSet FATAL_MESSAGE_TEXT = new SimpleAttributeSet();
   
   private static String baseDir = System.getProperty("user.dir");

   static {
      StyleConstants.setForeground(ERROR_MESSAGE_TEXT, Color.red);
      StyleConstants.setForeground(STACK_TRACE_TEXT, Color.blue);
      StyleConstants.setForeground(INFO_TEXT, Color.black);
      StyleConstants.setForeground(FATAL_MESSAGE_TEXT, Color.red);
      StyleConstants.setUnderline(FATAL_MESSAGE_TEXT, true);
      StyleConstants.setFontSize(FATAL_MESSAGE_TEXT, 14);
   }
   
   /** The timer for TimerTasks associated with this receiver. */
   private static Timer timer = new Timer();

   private TestExecutionTimerTask testExecutionTimerTask;
   private DietsService testerService;

   private boolean standalone;
   private DietsGUI gui;
   private String currentTestName = "";
   private String localTopologyName = "";
   private String currentTopologyName = "";

   private JList jlist;
   private JButton testButton;
   private JButton setupButton;
   private JButton generateButton;
   private JButton runInteractiveButton;

   private TraceLogTextPane descriptionPane;
   private TraceLogTextPane systemTopologyPane;
   private TraceLogTextPane globalTopologyPane;
   private TraceLogTextPane testTopologyPane;
   private TraceLogTextPane testConfigPane;
   private TraceLogTextPane testScriptPane;
   private TraceLogTextPane testStatusPane;
   private TestLayoutPanel testLayoutPane;

   private TracePanel sipTracePanel;
   private TracePanel pttTracePanel;
   private String progressScreenMessage = "";
   private ProgressMonitor progressMonitor;

   private JTabbedPane tabbedPane;
   private JScrollPane statusLogScrollPane;

   private int refTestNumber = 0;
   private int runTestNumber = 0;
   private String sipErrorMsg = "";
   private String pttErrorMsg = "";

   // accessors
   // --------------------------------------------------------------------------
   public Timer getTimer() {
      return timer;
   }

   public String getCurrentTopologyName() {
      return currentTopologyName;
   }
   public void setCurrentTopologyName(String currentTopologyName) {
      this.currentTopologyName = currentTopologyName;
   }

   public TestCaseDescriptor getCurrentTestCaseDescriptor() {
      return (TestCaseDescriptor) jlist.getSelectedValue();
   }

   public void setCurrentTest(String testDir, String topologyFileName) {
      this.currentTestName = testDir + "/testscript.xml";
      this.currentTopologyName = topologyFileName;
   }

   public String getStartupPropertiesFileName() {
      return gui.getStartupPropertiesFileName();
   }

   public void doStaticReInitialization(String startupFile)
      throws Exception
   {
      gui.doStaticReInitialization( startupFile);
   }

   public void newProgressMonitor() {
      setProgressMonitor(new ProgressMonitor(gui));
   }

   public ProgressMonitor getProgressMonitor() {
      return progressMonitor;
   }

   public void setProgressMonitor(ProgressMonitor monitor) {
      this.progressMonitor = monitor;
   }

   public void stopProgressMonitor() {
      setProgressScreenMessage("Done.");
      if (getProgressMonitor() != null) {
         getProgressMonitor().done();
         setProgressMonitor(null);
      }
      enableAllButtons();
   }

   public String getProgressScreenMessage() {
      return progressScreenMessage;
   }

   public void setProgressScreenMessage(String progressScreenMessage) {
      this.progressScreenMessage = progressScreenMessage;
      if (getProgressMonitor() != null) {
         synchronized (getProgressMonitor()) {
            getProgressMonitor().notify();
         }
      }
   }

   public TracePanel getSipTracePanel() {
      return sipTracePanel;
   }

   public TracePanel getPttTracePanel() {
      return pttTracePanel;
   }

   public String getSipTestError() {
      return sipErrorMsg;
   }

   public void setSipTestError(String errorMsg) {
      this.sipErrorMsg = errorMsg;
   }

   public String getPttTestError() {
      return pttErrorMsg;
   }

   public void setPttTestError(String errorMsg) {
      this.pttErrorMsg = errorMsg;
   }

   public void incrementRunTestNumber() {
      runTestNumber++;
      setSipTestError(null);
      setPttTestError(null);
   }

   public void incrementRefTestNumber() {
      refTestNumber++;
      setSipTestError(null);
      setPttTestError(null);
   }

   public void clearTestTraces() {
      refTestNumber = 0;
      runTestNumber = 0;
      setSipTestError(null);
      setPttTestError(null);
      gui.getJTabbedPane().removeAll();
   }

   // logging
   public void logSystemTopologyPane(boolean isClear, String message) {
      systemTopologyPane.logMessage(isClear, message);
   }

   public void logGlobalTopologyPane(boolean isClear, String message) {
      globalTopologyPane.logMessage(isClear, message);
   }

   public void logTestConfigPane(boolean isClear, String message) {
      testConfigPane.logMessage(isClear, message);
   }

   public void logTestStatusPane(boolean isClear, String message) {
      testStatusPane.logMessage(isClear, message);
   }

   // buttons
   public void disableAllButtons() {
      setupButton.setEnabled(false);
      generateButton.setEnabled(false);
      runInteractiveButton.setEnabled(false);
   }

   public void enableAllButtons() {
      setupButton.setEnabled(true);
      generateButton.setEnabled(true);
      runInteractiveButton.setEnabled(true);
   }

   public void enableSetupButton() {
      setupButton.setEnabled(true);
   }

   public void doSetupTest() {
      setupButton.requestFocus();
      setupButton.doClick();
   }

   // --------------------------------------------------------------------------
   /**
    * A class that waits for test execution to complete. This is basically 
    * an open loop timer. It is used in non-interactive execution.
    * 
    */
   class TestExecutionTimerTask extends TimerTask {

      private boolean interactive;
      private int secondsRemaining;
      private DietsGUI gui;

      public int getSecondsRemaining() {
         return secondsRemaining;
      }

      public TestExecutionTimerTask(DietsGUI gui, int seconds,
            boolean interactive) {
         this.gui = gui;
         this.secondsRemaining = seconds;
         this.interactive = interactive;
         gui.getStatusProgressBar().setIndeterminate(true);
         newProgressMonitor();
      }

      public void run() {
         secondsRemaining = secondsRemaining - 1000;
         if (secondsRemaining > 0) {
            setProgressScreenMessage("Running.  Time remaining: "
                  + (secondsRemaining / 1000) + " seconds");
         }
         
         boolean completed = false;
         try {
            completed = gui.getRemoteController().isTestCompleted();
            // New
            //completed &= gui.getRemoteController().isSaveTraceCompleted();           
         } 
         catch(Exception ex) {}

         showln("MMM check for test completed="+completed+" remains="+secondsRemaining);        
         if (completed) secondsRemaining = 0;
         if (secondsRemaining == 0) {
            showln("CANCEL timer: secondsRemaining="+secondsRemaining);
            cancel();
            if (!interactive) {
               getSipPttTraces(interactive);
            }
         }
      }
   }

   class PBThread extends Thread {
      //private boolean running = true;
      private int nloops = 10;
      private IndeterminateTimerTask ttask;

      PBThread( IndeterminateTimerTask ttask, int nloops) {
         this.ttask = ttask;
         this.nloops = nloops;
      }
      public void run() {
         for(int i=0; i < nloops; i++) {
            System.out.println(" Sleep counter="+i);
            try {
               Thread.sleep(1000L);
            }catch(Exception ex) { }
         }
         System.out.println("Done ...cancel timer");
         ttask.done();
      }
   }

   // constructor
   // --------------------------------------------------------------------------
   public TestExecutionPanel(Vector<TestCaseDescriptor> tests, DietsGUI gui,
       boolean standalone) {

      super();
      this.gui = gui;
      this.standalone = standalone;

      setLayout(new BorderLayout());
      setBorder(new TitledBorder("Conformance Tests"));

      JPanel listPanel = new JPanel();
      //listPanel.setMinimumSize(new Dimension(325, 300));
      listPanel.setPreferredSize(new Dimension(440, 300));
      //listPanel.setMaximumSize(new Dimension(480, 300));
      listPanel.setLayout(new BorderLayout());
      jlist = new JList(tests);
      jlist.addMouseListener(this);
      jlist.setSelectedIndex(0);
      JScrollPane scrollList = new JScrollPane(jlist);

      testButton = new JButton("Test Button");
      testButton.setToolTipText("Test new features");
      testButton.addActionListener(this);

      setupButton = new JButton("Setup Test");
      setupButton.setToolTipText("Setup RFSS configuration");
      setupButton.addActionListener(this);

      generateButton = new JButton("Generate Trace");
      generateButton.setToolTipText("Generate Reference Trace");
      generateButton.addActionListener(this);

      runInteractiveButton = new JButton("Run Test");
      runInteractiveButton.setToolTipText(
         "Run in interactive mode - simulates actual operation");
      runInteractiveButton.addActionListener(this);

      JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
      //buttonPanel.add(testButton);
      buttonPanel.add(setupButton);
      buttonPanel.add(generateButton);
      buttonPanel.add(runInteractiveButton);

      listPanel.add(scrollList, BorderLayout.CENTER);
      listPanel.add(buttonPanel, BorderLayout.SOUTH);

      //TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
      //String testDesc = selectedTest.toString();
      //String testNo = selectedTest.getTestNumber();
      
      // Description
      descriptionPane = new TraceLogTextPane( );
      JScrollPane descriptionScrollPane = new JScrollPane(descriptionPane);
      
      // System
      systemTopologyPane = new TraceLogTextPane( );
      //===JScrollPane systemTopologyScrollPane = new JScrollPane(systemTopologyPane);

      // Global
      globalTopologyPane = new TraceLogTextPane( );
      //===JScrollPane globalTopologyScrollPane = new JScrollPane(globalTopologyPane);

      // Test Topology
      testTopologyPane = new TraceLogTextPane( );
      JScrollPane testTopologyScrollPane = new JScrollPane(testTopologyPane);

      // Test Configuration   
      testConfigPane = new TraceLogTextPane( );
      JScrollPane configureScrollPane = new JScrollPane(testConfigPane);

      // Test Script
      testScriptPane = new TraceLogTextPane( );
      JScrollPane scriptScrollPane = new JScrollPane(testScriptPane);

      // Test Status
      testStatusPane = new TraceLogTextPane( );
      statusLogScrollPane = new JScrollPane(testStatusPane);

      // Test Layout
      testLayoutPane = new TestLayoutPanel( );
      JScrollPane testLayoutScrollPane = new JScrollPane(testLayoutPane);

      // populate the tabs
      updateTestTabbedPane( jlist.getSelectedIndex());
      
      // setup tabbed pane
      //----------------------------------------------------
      tabbedPane = new JTabbedPane();
      tabbedPane.add("Description", descriptionScrollPane);
      tabbedPane.setSelectedComponent(descriptionScrollPane);
      // Disabled
      //tabbedPane.add("System Topology", systemTopologyScrollPane);
      //tabbedPane.add("Global Topology", globalTopologyScrollPane);
      //
      tabbedPane.add("Test Topology", testTopologyScrollPane);
      tabbedPane.add("Test Configuration", configureScrollPane);
      tabbedPane.add("Test Script", scriptScrollPane);
      tabbedPane.add("Test Layout", testLayoutScrollPane);
      tabbedPane.add("Test Status", statusLogScrollPane);

      JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
            listPanel, tabbedPane);
      splitPane.setOneTouchExpandable(true);
      splitPane.setDividerLocation(0.45);
      splitPane.setDividerSize(7);
      add(splitPane, BorderLayout.CENTER);

      disableAllButtons();
      enableSetupButton();
      try {
         startServices();
      }
      catch(Exception ex) {
         logger.debug("startService: "+ex);
         String msg = "Failed to startServices: " + ex.getMessage() +
            "\nPlease exit the application and configure ipaddress in " +
	    "\nstartup/diets.daemon.localhost.properties and" +
	    "\ntesterconfig/standalone-configuration.xml\n";
	 JOptionPane.showMessageDialog(null, msg,
            "Start Services Error",
            JOptionPane.ERROR_MESSAGE);
         System.exit(-1);
      }
   }

   //------------------------------------------------------------------------------
   public void logError(String failureMessage, String errorTrace) {
      testStatusPane.logMessage(true, failureMessage);
      testStatusPane.logMessage(false, errorTrace);
      tabbedPane.setSelectedComponent(statusLogScrollPane);
   }

   public void logError(String failureMessage) {
      testStatusPane.logMessage(true, failureMessage + "\n");
      tabbedPane.setSelectedComponent(statusLogScrollPane);
   }

   public void logFatal(String failureMessage, String stackTrace) {
      testStatusPane.logMessage(true, failureMessage + "\n");
      testStatusPane.logMessage(false, stackTrace);
      tabbedPane.setSelectedComponent(statusLogScrollPane);
   }

   public void logStatusMessage(String statusMessage) {
      testStatusPane.logMessage(true, statusMessage + "\n");
   }
   
   public void updateSuggestedFile(String baseDir, String testNo) { 
    
      // make testcase specific output/testNo directory
      String outDir = baseDir + File.separator + "output" + File.separator + testNo;
      FileUtility.makeDir( outDir);
      
      String suggestFile;      
      // Description
      suggestFile = outDir + File.separator + "test-description-" +testNo +".txt";
      descriptionPane.setSuggestedFile( suggestFile);
      
      // System Topology
      suggestFile = outDir + File.separator + "system-topology-" +testNo +".txt";
      systemTopologyPane.setSuggestedFile( suggestFile);
      
      // Global Topology
      suggestFile = outDir + File.separator + "global-topology-"+testNo+".txt";
      globalTopologyPane.setSuggestedFile( suggestFile);      

      // Test Topology
      suggestFile = outDir + File.separator + "test-topology-" +testNo +".txt";
      testTopologyPane.setSuggestedFile( suggestFile);
      
      // Test Configuration
      suggestFile = outDir + File.separator + "test-configuration-"+testNo+".txt";
      testConfigPane.setSuggestedFile( suggestFile);

      // Test Script
      suggestFile = outDir + File.separator + "test-script-"+testNo+".txt";
      testScriptPane.setSuggestedFile( suggestFile);
      
      // Test Status
      suggestFile = outDir + File.separator + "test-status-"+testNo+".txt";
      testStatusPane.setSuggestedFile( suggestFile);     
   }

   public void startServices() throws Exception {

      showln("startServices(): START....");
      if( testerService != null) {
          stopServices();
      }

      String propertiesFileName = getStartupPropertiesFileName();
      DietsConfigProperties props = null;
      String testSuiteName = null;
      String testerTopologyFileName = null;
      String systemTopologyFileName = null;

      //TODO: This all should be replaced with ISSIConfigManager !!! 
      props = new DietsConfigProperties(propertiesFileName);
      testSuiteName = props.getProperty(DietsConfigProperties.TESTSUITE_PROPERTY);
      testerTopologyFileName = props.getProperty(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);

      //M3008 - hardcoded not good !!!
      //systemTopologyFileName = ISSITesterConstants.getSystemTopologyFileName(testSuiteName);
      systemTopologyFileName = props.getProperty(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);

      showln("  propertiesFileName="+propertiesFileName);
      showln("  testSuiteName="+testSuiteName);
      showln("  testerTopologyFileName="+testerTopologyFileName);
      showln("  systemTopologyFileName="+systemTopologyFileName);
      showln("----------------------------------------------");

      testerService = new DietsService(props, testSuiteName,
         testerTopologyFileName, systemTopologyFileName, this);

      testerService.startDaemon();
      showln("startServices(): startDaemon() DONE....");
   }

   public void stopServices() {
      showln("stopServices(): START....");
      if( testerService == null) return;
      try {
         testerService.stopDaemon();
      }
      catch(Throwable ex) { 
         // ignore
      }
      finally {
         testerService = null;
      }
      showln("stopServices(): DONE....");
   }

   public void closeShop() {
      showln("TestExectionPanel: closeShop(): START....");
      try {
         testerService.stopTestServices();
      } 
      catch(Exception ex) { }
      stopServices();
      showln("TestExectionPanel: closeShop(): DONE....");
   }

   //------------------------------------------------------------------------------
   // implementation of ActionListener
   //------------------------------------------------------------------------------
   public void actionPerformed(ActionEvent actionEvent) {

      gui.updateGlobalTopologyValues();
      Object source = actionEvent.getSource();
      if (source == setupButton) {

         // Setup Test
         disableAllButtons();
         clearTestTraces();

         String topoDir = ISSITesterConstants.getScenarioDir();
         String testDesc = getCurrentTestCaseDescriptor().toString();
         showln(">>>>> Setup Test Config: "+testDesc);
         showln("    currentTopologyDir: "+topoDir);
         showln("    currentTopologyName: "+getCurrentTopologyName());

         Map<String,String> nameMap = null;
         //------------------------------------------------------------
         try {
            TopologyConfig testTopology = getTopologyConfig(getCurrentTopologyName());
            TopologyConfigHelper helper = new TopologyConfigHelper();
            helper.reconfigureDaemonTesterService( testTopology, gui.getIssiTesterConfiguration());

            TestConfigControlDialog dialog = new TestConfigControlDialog(null, true,
               testDesc, testTopology);

            boolean answer = dialog.getAnswer();
            //showln("TestExecutionPanel: dialog-answer: "+ answer);
            if( answer) {

               nameMap = dialog.getRfssNameMap();
               showln("TestExecutionPanel: nameMap: "+ nameMap);

               String stFile = gui.getSystemTopologyFileName();
               String gtFile = gui.getGlobalTopologyFileName();

               // fix system config
               XmlSystemTopology stxmlDoc = new XmlSystemTopology();
               stxmlDoc.loadSystemTopology( stFile);
               stxmlDoc.reconcile( dialog.getRfssConfigSetupList());
               stxmlDoc.saveSystemTopology( "logs/systemtopology.xml");

               // fix global config
               String gtxmlMsg = FileUtility.loadFromFileAsString( gtFile);
               XmlGlobalTopology gtxmlDoc = new XmlGlobalTopology();
               gtxmlDoc.loadGlobalTopology( gtxmlMsg);
               gtxmlDoc.reconcileRfssName( nameMap);
               gtxmlDoc.saveGlobalTopology( "logs/globaltopology.xml");

               // fixup the daemon IP-Address
               dialog.reconcile(gui.getIssiTesterConfiguration());

               showln("systemTopology=\n"+testTopology.exportSystemTopology());
               showln("globalTopology=\n"+testTopology.exportGlobalTopology());
               showln("testerConfig=\n"+gui.getIssiTesterConfiguration());

               int yesno = JOptionPane.showConfirmDialog( null,
                  "Would you like to save and distribute configuration files ?\n" +
                  "Please be patience, save operation will take ~30 seconds...\n" +
                  "The configuration files will be distributed accordingly....\n\n",
                  "Save and Start Test Service",
                  JOptionPane.YES_NO_OPTION);
               if( yesno == JOptionPane.YES_OPTION) {

                  //NOTE: doesnot save system and global topology
                  testerService.saveConfiguration(gui.getIssiTesterConfiguration(),testTopology);

                  // move system and global config
                  FileUtility.copyFile(new File("logs/systemtopology.xml"), new File(stFile));
                  FileUtility.copyFile(new File("logs/globaltopology.xml"), new File(gtFile));
		  
                  // fix current topology configs
                  boolean saveTopo = true;
                  showln("*** reconsileRfssName()...save="+saveTopo);
                  ConformanceTestConfigManager manager = new ConformanceTestConfigManager();
                  List<String> modList = manager.reconcileRfssName(nameMap,
                     new File(topoDir), saveTopo);

                  // add glabal and system
                  modList.add( stFile);
                  modList.add( gtFile);
                  try {
                     // ship testscript topology.xml
                     testerService.shipConfigFilesList( modList);

                     // ship properties, config and redraw commands
                     testerService.shipConfigFiles();

                  } catch(Throwable ex) {
                     // change in IP, but host is not running
                     showln("Connect error: "+ex); 
                  }

                  //--------------------------------------------------
                  try {
                     showln("*** sendStaticReinitialization()...");
                     testerService.sendStaticReinitialization();
                     Thread.sleep(3000L);
                  } catch(Throwable ex) {
                     showln("sendStaticReinitialization: "+ex); 
                  }
                  showln("*** doStaticReInitialization()...");
                  doStaticReInitialization( getStartupPropertiesFileName());

                  showln("*** startService()...BOUNCE DAEMON");
                  startServices();
                  updateTestTabbedPane( jlist.getSelectedIndex());

                  try {
                     //showln("*** sendSetConformanceTest()...");
                     testerService.sendSetConformanceTest(jlist.getSelectedIndex());
                  } catch(Throwable ex) {
                     showln("sendSetConfrmanceTest: "+ex); 
                  }

                  String msg = "Test Configuration Setup is successful.\n" +
                     "Total number of files modified: " + modList.size() +"\n" +
                     "Before testing, please sync clock time in all RFSSes\n";
                  JOptionPane.showMessageDialog(null, msg,
                     "Test Setup Summary",
                     JOptionPane.INFORMATION_MESSAGE);

               }   // save-config
            }  // answer=yes
         } 
         catch(Exception ex) {
            String msg = "Error in updating Test Configuration based on user input:\n";
            logger.debug( msg, ex);
            JOptionPane.showMessageDialog(null, 
               msg + ex.getMessage(),
               "Test Config Setup Error",
               JOptionPane.ERROR_MESSAGE);
         }
         finally {
            // start test service
            try {
               showln("*** startTestServices()...");
               testerService.stopTestServices();
               testerService.startTestServices();
               enableAllButtons();
            } 
	    catch(Exception ex) {
               JOptionPane.showMessageDialog(null, 
                  ex.getMessage(),
                  "Test Config Setup Error",
                  JOptionPane.ERROR_MESSAGE);

               enableSetupButton();
               setupButton.doClick();
	    }
         }
      }
      else if (source == generateButton) {

         // Generate Ref Trace
         disableAllButtons();
         incrementRefTestNumber();

         try {

            TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
            currentTestName = (String) selectedTest.getFileName();
            localTopologyName = selectedTest.getTopologyFileName();
            
            showln(">>>>>>>>>>>>>> Generate Ref >>>>>>>>>>>>>>>>>>>>");
            logger.debug("globalTopology = " + gui.getGlobalTopologyFileName());
            logger.debug("systemTopology = " + gui.getSystemTopologyFileName());
            logger.debug("currentTestName = " + currentTestName);
            logger.debug("localTopologyName = " + localTopologyName);
            showln("********* tearDown ********");
            gui.getRemoteController().tearDownCurrentTest();
            showln("********* loadTest ********");

            TestScriptParser parser = new TestScriptParser(
                  ISSITesterConstants.getScenarioDir() + "/" + currentTestName,
                  ISSITesterConstants.getScenarioDir() + "/" + localTopologyName,
                  gui.getGlobalTopologyFileName(), 
                  gui.getSystemTopologyFileName(), false);
            parser.parse();
            logger.debug("loadTest(): currentTestName=" + currentTestName);
            gui.getRemoteController().loadTest(
                  ISSITesterConstants.getScenarioDir(), currentTestName,
                  selectedTest.getTestNumber(), localTopologyName,
                  gui.getGlobalTopologyFileName(), gui.getSystemTopologyFileName(),
                  false, gui.getEvaluatePassFail());
            logger.debug("runTest()...");
            gui.getRemoteController().runTest();

            startTestExecutionTimerTask(TEST_TIMEOUT, false);

         } catch (Exception e) {
            e.printStackTrace();
            logger.debug("Error communicating with the tester!!", e);
            JOptionPane.showMessageDialog(
               null,
               "Error occured in generating trace. \nCheck the tester configuration file",
               "Communication Error", 
               JOptionPane.ERROR_MESSAGE);
            enableAllButtons();
         }

      } else if (source == runInteractiveButton) {

         // Run Test
         disableAllButtons();
         incrementRunTestNumber();

         try {
            TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
            currentTestName = (String) selectedTest.getFileName();
            localTopologyName = selectedTest.getTopologyFileName();

            showln(">>>>>>>>>>>>>>>>> Run Test >>>>>>>>>>>>>>>>>>>>");
            showln("RT  scenarioDir=" + ISSITesterConstants.getScenarioDir());
            showln("RT  currentTestName=" + currentTestName);
            showln("RT  localTopologyName=" + localTopologyName);
            showln("-----------------------------------");
                        
            showln("********* tearDown ********");
            gui.getRemoteController().tearDownCurrentTest();
            showln("********* loadTest ********");
            
            // After generate traces, it takes time to create trace files
            // see refmessages/conformance/<testname>/...
            Thread.sleep(3000);    
            gui.getRemoteController().loadTest(
                  ISSITesterConstants.getScenarioDir(), currentTestName,
                  selectedTest.getTestNumber(), localTopologyName,
                  gui.getGlobalTopologyFileName(), gui.getSystemTopologyFileName(),
                  true, gui.getEvaluatePassFail());
            Thread.sleep(1000);

            showln("********* runTest...");
            gui.getRemoteController().runTest();

            showln("********* new TestScriptParser ... standalone="+standalone);
            TestScript testScript = new TestScriptParser(
                  ISSITesterConstants.getScenarioDir() + "/" + currentTestName,
                  ISSITesterConstants.getScenarioDir() + "/" + localTopologyName,
                  gui.getGlobalTopologyFileName(), 
                  gui.getSystemTopologyFileName(), true).parse();

            showln("********* ScenarioPrompter ********");
            new ScenarioPrompter(gui, gui.getRemoteController(), testScript,
                  gui.getScenarioPrompterState()).startPrompting();

            // Wait TEST_TIMEOUT before trying to retrieve traces.
            // testExecutionTimerTask = new TestExecutionTimerTask(gui);
            // timer.schedule(testExecutionTimerTask, 0, 1000);

         } catch (Exception ex) {
            try {
               showln("********* tearDown ********");
               gui.getRemoteController().tearDownCurrentTest();
            } catch(Exception ex2) { }
            
            logger.error("Communication error running test! ", ex);
            gui.showWarning(
               "Error Communicaticating with the tester or running the test!\n"
                  + "Exception message : " + ex.getMessage() + "\n"
                  + "Make sure test daemons are running (check tester configuration)\n"
                  + "Make sure reference traces are generated before running the test!",
               "Test Execution Error!");
            enableAllButtons();
         }
      }
      //------------------------------------------------
      else if (source == testButton) {

         int nseconds = 30000;
         newProgressMonitor();
         IndeterminateTimerTask ttask = new IndeterminateTimerTask(gui,nseconds);
         getTimer().schedule( ttask, 0, 1000);

         PBThread pbthread = new PBThread( ttask, 20);
         pbthread.start();
      }
   }

   public void mouseClicked(MouseEvent me) { }
   public void mouseEntered(MouseEvent me) { }
   public void mouseReleased(MouseEvent me) { }
   public void mouseExited(MouseEvent me) { }
   
   public void mousePressed(MouseEvent me)
   {
      showln("********* mousePressed() ********");
      clearTestTraces();

      int index = jlist.locationToIndex(me.getPoint());
      jlist.setSelectedIndex(index);
      updateTestTabbedPane( index);

      try {
         showln("mousePressed: sendSetConformanceTest()...");
         testerService.sendSetConformanceTest(jlist.getSelectedIndex());
      } catch(Throwable ex) {
         showln("mousePressed: sendSetConformanceTest(): "+ex); 
      }

      try {
         gui.renderRefTraceLogs();
      } catch (Exception ex) {
         logger.error("An unexpected execution error occured", ex);
         JOptionPane.showMessageDialog( null,
               "Error in rendering reference trace logs: "+currentTestName,
               "Render Reference Trace Error", 
               JOptionPane.ERROR_MESSAGE);
      }
   }

   public void setConformanceTestByIndex(int index)
   {
      jlist.setSelectedIndex(index);
      updateTestTabbedPane( index);
   }

   public void setTestLayoutPane()
   {
      //tabbedPane.setSelectedComponent(testLayoutPane);
      tabbedPane.setSelectedIndex(4);
   }

   public void updateTestTabbedPane(int index)
   {
      TestCaseDescriptor descriptor = (TestCaseDescriptor) jlist.getModel()
            .getElementAt(index);

      // Description
      descriptionPane.setText("Category : " + descriptor.getCategory()
            + "\nTest Number : " + descriptor.getTestNumber() + "\n\n"
            + descriptor.getTestDescription());

      // System Topology
      // Global Topology

      TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
      currentTestName = (String) selectedTest.getFileName();
      currentTopologyName = selectedTest.getTopologyFileName();
      String testFileName = ISSITesterConstants.getScenarioDir() + "/" + currentTestName;
      try {
	 // Test Script
         String ftext = FileUtility.loadFromFileAsString(testFileName); 
         testScriptPane.logMessage(true, ftext);

         // initialize the output filename
         updateSuggestedFile( baseDir, selectedTest.getTestNumber());
      }
      catch (Exception ex) {
         String msg = "Error in open/reading Test Script: " + testFileName;
         logger.debug( msg, ex);
         JOptionPane.showMessageDialog(null, msg,
               "Test Script Status",
               JOptionPane.ERROR_MESSAGE);
      }

      // Test Configuration
      String ftext = formatLocalTopology(false);
      testConfigPane.logMessage(true, ftext);

      // Test Status
      String xmlftext = formatLocalTopology(true);
      //testStatusPane.logMessage(true, xmlftext);
      testTopologyPane.logMessage(true, xmlftext);
      
      // Test Layout
      try {
         TopologyConfig testTopology = getTopologyConfig(getCurrentTopologyName());
         String testDesc = getCurrentTestCaseDescriptor().toString();
         String testNo = getCurrentTestCaseDescriptor().getTestNumber();
         testLayoutPane.setTopologyConfig( testDesc, testNo, testTopology);

         // Reset all daemons setTesterService, assign current test
         TopologyConfigHelper helper = new TopologyConfigHelper();
         helper.reconfigureDaemonTesterService( testTopology, gui.getIssiTesterConfiguration());

         
      } catch(Exception ex) { 
         // ignore
      }
   }

   /**
    * Get the PTT mmf/smf allocation information from the Emulated RFSS.
    * 
    * @return
    * @throws Exception
    */
   public Hashtable<String, HashSet<PttSessionInfo>> getPttSessionInfo() {

      Hashtable<String, HashSet<PttSessionInfo>> retval = null;
      String urlStr = ISSIDtdConstants.URL_ISSI_DTD_RUNTIME_DATA;
      try {
         StringBuffer toParse = new StringBuffer();
         toParse.append("<?xml version=\"1.0\" ?>\n");
         toParse.append("<!DOCTYPE issi-runtime-data SYSTEM \"" + urlStr +"\">\n");
         toParse.append("<issi-runtime-data>\n");
         toParse.append(gui.getRemoteController().getRfssPttSessionInfo());
         toParse.append("\n</issi-runtime-data>");
         InputSource inputSource = new InputSource(new ByteArrayInputStream(
               toParse.toString().getBytes()));
         RfssRuntimeDataParser parser = new RfssRuntimeDataParser(inputSource);
         retval = parser.parse();

      } catch (Exception e) {
         logger.fatal("An unexpected parse exception occured", e);
      }
      return retval;
   }

   public void getSipPttTraces(boolean isInteractive) {

      //showln("getSipPttTraces: isInteractive=" + isInteractive);
      String sipTraces = null;
      setProgressScreenMessage("Getting SIP traces...");
      StringBuffer sbuf = new StringBuffer("<messages>\n");

      if (isInteractive) {
         try {
            if (gui.getTraceSource().equals("packet-monitor")) {
               sbuf.append(gui.getRemoteController().getSipTraces());
            } else {
               sbuf.append(gui.getRemoteController().getStackSipLogs());
            }
         } catch (Exception e) {
            logger.error("Error in fetching SIP traces", e);
            gui.showError("Error in fetching SIP traces: " + e.getMessage(), "Trace fetch error");
            return;
         }

      } else {
         try {
            sbuf.append(gui.getRemoteController().getStackSipLog());
         } catch (Exception e) {
            logger.error("Error in fetching SIP traces", e);
            gui.showError("Error in fetching SIP traces: " + e.getMessage(), "Trace fetch error");
            return;
         }
      }
      sbuf.append("</messages>");
      sipTraces = sbuf.toString();
      logger.debug("=== SIP TRACES: START ===\n");
      logger.debug(sipTraces);
      logger.debug("=== SIP TRACES: END ===\n");

      String pttTraces = null;
      sbuf = new StringBuffer("<pttmessages>\n");

      if (isInteractive) {
         try {
            if (gui.getTraceSource().equals("packet-monitor")) {
               sbuf.append(gui.getRemoteController().getPttTraces());
            } else {
               sbuf.append(gui.getRemoteController().getStackPttLogs());
            }
         } catch (Exception e) {
            logger.error("trace fetch error", e);
            gui.showError("Error in fetching PTT traces " + e.getMessage(),
                  "Trace fetch error");
            return;
         }
      } else {
         try {
            sbuf.append(gui.getRemoteController().getStackPttLog());
         } catch (Exception ex) {
            logger.error("Error in fetching PTT traces", ex);
            gui.showError("Error in fetching SIP traces: " + ex.getMessage(), "Trace fetch error");
            return;
         }
      }
      sbuf.append("</pttmessages>\n");
      pttTraces = sbuf.toString();
      logger.debug("=== PTT TRACES: START ===\n");
      logger.debug(pttTraces);
      logger.debug("=== PTT TRACES: END ===\n");

      Hashtable<String, HashSet<PttSessionInfo>> rfssSessionData = getPttSessionInfo();

      renderSipPttTraces(sipTraces, pttTraces, rfssSessionData, isInteractive, !isInteractive);

      gui.resetRemoteController();
      setProgressScreenMessage("Done.");

   }

   public void renderSipPttTraces(String sipTraces, String pttTraces,
         Hashtable<String, HashSet<PttSessionInfo>> rfssSessionData,
         boolean isInteractive, boolean toSave) {

      showln("TestExecutionPanel: renderSipPttTraces(): interactive="+isInteractive);
      //showln(" gui-global="+gui.getGlobalTopologyFileName());
      //showln(" gui-system="+gui.getSystemTopologyFileName());
      
      logger.debug("renderSipPttTraces: isInteractive " + isInteractive
            + " toSave " + toSave);
      boolean remoteRetrievalSucceeded = true;

      // First cancel the polling task
      if (testExecutionTimerTask != null)
         testExecutionTimerTask.cancel();

      Collection<RfssData> rfssList = null;
      String sipTab = "SIP-Ref-" + refTestNumber;
      String pttTab = "PTT-Ref-" + refTestNumber;
      if (isInteractive) {
         sipTab = "SIP-Test-" + runTestNumber;
         pttTab = "PTT-Test-" + runTestNumber;
      }
      try {
         try {
            Hashtable<String, Color> colorMap = new Hashtable<String, Color>();

            byte[] stringAsBytes = sipTraces.getBytes();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
                  stringAsBytes);

	    // Replaced with (true)
	    boolean interactive = isInteractive;
            TopologyConfig topologyConfig = getTopologyConfig(interactive,getCurrentTopologyName());
            
            SipTraceLoader traceLoader = new SipTraceLoader( byteArrayInputStream, 
                  rfssSessionData, colorMap, topologyConfig);

            rfssList = traceLoader.getSortedRfssList();

            List<MessageData> records = traceLoader.getRecords();
            String msgData = traceLoader.getMessageData();

            logger.debug("renderSipPttTraces: RTF SIP Traces... ");

            // Create a new tabbed panel
            sipTracePanel = new TracePanel(gui, gui.getJTabbedPane(),
                  currentTestName, rfssList, records, colorMap);

            sipTracePanel.setTitle(sipTab);
            sipTracePanel.setTestNumber(getCurrentTestCaseDescriptor().getTestNumber());
            sipTracePanel.setDataTextArea(TracePanel.DATA_ALL_MSG, msgData);


            // String sbufHex = HexDump.toHex( stringAsBytes, 16);
            // sipTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sbufHex);
            sipTracePanel.setDataTextArea(TracePanel.DATA_RAW_MSG, sipTraces);

            if (getSipTestError() != null) {
               sipTracePanel.setDataTextArea(TracePanel.DATA_ERROR_MSG, getSipTestError());
            }

            if (gui.getRemoteController() != null) {
               sipTracePanel.setTestResultLabel(gui.getRemoteController() .getTestResults());
            }

            // close existing tabs.
            addTraceToTabbedPanel(gui.getJTabbedPane(), sipTab, sipTracePanel);

            gui.getCloseMenuItem().setEnabled(true);
            gui.getCloseAllMenuItem().setEnabled(true);

         } catch (Exception ex) {
            logger.debug("Error in fetching SIP Trace: ", ex);
            ex.printStackTrace();
            remoteRetrievalSucceeded = false;

            String msg = "Error Fetching SIP Trace From Packet Monitor. "
                  + "Use File/Open to open SIP and PTT messages manually.\n";
            // sipTraceLogPane.logMessage( true, msg);
            testStatusPane.logMessage(true, msg);
         }
         // logger.debug("remoteRetrievalSucceeded="+remoteRetrievalSucceeded);

         // If remote retrieval of SIP traces failed, return here
         if (!remoteRetrievalSucceeded) {
            logger.debug("renderSipPttTraces: remoteRetrievalSucceeded... ");
            stopProgressMonitor();
            return;
         }

         // Now get PTT traces
         setProgressScreenMessage("Getting PTT traces...");

         try {
            if (pttTraces == null) {
               // There are no PTT traces so just return.
               stopProgressMonitor();
               return;
            }
            Hashtable<String, Color> colorMap = new Hashtable<String, Color>();

            logger.debug("ptt traces = " + pttTraces);

            //byte[] stringAsBytes = pttTraces.getBytes();
            //ByteArrayInputStream bais = new ByteArrayInputStream(stringAsBytes);
            //PttTraceLoader traceLoader = new PttTraceLoader(bais,colorMap);
            //List<MessageData> records = traceLoader.getRecords();
            //String msgData = traceLoader.getMessageData();

            // NOTE: use new PTT format
            //----------------------------
            //boolean keepHeader = false;
            boolean keepHeader = gui.getShowPttHeaderState();

            String title = "*** PTT Messages ***";
            XmlPttmessages xmlmsg = new XmlPttmessages(colorMap);
            Pttmessages pttmsg = xmlmsg.loadPttmessages(pttTraces);
            xmlmsg.getPttMessageData(pttmsg, keepHeader);
            List<MessageData> records = xmlmsg.getRecords();
            String msgData = xmlmsg.toISSIString( title, pttmsg, keepHeader);
            //----------------------------

            logger.debug("renderSipPttTraces: PTT TracePanel... ");

            // Create a new tabbed panel
            pttTracePanel = new TracePanel(gui, gui.getJTabbedPane(),
                  currentTestName, rfssList, records, colorMap);
            pttTracePanel.setTitle(pttTab);
            pttTracePanel.setTestNumber(getCurrentTestCaseDescriptor().getTestNumber());
            pttTracePanel.setDataTextArea(TracePanel.DATA_ALL_MSG, msgData);

            // String sbufHex = HexDump.toHex( stringAsBytes, 16);
            // pttTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sbufHex);
            pttTracePanel.setDataTextArea(TracePanel.DATA_RAW_MSG, pttTraces);

            if (gui.getRemoteController() != null) {
               pttTracePanel.setTestResultLabel(gui.getRemoteController().getTestResults());
            }

            addTraceToTabbedPanel(gui.getJTabbedPane(), pttTab, pttTracePanel);
            gui.getCloseMenuItem().setEnabled(true);
            gui.getCloseAllMenuItem().setEnabled(true);

         } catch (Exception ex) {
            String msg = "Error fetching PTT trace from PacketMonitor or Tester";
            setProgressScreenMessage(msg);
            msg += "\n" + ex.toString() + "\n";
            testStatusPane.logMessage(true, msg);
         }

      } catch (Throwable ex) {
         logger.debug("renderSipPttTraces: Throwable ex= " + ex);

      } finally {

         logger.debug("renderSipPttTraces: finally saveFiles()... ");
         stopProgressMonitor();
         try {
            if (toSave) {
               //TesterHelper.saveFiles(false);
               showln("*** sendSaveiTestFiles()...");
               testerService.sendSaveTestFiles();
            }
         } catch (Exception ex) {
            logger.error("Error saving files", ex);
         }
      }
   }

   private void addTraceToTabbedPanel(JTabbedPane tabbedPane, String tab,
         TracePanel tracePanel) {

      javax.swing.SwingUtilities.invokeLater(new Runnable() {
         private JTabbedPane tabbedPane;
         private String tab;
         private TracePanel tracePanel;

         public Runnable setParams(JTabbedPane tabbedPane, String tab,
               TracePanel tracePanel) {
            this.tabbedPane = tabbedPane;
            this.tab = tab;
            this.tracePanel = tracePanel;
            return this;
         }

         public void run() {
            tabbedPane.add(tab, tracePanel);
            tabbedPane.setSelectedComponent(tracePanel);
         }
      }.setParams(tabbedPane, tab, tracePanel));
   }

   private TopologyConfig getTopologyConfig(String curTopologyName)
      throws Exception {
      return getTopologyConfig( true, curTopologyName);
   }
   private TopologyConfig getTopologyConfig(boolean isInteractive, String curTopologyName)
      throws Exception {

      String topologyFileName = ISSITesterConstants.getScenarioDir() + "/" + curTopologyName;

      showln("\n*** TestExecPanel: getTopologyConfig ***");
      showln("  standalone: " + standalone);
      showln("  interactive: " + isInteractive);
      showln("  testerConfiguration: " + gui.getTesterConfigurationFile());
      showln("  systemTopologyName:  " + gui.getSystemTopologyFileName());
      showln("  globalTopologyName:  " + gui.getGlobalTopologyFileName());
      showln("  topologyFileName:    " + topologyFileName);

      TopologyConfig systemTopology = new SystemTopologyParser(
            gui.getIssiTesterConfiguration()).parse(gui.getSystemTopologyFileName());

      //GlobalTopologyParser globalTopologyParser = new GlobalTopologyParser(true);
      GlobalTopologyParser globalTopologyParser = new GlobalTopologyParser(isInteractive, standalone);
      TopologyConfig globalTopology = globalTopologyParser.parse(
            systemTopology, gui.getGlobalTopologyFileName());

      TopologyConfigParser parser = new TopologyConfigParser();
      TopologyConfig testTopology = parser.parse(globalTopology, topologyFileName);

      return testTopology;
   }
         
   private String formatLocalTopology(boolean xmlform) {
      try {
         TopologyConfig testTopology = getTopologyConfig( getCurrentTopologyName());
	 if( xmlform ) {
            String xmlStr = "<!-- Global Topology -->\n";
            xmlStr += testTopology.exportGlobalTopology();
            xmlStr += "\n\n<!-- System Topology -->\n";
            xmlStr += testTopology.exportSystemTopology();
	    return xmlStr;
	 } 
         else {
            return testTopology.getDescription();
         }

      } catch (Exception ex) {
         String msg = "Could not parse topology config file: " + getCurrentTopologyName();
         logger.error(msg, ex);
         JOptionPane.showMessageDialog(null, msg,
               "Parse File Status",
               JOptionPane.ERROR_MESSAGE);
         return "";
      }
   }

   private void startTestExecutionTimerTask(int millisec, boolean interactive) {

      // Wait TEST_TIMEOUT before trying to retrieve traces.
      testExecutionTimerTask = new TestExecutionTimerTask(gui,millisec,interactive);
      getTimer().schedule(testExecutionTimerTask, 0, 1000);
   }

}
