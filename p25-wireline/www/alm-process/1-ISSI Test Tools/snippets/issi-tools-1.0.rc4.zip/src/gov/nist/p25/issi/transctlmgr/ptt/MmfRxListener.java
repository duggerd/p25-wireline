/* This software was developed by employees of the National Institute of
 * Standards and Technology (NIST), an agency of the Federal Government.
 * Pursuant to title 15 United States Code Section 105, works of NIST
 * employees are not subject to copyright protection in the United States
 * and are considered to be in the public domain.  As a result, a formal
 * license is not needed to use the software.
 * 
 * The ISSI Emulator software is provided by NIST as a service and is expressly
 * provided "AS IS".  NIST MAKES NO WARRANTY OF ANY KIND, EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT
 * AND DATA ACCURACY.  NIST does not warrant or make any representations
 * regarding the use of the software or the results thereof including, but
 * not limited to, the correctness, accuracy, reliability or usefulness of
 * the software.
 * 
 * Permission to use this software is contingent upon your acceptance
 * of the terms of this agreement.
 */
package gov.nist.p25.issi.transctlmgr.ptt;

/**
 * This class defines the listener methods for an MMF.
 * 
 * @author steveq@nist.gov
 * @version $Revision: 1.5 $, $Date: 2007/03/29 23:11:44 $
 * @since 1.5
 * @see ISSI spec v8, Section 7.2, Figure 65 Summary of Transitions
 */
public interface MmfRxListener {

	/**
	 * Process an incoming spurt request.
	 * 
	 * @param event
	 */
	public void receivedPttRequest(MmfPacketEvent event);
	
	/**
	 * Process an incoming spurt request.
	 * 
	 * @param event
	 */
	public void receivedPttRequestWithVoice(MmfPacketEvent event);
	
	/**
	 * Indicates to the listener that an audio packet has arrived.
	 * 
	 * @param event
	 *            The received PTT packet event.
	 */
	public abstract void receivedPttProgress(MmfPacketEvent event);

	/**
	 * Process a spurt end event.
	 * 
	 * @param event
	 */
	public abstract void receivedPttEnd(MmfPacketEvent event);
	
	/**
	 * Indicates a timeout waiting for PROGRESS (audio) packets.
	 */
	public abstract void audioTimeout();

	
}