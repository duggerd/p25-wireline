//
package gov.nist.p25.issi.transctlmgr.ptt;

import gov.nist.p25.issi.ISSITimer;
import gov.nist.p25.issi.issiconfig.RfssConfig;
//import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.p25payload.*;
import gov.nist.rtp.RtpPacket;
import gov.nist.rtp.RtpSession;

//import java.io.PrintWriter;
import java.util.*;
import org.apache.log4j.Logger;

/**
 * This class handles sending connection maintenance heartbeats. This class does
 * NOT handle MUTE-related heartbeats.
 * 
 * @author mranga@nist.gov
 * @author steveq@nist.gov
 * @version $Revision: 1.16 $, $Date: 2007/08/21 04:06:22 $
 * @since 1.5
 */
public class HeartbeatTransmitter {

	/***************************************************************************
	 * Variables
	 **************************************************************************/	
	/** The mute transmission heartbeat task. */
	SendHeartbeatsTask sendHeartbeatsTask = null;

	/**
	 * Used to test heartbeat receive timeout by blocking outgoing heartbeat
	 * transmission.
	 */
	private boolean blockOutgoingHeartbeatTransmission = false;

	/** The logger for this class. */
	protected static Logger logger = Logger
			.getLogger(HeartbeatTransmitter.class);

	boolean querySent = false;
	
	private String sessionType;

	private LinkType linkType;

	private RtpSession rtpSession;

	private RfssConfig owningRfssConfig;
	
	private PttSessionInterface pttSession;

	/***************************************************************************
	 * Constructors
	 **************************************************************************/

	/**
	 * Construct a connection hearbeat transmitter (this is not the same as a
	 * MUTE transmission heartbeat transmitter).
	 * 
	 * @param pttSession
	 *            The owning PTT session.
	 */
	HeartbeatTransmitter(PttSessionInterface pttSession) {
		logger.debug("Creating new heartbeat transmitter");
		this.sessionType = pttSession.getSessionType();
		this.linkType = pttSession.getLinkType();
		this.rtpSession = pttSession.getRtpSession();
		this.owningRfssConfig = pttSession.getOwningRfss();
		this.pttSession = pttSession;
	}
	
	private void sendPttPacket(P25Payload p25Payload) throws Exception {
		
		RtpPacket rtpPacket = new RtpPacket();

		// The NIST RTP stack already define default values for some of these,
		// but we set each here for testing purposes.
		rtpPacket.setV(2);
		rtpPacket.setP(0);
		rtpPacket.setX(0);
		rtpPacket.setCC(0);
		rtpPacket.setM(0);
		rtpPacket.setPT(100);
		rtpPacket.setTS(0);
		rtpPacket.setSSRC(linkType.getValue());
		byte[] payload = p25Payload.getBytes();
		rtpPacket.setPayload(payload,payload.length);
		if (rtpSession.getRemoteRtpRecvPort() != -1) {
			if ( logger.isDebugEnabled()) {
				logger.debug("HeartbeatTransmitter: sendPttPacket " +
						p25Payload.getISSIPacketType() +
						" remote port = " + rtpSession.getRemoteRtpRecvPort());
			}

			rtpSession.sendRtpPacket(rtpPacket);
			// Log the outgoing packet if we are sending to another host
			// (other than ourselves).
			if (!rtpSession.getRemoteIpAddress().equals(
					rtpSession.getMyIpAddress().getHostAddress())) {
				this.owningRfssConfig.getRFSS().capturePttPacket(rtpPacket, p25Payload, true,this.pttSession);
			}

		} else {
			if ( logger.isDebugEnabled()) {
				logger.debug("HeartbeatTransmitter:sendPttPacket: cannot send packet " +
						p25Payload.getISSIPacketType() +
						" remote port = " + rtpSession.getRemoteRtpRecvPort());
			}
		}
		

	}

	/***************************************************************************
	 * Methods
	 **************************************************************************/

	/**
	 * This method sends a heartbeat.
	 * 
	 * @see TIA Specification Section 7.6.10
	 */
	public void sendHeartbeat() {

		P25Payload p25Payload = PttSession.createHeartbeatConnection();

		try {

			if (!blockOutgoingHeartbeatTransmission) {

				if (logger.isDebugEnabled())
					logger.debug(sessionType
							+ " sending HEARTBEAT TSN=0");

				this.sendPttPacket(p25Payload);

			} else {

				if (logger.isDebugEnabled())
					logger.debug(sessionType
							+ " blocked sending HEARTBEAT TSN=0");

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	/**
	 * This method sends a heartbeat query.
	 * 
	 * @see TIA Specification Section 7.6.10
	 */
	public void sendHeartbeatQuery() {

		P25Payload p25Payload = PttSession.createHeartbeatQuery();
			
		try {

			if (!blockOutgoingHeartbeatTransmission) {

				if (logger.isDebugEnabled())
					logger.debug(sessionType
							+ " sending HEARTBEAT QUERY TSN=0");

				this.sendPttPacket(p25Payload);

			} else {

				if (logger.isDebugEnabled())
					logger.debug(sessionType
							+ " blocked sending HEARTBEAT TSN=0");

			}

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	/**
	 * This method is used to test MMF Rx audio timeout by blocking transmission
	 * of audio from this SMF Tx.
	 */
	public void blockOutgoingHearbeats() {

		blockOutgoingHeartbeatTransmission = true;

	}

	/**
	 * Start the transmitter. This has to be a separate method because
	 * in call processing, you cannot send hearbeat until the ACK is seen.
	 * The transmitter is created but not started until the ACK.
	 */
	public void start() {
//		 Start sending heartbeats
		if ( sendHeartbeatsTask != null ) return;
			sendHeartbeatsTask = new SendHeartbeatsTask();

		if ( sessionType.equalsIgnoreCase("MMF") )
			sendHeartbeatQuery();
		
		ISSITimer.getTimer().schedule(sendHeartbeatsTask, TimerValues.THEARTBEAT,
				TimerValues.THEARTBEAT);
	}
	/**
	 * Stop this and exit all timers.
	 */
	public void stop() {
		if ( sendHeartbeatsTask != null) {
			this.sendHeartbeatsTask.cancel();
			this.sendHeartbeatsTask = null;
		}
	}
	/***************************************************************************
	 * Inner Classes
	 **************************************************************************/

	/**
	 * This class sends CONNECTION MAINTENANCE heartbeats with TSN=0. This class
	 * does NOT handle MUTE TRANSMISSION heartbeats.
	 * 
	 * @see TIA-109.BACA Section 7.5.1
	 */
	class SendHeartbeatsTask extends TimerTask {
		public void run() {

			try {

				if (!blockOutgoingHeartbeatTransmission) {

					if (logger.isDebugEnabled())
						logger.debug(sessionType
								+ " sending HEARTBEAT TSN=0");
					 if (rtpSession.getRemoteRtpRecvPort() > 0) {
						P25Payload p25Payload = PttSession.createHeartbeatConnection();
							//	.createPttPacket(PacketType.HEARTBEAT_CONNECTION);

						HeartbeatTransmitter.this.sendPttPacket(p25Payload);
					} else {
						logger
								.debug("Not sending heartbeat because port is not set " +
										rtpSession.getRemoteRtpRecvPort());
					}

				} else {

					if (logger.isDebugEnabled())
						logger.debug(sessionType
								+ " blocked sending HEARTBEAT TSN=0");

				}

			} catch (Exception e) {

				e.printStackTrace();

			}

		}

	}
	
	

}
