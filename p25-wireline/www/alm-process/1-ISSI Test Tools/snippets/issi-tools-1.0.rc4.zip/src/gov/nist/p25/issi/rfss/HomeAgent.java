//
package gov.nist.p25.issi.rfss;

import java.util.EventObject;

import javax.sip.ResponseEvent;
import javax.sip.address.Address;
import javax.sip.address.SipURI;
import javax.sip.header.ContactHeader;
import javax.sip.header.ToHeader;
import javax.sip.message.Request;
import javax.sip.message.Response;

import org.apache.log4j.Logger;

import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;

/**
 * This is the controlling SU that runs at the HOME rfss of the SU. It keeps the
 * state associated with the SU and does whatever actions need to be performed
 * at the home RFSS. Each SU has a controlling SU registered at the Home RFSS
 * for this purpose.
 * 
 */
@SuppressWarnings("unused")
public class HomeAgent implements HomeAgentInterface {

   private static Logger logger = Logger.getLogger(HomeAgent.class);

   private ContactHeader oldContact;
   private EventObject pendingEvent;
   private RFSS homeRfss;
   private ServiceAccessPoints saps;
   private SuConfig suConfig;
   private TopologyConfig topologyConfig;
   private UnitToUnitCall unitToUnitCall;
   private boolean pendingCallSetupRequest;

   public HomeAgent(SuConfig suConfig, TopologyConfig topologyConfig,
         RFSS homeRfss) {
      this.suConfig = suConfig;
      this.topologyConfig = topologyConfig;
      this.homeRfss = homeRfss;
   }

   /*
    * (non-Javadoc)
    * 
    * @see gov.nist.p25.issi.rfss.HomeAgentInterface#handleCallSetupResponseEvent(
    * gov.nist.p25.issi.rfss.UnitToUnitCallControlResponseEvent)
    */
   public void handleCallSetupResponseEvent(UnitToUnitCallControlResponseEvent ccResponseEvent) {
      try {
         ResponseEvent responseEvent = ccResponseEvent.getResponseEvent();
         if (pendingCallSetupRequest) {
            if (responseEvent.getResponse().getStatusCode() / 100 == 2) {
               unitToUnitCall = ccResponseEvent.getCallSegment();
               saps.getCallControlSAP().ccSetupConfirm(ccResponseEvent);
            }
         } else {
            // Store the call segment in our state.
            if (responseEvent.getResponse().getStatusCode() / 100 == 2) {
               unitToUnitCall = ccResponseEvent.getCallSegment();
            }
         }
      } catch (Exception ex) {
         throw new RuntimeException("Unexpected exception", ex);
      }
   }

   /*
    * (non-Javadoc)
    * 
    * @see gov.nist.p25.issi.rfss.HomeAgentInterface#handleTeardownResponse(gov.nist.p25.issi.rfss.CallTeardownResponseEvent)
    */
   public void handleTeardownResponse(CallTeardownResponseEvent ccTeardownEvent) {
      try {
         logger.info("HomeAgent: got a call teardown response "
               + "... sending REinvite at the new called serving");

         /*
          * We initated a teardown because of the SU moving.
          */
         if (pendingEvent  != null && pendingEvent instanceof RegisterEvent) {
            Request request = ((RegisterEvent) pendingEvent).serverTransaction.getRequest();
            
            RegisterEvent registerEvent = (RegisterEvent) this.pendingEvent;
            if (registerEvent.eventType == RegisterEvent.REGISTER_REGISTER) {

               this.homeRfss.getTestHarness().assertTrue(
                     this.suConfig == this.unitToUnitCall.getCalledSuConfig()
                  || this.suConfig == this.unitToUnitCall.getCallingSuConfig());
               this.homeRfss.getTestHarness().assertTrue(
                     this.suConfig.getHomeRfss() == this.saps.getCallControlSAP().getRfssConfig());
               // Get the contact header from the REGISTER request that we
               // have stored away
               ContactHeader contactHeader = (ContactHeader) request
                     .getHeader(ContactHeader.NAME);
               this.saps.getMobilityManagementSAP().mmRoamedRequest(
                     unitToUnitCall, contactHeader, oldContact);

               CallControlSAP ccSap = this.saps.getCallControlSAP();
               // Re-invite myself at my new location
               this.pendingCallSetupRequest = true;

               UnitToUnitCall unitToUnitCall = ccTeardownEvent.getCallSegment();
               logger.debug("Unit to unit call teardown " + unitToUnitCall);
               pendingEvent = null;

               ccSap.ccSendCallSetupInCallRoamingRequest(getSuConfig(),
                     unitToUnitCall,
                     ((SipURI) oldContact.getAddress().getURI()).getHost(),
                     (Address) contactHeader.getAddress().clone());               
            }
         }
      } catch (Exception ex) {
         logger.error("HomeAgent: Unexpected exception ",ex);
         throw new RuntimeException("Unexpected exception", ex);
      }
   }
   
   public void setServiceAccessPoints(ServiceAccessPoints saps) {
      this.saps = saps;
   }

   public void handleRegistrationEvent(RegisterEvent registerEvent) {
      try {
         logger.info("Got a register event");

         // This method gets invoked at the home RFSS when the registration
         // state changes.
         if (registerEvent.eventType == RegisterEvent.REGISTER_REGISTER) {
            oldContact =  saps.getMobilityManagementSAP().getCurrentRegistration();
            Request request = registerEvent.serverTransaction.getRequest();
            ToHeader toHeader = (ToHeader) request.getHeader(ToHeader.NAME);
            SipURI toURI = (SipURI) toHeader.getAddress().getURI();
            String radicalName = toURI.getUser();

            if (unitToUnitCall != null) {
               pendingEvent = registerEvent;
               saps.getCallControlSAP().ccTeardownCallSegment(
                     this, unitToUnitCall, radicalName);

            } else {

               ContactHeader contactHeader = (ContactHeader) request
                     .getHeader(ContactHeader.NAME);
               if (!oldContact.equals(contactHeader)) {
                  if (logger.isDebugEnabled()) {
                     logger.debug("old contact == " + oldContact);
                     logger.debug("new contact == " + contactHeader);
                  }
                  homeRfss.getMobilityManager()
                        .getUnitToUnitMobilityManager().sendMMRoamed(
                              suConfig, contactHeader, oldContact, null);
               }

            }
         }
      } catch (Exception ex) {
         logger.error("unexpected exception", ex);
         homeRfss.logError("unexpected exception ex", ex);
      }
   }

   public ServiceAccessPoints getServiceAccessPoints() {
      return saps;
   }

   public SuConfig getSuConfig() {
      return suConfig;
   }

   public void handleDeRegistrationEvent(RegisterEvent event) {
      try {
         homeRfss.getMobilityManager().getUnitToUnitMobilityManager()
               .sendRegisterResponse(event, Response.OK);
      } catch (Exception ex) {
         logger.error("unexpected exception", ex);
         homeRfss.getTestHarness().fail("unexpected exception", ex);
      }
   }

   public void handleTeardownIndicate(
         CallTeardownIndicateEvent callTeardownIndicateEvent) {
      logger.debug("HomeAgent: handleTeardownIndicate");
   }
}
