//
package gov.nist.p25.issi.rfss.tester;

/**
 * Milli-second Time Trigger
 */
public class MsecTimeTrigger extends TimeTrigger {

   public MsecTimeTrigger(int value) {
      super(value);
   }
}
