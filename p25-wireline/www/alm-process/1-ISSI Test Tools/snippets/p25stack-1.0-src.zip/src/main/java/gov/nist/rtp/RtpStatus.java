//
package gov.nist.rtp;

/**
 * Rtp status events.
 * 
 */
public enum RtpStatus {

   RECEIVER_STOPPED, RECEIVER_STARTED;
}
