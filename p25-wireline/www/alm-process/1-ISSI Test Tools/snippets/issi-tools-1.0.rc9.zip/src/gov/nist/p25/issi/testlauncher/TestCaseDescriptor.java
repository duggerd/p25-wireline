//
package gov.nist.p25.issi.testlauncher;

/**
 * This describes a stanza in the test case registry. Each test case has a
 * directory and is described by some text (based on the test document) and
 * has a test number which corresponds to the test document.
 * 
 */
public class TestCaseDescriptor {
   
   private String category;
   private String directoryName;
   private String testNumber;
   private String testDescription;   
   private String topologyName;
   // conformance,capp
   private String testClass;

   // accessors
   public String getCategory() {
      return category;
   }

   public String getDirectoryName() {
      return directoryName;
   }
   public String getFileName() {
      return directoryName + "/testscript.xml";
   }

   public String getTestNumber() {
      return testNumber;
   }

   public String getTestDescription() {
      return testDescription + 
         "\nNOTE: ADDITIONAL SIGNALING FOR SETUP AND TEARDOWN\n" +
         "OF TEST IS INCLUDED IN CALL FLOW";
   }
   public void setTestDescription(String testDescription) {
      this.testDescription = testDescription.trim();
   }

   public String getTopologyFileName() {
      return directoryName + "/" + topologyName;
   }   

   public String getTestClass() {
      return testClass;
   }
   public void setTestClass(String testClass) {
      this.testClass = testClass;
   }

   // constructor
   public TestCaseDescriptor(String directory, String topologyName, String testNumber,
      String category) {
      this(directory, topologyName, testNumber, category, "conformance");
   }
   public TestCaseDescriptor(String directory, String topologyName, String testNumber,
      String category, String testClass) {
      this.directoryName = directory;
      this.testNumber = testNumber;
      this.category = category;
      this.topologyName = topologyName;   
      this.testClass = testClass;   
   }

   public String toString() {
      return testNumber + " : " + directoryName;
   }
}
