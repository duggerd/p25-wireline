//
package gov.nist.p25.issi.traceviewer;


import javax.sip.header.CSeqHeader;
import javax.sip.message.Message;
import javax.sip.message.Request;
import javax.sip.message.Response;

import org.apache.log4j.Logger;


public class SipMessageData extends MessageData 
      implements Comparable<SipMessageData> 
{
   private static Logger logger = Logger.getLogger(SipMessageData.class);
   
   private String timeStamp;
   private String transactionId;
   private Message sipMessage;
   
   // accessors
   public String getTimeStamp() {
      return timeStamp;
   }

   public String getTransactionId() {
      return transactionId;
   }

   public Message getSipMessage() {
      return this.sipMessage;    
   }
   public void setSipMessage(Message sipMessage) {
      if (sipMessage == null)
         throw new NullPointerException("SipMessageData: set null sipMessage");
      this.sipMessage = sipMessage;
   }
   
   // constructor
   public SipMessageData(String fromRfssId, String toRfssId, String fromPort,
         String toPort, String messageType, String data, String time,
         String timeStamp, String transactionId, boolean selected)
   {
      super(fromRfssId, toRfssId, fromPort, toPort, messageType, data, time,
            transactionId, selected, false);
      if( data == null)
         throw new NullPointerException("SipMessageData: null data!");
      this.timeStamp = timeStamp;
      this.transactionId = transactionId;
   }

//   private String getKey() {
//      if (timeStamp != null) {
//         return messageType + transactionId + ":" + timeStamp;
//      } else {
//         // Generate a random time stamp
//         return messageType + transactionId + ":"
//               + (int) (Math.random() * 1000);
//      }
//   }


   /**
    * Format a via header as RTF. Note that we only store the last four
    * significant digits of the branch ( should be random enough for a single
    * call flow).
    * 
    */
   /*****
   private static String formatViaHeader(ViaHeader viaHeader) {
      StringBuffer sbuf = new StringBuffer();

      String branch = viaHeader.getBranch();
      String restOfBranch = branch.substring("z9hG4bK".length());
      sbuf.append(HEADER_START
            + ViaHeader.NAME
            + ": SIP/2.0/UDP "
            + viaHeader.getHost()
            + ";branch=z9hG4bK"
            + IGNORED_FIELD
            + restOfBranch.substring(restOfBranch.length() - 4,
                  restOfBranch.length()) + HEADER_END);
      return sbuf.toString();

   }

   private static String formatMaxForwardsHeader(
         MaxForwardsHeader maxForwardsHeader) {
      return new StringBuffer().append(HEADER_START).append(
            MaxForwardsHeader.NAME).append(": ").append(IGNORED_FIELD)
            .append(maxForwardsHeader.getMaxForwards()).append(HEADER_END)
            .toString();
   }

   private static String formatExpiresHeader(ExpiresHeader expiresHeader) {
      StringBuffer sbuf = new StringBuffer();
      if (expiresHeader.getExpires() == 0) {
         return sbuf.append(HEADER_START).append(expiresHeader.toString())
               .append(HEADER_END).toString();

      } else {
         return sbuf.append(HEADER_START).append(ExpiresHeader.NAME).append(
               ": ").append(IGNORED_FIELD).append(
               expiresHeader.getExpires()).append(HEADER_END).toString();
      }
   }

   private static String formatFromHeader(FromHeader fromHeader) {
      StringBuffer sbuf = new StringBuffer();

      return sbuf.append(HEADER_START).append(FromHeader.NAME).append(": ")
            .append(fromHeader.getAddress().toString()).append(";tag=")
            .append(IGNORED_FIELD).append(fromHeader.getTag()).append(
                  HEADER_END).toString();
   }

   private static String formatToHeader(ToHeader toHeader) {
      StringBuffer sbuf = new StringBuffer();
      if (toHeader.getTag() != null) {
         return sbuf.append(HEADER_START).append(ToHeader.NAME).append(": ")
               .append(toHeader.getAddress().toString()).append(";tag=")
               .append(IGNORED_FIELD).append(toHeader.getTag()).append(
                     HEADER_END).toString();
      } else {
         return sbuf.append(HEADER_START).append(ToHeader.NAME).append(": ")
               .append(toHeader.getAddress().toString())
               .append(HEADER_END).toString();
      }
   }

   private static String formatCSeqHeader(CSeqHeader cseqHeader) {
      StringBuffer sbuf = new StringBuffer();
      return sbuf.append(HEADER_START).append(CSeqHeader.NAME + ": ").append(
            IGNORED_FIELD).append((int) cseqHeader.getSeqNumber()).append(
            HEADER_RESTART).append(cseqHeader.getMethod()).append(
            HEADER_END).toString();
   }

   private static String formatCallIdHeader(CallIdHeader callIdHeader) {
      StringBuffer sbuf = new StringBuffer();
      return sbuf.append(HEADER_START).append(CallIdHeader.NAME).append(": ")
            .append(IGNORED_FIELD).append(callIdHeader.getCallId()).append(
                  HEADER_END).toString();
   }

   private static String formatLine(String line) {
      return (HEADER_START + line + HEADER_END);
   }

   private static String formatWarningHeader(WarningHeader warningHeader) {
      return new StringBuffer().append(OPTIONAL_HEADER).append(
            warningHeader.toString()).append(HEADER_END).toString();
   }
    *****/

   @Override
   public boolean equals(Object other) {
      return this.hashCode() == other.hashCode();
   }

   @Override
   public int hashCode() {
      return super.hashCode();
   }

   public int compareTo(SipMessageData m2) {
      SipMessageData m1 = this;
      try {
         long ts1 = Long.parseLong(m1.getTime());
         long ts2 = Long.parseLong(m2.getTime());
         if (ts1 < ts2)
            return -1;
         else if (ts1 > ts2)
            return 1;
         else {
            if (m2.sipMessage instanceof Response 
                  && m1 instanceof Request
                  && m2.transactionId.equals(m1.transactionId)) {
               return -1;
            } else if (m1.sipMessage instanceof Response
                  && m2 instanceof Request
                  && !((CSeqHeader) m1.sipMessage
                        .getHeader(CSeqHeader.NAME)).getMethod()
                        .equals(m2.sipMessage.getHeader(CSeqHeader.NAME))) {
               return -1;
            } else if (m2.sipMessage instanceof Response 
                  && m1 instanceof Response
                  && m2.transactionId.equals(m1.transactionId)) {
               // #166
               // Request: INVITE
               // Response: 403 Forbidden followed by ACK
               logger.debug("compareTo(): Request, error response, ACK response...");
               return -1;
            } else {
//TODO: can this a problem ?
               String type = getMessageType();
               if( type.startsWith(Request.ACK)) {
                  logger.debug("compareTo(): ACK sip default return of 1 !!!");
                  return 1;
               } else {
                  // error reponse
                  logger.debug("compareTo(): default return of -1 !!! "+type);
                  return -1;
               }
            }
         }

      } catch (NumberFormatException ex) {
         ex.printStackTrace();
         //System.exit(0);
         return 0;
      }
   }

   @Override
   public String getData() {
      String output = super.getData();
      try {
         output = SipMessageFormatter.format(output);
      } catch(Exception ex) {
         logger.debug("Failed to format SIP message to a fixed order, use native.");
      }
      return output;
   }
   
   @Override
   public String toString() {
      StringBuffer sb = new StringBuffer();
      if( timeStamp != null)
         sb.append(" timeStamp=\"" + timeStamp + "\"\n");
      sb.append(" fromRfssId=\"" + getFromRfssId() + "\"\n");
      sb.append(" toRfssId=\"" + getToRfssId() + "\"\n");
      sb.append(" transactionId=\"" + transactionId + "\"\n");
      sb.append("<sip-message>\n");
      sb.append(sipMessage == null ? "": sipMessage.toString());
      sb.append("</sip-message>\n");
      return sb.toString();
   }
}
