//
package gov.nist.p25.issi.transctlmgr.ptt;

/**
 * This class implements ISSI link types.
 */
public enum LocalPolicy {
   SELF_GRANT ,
   DENY
}
