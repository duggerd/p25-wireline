//
package gov.nist.p25.issi.traceviewer;

import java.awt.Color;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Hashtable;
import java.util.TreeSet;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;

//import org.apache.log4j.Logger;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;


/**
 * This class implements a PTT XML trace file loader.
 * 
 */
public class PttTraceLoader extends DefaultHandler 
   implements TraceLoader {

   //private static Logger logger = Logger.getLogger(PttTraceLoader.class);

   private Properties props = new Properties();
   private TreeSet<MessageData> messageList;
   private Hashtable<String, Color> colorMap;
   private String myIpAddress = "";
   private String myRtpRecvPort = "";
   private String myRfssId = "";
   private String remoteRtpRecvPort = "";
   private String remoteRfssId = "";
   private String messageType = "";
   private String pttMessageData = "";
   private String rtfData = "";
   private String receptionTime = "";
   private boolean isSender;
   private boolean inRtfFormat;
   private String sequenceNumber = "";
   private String rawdata = "";
   
   // accessors
   public String getMyIpAddress() {
      return myIpAddress;
   }

   // constructors
   public PttTraceLoader(InputStream inputStream)
      throws Exception
   {
      this( inputStream, new Hashtable<String, Color>());
   }
   
   public PttTraceLoader(InputStream inputStream,
         Hashtable<String, Color> colorMap)
      throws Exception
   {
      this.messageList = new TreeSet<MessageData>();
      this.colorMap = colorMap;

      SAXParserFactory factory = SAXParserFactory.newInstance();
      try {
         SAXParser saxParser = factory.newSAXParser();
         saxParser.parse(inputStream, this);
      } catch (Exception ex) {
         ex.printStackTrace();
         throw ex;
      }
   }

   public void startElement(String namespaceURI, String localName,
         String qualifiedName, Attributes attrs) throws SAXException {

      String elementName = localName;
      if ("".equals(elementName)) {
         elementName = qualifiedName;
      }

      if (!elementName.equals("rtf-format") && 
            !elementName.equals("trace") &&
            !elementName.equals("pttmessages"))
         pttMessageData += elementName + "\n";

      if (elementName.equals("rtf-format"))
         inRtfFormat = true;

      if (attrs != null && !elementName.equals("rtf-format")) {

         for (int i = 0; i < attrs.getLength(); i++) {

            String attributeName = attrs.getLocalName(i);
            if ("".equals(attributeName)) {
               attributeName = attrs.getQName(i);
            }

            // Here is the key:value pair that user sees
            pttMessageData += "\t" + attributeName + " = "
                  + attrs.getValue(i) + "\n";
            String propname = elementName + "." + attributeName;

            // Capture the fields for pattern matching.
            if (propname.equals("ptt-packet.receivingRfssId")
                  || propname.equals("ptt-packet.sessionType")
                  || propname.equals("rtp-header.version")
                  || propname.equals("rtp-header.padding")
                  || propname.equals("rtp-header.marker")
                  || propname.equals("rtp-header.headerExtension")
                  || propname.equals("rtp-header.csrcCount")
                  || propname.equals("rtp-header.payloadType")
                  || propname.equals("rtp-header.SSRC")
                  || propname.equals("control-octet.signalBit")
                  || propname.equals("control-octet.compactBit")
                  || propname.equals("block-header.payloadType")
                  || propname.equals("block-header.blockType")
                  || propname.equals("issi-packet-type.muteStatus")
                  || propname.equals("issi-packet-type.losingAudio")
                  || propname.equals("issi-packet-type.serviceOptions")
                  || propname.equals("issi-packet-type.packetType")) {
               props.setProperty(elementName + "." + attributeName,
                     attrs.getValue(i));
            }
            handleAttribute(attributeName, attrs.getValue(i));
         }
      }
   }

   public void handleAttribute(String attrName, String attrValue) {

      if (attrName.equals("myIpAddress")) {
         myIpAddress = attrValue;
      } else if (attrName.equals("receivingRfssId")) {
         myRfssId = attrValue;
      } else if (attrName.equals("isSender")) {
         isSender = attrValue.equals("true");
      } else if (attrName.equals("rawdata")) {
         rawdata = attrValue;
      } else if (attrName.equals("myRtpRecvPort")) {
         myRtpRecvPort = attrValue;
      } else if (attrName.equals("sendingRfssId")) {
         remoteRfssId = attrValue;
      } else if (attrName.equals("remoteRtpRecvPort")) {
         remoteRtpRecvPort = attrValue;
      } else if (attrName.equals("packetType")) {
         messageType = attrValue;
         if (colorMap != null) {
            if (!colorMap.containsKey(attrValue)) {
               colorMap.put(attrValue, Color.black);
            }
         }
      } else if (attrName.equals("packetNumber")) {
         sequenceNumber = attrValue;
      } else if (attrName.equals("receptionTime")) {
         receptionTime = attrValue;
      }
   }

   public void endElement(String namespaceURI, String simpleName,
         String qualifiedName) throws SAXException {

      if (qualifiedName.equals("rtf-format")) {
         inRtfFormat = false;
      }
      if (qualifiedName.equals("ptt-packet")) {

         if (!pttMessageData.equals("")) {

            PttMessageData messageData = new PttMessageData(remoteRfssId,
                  myRfssId, myRtpRecvPort, remoteRtpRecvPort,
                  messageType, pttMessageData, receptionTime, sequenceNumber,
                  rtfData, false, isSender, props);

            //System.out.println("setRawdata=<"+rawdata+">");
            messageData.setRawdata( rawdata);
            messageList.add(messageData);

            // Reset data
            props = new Properties();
            isSender = false;
            myIpAddress = "";
            myRfssId = "";
            myRtpRecvPort = "";
            remoteRtpRecvPort = "";
            messageType = "";
            pttMessageData = "";
            receptionTime = "";
            sequenceNumber = "";
            remoteRfssId = "";
            rtfData = "";
            rawdata = "";
         }
      }
   }

   public void characters(char buf[], int offset, int len) throws SAXException {
      String s = new String(buf, offset, len);
      if (!inRtfFormat) {
         if (s.length() > 8)
            pttMessageData += "\t" + s + "\n";
      } else {
         this.rtfData += s;
      }
   }

   public List<MessageData> getRecords(String rfssDomainName) {
      List<MessageData> alist = new ArrayList<MessageData>();
      for (MessageData mdata : messageList) {
         if ( mdata.getToRfssId().equals(rfssDomainName))
            alist.add(mdata);
      }
      return alist;
   }

   public List<MessageData> getRecords() {
      int counter = 0;
      ArrayList<MessageData> alist = new ArrayList<MessageData>();
      for (MessageData mdata: messageList) {
         mdata.setId(++counter);
         alist.add(mdata);
      }
      return alist;
   }
   
   public String getMessageData() {
      StringBuffer sbuf = new StringBuffer();
      for (MessageData mdata: getRecords()) {
         sbuf.append("F" + mdata.getId() + ":\n");
         sbuf.append(mdata.getData().trim());
         sbuf.append("\n\n");
      }
      return sbuf.toString();
   }
}
