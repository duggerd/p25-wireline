//
package gov.nist.p25.issi.traceviewer;

import gov.nist.p25.common.util.ByteArrayUtil;
import gov.nist.p25.common.util.FileUtility;
import gov.nist.p25.common.util.HexDump;
import gov.nist.p25.issi.constants.ISSILogoConstants;
import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JViewport;
import org.apache.log4j.Logger;

/**
 * This class implements 2D graphics for the trace viewer sequence diagram.
 */
public class DiagramPanel extends JPanel
   implements ActionListener, MouseListener, MouseMotionListener,
              MouseWheelListener
{
   private static final long serialVersionUID = -1L;
   //private static Logger logger = Logger.getLogger("gov.nist.p25.issi");
   private static Logger logger = Logger.getLogger(DiagramPanel.class);
   public static void showln(String s) { System.out.println(s); }

   private final static String NEWLINE = System.getProperty("line.separator");
   private final static String CMD_NEW_WINDOW = "New Window";
   private final static String CMD_AUTO_SAVE = "Auto Save";
   private final static String CMD_SAVE_AS = "Save As";
   private final static String CMD_CLOSE = "Close";
   private final static String CMD_CLOSE_ALL = "Close All";
   private final static String CMD_MARK_TIME = "Mark Time";
   private final static String CMD_RESET_TIME = "Reset Time";

   private static final int TOP_PAD = 50;
   private static final int NODE_SEPARATOR_PAD = 60;
   private static final int NODE_WIDTH = 130;
   private static final int NODE_HEIGHT = 60;
   private static final int FONT_PT_SIZE = 11;
   private static final int MESSAGE_SEPARATOR_PAD = 40;
   private static final int MESSAGE_LABEL_SEPARATOR_PAD = 10;
   private static final int MESSAGE_SELECT_HEIGHT = 20;

   private static final int ARROW_WIDTH = 10;
   private static final int ARROW_TOP_HEIGHT = 5;
   //private static final int ARROW_BOTTOM_HEIGHT = 5;

   private static final double ARC_HEIGHT = 60;
   private static final double ARC_WIDTH = 60;
   //private static final int RFSS_Y_PAD = 10;
   //private static final int RFSS_X_PAD = 10;

   private final static BasicStroke stroke = new BasicStroke(1.0f);
   private final static int NUM_PRINTED_MESSAGES_PER_PAGE = 20;

   private TracePanel tracePanel = null;
   private JPopupMenu rightClickPopupMenu;
   private ZoomLevel currentZoomLevel = ZoomLevel.ZOOM_100;
   //private ZoomLevel printingZoomLevel = ZoomLevel.ZOOM_50;

   private int mousePressedXPos = 0;
   private int mousePressedYPos = 0;
   private int numPrintPages = 0;   
   private long clickedTime;
   private long timeZero;
   private double scale = 1.0D;
   
   // accessors
   public int getNumPrintPages() {
      return numPrintPages;
   }
   
   // constructor
   public DiagramPanel(TracePanel tracePanel) {

      this.tracePanel = tracePanel;
      setDoubleBuffered(true);
      setBackground(Color.white);
      addMouseListener(this);
      addMouseMotionListener(this);
      addMouseWheelListener( this);

      rightClickPopupMenu = new JPopupMenu();
      JMenuItem newWindowClickMenuItem = new JMenuItem(CMD_NEW_WINDOW);
      newWindowClickMenuItem.setActionCommand(CMD_NEW_WINDOW);
      newWindowClickMenuItem.addActionListener(this);
      
      JMenuItem autoSaveClickMenuItem = new JMenuItem(CMD_AUTO_SAVE);
      autoSaveClickMenuItem.setActionCommand(CMD_AUTO_SAVE);
      autoSaveClickMenuItem.addActionListener(this);

      JMenuItem saveAsClickMenuItem = new JMenuItem(CMD_SAVE_AS);
      saveAsClickMenuItem.setActionCommand(CMD_SAVE_AS);
      saveAsClickMenuItem.addActionListener(this);
      
      JMenuItem closeRightClickMenuItem = new JMenuItem(CMD_CLOSE);
      closeRightClickMenuItem.setActionCommand(CMD_CLOSE);
      closeRightClickMenuItem.addActionListener(this);
      
      JMenuItem closeAllMenuItem = new JMenuItem(CMD_CLOSE_ALL);
      closeAllMenuItem.setActionCommand(CMD_CLOSE_ALL);
      closeAllMenuItem.addActionListener(this);
      
      JMenuItem markTimeMenuItem = new JMenuItem(CMD_MARK_TIME);
      markTimeMenuItem.setActionCommand(CMD_MARK_TIME);
      markTimeMenuItem.addActionListener(this);

      JMenuItem resetTimeMenuItem = new JMenuItem(CMD_RESET_TIME);
      resetTimeMenuItem.setActionCommand(CMD_RESET_TIME);
      resetTimeMenuItem.addActionListener(this);

      rightClickPopupMenu.add(newWindowClickMenuItem);
      rightClickPopupMenu.addSeparator();
      rightClickPopupMenu.add(autoSaveClickMenuItem);
      rightClickPopupMenu.add(saveAsClickMenuItem);
      rightClickPopupMenu.addSeparator();
      rightClickPopupMenu.add(closeRightClickMenuItem);
      rightClickPopupMenu.add(closeAllMenuItem);
      rightClickPopupMenu.addSeparator();
      rightClickPopupMenu.add(markTimeMenuItem);
      rightClickPopupMenu.add(resetTimeMenuItem);
   }

   public int[] setData(Collection<RfssData> rfssList,
         List<MessageData> messageList) {

      double zoomMax = ZoomLevel.ZOOM_MAX.value();
      int rfssSize = rfssList.size();
      int totalWidth = (int) (rfssSize
            * ((NODE_SEPARATOR_PAD * zoomMax) + (NODE_WIDTH * zoomMax)) + 
            (NODE_SEPARATOR_PAD * zoomMax));
      totalWidth += 40;

      int messageListSize = messageList.size();
      int totalHeight = (int) (messageListSize
            * (MESSAGE_SEPARATOR_PAD * zoomMax) + MESSAGE_SEPARATOR_PAD);
      totalHeight += 40;
      //showln("setData(0): totalWidth="+totalWidth +" totalHeight="+totalHeight);

      //TODO: the totalWidth and totalHeight is about 2x too big
      double sfx = 6.0;
      if( messageListSize < 500) sfx = 6.0;
      if( messageListSize < 400) sfx = 5.0;
      if( messageListSize < 350) sfx = 4.0;
      if( messageListSize < 250) sfx = 2.0;
      if( messageListSize < 200) sfx = 1.5;
      if( messageListSize < 100) sfx = 1.4;
      if( messageListSize < 75) sfx = 1.2;
      if( messageListSize < 50) sfx = 0.8;
      if( messageListSize < 20) sfx = 0.7;
      totalWidth *= sfx * 0.70;
      totalHeight *= sfx;

      this.setPreferredSize(new Dimension(totalWidth, totalHeight));
      this.revalidate();

      // Set number of print pages
      int numMessages = messageList.size();
      numPrintPages = (int) (numMessages / NUM_PRINTED_MESSAGES_PER_PAGE);

      //showln("setData(1): messageListSize="+messageListSize+" sfx="+sfx);
      //showln("setData(1): totalWidth="+totalWidth +" totalHeight="+totalHeight);
      int[] traceSize = new int[2];
      traceSize[0] = totalWidth;
      traceSize[1] = totalWidth;
      return traceSize;
   }

   private void disableMessageSelected() {
      List<MessageData> messageList = tracePanel.getMessageList();
      for (int i = 0; i < messageList.size(); i++) {
         MessageData messageData = (MessageData) messageList.get(i);
         if (messageData == null) continue;
         if (messageData.isSelected()) {
            messageData.setSelected(false);
            break;
         }
      }
   }

   private void disableRfssSelected() {
      Collection<RfssData> rfssList = tracePanel.getRfssList();
      for (RfssData rfssData : rfssList) {
         if (rfssData.isSelected()) {
            rfssData.setSelected(false);
            break;
         }
      }
   }

   private RfssData getRfssById(String seekPort) {
      // logger.debug("getRfssByPort " + seekPort);
      RfssData foundRfss = null;
      Collection<RfssData> rfssList = tracePanel.getRfssList();
      for (RfssData rfssData : rfssList) {
         if ((rfssData.getRfssConfig().getDomainName()).equals(seekPort)) {
            foundRfss = rfssData;
         }
         if (foundRfss != null)
            break;
      }
      return foundRfss;
   }

   private RfssData getRfssByPort(String seekPort) {
      logger.debug("getRfssByPort " + seekPort);
      RfssData foundRfss = null;
      Collection<RfssData> rfssList = tracePanel.getRfssList();
      for (RfssData rfssData : rfssList) {
         for (int j = 0; j < rfssData.getPorts().size(); j++) {
            String port = rfssData.getPorts().get(j);
            if (port.equals(seekPort)) {
               foundRfss = rfssData;
               break;
            }
         }
         if (foundRfss != null)
            break;
      }
      if (foundRfss == null) {
         logger.debug("Here is the list of rfss " + rfssList);
         for (RfssData rfssData : rfssList) {
            logger.debug("ports = " + rfssData.getPorts());
         }
      }
      return foundRfss;
   }

   private RfssData getRfssByLocation(int mouseX, int mouseY) {
      RfssData foundRfss = null;
      Collection<RfssData> rfssList = tracePanel.getRfssList();
      for (RfssData rfssData : rfssList) {
         if (((rfssData.getX() <= mouseX) && (mouseX <= (rfssData.getX() + rfssData
               .getDimension().width)))
               && ((rfssData.getY() <= mouseY) && (mouseY <= (rfssData
                     .getY() + rfssData.getDimension().height)))) {
            foundRfss = rfssData;
            break;
         }
      }
      return foundRfss;
   }

   private MessageData getMessageByLocation(int mouseX, int mouseY) {
      MessageData foundMessage = null;
      List<MessageData> messageList = tracePanel.getMessageList();
      for (int i = 0; i < messageList.size(); i++) {
         MessageData messageData = (MessageData) messageList.get(i);
	 if( messageData == null) continue;
	 if( messageData.getDimension() == null) continue;

         if (((messageData.getX() <= mouseX) && (mouseX <= (messageData
               .getX() + messageData.getDimension().width)))
               && ((messageData.getY() <= mouseY) && (mouseY <= (messageData
                     .getY() + messageData.getDimension().height)))) {
            foundMessage = messageData;
            break;
         }
      }
      return foundMessage;
   }

   public String getSortedMessageData() {
      StringBuffer sbuf = new StringBuffer();
      List<MessageData> messageList = tracePanel.getMessageList();
      for (int i = 0; i < messageList.size(); i++) {
         MessageData messageData = (MessageData) messageList.get(i);
	 if( messageData == null) continue;
         String msg = "F"+messageData.getId()+":\n"+messageData.getData().trim();            
         sbuf.append( msg);
         sbuf.append( "\n\n");
      }
      return sbuf.toString();
   }

   //----------------------------------------------------------------------
   protected void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;
      double zoomValue = currentZoomLevel.value();
      int newFontSize = (int) (FONT_PT_SIZE * zoomValue);
      g2d.setFont(new Font("Tahoma", Font.PLAIN, newFontSize));
      FontMetrics metrics = g2d.getFontMetrics();
      drawNodes(g2d, zoomValue, metrics);
      drawMessages(g2d, zoomValue, metrics);
   }

   public void saveAs(String fileName) {
      logger.debug("path for save: " + fileName + ".jpg");
      try {
         // Compute the size of the image first
         int rfssListSize = tracePanel.getRfssList().size();
         int messageListSize = tracePanel.getMessageList().size();

         int width = NODE_SEPARATOR_PAD + (rfssListSize * NODE_WIDTH)
               + (rfssListSize * NODE_SEPARATOR_PAD);
         int height = TOP_PAD + NODE_HEIGHT + MESSAGE_SEPARATOR_PAD
               + (messageListSize * MESSAGE_SEPARATOR_PAD)
               + MESSAGE_SEPARATOR_PAD;

         BufferedImage bufferedImage = new BufferedImage(width, height,
               BufferedImage.TYPE_INT_RGB);
         Graphics2D g2d = bufferedImage.createGraphics();
         double zoomValue = currentZoomLevel.value();
         int newFontSize = (int) (FONT_PT_SIZE * zoomValue);
         g2d.setFont(new Font("Tahoma", Font.PLAIN, newFontSize));
         FontMetrics metrics = g2d.getFontMetrics();
         g2d.setColor(Color.white);
         g2d.fillRect(0, 0, width, height);
         drawNodes(g2d, zoomValue, metrics);
         drawMessages(g2d, zoomValue, metrics);

         OutputStream out = new FileOutputStream(fileName);
         ImageIO.write(bufferedImage, "jpg", out);
         out.close();
      } 
      catch (Exception e) {
         logger.error("An exception occured while trying to save file", e);
         JOptionPane.showMessageDialog(null,
            "An Error Occured while saving the file",
            "Save File Error", JOptionPane.ERROR_MESSAGE);
      }
   }

   private String getSuggestFileName() {
      String testNo = tracePanel.getTestNumber();
      String outDir = System.getProperty("user.dir") + 
            File.separator + "output" + 
            File.separator + testNo;
      // create output directory if it doesnot exists
      FileUtility.makeDir( outDir);
      String suggestFile = outDir + File.separator + 
            tracePanel.getTitle() + "-" + testNo;
      showln("suggestFile="+suggestFile);
      return suggestFile;
   }

   public void saveAs() {
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setDialogTitle("Save As");
      String testNo = tracePanel.getTestNumber();
      String suggestFile = System.getProperty("user.dir") + 
            File.separator + "output" + 
            File.separator + testNo +
            File.separator + tracePanel.getTitle();
      showln("suggestFile="+suggestFile+"  testNo="+testNo);
      
      if( testNo != null && testNo.length() > 0) {
         suggestFile += "-" + testNo;
      }
      File sfile = new File(suggestFile);
      fileChooser.setSelectedFile( sfile);
      
      TraceFileFilter traceFilter = new TraceFileFilter();
      traceFilter.addExtension("jpg");
      traceFilter.setDescription("JPG Files");
      fileChooser.setFileFilter(traceFilter);

      int returnVal = fileChooser.showSaveDialog(tracePanel.getTabbedPane());
      File file = null;
      if (returnVal == JFileChooser.APPROVE_OPTION) {
         file = fileChooser.getSelectedFile();
         // this is where a real application would save the file.
         logger.debug("Saving: " + file.getName() + "." + NEWLINE);
      } else {
         logger.debug("Save command cancelled by user." + NEWLINE);
         return;
      }

      String fullpath = file.getAbsolutePath();
      saveByFullpath( fullpath);
   }

   public void autoSave() {
      String suggestFile = getSuggestFileName();
      showln("autoSave: suggestFile="+suggestFile);
      saveByFullpath( suggestFile);
   }

   private void saveByFullpath(String fullpath) {

      saveAs(fullpath + ".jpg");
      
      // save translated message and raw message
      String data = tracePanel.getDataTextArea(TracePanel.DATA_ALL_MSG).getText();
      saveAsFile(fullpath + ".all.txt", data);
      
      data = tracePanel.getDataTextArea(TracePanel.DATA_RAW_MSG).getText();
      saveAsFile(fullpath + ".raw.txt", data);
      
      data = tracePanel.getDataTextArea(TracePanel.DATA_ERROR_MSG).getText();
      saveAsFile(fullpath + ".selraw.txt", data);
         
      data = tracePanel.getDataTextArea(TracePanel.DATA_SELECTED_MSG).getText();
      saveAsFile(fullpath + ".selmsg.txt", data);
   }
   
   private void saveAsFile( String fullpath, String message) {
      try {
         OutputStream out = new FileOutputStream(new File(fullpath));
         out.write(message.getBytes());
         out.close();
      }
      catch (Exception ex) {
         String msg = "An error occured while saving file: "+ fullpath;
         logger.error( msg, ex);
         JOptionPane.showMessageDialog(null, msg,
            "Save File Status", 
            JOptionPane.ERROR_MESSAGE);
      }
   }

   private void drawNodes(Graphics2D g2d, double zoomValue, FontMetrics metrics) {
      Collection<RfssData> rfssList = tracePanel.getRfssList();
      g2d.setColor(Color.black);
      
      String titleString = tracePanel.getTestNumber() +" : " + tracePanel.getTitle();
      Font g2dFont = g2d.getFont();
      Font titleFont = new Font("SansSerif", Font.BOLD, 12);
      g2d.setFont( titleFont);
      g2d.drawString( titleString, 160, 30);    
      g2d.setFont( g2dFont);

      int i = 0;
      for (RfssData rfssData : rfssList) {
         String idString = rfssData.getRfssConfig() != null ? rfssData
               .getRfssConfig().getDomainName() : rfssData.getId();
         Color color = Color.black;
         
         String nameString = rfssData.getRfssConfig() != null ? rfssData
               .getRfssConfig().getRfssName()  : "";
         String ipAddrString = rfssData.getAddress() != null ? rfssData.getAddress() : "";      

         int idStringWidth = metrics.stringWidth(idString);
         int idStringHeight = metrics.getHeight();
         int nameStringWidth = metrics.stringWidth(nameString);
         int ipAddrStringWidth = metrics.stringWidth(ipAddrString);
         
         /***
         String portNumberString = "";
         for (int j = 0; j < rfssData.getPorts().size(); j++) {
            portNumberString += rfssData.getPorts().get(j);
            if (j < (rfssData.getPorts().size() - 1)) {
               portNumberString += ",";
            }
         }
          ***/
         String portNumberString = rfssData.getPorts().get(0);
         int portNumberStringWidth = metrics.stringWidth(portNumberString);

         int x = (int) ((NODE_SEPARATOR_PAD * zoomValue)
               + (i * NODE_WIDTH * zoomValue) + (i * NODE_SEPARATOR_PAD * zoomValue));
         int y = (int) (TOP_PAD * zoomValue);
         g2d.setPaint(new Color(255, 235, 205));
         g2d.fill(new Rectangle2D.Double(x, y, NODE_WIDTH * zoomValue,
               NODE_HEIGHT * zoomValue));
         if (rfssData.isSelected())
            g2d.setPaint(Color.red);
         else
            g2d.setPaint(color);
         g2d.setStroke(stroke);
         g2d.draw(new Rectangle2D.Double(x, y, NODE_WIDTH * zoomValue,
               NODE_HEIGHT * zoomValue + 2));
         
         g2d.drawString( nameString,
               x + ((int) (NODE_WIDTH * zoomValue) / 2 - nameStringWidth / 2),
               y + ((int) (NODE_HEIGHT * zoomValue) / 2 - idStringHeight * 1));
         g2d.drawString( idString,
               x + ((int) (NODE_WIDTH * zoomValue) / 2 - idStringWidth / 2),
               y + ((int) (NODE_HEIGHT * zoomValue) / 2 ));
         g2d.drawString( ipAddrString,
               x + ((int) (NODE_WIDTH * zoomValue) / 2 - ipAddrStringWidth / 2),
               y + ((int) (NODE_HEIGHT * zoomValue) / 2 + idStringHeight));
         g2d.drawString( portNumberString,
               x + ((int) (NODE_WIDTH * zoomValue) / 2 - portNumberStringWidth / 2),
               y + ((int) (NODE_HEIGHT * zoomValue) / 2 + idStringHeight*2));
         /*
          * g2d .drawString( portNumberString, x + ((int) (NODE_WIDTH *
          * zoomValue) / 2 - portNumberStringWidth / 2), y + ((int)
          * (NODE_HEIGHT * zoomValue) / 2 + portNumberStringHeight * 1));
          */

         List<MessageData> messageList = tracePanel.getMessageList();
         int messageListSize = messageList.size();
         g2d.drawLine(x + (int) ((NODE_WIDTH * zoomValue) / 2),
               (int) (y + (NODE_HEIGHT * zoomValue)), x
                     + (int) ((NODE_WIDTH * zoomValue) / 2),
               (int) ((y + (NODE_HEIGHT * zoomValue))
                     + MESSAGE_SEPARATOR_PAD + (MESSAGE_SEPARATOR_PAD
                     * messageListSize * zoomValue)));
         rfssData.setX(x);
         rfssData.setY(y);
         rfssData.setDimension(new Dimension((int) (NODE_WIDTH * zoomValue),
               (int) (NODE_HEIGHT * zoomValue)));
         i++;
      }
   }

//   private void printHeadersAndFooters(Graphics2D g2d, FontMetrics metrics,
//         int page) {
//
//      // Set footer
//      Calendar cal = Calendar.getInstance(TimeZone.getDefault());
//
//      String DATE_FORMAT = "HH:mm:ss MM/dd/yyyy";
//      java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
//            DATE_FORMAT);
//      sdf.setTimeZone(TimeZone.getDefault());
//      String header = "ISSI Tester v0.1a: " + tracePanel.getFileName() + "    "
//            + sdf.format(cal.getTime()) + "    " + "Page " + (page + 1)
//            + " of " + (numPrintPages + 1);
//      g2d.setStroke(stroke);
//      g2d.drawString(header, 0, metrics.getHeight());
//   }
//
//   private void printNodes(Graphics2D g2d, double zoomValue,
//         FontMetrics metrics, int page) {
//
//      Collection<RfssData> rfssList = tracePanel.getRfssList();
//      //int rfssListSize = rfssList.size();
//      // g2d.setColor(Color.black);
//      int i = 0;
//      for (RfssData rfssData : rfssList) {
//
//         int x = (int) ((NODE_SEPARATOR_PAD * zoomValue)
//               + (i * NODE_WIDTH * zoomValue) + (i * NODE_SEPARATOR_PAD * zoomValue));
//         int y = (int) (TOP_PAD * zoomValue);
//
//         // Only print RFSS nodes on first page
//
//         String idString = rfssData.getRfssConfig() != null ? rfssData
//               .getRfssConfig().getDomainName(): 
//                  rfssData.getId();
//               
//         Color color = rfssData.getRfssConfig() != null ? rfssData.getRfssConfig().getColor() :
//            Color.black;
//
//         // String idString = rfssData.getId();
//         int idStringWidth = metrics.stringWidth(idString);
//         int idStringHeight = metrics.getHeight();
//         String ipAddrString = rfssData.getAddress() + ":";
//         int ipAddrStringWidth = metrics.stringWidth(ipAddrString);
//
//         String portNumberString = "";
//
//         for (int j = 0; j < rfssData.getPorts().size(); j++) {
//            portNumberString += rfssData.getPorts().get(j);
//            if (j < (rfssData.getPorts().size() - 1)) {
//               portNumberString += ", ";
//            }
//         }
//
//         int portNumberStringWidth = metrics.stringWidth(portNumberString);
//         int portNumberStringHeight = metrics.getHeight();
//
//         g2d.setPaint(new Color(255, 235, 205));
//         g2d.fill(new Rectangle2D.Double(x, y, NODE_WIDTH * zoomValue,
//               NODE_HEIGHT * zoomValue));
//
//         if (rfssData.isSelected())
//            g2d.setPaint(Color.red);
//         else
//            g2d.setPaint(color);
//
//         g2d.setStroke(stroke);
//         g2d.draw(new Rectangle2D.Double(x, y, NODE_WIDTH * zoomValue,
//               NODE_HEIGHT * zoomValue));
//
//         g2d
//               .drawString(
//                     idString,
//                     x
//                           + ((int) (NODE_WIDTH * zoomValue) / 2 - idStringWidth / 2),
//                     y
//                           + ((int) (NODE_HEIGHT * zoomValue) / 2 - idStringHeight * 1));
//
//         g2d
//               .drawString(
//                     ipAddrString,
//                     x
//                           + ((int) (NODE_WIDTH * zoomValue) / 2 - ipAddrStringWidth / 2),
//                     y + ((int) (NODE_HEIGHT * zoomValue) / 2));
//
//         g2d
//               .drawString(
//                     portNumberString,
//                     x
//                           + ((int) (NODE_WIDTH * zoomValue) / 2 - portNumberStringWidth / 2),
//                     y
//                           + ((int) (NODE_HEIGHT * zoomValue) / 2 + portNumberStringHeight * 1));
//
//         rfssData.setX(x);
//         rfssData.setY(y);
//         rfssData.setDimension(new Dimension((int) (NODE_WIDTH * zoomValue),
//               (int) (NODE_HEIGHT * zoomValue)));
//
//         g2d.drawLine(x + (int) ((NODE_WIDTH * zoomValue) / 2),
//               (int) (y + (NODE_HEIGHT * zoomValue)), x
//                     + (int) ((NODE_WIDTH * zoomValue) / 2),
//               (int) ((y + (NODE_HEIGHT * zoomValue))
//                     + MESSAGE_SEPARATOR_PAD + (MESSAGE_SEPARATOR_PAD
//                     * NUM_PRINTED_MESSAGES_PER_PAGE * zoomValue)));
//         i++;
//
//      }
//   }

   private void drawMessages(Graphics2D g2d, double zoomValue,
         FontMetrics metrics) {
      List<MessageData> messageList = tracePanel.getMessageList();
      int messageListSize = messageList.size();
      int startX = 0;
      int startY = (int) ((TOP_PAD * zoomValue) + (NODE_HEIGHT * zoomValue));
      int endX = 0;
      int endY = startY;

      for (int i = 0; i < messageListSize; i++) {
         MessageData messageData = (MessageData) messageList.get(i);
         RfssData fromRfss = messageData.getFromRfssId() != null ? getRfssById(messageData
               .getFromRfssId())
               : getRfssByPort(messageData.getFromPort());
         if (fromRfss == null) {
            logger.error("Could not find an RFSS (fromRfss) "
                  + messageData.getFromRfssId() + ":"
                  + messageData.getFromPort());
            return;
         }
         RfssData toRfss = messageData.getToRfssId() != null ? getRfssById(messageData
               .getToRfssId())
               : getRfssByPort(messageData.getToPort());
         if (toRfss == null) {
            logger.error("Could not find an RFSS "
                  + messageData.getFromRfssId() + ":"
                  + messageData.getToPort());
            return;
         }
         startX = fromRfss.getX() + (fromRfss.getDimension().width / 2);
         startY += (MESSAGE_SEPARATOR_PAD * zoomValue);
         endX = toRfss.getX() + (toRfss.getDimension().width / 2);
         endY = startY;

         // Set message color
         Color color = null;
         if (messageData.isSelected()) {
            color = Color.red;
         } else {
            Hashtable<String, Color> colorMap = tracePanel.getColorMap();
            color = (Color) colorMap.get(messageData.getColorMapKey());
         }

         g2d.setColor(color);
         if (startX < endX) {

            g2d.drawLine(startX, startY, endX, endY);
            int topX = endX - (int) (ARROW_WIDTH * zoomValue);
            int topY = endY - (int) (ARROW_TOP_HEIGHT * zoomValue);
            int bottomX = endX - (int) (ARROW_WIDTH * zoomValue);
            int bottomY = endY + (int) (ARROW_TOP_HEIGHT * zoomValue);
            int pointX = endX;
            int pointY = endY;
            int[] xPoints = { topX, bottomX, pointX };
            int[] yPoints = { topY, bottomY, pointY };
            int numPoints = 3;

            Polygon arrowHead = new Polygon(xPoints, yPoints, numPoints);
            g2d.fillPolygon(arrowHead);

            messageData.setX(startX);
            messageData.setY(startY - (int) (MESSAGE_SELECT_HEIGHT * zoomValue));
            messageData.setDimension(new Dimension((int) (endX - startX),
                  (int) (MESSAGE_SELECT_HEIGHT * 2 * zoomValue)));

            String msg = messageData.getMessageType();
            String message = "F" + messageData.getId() + " : " + msg;
            int messageStringWidth = metrics.stringWidth(message);

            int midX = endX - ((endX - startX) / 2);
            int stringX = midX - (messageStringWidth / 2);
            int stringY = startY - (int) (MESSAGE_LABEL_SEPARATOR_PAD * zoomValue);

            g2d.drawString(message, stringX, stringY);

            /*
             * int fontHeight = metrics.getHeight();
             * g2d.drawString(new Integer(i).toString(), (int)
             * (NODE_SEPARATOR_PAD * zoomValue) + (int) (.3 * NODE_WIDTH *
             * zoomValue), startY + (fontHeight / 2));
             */
         } else if (startX > endX) {

            g2d.drawLine(startX, startY, endX, endY);
            int topX = endX + (int) (ARROW_WIDTH * zoomValue);
            int topY = endY - (int) (ARROW_TOP_HEIGHT * zoomValue);
            int bottomX = endX + (int) (ARROW_WIDTH * zoomValue);
            int bottomY = endY + (int) (ARROW_TOP_HEIGHT * zoomValue);
            int pointX = endX;
            int pointY = endY;

            int[] xPoints = { topX, bottomX, pointX };
            int[] yPoints = { topY, bottomY, pointY };
            int numPoints = 3;

            Polygon arrowHead = new Polygon(xPoints, yPoints, numPoints);
            g2d.fillPolygon(arrowHead);

            messageData.setX(endX);
            messageData.setY(endY - (int) (MESSAGE_SELECT_HEIGHT * zoomValue));
            messageData.setDimension(new Dimension((int) (startX - endX),
                  (int) (MESSAGE_SELECT_HEIGHT * 2 * zoomValue)));

            String message = "F" + messageData.getId() + " : " + messageData.getMessageType();
            int messageStringWidth = metrics.stringWidth(message);

            int midX = endX - ((endX - startX) / 2);
            int stringX = midX - (messageStringWidth / 2);
            int stringY = startY - (int) (MESSAGE_LABEL_SEPARATOR_PAD * zoomValue);

            g2d.drawString(message, stringX, stringY);

            /*
             * int fontHeight = metrics.getHeight();
             * 
             * g2d.drawString(new Integer(i).toString(), (int)
             * (NODE_SEPARATOR_PAD * zoomValue) + (int) (.3 * NODE_WIDTH *
             * zoomValue), startY + (fontHeight / 2));
             */

         } else if (startX == endX) {

            g2d.draw(new Arc2D.Double((double) startX
                  - (.5 * ARC_WIDTH * zoomValue), (double) startY,
                  (double) ARC_WIDTH * zoomValue, (double) ARC_HEIGHT
                        * zoomValue, (double) 270, (double) 180,
                  Arc2D.OPEN));

            int topX = endX + (int) (ARROW_WIDTH * zoomValue);
            int topY = (int) (MESSAGE_SEPARATOR_PAD * zoomValue) + endY
                  - (int) (ARROW_TOP_HEIGHT * zoomValue);
            int bottomX = endX + (int) (ARROW_WIDTH * zoomValue);
            int bottomY = (int) (MESSAGE_SEPARATOR_PAD * zoomValue) + endY
                  + (int) (ARROW_TOP_HEIGHT * zoomValue);
            int pointX = endX;
            int pointY = (int) (MESSAGE_SEPARATOR_PAD * zoomValue) + endY;

            int[] xPoints = { topX, bottomX, pointX };
            int[] yPoints = { topY, bottomY, pointY };
            int numPoints = 3;

            Polygon arrowHead = new Polygon(xPoints, yPoints, numPoints);
            g2d.fillPolygon(arrowHead);

            String message = messageData.getMessageType();
            int messageStringWidth = metrics.stringWidth(message);

            int stringX = (int) (startX - (messageStringWidth / 2));
            messageData.setY(endY - (int) (MESSAGE_SELECT_HEIGHT * zoomValue));
            messageData.setDimension(new Dimension(
                  (int) (messageStringWidth),
                  (int) ((ARC_HEIGHT * zoomValue) + (MESSAGE_SELECT_HEIGHT * 2 * zoomValue))));

            int stringY = startY - (int) (MESSAGE_LABEL_SEPARATOR_PAD * zoomValue);
            g2d.drawString(message, stringX, stringY);
            int fontHeight = metrics.getHeight();
            g2d.drawString(new Integer(i).toString(),
                  (int) (NODE_SEPARATOR_PAD * zoomValue)
                        + (int) (.3 * NODE_WIDTH * zoomValue), startY
                        + (fontHeight / 2));
         }
      }
   }

   /***
   private void printMessages(Graphics2D g2d, double zoomValue,
         FontMetrics metrics, int startMsgIndex, int finishMsgIndex) {

      List<MessageData> messageList = tracePanel.getMessageList();
      int startX = 0;
      int startY = (int) ((TOP_PAD * zoomValue) + (NODE_HEIGHT * zoomValue));
      int endX = 0;
      int endY = startY;

      for (int i = startMsgIndex; i < finishMsgIndex; i++) {

         MessageData messageData = (MessageData) messageList.get(i);

         RfssData fromRfss = getRfssById(messageData.getFromRfssId() + ":" + messageData.getFromPort());
         RfssData toRfss = getRfssById(messageData.getToRfssId() + ":" + messageData.getToPort());

         startX = fromRfss.getX() + (fromRfss.getDimension().width / 2);
         startY += (MESSAGE_SEPARATOR_PAD * zoomValue);
         endX = toRfss.getX() + (toRfss.getDimension().width / 2);
         endY = startY;

         // Set message color
         Color color = null;

         if (messageData.isSelected()) {
            color = Color.red;
         } else {
            Hashtable<String, Color> colorMap = tracePanel.getColorMap();
            color = (Color) colorMap.get(messageData.getColorMapKey());
         }

         g2d.setColor(color);
         if (startX < endX) {

            g2d.drawLine(startX, startY, endX, endY);

            int topX = endX - (int) (ARROW_WIDTH * zoomValue);
            int topY = endY - (int) (ARROW_TOP_HEIGHT * zoomValue);
            int bottomX = endX - (int) (ARROW_WIDTH * zoomValue);
            int bottomY = endY + (int) (ARROW_TOP_HEIGHT * zoomValue);
            int pointX = endX;
            int pointY = endY;

            int[] xPoints = { topX, bottomX, pointX };
            int[] yPoints = { topY, bottomY, pointY };
            int numPoints = 3;

            Polygon arrowHead = new Polygon(xPoints, yPoints, numPoints);
            g2d.fillPolygon(arrowHead);

            messageData.setX(startX);
            messageData.setY(startY - (int) (MESSAGE_SELECT_HEIGHT * zoomValue));
            messageData.setDimension(new Dimension((int) (endX - startX),
                  (int) (MESSAGE_SELECT_HEIGHT * 2 * zoomValue)));

            String msg = messageData.getMessageType();
            String message = "F" + messageData.getId() + " : " + msg;
            int messageStringWidth = metrics.stringWidth(message);

            int midX = endX - ((endX - startX) / 2);
            int stringX = midX - (messageStringWidth / 2);
            int stringY = startY - (int) (MESSAGE_LABEL_SEPARATOR_PAD * zoomValue);
            g2d.drawString(message, stringX, stringY);
            int fontHeight = metrics.getHeight();
            g2d.drawString(new Integer(i).toString(),
                  (int) (NODE_SEPARATOR_PAD * zoomValue)
                        + (int) (.3 * NODE_WIDTH * zoomValue), startY
                        + (fontHeight / 2));

         } else if (startX > endX) {

            g2d.drawLine(startX, startY, endX, endY);

            int topX = endX + (int) (ARROW_WIDTH * zoomValue);
            int topY = endY - (int) (ARROW_TOP_HEIGHT * zoomValue);
            int bottomX = endX + (int) (ARROW_WIDTH * zoomValue);
            int bottomY = endY + (int) (ARROW_TOP_HEIGHT * zoomValue);
            int pointX = endX;
            int pointY = endY;

            int[] xPoints = { topX, bottomX, pointX };
            int[] yPoints = { topY, bottomY, pointY };
            int numPoints = 3;

            Polygon arrowHead = new Polygon(xPoints, yPoints, numPoints);
            g2d.fillPolygon(arrowHead);

            messageData.setX(endX);
            messageData.setY(endY - (int) (MESSAGE_SELECT_HEIGHT * zoomValue));
            messageData.setDimension(new Dimension((int) (startX - endX),
                  (int) (MESSAGE_SELECT_HEIGHT * 2 * zoomValue)));

            String message = "F" + messageData.getId() + " : " + messageData.getMessageType();
            int messageStringWidth = metrics.stringWidth(message);

            int midX = endX - ((endX - startX) / 2);
            int stringX = midX - (messageStringWidth / 2);
            int stringY = startY - (int) (MESSAGE_LABEL_SEPARATOR_PAD * zoomValue);

            g2d.drawString(message, stringX, stringY);

            int fontHeight = metrics.getHeight();

            g2d.drawString(new Integer(i).toString(),
                  (int) (NODE_SEPARATOR_PAD * zoomValue)
                        + (int) (.3 * NODE_WIDTH * zoomValue), startY
                        + (fontHeight / 2));

         } else if (startX == endX) {

            g2d.draw(new Arc2D.Double((double) startX
                  - (.5 * ARC_WIDTH * zoomValue), (double) startY,
                  (double) ARC_WIDTH * zoomValue, (double) ARC_HEIGHT
                        * zoomValue, (double) 270, (double) 180,
                  Arc2D.OPEN));

            int topX = endX + (int) (ARROW_WIDTH * zoomValue);
            int topY = (int) (MESSAGE_SEPARATOR_PAD * zoomValue) + endY
                  - (int) (ARROW_TOP_HEIGHT * zoomValue);
            int bottomX = endX + (int) (ARROW_WIDTH * zoomValue);
            int bottomY = (int) (MESSAGE_SEPARATOR_PAD * zoomValue) + endY
                  + (int) (ARROW_TOP_HEIGHT * zoomValue);
            int pointX = endX;
            int pointY = (int) (MESSAGE_SEPARATOR_PAD * zoomValue) + endY;

            int[] xPoints = { topX, bottomX, pointX };
            int[] yPoints = { topY, bottomY, pointY };
            int numPoints = 3;

            Polygon arrowHead = new Polygon(xPoints, yPoints, numPoints);
            g2d.fillPolygon(arrowHead);

            String message = messageData.getMessageType();
            int messageStringWidth = metrics.stringWidth(message);

            int stringX = (int) (startX - (messageStringWidth / 2));
            messageData.setY(endY - (int) (MESSAGE_SELECT_HEIGHT * zoomValue));

            messageData.setDimension(new Dimension(
                        (int) (messageStringWidth),
                        (int) ((ARC_HEIGHT * zoomValue) + (MESSAGE_SELECT_HEIGHT * 2 * zoomValue))));

            int stringY = startY - (int) (MESSAGE_LABEL_SEPARATOR_PAD * zoomValue);
            g2d.drawString(message, stringX, stringY);
            int fontHeight = metrics.getHeight();
            g2d.drawString(new Integer(i).toString(),
                  (int) (NODE_SEPARATOR_PAD * zoomValue)
                        + (int) (.3 * NODE_WIDTH * zoomValue), startY
                        + (fontHeight / 2));
         }
      }  // for-loop
   }
    ***/

   // implementation of MouseListener
   //--------------------------------------------------------------------
   public void mouseClicked(MouseEvent e) {

      if (e.getClickCount() == 2) {
         createNewWindow();
      }

      //showln("mouseClicked(): "+e.getX()+","+e.getY());
      RfssData rfssData = getRfssByLocation(e.getX(), e.getY());
      if (rfssData != null) {

         disableMessageSelected();
         disableRfssSelected();
         rfssData.setSelected(true);
         repaint();

         //showln("RFSS-time="+rfssData.getTime());
	 clickedTime = rfssData.getTime();
         setToolTipText("Time(ms): "+clickedTime +"  delta: "+(clickedTime-timeZero));

         //JTextArea textArea = tracePanel.getTextArea();
         StringBuffer sbuf = new StringBuffer();         
         sbuf.append("ID: " + rfssData.getId() + "\nIP Address: " + rfssData.getAddress());
         for (int i = 0; i < rfssData.getPorts().size(); i++) {
            if (i == 0)
               sbuf.append("\nSIP Recv Port: " + rfssData.getPorts().get(i));
            else
               sbuf.append("\nRTP Recv Port: " + rfssData.getPorts().get(i));
         }
         
         if (rfssData.getRfssConfig() != null) {
            sbuf.append("\nRfss Symbolic name = " + rfssData.getRfssConfig().getRfssName());
            sbuf.append("\nDomain name = " + rfssData.getRfssConfig().getDomainName());
            if (rfssData.getRfssConfig().getHomeSubsciberUnits().hasNext()) {
               sbuf.append("\nSu IDs homed at this RFSS = [ ");

               for (Iterator<SuConfig> it= rfssData.getRfssConfig().getHomeSubsciberUnits(); it.hasNext();) {
                  SuConfig suConfig = it.next();
                  sbuf.append(" ( Symbolic name = ");
                  sbuf.append(suConfig.getSuName() + " , ");
                  sbuf.append("SU ID = ");
                  sbuf.append(suConfig.getSuId() + " ) ");
               }
               sbuf.append("]");
            }

            if (rfssData.getRfssConfig().getInitialServedSubscriberUnits()
                  .size() != 0) {
               sbuf.append("\nSu IDs initially served at this RFSS = [ ");
               for (SuConfig suConfig : rfssData.getRfssConfig() .getInitialServedSubscriberUnits()) {

                  sbuf.append(" ( SU Symbolic name = ");
                  sbuf.append(suConfig.getSuName() + " , ");
                  //M1001 %x
                  sbuf.append("SU ID = ");
                  sbuf.append(Integer.toHexString(suConfig.getSuId()) + "(hex)) ");
               }
               sbuf.append("]");
            }

            if (rfssData.getRfssConfig().getAssignedGroups().hasNext()) {
               sbuf.append("\nGroup IDs homed at this RFSS = [ ");

               for (Iterator<GroupConfig> it= rfssData.getRfssConfig().getAssignedGroups(); it.hasNext();) {
                  GroupConfig groupConfig = it.next();
                  sbuf.append("( Group Symbolic Name = " + groupConfig.getGroupName());
                  sbuf.append(" , Group ID = ");
                  sbuf.append(Integer.toHexString(groupConfig.getGroupId()) + "(hex)) ");
               }
               sbuf.append("]");
            }
            for (PttSessionInfo pttSessionInfo : rfssData.getPttSessionInfo()) {
               sbuf.append("\n[");
               sbuf.append(pttSessionInfo.toString());
               sbuf.append("]\n");
            }
            tracePanel.setDataTextArea( TracePanel.DATA_SELECTED_MSG, sbuf.toString());

            //showln("mouseClick: SIP...");
            //JOptionPane.showMessageDialog(null, sbuf.toString(),
            //   "RFSS Info", JOptionPane.INFORMATION_MESSAGE);
         }

      } else {

         disableRfssSelected();

         // Try messages
         MessageData messageData = getMessageByLocation(e.getX(), e.getY());
         if (messageData != null) {

            disableMessageSelected();
            messageData.setSelected(true);
            repaint();
   
	    // It could be SIP or PTT message
            //showln("MSG-time(2)="+messageData.getTime());
	    try {
               clickedTime = Long.parseLong(messageData.getTime());
               setToolTipText("Time(ms): "+clickedTime +"  delta: "+(clickedTime-timeZero));
	    } catch(Exception ex) { }

            //showln("PTT using getId():"+messageData.getId());
            String msg = "F"+messageData.getId()+":\n"+messageData.getData().trim();            
            tracePanel.setDataTextArea( TracePanel.DATA_SELECTED_MSG, msg);

            // display in hex: 80 04 1A 2B 04  ...
            String rawdata = messageData.getRawdata();
            //showln("PTT SELECTED - rawdata=<"+ rawdata + ">");

            // check for ' '
            if( rawdata.charAt(2) != ' ' || rawdata.charAt(5) != ' ' || 
                rawdata.charAt(8) != ' ' || rawdata.charAt(11) != ' ')
            {
               String sbHex = HexDump.dump(rawdata.getBytes(), 0, 0);
               tracePanel.setDataTextArea( TracePanel.DATA_ERROR_MSG, sbHex);
            } 
            else
	    {
               byte[] hexArray = ByteArrayUtil.fromHexString( rawdata);
               if( hexArray != null) {
                  String sbHex = HexDump.dump(hexArray, 0, 0);
   	          if( sbHex != null)
                     tracePanel.setDataTextArea( TracePanel.DATA_ERROR_MSG, sbHex);
   	       }
            }

         } else {
            disableMessageSelected();
            repaint();
         }
      }
   }

   public void mousePressed(MouseEvent e) {
      int buttonNumber = e.getButton();
      if (buttonNumber == 3) {
         rightClickPopupMenu.show(this, e.getX(), e.getY());
      }
      else {
         mousePressedXPos = e.getX();
         mousePressedYPos = e.getY();
         setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
      }
   }

   public void mouseReleased(MouseEvent e) {
      setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
   }

   public void mouseEntered(MouseEvent e) {
      //showln("Mouse location: "+e.getX()+","+e.getY());
      RfssData rfssData = getRfssByLocation(e.getX(), e.getY());
      if (rfssData != null) {
         setToolTipText("Time(ms): "+rfssData.getTime());
      }
      else {
         MessageData msgData = getMessageByLocation(e.getX(), e.getY());
         if( msgData != null) {
            setToolTipText("Time(ms): "+msgData.getTime());
         }
	 else {
            setToolTipText(null);
	 }
      }
   } 
   public void mouseExited(MouseEvent e) { }
   public void mouseMoved(MouseEvent arg0) { }

   public void mouseDragged(MouseEvent e) {

     Container c = getParent();
     if( c instanceof JViewport) {
        JViewport jv = (JViewport) c;
        Point p = jv.getViewPosition();
        int newX = p.x - (e.getX() - mousePressedXPos);
        int newY = p.y - (e.getY() - mousePressedYPos);
  
        int maxX = this.getWidth() - jv.getWidth();
        int maxY = this.getHeight() - jv.getHeight();
  
        if (newX < 0)
           newX = 0;
        if (newX > maxX)
           newX = maxX;
        if (newY < 0)
           newY = 0;
        if (newY > maxY)
           newY = maxY;
        jv.setViewPosition(new Point(newX, newY));
     }
   }

   // implementation of ActionListener
   //--------------------------------------------------------------------
   public void actionPerformed(ActionEvent ae) {

      String cmd = ae.getActionCommand();
      if (CMD_NEW_WINDOW.equals(cmd)) {

         createNewWindow();

      } else if (CMD_SAVE_AS.equals(cmd)) {

         saveAs();

      } else if (CMD_AUTO_SAVE.equals(cmd)) {

         autoSave();

      } else if (CMD_CLOSE.equals(cmd)) {

         int selectedIndex = tracePanel.getTabbedPane().getSelectedIndex();
         tracePanel.getTabbedPane().remove(selectedIndex);
         
      } else if (CMD_CLOSE_ALL.equals(cmd)) {

         tracePanel.getTabbedPane().removeAll();
      
      } else if (CMD_MARK_TIME.equals(cmd)) {

         timeZero = clickedTime;

      } else if (CMD_RESET_TIME.equals(cmd)) {

         timeZero = 0;
      }
   }

//   private void zoom(ZoomLevel toZoomLevel) {
//
//      tracePanel.setZoomLabel(toZoomLevel);
//
//      double viewProportion = toZoomLevel.value() / currentZoomLevel.value();
//      currentZoomLevel = toZoomLevel;
//
//      double newCursorXPos = (mousePressedXPos * viewProportion);
//      double newCursorYPos = (mousePressedYPos * viewProportion);
//
//      JViewport jv = tracePanel.getScrollPane().getViewport();
//      Dimension dimension = jv.getExtentSize();
//      int viewWidth = dimension.width;
//      int viewHeight = dimension.height;
//
//      int newViewX = (int) (newCursorXPos - viewWidth / 2);
//      if (newViewX < 0)
//         newViewX = 0;
//
//      int newViewY = (int) (newCursorYPos - viewHeight / 2);
//      if (newViewY < 0)
//         newViewY = 0;
//
//      jv.setViewPosition(new Point((int) (newViewX), (int) (newViewY)));
//
//      this.repaint();
//   }

   private void createNewWindow() {
      JFrame frame = new JFrame();
      frame.setLayout(new BorderLayout());
      frame.setMinimumSize(new Dimension(750, 600));
      frame.setPreferredSize(new Dimension(800, 600));
      frame.setMaximumSize(new Dimension(850, 600));
      frame.setSize(800, 600);
      frame.setIconImage(new ImageIcon(ISSILogoConstants.ISSI_TESTER_LOGO).getImage());

      frame.setTitle(tracePanel.getTitle()+" <> "+tracePanel.getFileName());

      TracePanel newTracePanel = new TracePanel(tracePanel);      
      frame.add(newTracePanel, BorderLayout.CENTER);
      frame.setLocationRelativeTo(tracePanel.getFrame());
      frame.setVisible(true);
   }   

   //--------------------------------------------------------------
   public void mouseWheelMoved(MouseWheelEvent e) {
      if(e.getScrollType() == MouseWheelEvent.WHEEL_UNIT_SCROLL) {
         // do a fast vertical scroll 1/20 of total height
         int incy = e.getWheelRotation();
         Container c = getParent();
         if (c instanceof JViewport)
         {
            JViewport jv = (JViewport) c;
            Point p = jv.getViewPosition();
            int maxX = getWidth() - jv.getWidth();
            int maxY = getHeight() - jv.getHeight();
            int newX = p.x;
	    //TODO: change direction !!
            //int newY = p.y - maxY/20 * incy;
            int newY = p.y + maxY/20 * incy;

            if (newX < 0)
               newX = 0;
            if (newX > maxX)
               newX = maxX;
            if (newY < 0)
               newY = 0;
            if (newY > maxY)
               newY = maxY;
            jv.setViewPosition(new Point(newX, newY));
         }
      }
   }
}
