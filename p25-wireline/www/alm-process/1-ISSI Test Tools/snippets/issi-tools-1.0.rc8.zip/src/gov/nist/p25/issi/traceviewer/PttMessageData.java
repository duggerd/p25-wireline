//
package gov.nist.p25.issi.traceviewer;

import java.util.Properties;
import org.apache.log4j.Logger;


public class PttMessageData extends MessageData 
      implements Comparable<PttMessageData>
{
   private static Logger logger = Logger.getLogger(PttMessageData.class);

   private String sequenceNumber;   
   private Properties properties;

   // accessor
   public String getSequenceNumber() {
      return sequenceNumber;
   }

   public Properties getProperties() {
      return properties;
   }
   
   // constructor
   public PttMessageData(
         String remoteRfssId,
         String myRfssId, 
         String myRtpRecvPort, 
         String remoteRtpRecvPort, 
         String messageType, 
         String data, 
         String time, 
         String sequenceNumber,
         String rtfData,               // not used
         boolean selected,
         boolean isSender,
         Properties props)
   {
      super(remoteRfssId, myRfssId, remoteRtpRecvPort, myRtpRecvPort, 
            messageType, data, time, messageType, selected,isSender);
      this.sequenceNumber = sequenceNumber;
      //this.rtfData = rtfData;
      this.properties = props;   
   }

   private static final String TAG_HEARTBEAT = "Heartbeat";
   private static final String TAG_HEARTBEAT_QUERY = "Heartbeat Query";
   private static final String TAG_PTT_TRANSMIT_REQUEST = "PTT Transmit Request";
   private static final String TAG_PTT_TRANSMIT_GRANT = "PTT Transmit Grant";
   private static final String TAG_PTT_TRANSMIT_START = "PTT Transmit Start";
   private static final String TAG_PTT_TRANSMIT_PROGRESS = "PTT Transmit Progress";
   private static final String TAG_PTT_TRANSMIT_END = "PTT Transmit End";

   public int compareTo(PttMessageData m2) {
      PttMessageData m1 = this;
      int Q = 0;
      try {
         long ts1 = Long.parseLong(m1.getTime());
         long ts2 = Long.parseLong(m2.getTime());
         if (ts1 < ts2)
            return -1;
         else if (ts1 > ts2)
            return 1;
         else {
            // timestamp are same
            logger.debug("compareTo(P0): m1.seqNo: "+m1.getSequenceNumber()+
             " type:"+m1.getMessageType()+
             " time:"+m1.getTime());
            logger.debug("compareTo(P0): m2.seqNo: "+m2.getSequenceNumber()+
             " type:"+m2.getMessageType()+
             " time:"+m2.getTime());
            int sq1 = Integer.parseInt(m1.getSequenceNumber());
            int sq2 = Integer.parseInt(m2.getSequenceNumber());
            //if ( sq1 < sq2) return -1;
            //else if (sq1 > sq2) return 1;
            //else return 0;
            if ( sq1 < sq2) Q = -1;
            else if (sq1 > sq2) Q = 1;
            else Q = 0;            

            // apply rules by message type 
	    //---------------------
            if( m1.getMessageType().equals(m2.getMessageType())) {
               logger.debug("compareTo(P1): same msg/time -------------Q="+Q);
               return Q;
            } 
	    //---------------------
	    if( TAG_HEARTBEAT_QUERY.equals(m1.getMessageType()) &&
                TAG_HEARTBEAT.equals(m2.getMessageType())) {
                Q = -1; 
            }
	    else if( TAG_HEARTBEAT.equals(m1.getMessageType()) &&
                TAG_HEARTBEAT_QUERY.equals(m2.getMessageType())) {
                Q = 1; 
            }
	    //---------------------
	    else if( TAG_PTT_TRANSMIT_REQUEST.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_GRANT.equals(m2.getMessageType())) {
                Q = -1; 
            }
	    else if( TAG_PTT_TRANSMIT_GRANT.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_REQUEST.equals(m2.getMessageType())) {
                Q = 1; 
            }
	    //---------------------
	    else if( TAG_PTT_TRANSMIT_GRANT.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_START.equals(m2.getMessageType())) {
                Q = -1; 
            }
	    else if( TAG_PTT_TRANSMIT_START.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_GRANT.equals(m2.getMessageType())) {
                Q = 1; 
            }
	    //---------------------
	    else if( TAG_PTT_TRANSMIT_START.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_PROGRESS.equals(m2.getMessageType())) {
                Q = -1; 
            }
	    else if( TAG_PTT_TRANSMIT_PROGRESS.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_START.equals(m2.getMessageType())) {
                Q = 1; 
            }
	    //---------------------
	    else if( TAG_PTT_TRANSMIT_GRANT.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_PROGRESS.equals(m2.getMessageType())) {
                Q = -1; 
            }
	    else if( TAG_PTT_TRANSMIT_PROGRESS.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_GRANT.equals(m2.getMessageType())) {
                Q = 1; 
            }
	    //---------------------
	    else if( TAG_PTT_TRANSMIT_PROGRESS.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_END.equals(m2.getMessageType())) {
                Q = -1; 
            }
	    else if( TAG_PTT_TRANSMIT_END.equals(m1.getMessageType()) &&
                TAG_PTT_TRANSMIT_PROGRESS.equals(m2.getMessageType())) {
                Q = 1; 
            }
	    //---------------------
            logger.debug("compareTo(P2): --------------------------------Q="+Q);
            return Q;
         }
      } catch (NumberFormatException ex) {
         ex.printStackTrace();
         return 0;
      }
   }

   // Use by PttTraceVerifier only ?
   public boolean match(PttMessageData that) {
      for ( String name: that.getProperties().stringPropertyNames())
      {
         if ( getProperties().get(name) == null) 
            return false;
         if ( !getProperties().get(name).equals(that.getProperties().get(name)))
            return false;
      }
      return true;
   }
}
