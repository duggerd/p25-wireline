1. The Concurrent Library is in the public domain and avaialable from OSWEGO.edu
2. The commons http client is from the Apache software foundation.
3. The javax.servlet.jar is from the Apache Tomcat project.
4. JAXME is from the apache JAXME project.
5. JETTY is a small web server obtained from http://mortbay.org
6. The JAIN-SIP API and RI are from the JAIN-SIP project http://jain-sip.dev.java.net
7. The Scripting Engine implementation for Jython 2.1 was obtained from https://scripting.dev.java.net/ and is redistributed under the
terms of the BSD license.
8. The (java python) jython 2.1 imlementation was obtained from http://www.jython.org/ and is redistributed under the terms of the 
license there.

Licenses for these are included in the LICENSES directory.
