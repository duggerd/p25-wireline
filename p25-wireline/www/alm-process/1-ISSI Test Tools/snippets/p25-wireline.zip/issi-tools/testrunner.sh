${ANT_HOME}/bin/ant runscript -Dtest=$1
${ANT_HOME}/bin/ant viewlog
