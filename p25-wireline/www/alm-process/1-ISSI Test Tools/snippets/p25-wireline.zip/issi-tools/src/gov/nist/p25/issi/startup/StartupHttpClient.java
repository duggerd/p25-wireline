package gov.nist.p25.issi.startup;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import javax.swing.JOptionPane;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.issiconfig.WebServerAddress;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.log4j.Logger;

public class StartupHttpClient {
   
   private static Logger logger = Logger.getLogger(StartupHttpClient.class);
 
	private HttpClient httpClient;
	private ISSITesterConfiguration testerConfig;

	//private TopologyConfig systemConfig;
	private TopologyConfig globalConfig;
	private String testerConfigFileName;
	private String systemConfigFileName;
	private String globalConfigFileName;
	private DietsConfigProperties startupProps;

	private String sendHttpRequest(WebServerAddress webServerAddress,
			boolean resultFlag, NameValuePair[] nvPairs, String body)
			throws Exception {
		PostMethod method = new PostMethod(webServerAddress.getHttpControlUrl());

		logger.debug("sending http request to URL "
				+ webServerAddress.getHttpControlUrl());
		method.setQueryString(nvPairs);
      logger.debug("body=" + body);
		if (body != null)
			method.setRequestBody(new ByteArrayInputStream(body.getBytes()));
		try {

			int rc = this.httpClient.executeMethod(method);

			if (rc != 200) {
				String retval = method.getResponseBodyAsString();

				System.out.println("StartupHttpClient: rc= " + rc);
				System.out.println("Failure reason = " + retval);
				throw new Exception("Unexpected error in sending request " + rc);
			}

			if (resultFlag) {
				String retval = method.getResponseBodyAsString();
				return retval;
			} else
				return null;
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null,
					"A failure occured while completing the operation\n"
							+ "Please check if the daemons are running at \n"
							+ " the addresses and ports specified in "
							+ this.testerConfigFileName,
					"Error Communicating with daemons",
					JOptionPane.ERROR_MESSAGE);
			logger.error(ex.getMessage());
			throw ex;
		} finally {
			method.releaseConnection();
		}
	}

	public StartupHttpClient(String configFileName,
			ISSITesterConfiguration testerConfig, String systemConfigFileName,
			String globalConfigFileName, DietsConfigProperties startupProps,
			TopologyConfig globalConfig) {
		this.httpClient = new HttpClient();
		this.systemConfigFileName = systemConfigFileName;
		this.globalConfigFileName = globalConfigFileName;
		this.globalConfig = globalConfig;
		this.testerConfigFileName = configFileName;
		this.testerConfig = testerConfig;
		this.startupProps = startupProps;
	}

	public void shipConfigFiles() throws Exception {
		for (DaemonWebServerAddress config : testerConfig.getDaemonAddresses()) {
			this.sendHttpRequest(config, false, new NameValuePair[] {
					new NameValuePair(ISSITesterConstants.COMMAND,
							ISSITesterConstants.UPDATE_CONFIGURATION_FILE),
					new NameValuePair(ISSITesterConstants.FILENAME_TO_UPDATE,
							testerConfigFileName) }, testerConfig.toString());

			this.sendHttpRequest(config, false, new NameValuePair[] {
					new NameValuePair(ISSITesterConstants.COMMAND,
							ISSITesterConstants.UPDATE_CONFIGURATION_FILE),
					new NameValuePair(ISSITesterConstants.FILENAME_TO_UPDATE,
							systemConfigFileName) }, globalConfig
					.exportSystemTopology());

			if (globalConfigFileName != null) {
				this.sendHttpRequest(config, false, new NameValuePair[] {
						new NameValuePair(ISSITesterConstants.COMMAND,
								ISSITesterConstants.UPDATE_CONFIGURATION_FILE),
						new NameValuePair(
								ISSITesterConstants.FILENAME_TO_UPDATE,
								globalConfigFileName) }, globalConfig
						.exportGlobalTopology());
			}

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			startupProps.store(bos, "Shipped");
			byte bytes[] = bos.toByteArray();
			String startupProps = new String(bytes);

			this.sendHttpRequest(config, false, new NameValuePair[] {
					new NameValuePair(ISSITesterConstants.COMMAND,
							ISSITesterConstants.UPDATE_CONFIGURATION_FILE),
					new NameValuePair(ISSITesterConstants.FILENAME_TO_UPDATE,
							ISSITesterConstants.STARTUP_PROPERTIES_FILENAME) },
					startupProps);

			this.sendHttpRequest(config, false,
					new NameValuePair[] { new NameValuePair(
							ISSITesterConstants.COMMAND,
							ISSITesterConstants.REDRAW) }, null);
		}
	}

	public void startServices() throws Exception {
		for (DaemonWebServerAddress config : testerConfig.getDaemonAddresses()) {
			this.sendHttpRequest(config, false, new NameValuePair[] {
					new NameValuePair(ISSITesterConstants.COMMAND,
							ISSITesterConstants.START_SERVICES),
					new NameValuePair(
							ISSITesterConstants.TESTER_DAEMON_TOPOLOGY,
							testerConfigFileName) }, null);
		}
	}

	public void stopServices() throws Exception {
		for (DaemonWebServerAddress config : testerConfig.getDaemonAddresses()) {
			this.sendHttpRequest(config, false,
					new NameValuePair[] { new NameValuePair(
							ISSITesterConstants.COMMAND,
							ISSITesterConstants.STOP_SERVICES) }, null);
		}
	}

}
