//
package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.GlobalTopologyParser;
import gov.nist.p25.issi.issiconfig.SystemTopologyParser;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfigurationParser;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;

import org.mortbay.http.HttpContext;
import org.mortbay.http.SocketListener;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.servlet.ServletHandler;


public class DietsService {

   private static Logger logger = Logger.getLogger(DietsService.class);

   private static int httpPort = ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT;
   private static Server httpServer;
   private static HttpContext httpContext;

   private DietsConfigProperties configProperties;
   private ISSITesterConfiguration testerconfig;
   private Properties localhostProperties;
   private TopologyConfig topologyConfig;

   protected static boolean daemonRunning;
   protected SocketListener socketListener;


   // accessors
   // TODO: needs a DietsConfigPropertiesHelper
   // --------------------------------------------------
   public String getTesterTopologyFileName() {
      return configProperties.getProperty(
		DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
   }
   public void setTesterTopologyFileName(String testerTopologyFileName) {
      if (testerTopologyFileName != null) {
         configProperties.setProperty(
             DietsConfigProperties.DAEMON_CONFIG_PROPERTY,
             testerTopologyFileName);
      } else {
          configProperties.remove(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
      }
   }

   public String getSystemTopologyFileName() {
      return configProperties.getProperty(
		DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
   }
   public void setSystemTopologyFileName(String systemTopologyFileName) {
      if (systemTopologyFileName == null) {
         configProperties.remove(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
      } else {
         configProperties.setProperty(
		DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
		systemTopologyFileName);
      }
   }
   
   public String getGlobalTopologyFileName() {
      String testSuite = configProperties.getProperty(
		DietsConfigProperties.TESTSUITE_PROPERTY);
      if (testSuite != null)
         return ISSITesterConstants.getGlobalTopologyFileName(testSuite);
      else
         return null;
   }

   public void setTestSuiteName(String testSuiteName) {
      if (testSuiteName == null) {
         configProperties.remove(DietsConfigProperties.TESTSUITE_PROPERTY);
      } else {
         configProperties.setProperty(
            DietsConfigProperties.TESTSUITE_PROPERTY, testSuiteName);
      }
   }

   // --------------------------------------------------
   public StartupHttpClient getStartupHttpClient()
   {
      StartupHttpClient sc = new StartupHttpClient(
            getTesterTopologyFileName(),
            testerconfig,
	    getSystemTopologyFileName(),
            getGlobalTopologyFileName(),
            configProperties,
            topologyConfig);
      return sc;
   }

   public void startTestServices()
   {
      try {
         StartupHttpClient sc = getStartupHttpClient();
         sc.shipConfigFiles();
         sc.startServices();
      }
      catch (Exception ex) {
         logger.error("Error shipping files!", ex);
      }
   } 

   public void stopTestServices()
   {
      try {
         StartupHttpClient sc = getStartupHttpClient();
         sc.stopServices();
      }
      catch (Exception ex) {
         logger.error("Error shipping files!", ex);
      }
   }

   public void startDaemon()
   {
      String ipAddress = null;
      int port = httpPort;
      try {
               httpServer = new Server();

               ipAddress = localhostProperties.getProperty(
			       DietsConfigProperties.DAEMON_IP_ADDRESS);

               socketListener = new SocketListener();
               socketListener.setMaxThreads(10);
               socketListener.setMinThreads(3);
               socketListener.setHost(ipAddress);
               socketListener.setPort(port);
               socketListener.start();

               httpServer.addListener(socketListener);
               httpContext = new HttpContext();
               httpContext.setContextPath("/diets/*");

               ServletHandler servletHandler = new ServletHandler();
               // Register a welcome servlet with the Servlet Handler.
               servletHandler.addServlet("controller", "/controller/*",
                     ConfigurationServlet.class.getName());
               ConfigurationServlet.setServer(httpServer);
//????
//ConfigurationServlet.setClusterManagerStartup(DietsService.this);

               // "gov.nist.p25.issi.servlets.ControlServlet");
               httpContext.addHandler(servletHandler);
               httpServer.addContext(httpContext);

               httpContext.start();
               httpServer.start();
               daemonRunning = true;
      }
      catch (Exception ex) {
          logger.error("Could not bind to " + ipAddress + ":" + port
                     + "\nconfigure IP address and port", ex);

      }
   }

   public void stopDaemon()
   {
      try {
         socketListener.stop();
	 socketListener = null;

         httpContext.stop();
         httpServer.removeContext(httpContext);
         httpServer.stop();
         daemonRunning = false;
      }
      catch (Exception ex) {
         logger.error("Could not stop server", ex);
      }
   }

   public void close() 
   {
      System.out.println("DietsService: close()");
      if(daemonRunning)
      {
         stopDaemon();
      }
   }

   //++++++++++++++++++++++++++++++
   // Constructor
   public DietsService(DietsConfigProperties props, String testSuite,
         String dietsConfigFileName, String systemTopologyFileName)
         throws Exception
   {
      logger.debug("dietsConfigFileName = " + dietsConfigFileName);
      configProperties = (props==null ? new DietsConfigProperties() : props);

      localhostProperties = new Properties();
      try {
         localhostProperties.load(new FileInputStream(new File(
               ISSITesterConstants.LOCALHOST_PROPERTIES_FILE)));
         if (localhostProperties.getProperty(DietsConfigProperties.DAEMON_HTTP_PORT) == null)
            localhostProperties.setProperty(
                  DietsConfigProperties.DAEMON_HTTP_PORT,
		  new Integer(ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT)
                        .toString());
      }
      catch (Exception ex) {
         logger.debug("Cannot read "
               + ISSITesterConstants.LOCALHOST_PROPERTIES_FILE
               + ". Will start daemon on 127.0.0.1 address and port "
               + ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT);
         localhostProperties.setProperty(
               DietsConfigProperties.DAEMON_IP_ADDRESS, "127.0.0.1");
         localhostProperties.setProperty(
               DietsConfigProperties.DAEMON_HTTP_PORT,
	       new Integer( ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT)
                     .toString());
      }

      setTestSuiteName(testSuite);
      setSystemTopologyFileName(systemTopologyFileName);
      setTesterTopologyFileName(dietsConfigFileName);

      if (getTesterTopologyFileName() == null) {
         testerconfig = new ISSITesterConfiguration();
      } else {
         testerconfig = new ISSITesterConfigurationParser(
               getTesterTopologyFileName()).parse();
      }

      if (getGlobalTopologyFileName() == null &&
          getSystemTopologyFileName() != null)
      {
         topologyConfig = new SystemTopologyParser(testerconfig)
               .parse(getSystemTopologyFileName());
      }
      else if (getSystemTopologyFileName() != null)
      {
         TopologyConfig systemTopology = new SystemTopologyParser(
               testerconfig).parse(getSystemTopologyFileName());

         topologyConfig = new GlobalTopologyParser(true).parse(
               systemTopology, getGlobalTopologyFileName());
      }
      else 
      {
         topologyConfig = new TopologyConfig();
      }
   }

   //==============================================================
   public static final void main(String[] args) throws Exception
   {
      PropertyConfigurator.configure("log4j.properties");
      logger.addAppender(new ConsoleAppender(new SimpleLayout()));

      String propertiesFileName = 
	      ISSITesterConstants.STARTUP_PROPERTIES_FILENAME;

      DietsConfigProperties props;
      String testSuite;
      String dietsConfigFileName;
      String systemTopologyFileName;

      // Test-1: all null
      //DietsService service = new DietsService(props, testSuite,
      //   dietsConfigFileName, systemTopologyFileName);

      // Test-2: non-null
      props = new DietsConfigProperties(propertiesFileName);
      testSuite = props.getProperty(DietsConfigProperties.TESTSUITE_PROPERTY);
      dietsConfigFileName = props.getProperty(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
      if (testSuite != null)
         systemTopologyFileName = "testsuites/" +testSuite +"/systemtopology.xml";
      else
         systemTopologyFileName = null;

      DietsService service = new DietsService(props, testSuite,
         dietsConfigFileName, systemTopologyFileName);

      System.out.println("service="+service);
      service.startDaemon();
      service.startTestServices();

      System.out.println("Sleep 10 secs...");
      try {
         Thread.sleep(10000L);
      } catch(Exception ex) { }
      System.out.println("Wakeup...stopXXX()");

      service.stopTestServices();
      service.stopDaemon();

      System.out.println("Done...");
   }
}
