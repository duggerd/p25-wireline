//
package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.constants.ISSILogoConstants;
import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.issiconfig.SystemConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.issiconfig.WacnConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashSet;
import java.util.Hashtable;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import org.apache.log4j.Logger;

import att.grappa.Edge;
import att.grappa.Element;
import att.grappa.Graph;
import att.grappa.Grappa;
import att.grappa.GrappaBox;
import att.grappa.GrappaColor;
import att.grappa.GrappaConstants;
import att.grappa.GrappaListener;
import att.grappa.GrappaPanel;
import att.grappa.GrappaPoint;
import att.grappa.Node;
import att.grappa.Subgraph;

/**
 * A topology editor for the ISSI Tester configuration.
 * 
 * @author M. Ranganathan <mranga@nist.gov>
 * 
 */
public class ClusterConfigurationEditor {
   
   private static Logger logger = Logger.getLogger(ClusterConfigurationEditor.class);
   private Graph graph;
   private GrappaPanel graphPanel;
   private DietsStartup startup;

   private Hashtable<DaemonWebServerAddress, DaemonNode> daemonToNodeMap = new Hashtable<DaemonWebServerAddress, DaemonNode>();
   Hashtable<RfssConfig, RfssNode> rfssToNodeMap = new Hashtable<RfssConfig, RfssNode>();
   private Hashtable<WacnConfig, WacnNode> wacnToNodeMap = new Hashtable<WacnConfig, WacnNode>();
   private Hashtable<SystemConfig, SystemNode> systemToNodeMap = new Hashtable<SystemConfig, SystemNode>();
   private Hashtable<SuConfig, SuNode> suToNodeMap = new Hashtable<SuConfig, SuNode>();
   private Hashtable<GroupConfig, GroupNode> sgToNodeMap = new Hashtable<GroupConfig, GroupNode>();

   private HashSet<GraphNode> nodes = new HashSet<GraphNode>();
   private HashSet<Edge> edges = new HashSet<Edge>();

   private JPopupMenu rightClickPopupMenu;
   private JMenuItem addRfssMenuItem;
   private JMenuItem addDaemonMenuItem;
   private JMenuItem addWacnMenuItem;
   private JMenuItem addSystemMenuItem;
   private JMenuItem helpMenuItem;
   private JMenuItem saveAsMenuItem;
   static  int VERTICAL_SPACING = 80;

   static {
      Grappa.labelGraphBottom = true;
      Grappa.setToolTipText("Mapping of ISSI Tester emulator nodes to daemons");

   }

   class ClusterManagerMouseListener extends MouseAdapter implements
         MouseListener {

      @Override
      public void mouseClicked(MouseEvent e) {

         int buttonNumber = e.getButton();
         if (buttonNumber == 3) {
            rightClickPopupMenu.show(
                  ClusterConfigurationEditor.this.startup, e.getX(), e
                        .getY());
         }
      }
   }

   /**
    * The action listener that fires when you click on a graph element.
    * 
    */

   class ClusterManagerListener implements GrappaListener {

      @Override
      public void grappaClicked(Subgraph subgraph, Element element,
            GrappaPoint grappaPoint, int modifiers, int clickCount,
            GrappaPanel grappaPanel) {
         if (element instanceof Node) {
            GraphNode node = (GraphNode) element;
            node.showAttributes();
         } else if (element instanceof Edge) {
            Edge edge = (Edge) element;
            logger.debug("Clicked on edge" + edge.getName());
         }
      }

      @Override
      public void grappaDragged(Subgraph arg0, GrappaPoint arg1, int arg2,
            Element arg3, GrappaPoint arg4, int arg5, GrappaBox arg6,
            GrappaPanel arg7) {
         // TODO Auto-generated method stub

      }

      @Override
      public void grappaPressed(Subgraph subg, Element elem, GrappaPoint pt,
            int modifiers, GrappaPanel panel) {
         if ((modifiers & (InputEvent.BUTTON2_MASK | InputEvent.BUTTON3_MASK)) != 0
               && (modifiers & (InputEvent.BUTTON2_MASK | InputEvent.BUTTON3_MASK)) == modifiers) {
            java.awt.geom.Point2D mpt = panel.getTransform().transform(pt,
                  null);
            rightClickPopupMenu.show(panel, (int) mpt.getX(), (int) mpt
                  .getY());

         }

      }

      @Override
      public void grappaReleased(Subgraph arg0, Element arg1,
            GrappaPoint arg2, int arg3, Element arg4, GrappaPoint arg5,
            int arg6, GrappaBox arg7, GrappaPanel arg8) {
      }

      @Override
      public String grappaTip(Subgraph arg0, Element arg1, GrappaPoint arg2,
            int arg3, GrappaPanel arg4) {
         return null;
      }
   }

   class ClusterManagerActionListener implements ActionListener {

      @Override
      public void actionPerformed(ActionEvent e) {
         if (e.getSource() == ClusterConfigurationEditor.this.addDaemonMenuItem) {
            logger.debug("Adding a new Diets Daemon");
            DaemonNode
                  .createNewNode(ClusterConfigurationEditor.this, graph);

         } else if (e.getSource() == ClusterConfigurationEditor.this.addWacnMenuItem) {
            logger.debug("Adding a new WACN node");
            WacnNode.createNewNode(ClusterConfigurationEditor.this, graph);

         } else if (e.getSource() == ClusterConfigurationEditor.this.addSystemMenuItem) {
            logger.debug("Adding a new System node");
            SystemNode
                  .createNewNode(ClusterConfigurationEditor.this, graph);
         } else if (e.getSource() == ClusterConfigurationEditor.this.addRfssMenuItem) {
            logger.debug("Adding a new RFSS node");
            RfssNode.createNewNode(ClusterConfigurationEditor.this, graph);
         } else if (e.getSource() == ClusterConfigurationEditor.this.saveAsMenuItem) {
            logger.debug("Saving configuration");
            String systemTopologyFileName = 
               ClusterConfigurationEditor.this.startup.getSystemTopologyFileName();
            String globalTopologyFileName = 
               ClusterConfigurationEditor.this.startup.getGlobalTopologyFileName();
            String daemonTopologyFileName = 
               ClusterConfigurationEditor.this.startup.getTesterTopologyFileName();
            
            new SaveConfigDialog(ClusterConfigurationEditor.this,
                  systemTopologyFileName, globalTopologyFileName,daemonTopologyFileName);
         }

      }

   }
   
   class ClusterManagerHelpActionListener implements ActionListener {

      @Override
      public void actionPerformed(ActionEvent arg0) {
         JOptionPane.showMessageDialog(ClusterConfigurationEditor.this.startup, 
            "This graph represents the logical topology of the system. This \n" +
            "topology is composed from the system topology, the global topology \n" +
            "and the daemon (tester) configuration files shown in the selection tables below. \n" +
            "You can selectively edit the attributes of the nodes in this graph and \n" +
            "add new nodes to the graph. The configuration files \n" +
            "will be updated if you elect to save the configuration or start \n"+
            "the services.", "Help", JOptionPane.INFORMATION_MESSAGE);
      }
   }


   ISSITesterConfiguration getTesterConfig() {
      return startup.getTesterConfiguration();
   }

   TopologyConfig getTopologyConfig() {
      return this.startup.getTopologyConfig();
   }

   public void clear() {
      for (Node node : this.nodes) {
         graph.removeNode(node.getName());
      }
      for (Edge edge : this.edges) {
         graph.removeEdge(edge.getName());
      }
      this.daemonToNodeMap.clear();
      this.rfssToNodeMap.clear();
      this.wacnToNodeMap.clear();
      this.systemToNodeMap.clear();
      this.suToNodeMap.clear();
      this.graph.repaint();
   }

   public void drawRfssNodes() {
      int cnt = 0;
      for (RfssConfig rfssConfig : getTopologyConfig().getRfssConfigurations()) {
         logger.info("adding RFSS" + rfssConfig.getRfssName());
         logger.info("Adding rfss node: " + rfssConfig.getRfssName());

         int xpos = cnt * VERTICAL_SPACING;
         RfssNode node = new RfssNode(this, rfssConfig, graph);
         this.nodes.add(node);
         node.setTsterConfig(getTesterConfig());

         node.setXPosition(xpos);

         node.setAttribute(GrappaConstants.COLOR_ATTR, GrappaColor.getColor(
               "Green", Color.GREEN));

         this.rfssToNodeMap.put(rfssConfig, node);

         graph.addNode(node);
         cnt++;
      }
   }

   public void drawSuNodes() {
      int cnt = 0;

      for (SuConfig suConfig : this.getTopologyConfig().getSuConfigurations()) {
         int xpos = cnt * VERTICAL_SPACING;
         SuNode suNode = new SuNode(this, suConfig, graph);
         suNode.setXPosition(xpos);
         cnt++;
         this.suToNodeMap.put(suConfig, suNode);
         this.nodes.add(suNode);

      }

   }

   public void drawGroupNodes() {
      int cnt = 0;

      for (GroupConfig sgConfig : this.getTopologyConfig()
            .getGroupConfigurations()) {
         int xpos = cnt * VERTICAL_SPACING;
         GroupNode groupNode = new GroupNode(this, sgConfig, graph);

         groupNode.setXPosition(xpos);
         cnt++;
         this.sgToNodeMap.put(sgConfig, groupNode);

         this.nodes.add(groupNode);

      }
   }

   public void redraw() {
      this.clear();
      int cnt = 0;

      if (getTesterConfig() != null) {
         for (DaemonWebServerAddress serverconfig : getTesterConfig()
               .getDaemonAddresses()) {
            logger.info("adding node " + serverconfig.getIpAddress());
            DaemonNode node = new DaemonNode(this, serverconfig, graph);
            this.nodes.add(node);
            graph.addNode(node);
            node.setAttribute(GrappaConstants.BBOX_ATTR, new GrappaBox(
                  new Rectangle(100, 100)));

            this.daemonToNodeMap.put(serverconfig, node);
            cnt++;

         }
      }

      if (getTopologyConfig() != null) {
         cnt = 0;

         for (WacnConfig wacnConfig : getTopologyConfig().getWacnConfigurations()) {
            WacnNode wacnNode = new WacnNode(this, graph, wacnConfig);
            this.nodes.add(wacnNode);
            this.wacnToNodeMap.put(wacnConfig, wacnNode);
            wacnNode.setXPosition(VERTICAL_SPACING * cnt);
            cnt++;
         }

         cnt = 0;

         for (SystemConfig systemConfig : getTopologyConfig()
               .getSystemConfigurations()) {
            SystemNode systemNode = new SystemNode(this, graph,
                  systemConfig);
            this.nodes.add(systemNode);

            this.systemToNodeMap.put(systemConfig, systemNode);
            graph.addNode(systemNode);
            systemNode.setXPosition(cnt * VERTICAL_SPACING);
            WacnConfig wacnConfig = systemConfig.getWacnConfig();
            WacnNode wacnNode = this.wacnToNodeMap.get(wacnConfig);
            Edge edge = new Edge(graph, wacnNode, systemNode);
            this.edges.add(edge);

         }

         cnt = 0;
         for (RfssConfig rfssConfig : getTopologyConfig().getRfssConfigurations()) {
            logger.info("adding RFSS" + rfssConfig.getRfssName());
            logger.info("Adding rfss node: " + rfssConfig.getRfssName());

            int xpos = cnt * VERTICAL_SPACING;
            RfssNode node = new RfssNode(this, rfssConfig, graph);
            this.nodes.add(node);
            node.setTsterConfig(getTesterConfig());
            node.setXPosition(xpos);
            node.setAttribute(GrappaConstants.COLOR_ATTR, GrappaColor
                  .getColor("Green", Color.GREEN));

            this.rfssToNodeMap.put(rfssConfig, node);
            graph.addNode(node);

            SystemConfig systemConfig = rfssConfig.getSysConfig();
            SystemNode systemNode = this.systemToNodeMap.get(systemConfig);

            Edge edge = new Edge(graph, systemNode, node);
            this.edges.add(edge);
            systemNode.setXPosition(xpos);
            WacnConfig wacnConfig = systemConfig.getWacnConfig();
            WacnNode wacnNode = this.wacnToNodeMap.get(wacnConfig);
            wacnNode.setXPosition(xpos);

            if (rfssConfig.isEmulated() && getTesterConfig() != null) {
               String nodeName = rfssConfig.getTag();
               DaemonWebServerAddress serverconfig = getTesterConfig()
                     .getDaemonByName(nodeName);
               if (serverconfig != null) {

                  DaemonNode wsnode = this.daemonToNodeMap
                        .get(serverconfig);
                  edge = new Edge(graph, node, wsnode, nodeName);
                  this.edges.add(edge);
                  // Position daemon nodes near their assigned RFSSs.
                  wsnode.setXPosition(xpos);

                  wsnode.setAttribute(GrappaConstants.COLOR_ATTR,
                        GrappaColor.getColor("Red", Color.RED));
                  serverconfig.setMapped(true);
               }
            }
            cnt++;
         }
         drawSuNodes();
         drawGroupNodes();
      }
      /*
       * These are the guys that do not have any emulated RFSS assigned to
       * them.
       */
      if (getTesterConfig() != null) {
         cnt = 0;
         for (DaemonWebServerAddress serverconfig : getTesterConfig()
               .getDaemonAddresses()) {
            if (!serverconfig.isMapped()) {
               DaemonNode daemonNode = this.daemonToNodeMap
                     .get(serverconfig);
               daemonNode.setXPosition(cnt * VERTICAL_SPACING);
               daemonNode.setAttribute(GrappaConstants.COLOR_ATTR,
                     GrappaColor.getColor("Red", Color.RED));
               cnt++;

            }

         }
      }
      graph.repaint();

   }

   public ClusterConfigurationEditor(DietsStartup dietsStartup, Container container)
         throws Exception {
      this.startup =  dietsStartup;
      startup.setIconImage(new ImageIcon(ISSILogoConstants.ISSI_TESTER_LOGO).getImage());
      startup.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

      this.graph = new Graph("ISSITesterConfiguration");
      this.graph.setAttribute(GrappaConstants.LABEL_ATTR, "Topology Editor");
      this.graph.setAttribute(GrappaConstants.DIR_ATTR, "true");
      this.graph.setSelectable(true);
      this.graphPanel = new GrappaPanel(this.graph);
   
      this.graphPanel.addGrappaListener(new ClusterManagerListener());
      Dimension screenSize =startup.getToolkit().getScreenSize();

      this.graphPanel.setPreferredSize(new Dimension(screenSize.width*3/4,screenSize.height*3/4));
      ClusterConfigurationEditor.VERTICAL_SPACING = screenSize.height/12;

      graphPanel.setScaleToFit(false);
      graphPanel.setAutoscrolls(true);
      
      JScrollPane jscrollPane = new JScrollPane(
            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      jscrollPane.setViewportView(graphPanel);      
      container.add(jscrollPane);

      rightClickPopupMenu = new JPopupMenu();      
      this.helpMenuItem = new JMenuItem("Help");
      helpMenuItem.setActionCommand("Help");
      helpMenuItem.setToolTipText("Help");
      helpMenuItem.addActionListener(new ClusterManagerHelpActionListener());
      rightClickPopupMenu.add(helpMenuItem);
      rightClickPopupMenu.addSeparator();

      this.addDaemonMenuItem = new JMenuItem("New ISSI Tester Daemon");
      addDaemonMenuItem.setActionCommand("New ISSI Tester Daemon");
      addDaemonMenuItem.setToolTipText("Add a new Diets Daemon");
      addDaemonMenuItem.addActionListener(new ClusterManagerActionListener());
      rightClickPopupMenu.add(addDaemonMenuItem);

      this.addWacnMenuItem = new JMenuItem("New WACN Configuration");
      addWacnMenuItem.setActionCommand("New WACN");
      addWacnMenuItem.setToolTipText("Add a WACN Definition");

      addWacnMenuItem.addActionListener(new ClusterManagerActionListener());
      rightClickPopupMenu.add(addWacnMenuItem);

      this.addSystemMenuItem = new JMenuItem("New System Configuration");
      addSystemMenuItem.setActionCommand("New System");
      addSystemMenuItem.setToolTipText("Add a System Definition");
      addSystemMenuItem.addActionListener(new ClusterManagerActionListener());
      rightClickPopupMenu.add(addSystemMenuItem);

      this.addRfssMenuItem = new JMenuItem("New RFSS Configuration");
      this.addRfssMenuItem.setActionCommand("New RFSS Definition");
      addRfssMenuItem.setToolTipText("Add an RFSS Defintion");
      addRfssMenuItem.addActionListener(new ClusterManagerActionListener());
      rightClickPopupMenu.add(addRfssMenuItem);

      rightClickPopupMenu.addSeparator();
      this.saveAsMenuItem = new JMenuItem("Save As ...");
      this.saveAsMenuItem.setToolTipText("Save the configuration.");
      saveAsMenuItem.addActionListener(new ClusterManagerActionListener());
      rightClickPopupMenu.add(saveAsMenuItem);

      this.redraw();

   }

   public JFrame getJFrame() {
      return this.startup;
   }

}
