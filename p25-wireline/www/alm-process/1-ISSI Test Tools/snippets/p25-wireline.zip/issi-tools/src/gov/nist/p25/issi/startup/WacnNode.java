package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;

import gov.nist.p25.issi.issiconfig.WacnConfig;
import att.grappa.Graph;
import att.grappa.GrappaConstants;
import att.grappa.GrappaShape;

public class WacnNode extends GraphNode {
	
	private WacnConfig wacnConfig;
	
	class UpdateActionListener extends CreateActionListener {
		
		private ConfigTableModel tableModel;

		public UpdateActionListener(ConfigTableModel tableModel) {
			this.tableModel = tableModel;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if ( jtable.isEditing()) {
        		jtable.editCellAt(0,0); // Move the focus out so the value takes.
        	}
        	tableModel.fireTableDataChanged();
        	jtable.requestFocus();
       	
			int wacnId = tableModel.getDataAsHexInt("wacnId");
			WacnNode.this.wacnConfig.setWacnId(wacnId);
			WacnNode.this.clusterEditor.redraw();
				
		}		
	}

	public WacnNode(ClusterConfigurationEditor clusterManager, Graph graph, WacnConfig wacnConfig) {
		super(clusterManager,graph);
		this.wacnConfig = wacnConfig;
		super.setYPosition(WACN_YPOSITION);
		super.setName(wacnConfig.getWacnName());
		super
		.setAttribute(GrappaConstants.SHAPE_ATTR,
				GrappaShape.TRAPEZIUM_SHAPE);
	}

	@Override
	public void showAttributes() {
		ConfigTableModel configTableModel = new ConfigTableModel("WACN Config");
		configTableModel.setUnEditable("wacnName");
		configTableModel.setData("wacnName", wacnConfig.getWacnName());
		configTableModel.setData("wacnId",Integer.toHexString(wacnConfig.getWacnId()));
		showTable(this.clusterEditor,configTableModel, new UpdateActionListener(configTableModel));
		
	}
	public static void createNewNode(ClusterConfigurationEditor configEditor, Graph graph) {
		ConfigTableModel configTableModel = new ConfigTableModel("WACN Config");
		
		configTableModel.setData("wacnName", "");
		configTableModel.setData("wacnId", "");
		showTable(configEditor,configTableModel, 
				new CreateNewWacnActionListener(configEditor,configTableModel));	
	}

	@Override
	public void cleanupAction() {
				
	}
	
}
