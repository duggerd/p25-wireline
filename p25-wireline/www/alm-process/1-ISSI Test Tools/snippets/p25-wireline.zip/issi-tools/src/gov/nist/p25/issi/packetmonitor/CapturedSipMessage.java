//
package gov.nist.p25.issi.packetmonitor;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.packetmonitor.PacketMonitor.EndPoint;

import javax.sip.header.CallIdHeader;
import javax.sip.header.TimeStampHeader;
import javax.sip.header.ViaHeader;
import javax.sip.message.Message;

/**
 * Represents a catptured SIP Message.
 * 
 */
public class CapturedSipMessage {

   private final PacketMonitor packetMonitor;

   EndPoint destination;
   long timeStamp;
   Message message;

   CapturedSipMessage(PacketMonitor packetMonitor, EndPoint destination, long time, Message message) {
      this.packetMonitor = packetMonitor;
      this.destination = destination;
      this.message = message;
      this.timeStamp = time;
   }

   /**
    * The captured object which can be a SIP Message or an array of bytes.
    * 
    * @return the stored object.
    */
   public Message getMesage() {
      return message;
   }

   public String toString() {
      String firstLine = ((SIPMessage) message).getFirstLine();
      String source = null;
      ViaHeader viaHeader = (ViaHeader) message.getHeader(ViaHeader.NAME);
      String tid = viaHeader.getBranch();
      RfssConfig destinationRfss = PacketMonitor.topologyConfig.getRfssConfig(
            destination.host, destination.port);
      String destinationRfssDomainName = destinationRfss.getDomainName();
      //int destinationRfssId = destinationRfss.getRfssId();

      if (!firstLine.startsWith(("SIP"))) {
         source = viaHeader.getHost();
         this.packetMonitor.transactionTable.put(tid, destinationRfssDomainName);
         //System.out.println("CapturedSipMessage(1): tid=" +tid +" source=" +source);
      } else {
         source = this.packetMonitor.transactionTable.get(tid);
         if (source == null) {
            PacketMonitor.logger
                  .error("Could not find source for response for transaction id "
                        + tid + "\nmessage = [" + message + "]");
            this.packetMonitor.errorFlag = true;
            this.packetMonitor.errorString = "Could not find source for response for transaction id "
                  + tid + "\nmessage = [" + message + "]";
            return "";
         }
         //System.out.println("CapturedSipMessage(2): tid=" +tid +" source=" +source);
      }

      RfssConfig rfssConfig = PacketMonitor.topologyConfig.getRfssConfig(source);

      if (rfssConfig == null) {
         PacketMonitor.logger.error("could not find rfss config for " + source);
         this.packetMonitor.errorString = ";could not find rfss config for "
               + source;
         this.packetMonitor.errorFlag = true;
         return "";
      }
      String sourceHostPort = rfssConfig.getIpAddress() + ":"
            + rfssConfig.getSipPort();

      String sourceRfssDomainName = rfssConfig.getDomainName();
      // int sourceRfssId = rfssConfig.getRfssId();
      boolean isSender = false;

      long timeStampHeaderValue = 0;
      if (message.getHeader(TimeStampHeader.NAME) != null) {
         TimeStampHeader tsHeader = (TimeStampHeader) message
               .getHeader(TimeStampHeader.NAME);
         timeStampHeaderValue = tsHeader.getTime();
      }
      String callId = ((CallIdHeader) message
            .getHeader(CallIdHeader.NAME)).getCallId();

      if (sourceRfssDomainName.equals(destinationRfssDomainName)) {
         PacketMonitor.logger.debug("Not logging self loop");
         return "";
      }
      String log = "<message\nfrom=\""
            + sourceHostPort
            + "\" \n"
            + "fromRfssId = \""
            + sourceRfssDomainName
            + "\" \n to=\""
            + destination
            + "\"\n toRfssId = \""
            + destinationRfssDomainName
            + "\"\n time=\""
            + timeStamp
            + "\""
            + (timeStampHeaderValue != 0 ? "\ntimeStamp = \""
                  + timeStampHeaderValue + "\"" : "")
            + "\nisSender=\"" + isSender + "\" \ntransactionId=\""
            + tid + "\" \ncallId=\"" + callId + "\" \nfirstLine=\""
            + firstLine.trim() + "\" \n>\n";
      log += "<![CDATA[\n";
      log += message;
      log += "]]>\n";
      log += "</message>\n";
      return log;
   }
}
