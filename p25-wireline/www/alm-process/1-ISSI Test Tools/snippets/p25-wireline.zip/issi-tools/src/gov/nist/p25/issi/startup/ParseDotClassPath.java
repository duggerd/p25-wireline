package gov.nist.p25.issi.startup;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
/**
 * Parses Eclipse's &#x2E;classpath files and turns them into
 * the CLASSPATH env var format. This code is redistributed
 * according to the terms and conditions of the Berkely
 * (BSD) license see LICENSE.txt
 * 
 * @author
 *      Kohsuke Kawaguchi (kk@kohsuke.org)
 */
class ParseDotClasspath {
	private static final String KIND_VAR = "var";
	static Set<String> kinds = new HashSet<String>(Arrays.asList(new String[] { "lib",
			"output", "src", KIND_VAR }));

	class ClasspathBuilder {
		/**
		 * Path separator. The default value is platform-dependent.
		 */
		private String separator = File.pathSeparator;

		private final StringBuffer buf = new StringBuffer();

		/**
		 * Overrides the platform-default separator string.
		 */
		public void setSeparator(String sep) {
			this.separator = sep;
		}

		public void reset() {
			buf.setLength(0);
		}

		/**
		 * Adds a new entry
		 */
		public void add(File f) {
			if (buf.length() != 0)
				buf.append(separator);
			buf.append(f.toString());
		}

		/**
		 * Returns the string formatted for the CLASSPATH variable.
		 */
		public String getResult() {
			return buf.toString();
		}
	}

	

	/**
	 * Reads a ".classpath" file and turns it into a string formatted to fit the
	 * CLASSPATH variable.
	 */
	private void parseDotClasspath(File dotClasspath,
			final ClasspathBuilder builder) throws Exception {
		// all entries in .classpath are relative to this directory.
		final File baseDir = dotClasspath.getParentFile().getAbsoluteFile();

		// XMLReader parser = XMLReaderFactory.createXMLReader();
		SAXParserFactory spf = SAXParserFactory.newInstance();
		spf.setNamespaceAware(true);
		XMLReader parser = spf.newSAXParser().getXMLReader();
		parser.setContentHandler(new DefaultHandler() {
			public void startElement(String uri, String localName,
					String qname, Attributes atts) {
				if (!localName.equals("classpathentry"))
					return; // unknown

				String kind = atts.getValue("kind");
				// We want to only extract the lib portions.
				if (kind != null && kind.equals("lib")) {
					String path = atts.getValue("path");
					if (kind.equals(KIND_VAR)) {
						int i = path.indexOf('/');
						String dir = System.getProperty(path.substring(0, i));
						path = dir + '/' + path.substring(i + 1);
					}

					builder.add(absolutize(baseDir, path));
				}

				String output = atts.getValue("output");
				if (output != null) {
					builder.add(absolutize(baseDir, output));
				}
			}
		});
		parser.parse(dotClasspath.toURI().toString());
	}

	private File absolutize(File base, String path) {
		path = path.replace('/', File.separatorChar);
		File child = new File(path);
		if (child.isAbsolute())
			return child;
		else
			return new File(base, path);
	}
	
	public String parseDotClassPath() throws Exception {
		ClasspathBuilder builder = new ClasspathBuilder();
		parseDotClasspath(new File("./.classpath"), builder);

		return (builder.getResult());

	}
}
