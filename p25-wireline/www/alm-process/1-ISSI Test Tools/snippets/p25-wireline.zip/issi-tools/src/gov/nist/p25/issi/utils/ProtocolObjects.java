//
package gov.nist.p25.issi.utils;

import gov.nist.p25.issi.constants.ISSITesterConstants;

import java.util.HashSet;
import java.util.Properties;

import javax.sip.header.*;
import javax.sip.message.*;
import javax.sip.*;
import javax.sip.address.*;

import org.apache.log4j.Logger;

/**
 * This class contains the Protocol Objects -- i.e. SIP and eventually RTP.
 * 
 * @author M. Ranganathan
 * 
 */
public class ProtocolObjects {
   
   static Logger logger = Logger.getLogger("gov.nist.javax.sip");
   
   public static final HeaderFactory headerFactory;
   public static final MessageFactory messageFactory;   
   public static final AddressFactory addressFactory;   
   public static final SipFactory sipFactory;
   
   private static Properties properties;   
   private static HashSet<SipStack> sipStacks ;
   private static boolean running;
   
   static {
      sipStacks = new HashSet<SipStack>();
      sipFactory = SipFactory.getInstance();
      sipFactory.setPathName("gov.nist");
      properties = new Properties();

      //properties.setProperty("gov.nist.javax.sip.TRACE_LEVEL", "16");
      if ( logger.isDebugEnabled() ) {
         properties.setProperty("gov.nist.javax.sip.TRACE_LEVEL", "32");
      } else {
         properties.setProperty("gov.nist.javax.sip.TRACE_LEVEL", "16");
      }      
      properties.setProperty("gov.nist.javax.sip.DEBUG_LOG", ISSITesterConstants.DEBUG_LOG);
         
      try {
         headerFactory = sipFactory.createHeaderFactory();
         addressFactory = sipFactory.createAddressFactory();
         messageFactory = sipFactory.createMessageFactory();

      } catch (Exception x) {
   
         throw new RuntimeException("Bad initialization ", x);
      }
   }
   
   //-------------------------------------------------------------------
   public static MessageFactory getMessageFactory() {
      return messageFactory;
   }

   public static HeaderFactory getHeaderFactory() {
      return headerFactory;
   }

   public static AddressFactory getAddressFactory() {
      return addressFactory;
   }
   
   public static boolean isRunning() {
      return running;
   }
   
   public static void start() throws Exception {
      logger.debug("Start sip stacks!");
      for (SipStack sipStack: sipStacks) {
         sipStack.start();
      }
      ProtocolObjects.running = true;     
   }

   public static synchronized void stop() {
      logger.debug("Stopping stacks!");
      for (SipStack sipStack: sipStacks) {         
         sipStack.stop();
      }
      sipStacks.clear();
      ProtocolObjects.running = false;    
   }
   
   public static Properties getProperties() {
      return properties;
   }
   public static SipFactory getSipFactory() {
      return sipFactory;
   }
   
   public static void addToSipStacks( SipStack sipStack) {
      sipStacks.add(sipStack);      
   }

/***********
   //EHC: This should be moved to SipStackFactory !!!
   public static SipStack getSipStack(String rfssName, TopologyConfig topologyConfig) {
      try {
         //EHC===
         Properties properties = getProperties();
         // Create SipStack object
         // Log only messages here.         
         properties.setProperty("javax.sip.STACK_NAME", "rfss."+rfssName);
      
         // Log the message contents of the message.
         properties.setProperty("gov.nist.javax.sip.LOG_MESSAGE_CONTENT", "true");
         properties.setProperty("gov.nist.javax.sip.SERVER_LOG",
               "logs/"+ rfssName + ".messagelog.sip");

         properties.setProperty("javax.sip.ROUTER_PATH", RfssRouter.class.getName());
         //"gov.nist.javax.sip.COMPUTE_CONTENT_LENGTH_FROM_MESSAGE_BODY"
         properties.setProperty("gov.nist.javax.sip.COMPUTE_CONTENT_LENGTH_FROM_MESSAGE_BODY", "true");

         //EHC=== SipStack sipStack = sipFactory.createSipStack(properties);
         SipStack sipStack = getSipFactory().createSipStack(properties);
         RfssRouter rfssRouter = (RfssRouter)sipStack.getRouter();
         rfssRouter.setTopologyConfig(topologyConfig);
         logger.debug("createSipStack " + sipStack);
         //EHC=== sipStacks.add(sipStack);
         addToSipStacks( sipStack);
         
         return sipStack;
      } 
      catch (PeerUnavailableException e) {
         // could not find
         // in the classpath
         e.printStackTrace();
         throw new RuntimeException("Bad initialization ", e);
      }      
   }
 **********/

}
