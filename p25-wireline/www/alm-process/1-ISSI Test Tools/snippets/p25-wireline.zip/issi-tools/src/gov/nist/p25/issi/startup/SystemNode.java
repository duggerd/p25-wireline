//
package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;

import gov.nist.p25.issi.issiconfig.SystemConfig;
import att.grappa.Graph;
import att.grappa.GrappaConstants;
import att.grappa.GrappaShape;

/**
 * Graphical representation of a system node.
 * 
 * @author M. Ranganathan
 * 
 */
public class SystemNode extends GraphNode {

	private SystemConfig systemConfig;

	class UpdateActionListener extends CreateActionListener {
		private ConfigTableModel tableModel;

		public UpdateActionListener(ConfigTableModel tableModel) {
			this.tableModel = tableModel;
		}

		@Override
		public void actionPerformed(ActionEvent ae) {

			if (jtable.isEditing()) {
				jtable.editCellAt(0, 0); // Move the focus out so the value
											// takes.
			}
			tableModel.fireTableDataChanged();
			jtable.requestFocus();

			int systemId = tableModel.getDataAsHexInt("systemId");
			systemConfig.setSystemId(systemId);
			String wacnName = tableModel.getDataAsString("wacnName");
			systemConfig.setWacnName(wacnName);
			SystemNode.this.clusterEditor.redraw();
		}
	}

	public SystemNode(ClusterConfigurationEditor clusterManager, Graph graph,
			SystemConfig systemConfig) {
		super(clusterManager, graph);
		super.setName(systemConfig.getSymbolicName());
		this.systemConfig = systemConfig;
		super.setYPosition(SYSTEMNODE_YPOSITION);
		super.setAttribute(GrappaConstants.SHAPE_ATTR,
				GrappaShape.HEXAGON_SHAPE);
	}

	public void showAttributes() {
		ConfigTableModel tableModel = new ConfigTableModel("SystemConfig");
		tableModel.setUnEditable("systemName");
		tableModel.setUnEditable("systemDomainName");
		tableModel.setData("systemName", systemConfig.getSymbolicName());
		tableModel.setData("systemDomainName", systemConfig.getSystemName());
		tableModel.setData("systemId", Integer.toHexString(systemConfig.getSystemId()));
		tableModel.setData("wacnName", systemConfig.getWacnName());
		super.showTable(this.clusterEditor, tableModel,
				new UpdateActionListener(tableModel));
	}

	@Override
	public void cleanupAction() {
	}

	public static void createNewNode(
			ClusterConfigurationEditor clusterConfigurationEditor, Graph graph) {
		ConfigTableModel tableModel = new ConfigTableModel("SystemConfig");
		
		tableModel.setData("systemName", "");
		tableModel.setData("systemId", "");
		tableModel.setData("wacnName", "");
		showTable(clusterConfigurationEditor, tableModel,
				new CreateNewSystemActionListener(clusterConfigurationEditor,tableModel));				
	}
}
