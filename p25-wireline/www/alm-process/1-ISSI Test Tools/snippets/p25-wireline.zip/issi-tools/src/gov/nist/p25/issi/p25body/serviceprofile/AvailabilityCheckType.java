//
package gov.nist.p25.issi.p25body.serviceprofile;

public enum AvailabilityCheckType {
   /*
    * ("AvailCheck"|"DirectCall"|"BothAvailCheckAndDirectCall")
    */
   AVAIL_CHECK_ONLY(1, "SU supports only Availability Check","AvailabilityCheck"), 
   DIRECT_CALL_ONLY(2, "SU supports only Direct Call","DirectCall"), 
   AVAIL_CHECK_AND_DIRECT_CALL(3,"SU supports both Availability Check and Direct Call","AvailabilityCheckAndDirectCall");

   private int intValue;
   private String shortDesc;
   private String description;
   
   AvailabilityCheckType(int dup, String desc, String shortDesc) {
      this.intValue = dup;
      this.description = desc;
      this.shortDesc = shortDesc;
   }

   public int getIntValue() {
      return intValue;
   }

   @Override
   public String toString() {
      return description;
   }

   public static AvailabilityCheckType getInstance(int typeval) {
      for (AvailabilityCheckType d : AvailabilityCheckType.values())
         if (d.intValue == typeval)
            return d;
      throw new IllegalArgumentException("Value out of range: "+typeval);
   }
   
   public static AvailabilityCheckType getInstance(String desc) {
      for (AvailabilityCheckType acType : AvailabilityCheckType.values() ) {
         if ( desc.equals(acType.shortDesc)) {
            return acType;
         }
      }
      throw new IllegalArgumentException("Invalid value: " + desc);
   }
}
