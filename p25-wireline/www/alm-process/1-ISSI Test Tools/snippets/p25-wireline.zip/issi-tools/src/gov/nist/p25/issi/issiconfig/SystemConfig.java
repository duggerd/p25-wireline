package gov.nist.p25.issi.issiconfig;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Iterator;

/**
 * A class that defines the identity of a system.
 * 
 * @author M. Ranganathan
 * 
 */
@SuppressWarnings("unchecked")
public class SystemConfig implements Serializable {
   
   private static final long serialVersionUID = -1L;
   
   private WacnConfig wacnConfig;   
   private int systemId;   
   private String sname;   
   private boolean assigned;

   /**
    * The topology of the system.
    */
   private TopologyConfig topologyConfig;

   /**
    * A table of all the RFSSs configured for which I am the system.
    */
   private Hashtable<String, RfssConfig> rfssTable;


   public SystemConfig(TopologyConfig topologyConfig, String systemName, WacnConfig wacnConfig, int systemId) {
      
      if (systemId > (1 << 13) - 1)
         throw new IllegalArgumentException(
               "value too large only 12 bits for systemId");
      
      this.sname = systemName;
      this.wacnConfig = wacnConfig;
      this.wacnConfig.setAssigned(true);
      this.systemId = systemId;
      this.rfssTable = new Hashtable<String, RfssConfig>();
      this.topologyConfig = topologyConfig;
   }

   public static String getSystemName(int wacnId, int systemId) {
      String wacnIdName = Integer.toHexString(wacnId);
      int diff = 5 - wacnIdName.length();

      // prepend 0's to the right length.
      for (int i = 0; i < diff; i++) {
         wacnIdName = "0" + wacnIdName;
      }

      String systemIdName = Integer.toHexString(systemId);
      diff = 3 - systemIdName.length();
      for (int i = 0; i < diff; i++) {
         systemIdName = "0" + systemIdName;
      }
      return systemIdName + "." + wacnIdName;
   }

   /**
    * Get the symbolic name of the system.
    */
   public String getSymbolicName() {
      return sname;
   }
   
   /**
    * Get the domain name for the system ( as defined in 3.4.1.1 of the spec ).
    * 
    * @return formatted system name of the system.
    */
   public String getSystemName() {
      return getSystemName(wacnConfig.getWacnId(), systemId);
   }

   public String getWacnName() {
      return wacnConfig.getWacnName();
   }
   
   public void addRfss(RfssConfig rfssConfig) {
      String key = rfssConfig.getDomainName();
      rfssTable.put(key, rfssConfig);

   }

   public RfssConfig getRfssConfig(int rfssId) {
      String key = RfssConfig.getDomainName(this, rfssId);
      return (RfssConfig) rfssTable.get(key);
   }

   public Iterator getRfssConfigurations() {
      return rfssTable.values().iterator();
   }

   public TopologyConfig getTopologyConfig() {
      return topologyConfig;
   }

   public int getSystemId() {
      return systemId;
   }

   public int getWacnId() {
      return wacnConfig.getWacnId();
   }

   public void setAssigned(boolean assigned) {
      this.assigned = assigned;
   }

   public boolean isAssigned() {
      return assigned;
   }

   public WacnConfig getWacnConfig() {      
      return wacnConfig;
   }

   public void setSystemId(int systemId) {
      this.systemId = systemId;      
   }

   public void setWacnName(String wacnName) {
      WacnConfig wacnConfig = this.topologyConfig.getWacnConfig(wacnName);
      if ( wacnConfig == null )
         throw new IllegalArgumentException("Bad wacn name " + wacnName);
      else
         wacnConfig = topologyConfig.getWacnConfig(wacnName);      
   }
   
   public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append("<systemconfig\n");
      sb.append("\tsystemName=\"" + sname + "\"\n");
      sb.append("\tsystemId=\"" + Integer.toHexString(systemId) + "\"\n"); 
      sb.append("\twacnName=\"" + wacnConfig.getWacnName() +"\"\n/>\n");
      return sb.toString();
   }
}
