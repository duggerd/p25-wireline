//
package gov.nist.p25.issi.packetmonitor.gui;

/**
 * Control interface for the packet monitor.
 * 
 * @author mranga
 * @author niepin
 *
 */
public interface PacketMonitorController {

   /**
    * Start packet capture.
    *
    */
   void startCapture() throws Exception;

   /**
    * Fetch and display SIP and PTT traces.
    *
    */
   String fetchSipTraces() throws Exception;
   
   String fetchPttTraces() throws Exception;
   
   /**
    * Fetch result table string
    * @return
    * @throws Exception
    */
   String fetchResult() throws Exception;
   
   /**
    * Fetch error status.
    */
   boolean fetchErrorFlag() throws Exception;
   
   /**
    * Fetch the error String.
    */
   String fetchErrorString() throws Exception;
}
