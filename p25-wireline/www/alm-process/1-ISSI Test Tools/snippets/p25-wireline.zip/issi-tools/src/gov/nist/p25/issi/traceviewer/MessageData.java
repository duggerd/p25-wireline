//
package gov.nist.p25.issi.traceviewer;

import java.awt.Dimension;

/**
 * @author steveq@nist.gov
 * @version $Revision: 1.3 $, $Date: 2007/07/05 00:20:59 $
 * @since 1.5
 */
public abstract class MessageData {
      
   private int id;
   private String fromRfssId;
   private String toRfssId;
   private String fromPort;
   private String toPort;
   private String messageType;

   private String textData = "";
   private String data;
   private String time;
   private int x;
   private int y;
   private Dimension dimension;
   private String colorMapKey;
   private boolean selected = false;   
   private boolean isSender  = false;
   
   public MessageData(String fromRfssId, String toRfssId, String fromPort, 
         String toPort, String messageType,
         String data, String time, String colorMapKey, 
         boolean selected, boolean isSender) {
      this.fromRfssId = fromRfssId;
      this.toRfssId = toRfssId;
      this.fromPort = fromPort;
      this.toPort = toPort;
      this.messageType = messageType;
      this.data = data;
      this.time = time;
      this.setColorMapKey(colorMapKey);
      this.setSelected(selected);
      this.id = -1;
      this.setSender(isSender);
   }

   public String getFromRfssId() {
      return  ! isSender() ?fromRfssId : toRfssId;
   }

   public String getToRfssId() {
      return ! isSender() ? toRfssId : fromRfssId;   
   }

   public String getFromPort() {
      return !isSender() ? fromPort : toPort;
   }

   public String getToPort() {
      return !isSender() ? toPort : fromPort;
   }

   public String getMessageType() {
      return messageType;
   }

   public String getData() {
      return data;
   }
   
   // Uses to reformat data into ISSI Spec
   public String getTextData() {
      return textData;
   }
   public void setTextData(String textData) {
      this.textData = textData;
   }

   public String getTime() {
      return this.time;
   }

   public String colorMapKey() {
      return getColorMapKey();
   }

   public void setId(int id) {
      this.id = id;
   }

   public int getId() {
      return id;
   }
   
   //M1031:disabled public abstract String getRtfText();

   public void setY(int y) {
      this.y = y;
   }
   public int getY() {
      return y;
   }

   public void setX(int x) {
      this.x = x;
   }
   public int getX() {
      return x;
   }

   public void setDimension(Dimension dimension) {
      this.dimension = dimension;
   }

   public Dimension getDimension() {
      return dimension;
   }

   private void setColorMapKey(String colorMapKey) {
      this.colorMapKey = colorMapKey;
   }

   public String getColorMapKey() {
      return colorMapKey;
   }

   public void setSelected(boolean selected) {
      this.selected = selected;
   }

   public boolean isSelected() {
      return selected;
   }

   void setSender(boolean isSender) {
      this.isSender = isSender;
   }

   boolean isSender() {
      return isSender;
   }
}
