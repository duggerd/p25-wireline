//
package gov.nist.p25.issi.traceviewer;

import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.p25body.ContentList;
import gov.nist.p25.issi.p25body.SdpContent;
import gov.nist.p25.issi.utils.ProtocolObjects;
import gov.nist.javax.sip.parser.StringMsgParser;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.TreeSet;

import javax.sdp.MediaDescription;
import javax.sdp.SessionDescription;
import javax.sip.header.CSeqHeader;
import javax.sip.header.ViaHeader;
import javax.sip.message.Message;
import javax.sip.message.Request;
import javax.sip.message.Response;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SipTraceFileParser extends DefaultHandler {
   
   private static Logger logger = Logger.getLogger(SipTraceFileParser.class);
   
   private TopologyConfig topologyConfig;
   private TreeSet<SipMessageData> messageList;
   private HashSet<RfssData> rfssList = new HashSet<RfssData>();
   private String myIpAddress;
   private String mySipRecvPort;
   private String myRfssId;
   private String remoteRfssId;
   private String remoteSipRecvPort;
   private String messageType;
   private String time;
   private String timeStamp;
   private String transactionId;
   private StringBuffer sipMessageData = new StringBuffer();
   private Hashtable<String, HashSet<PttSessionInfo>> runtimeData;
   private int counter;
   private SAXParser saxParser;
   private InputStream inputStream;
   
   // accessor
   public HashSet<RfssData> getRfssList() {
      return rfssList;
   }

   // /////////////////////////////////////////////////////////////////////
   // Constructor
   // /////////////////////////////////////////////////////////////////////
   public SipTraceFileParser(InputStream inputStream,
         Hashtable<String, HashSet<PttSessionInfo>> runtimeData,
         TopologyConfig topologyConfig) {

      this.topologyConfig = topologyConfig;
      this.messageList = new TreeSet<SipMessageData>();
      this.runtimeData = runtimeData;      
      this.inputStream = inputStream;

      try {
         SAXParserFactory factory = SAXParserFactory.newInstance();
         saxParser = factory.newSAXParser();
      
      } catch (Exception t) {
         throw new RuntimeException("Unexpected error configuring parser", t);
      }
   }
   
   public void parse() throws Exception {
      StringMsgParser.setComputeContentLengthFromMessage(true);
      saxParser.parse(inputStream,this);
   }

   // /////////////////////////////////////////////////////////////////////
   // Methods
   // /////////////////////////////////////////////////////////////////////
   public void startElement(String namespaceURI, String localName,
         String qualifiedName, Attributes attrs) 
      throws SAXException {

      String elementName = localName;
      if ("".equals(elementName)) {
         elementName = qualifiedName;
      }
      if (attrs != null) {

         for (int i = 0; i < attrs.getLength(); i++) {
            String attributeName = attrs.getLocalName(i);
            if ("".equals(attributeName)) {
               attributeName = attrs.getQName(i);
            }
            handleAttribute(attributeName, attrs.getValue(i));
         }
      }
   }

   public void handleAttribute(String attrName, String attrValue) {

      // Check if we need to add a new RFSS object
      if (attrName.equals("from")) {
         int portIndex = attrValue.indexOf(':');
         myIpAddress = attrValue.substring(0, portIndex);
         mySipRecvPort = attrValue.substring(portIndex + 1);
      } else if (attrName.equals("fromRfssId")) {
         myRfssId = attrValue;
      } else if (attrName.equals("toRfssId")) {
         remoteRfssId = attrValue;
      } else if (attrName.equals("to")) {
         int portIndex = attrValue.indexOf(':');
         remoteSipRecvPort = attrValue.substring(portIndex + 1);
      } else if (attrName.equals("firstLine")) {
         messageType = attrValue;
      } else if (attrName.equals("time")) {
         time = attrValue;
      } else if (attrName.equals("timeStamp")) {
         timeStamp = attrValue;
      } else if (attrName.equals("transactionId")) {
         transactionId = attrValue;      
      }
   }

   public void endElement(String namespaceURI, String simpleName,
         String qualifiedName) throws SAXException {

      Message message = null;
      try {
         if (qualifiedName.equals("message")) {

            String msgData = sipMessageData.toString();
            //String xmsgData = SipMessageFormatter.format( msgData);
            //System.out.println("+++++++++++MsgData\n"+msgData+"\n---------------\n");
         
            //if (sipMessageData.toString().length() != 0) {
            if (msgData.length() != 0) {

               SipMessageData messageData = new SipMessageData(myRfssId,
                     remoteRfssId, mySipRecvPort, remoteSipRecvPort,
                     messageType, msgData, time,     // M1016
                     timeStamp, transactionId, false);

               messageList.add(messageData);
               logger.debug("Added " + messageData.getFromRfssId()
                     + " messageType " + messageType + " tid "
                     + transactionId);
               
               // Set RFSSs list here
               if (!RfssUtil.rfssExists(rfssList, myRfssId)) {

                  RfssData rfssData = new RfssData(myRfssId, myIpAddress,
                        mySipRecvPort);
                  RfssConfig rfssConfig = this.topologyConfig
                        .getRfssConfig(myIpAddress, Integer
                              .parseInt(mySipRecvPort));
                  if (rfssConfig == null) {
                     logger.error(
                           "Cannot find RfssConfig for " + myIpAddress
                                 + ":" + mySipRecvPort);
                     return;
                  }
                  rfssData.setRfssConfig(rfssConfig);
                  rfssData.setTime(Long.parseLong(time), 0);

                  rfssList.add(rfssData);
                  HashSet<PttSessionInfo> sessionInfo = 
                     this.runtimeData != null ? this.runtimeData
                        .get(rfssConfig.getDomainName())
                        : null;
                  if (sessionInfo != null)
                     rfssData.setPttSessionInfo(sessionInfo);
               } else {
                  RfssData rfssData = RfssUtil.getRfss(rfssList, myRfssId);
                  long t = Long.parseLong(time);
                  if (t < rfssData.getTime()) {
                     rfssData.setTime(t, 0);
                  }
               }
               RfssConfig remoteRfss = topologyConfig.getRfssConfig(remoteRfssId);

               if (remoteRfss != null
                     && !RfssUtil.rfssExists(rfssList, remoteRfssId)) {
                  RfssData rfssData = new RfssData(remoteRfssId,
                        remoteRfss.getIpAddress(), remoteSipRecvPort);
                  // The remote RFSS is the destination of the message. It
                  // is delayed by 1 for the sorting order.
                  rfssData.setTime(Long.parseLong(time), 1);
                  rfssData.setRfssConfig(remoteRfss);
                  rfssList.add(rfssData);
                  HashSet<PttSessionInfo> sessionInfo = 
                     this.runtimeData != null ? this.runtimeData
                        .get(remoteRfss.getDomainName())
                        : null;
                  if (sessionInfo != null)
                     rfssData.setPttSessionInfo(sessionInfo);
                  
               } else if (RfssUtil.rfssExists(rfssList, remoteRfssId)) {
                  RfssData rfssData = RfssUtil.getRfss(rfssList,remoteRfssId);
                  long t = Long.parseLong(time);
                  if (t < rfssData.getTime()) {
                     rfssData.setTime(t, 1);
                  }

               } else
                  logger.error("Could not find remoteRfssId" + remoteRfssId);

               // We now attempt to assign ports to the Rfss using
               // the sdp data in the signaling messages.
               if (msgData.trim().startsWith("SIP")) {
                  // Looking at a response here.
                  Response sipResponse = ProtocolObjects.messageFactory
                        .createResponse(msgData);    //M1016
                  message = sipResponse;
                  
                  //====================
                  //System.out.println("SipTraceFileParser: createResponse=\n"+sipResponse);
                  //====================

                  if (sipResponse.getStatusCode() == Response.OK
                        && ((CSeqHeader) sipResponse
                              .getHeader(CSeqHeader.NAME))
                              .getMethod().equals(Request.INVITE)) {
                     // logger.debug("Found an OK - assigning ports");
                     for (MessageData mdata : this.messageList) {
                        SipMessageData smData = (SipMessageData) messageData;

                        if (mdata.getMessageType().startsWith(Request.INVITE)) {
                           logger.debug("checking TID "+ smData.getTransactionId());
                           if (smData.getTransactionId().equals(transactionId)) {
                              String fromRfssId = smData.getFromRfssId();
                              //M1009 String toRfssId = smData.getToRfssId();
                              // Now get the SdpPort.
                              ContentList contentList = ContentList
                                    .getContentListFromMessage(sipResponse);
                              SdpContent sdpContent = (SdpContent) ContentList
                                    .getContentByType(contentList,
                                          "application", "sdp");
                              SessionDescription sd = sdpContent
                                    .getSessionDescription();
                              int port = ((MediaDescription) sd
                                    .getMediaDescriptions(false)
                                    .get(0)).getMedia()
                                    .getMediaPort();
                              boolean added = false;
                              for (RfssData rd : this.rfssList) {
                                 logger.debug("RfssDataDomain name  = "
                                       + fromRfssId+ " checking "
                                       + rd.getRfssConfig().getDomainName());
                                 if (rd.getRfssConfig()
                                       .getDomainName().equals(fromRfssId)) {
                                    added = true;
                                    rd.addPort(new Integer(port).toString());
                                 }
                              }
                              if (!added) {
                                 logger.error("Could not find rfss "+ fromRfssId);
                              }
                           }
                        }
                     }
                  }
                  messageData.setSipMessage(sipResponse);
               } else {
                  Request sipRequest = ProtocolObjects.messageFactory
                        .createRequest(msgData);

                  message = sipRequest;
                  if (sipRequest.getMethod().equals(Request.INVITE)) {
                     // Now get the SdpPort.
                     ContentList contentList = ContentList
                           .getContentListFromMessage(sipRequest);
                     SdpContent sdpContent = (SdpContent) ContentList
                           .getContentByType(contentList,
                                 "application", "sdp");
                     SessionDescription sd = sdpContent
                           .getSessionDescription();
                     int port = ((MediaDescription) sd
                           .getMediaDescriptions(false).get(0))
                           .getMedia().getMediaPort();
                     ViaHeader via = (ViaHeader) sipRequest
                           .getHeader(ViaHeader.NAME);
                     String rfssId = via.getHost();
                     boolean added = false;
                     for (RfssData rd : rfssList) {
                        if (rd.getRfssConfig().getDomainName().equals(
                              rfssId)) {
                           rd.addPort(new Integer(port).toString());
                           added = true;
                        }
                     }
                     if (!added)
                        logger.error("Did not add port " + port
                              + " rfssId = " + rfssId);
                  }
                  messageData.setSipMessage(sipRequest);
               }

               if (time == null 
                     || myIpAddress == null
                     || remoteSipRecvPort == null 
                     || time == null
                     || sipMessageData.equals(""))
                  throw new SAXException("missing a required attribute");

               // Reset data
               myIpAddress = null;
               mySipRecvPort = null;
               myRfssId = null;
               remoteRfssId = null;
               remoteSipRecvPort = null;
               messageType = null;
               sipMessageData = new StringBuffer();
               time = null;
               timeStamp = null; // NOT a required attribute.
               // Note -- default value MUST be NULL not ""
            }
         }
      } catch (Exception ex) {
         logger.fatal("Error in parsing retrieved message " + message, ex);
         throw new SAXException(ex);   // M1009
      }
   }

   public void characters(char buf[], int offset, int len) throws SAXException {
      sipMessageData.append(buf, offset, len);
   }

   public ArrayList<SipMessageData> getRecords() {
      ArrayList<SipMessageData> alist = new ArrayList<SipMessageData>();
      for (Iterator<SipMessageData> it = messageList.iterator();
            it.hasNext();) {
         SipMessageData mdata = it.next();
         mdata.setId(++counter);
         alist.add(mdata);
      }
      return alist;
   }

}
