//
package gov.nist.p25.issi.testlauncher;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;

/**
 * Splash screen for DIETS.
 * 
 * @author steveq@nist.gov
 * @version $Revision: 1.7 $, $Date: 2007/08/17 01:49:42 $
 * @since 1.5
 */

public class SplashScreen extends JWindow {
   
   private static final long serialVersionUID = -1L;
   
   public SplashScreen(String filename, Frame f, int waitTime) {
      super(f);
      JLabel l = new JLabel(new ImageIcon(filename));
      getContentPane().add(l, BorderLayout.CENTER);
      pack();
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension labelSize = l.getPreferredSize();
      setLocation(screenSize.width / 2 - (labelSize.width / 2),
            screenSize.height / 2 - (labelSize.height / 2));
      addMouseListener(new MouseAdapter() {
         public void mousePressed(MouseEvent e) {
            setVisible(false);
            dispose();
         }
      });
      final int pause = waitTime;
      final Runnable closerRunner = new Runnable() {
         public void run() {
            setVisible(false);
            dispose();
         }
      };
      Runnable waitRunner = new Runnable() {
         public void run() {
            try {
               Thread.sleep(pause);
               SwingUtilities.invokeAndWait(closerRunner);
            } catch (Exception e) {
               e.printStackTrace();
               // can catch InvocationTargetException
               // can catch InterruptedException
            }
         }
      };
      setVisible(true);
      Thread splashThread = new Thread(waitRunner, "SplashThread");
      splashThread.start();
   }
}
