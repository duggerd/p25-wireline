//
package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

/**
 * The table model for the startup properties table.
 * 
 * @author mranga@nist.gov
 *
 */
@SuppressWarnings("unchecked")
public class StartupPropertiesTableModel extends AbstractTableModel {
   
   private static final long serialVersionUID = -1L;
   
	private Properties valueTable;
	private Hashtable<Integer, String> indexToNameTable = new Hashtable<Integer, String>();
	private int index = 0;
	private Hashtable<Integer, JButton> indexToButtonTable[] = new Hashtable[3];

	public StartupPropertiesTableModel( Properties valueTable) {
		indexToButtonTable[0] = new Hashtable<Integer, JButton>();
		indexToButtonTable[1] = new Hashtable<Integer, JButton>();
		indexToButtonTable[2] = new Hashtable<Integer,JButton>();
		this.valueTable = valueTable;
	}

	/**
	 * Method for initially populating the table.
	 */
	public void setData(String name, Object value, JButton selectButton,
			JButton clearButton) {
		if (value != null && ! value.toString().equals(""))
			valueTable.put(name, value);
		else 
			valueTable.remove(name);
		indexToNameTable.put(new Integer(index), name);
		if ( selectButton == null || clearButton == null ) 
		   throw new NullPointerException("Null value");
		indexToButtonTable[0].put(index, selectButton);
		indexToButtonTable[1].put(index, clearButton);
		JButton helpButton = new JButton("What is this?");
		indexToButtonTable[2].put(index, helpButton);
		helpButton.addActionListener ( new ActionListener() {
			private String propName;

			public ActionListener setPropName(String propName) {
				this.propName = propName;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent ae) {
				DietsStartup.showHelpText(propName);				
			}			
		}.setPropName(name));
		index++;
	}

	/**
	 * This method is for inputting from a file selection menu.
	 */
	public void setData(String name, Object value) {
		if ( value == null || ((String) value).equals("") )
			this.valueTable.remove(name);
		else
			this.valueTable.put(name, value);
	}

	@Override
	public int getColumnCount() {
		return 5;
	}

	@Override
	public int getRowCount() {
		return index;
	}

	@Override
	public Object getValueAt(int row, int column) {
		if (column == 0) {
			return indexToNameTable.get(row);
		} else if (column == 1) {
			String name = indexToNameTable.get(row);
			return valueTable.get(name) == null ?  "" : valueTable.get(name) ;
		} else if (column == 2 || column == 3 || column == 4) {
			return indexToButtonTable[column - 2].get(row);
		} else {
			throw new IllegalArgumentException("bad column " + column);
		}
	}

	@Override
	public void setValueAt(Object value, int row, int column) {
		if ( value == null ) throw new NullPointerException("Attempt to insert a null ");
		String propName = indexToNameTable.get(row);
		this.setData(propName, value);
	}

	@Override
	public Class getColumnClass(int column) {
		return getValueAt(0, column).getClass();		
	}

	@Override
	public boolean isCellEditable(int row, int col) {
		if (col == 4 || col == 3 || col == 2 || col == 0)
			return false;
		else
			return true;
	}
}