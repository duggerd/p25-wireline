//
package gov.nist.p25.issi.p25body;

import gov.nist.p25.issi.constants.ISSIConstants;
import gov.nist.p25.issi.utils.ProtocolObjects;

import java.text.ParseException;
import java.util.Iterator;

import javax.sip.header.ContentTypeHeader;
import javax.sip.message.Message;
import javax.sip.header.*;

import org.apache.log4j.Logger;

/**
 * Content list for multipart mime content type.
 * 
 * @author M. Ranganathan
 * 
 */
public class ContentList extends java.util.LinkedList<Content> {
   
   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ContentList.class);
   
   private static HeaderFactory headerFactory = ProtocolObjects.getHeaderFactory();
   private static final ContentTypeHeader multipartMimeContentTypeHeader;

   static {
      try {
         multipartMimeContentTypeHeader = headerFactory
               .createContentTypeHeader("multipart", "mixed");
         multipartMimeContentTypeHeader.setParameter("boundary", "\""
               + ISSIConstants.BODY_BOUNDARY + "\"");
         logger.debug("multipartMimeContentTypeHeader  = "
               + multipartMimeContentTypeHeader);
      } catch (ParseException ex) {
         throw new RuntimeException(ex);
      }
   }
   
   // M1012
   private Content unmatchedContent;
   
   public Content getUnmatchedContent() {
      return unmatchedContent;
   }

   /**
    * Creates a default content list.
    */
   public ContentList() {
      this.add(CallParamContent.createCallParamContent());
      this.add(RegisterParamContent.createRegisterParamContent());
   }

   private int packingSize() {
      int retval = 0;
      for (Content content : this) {
         if (!content.isDefault())
            retval++;
      }
      return retval;
   }

   @Override
   public boolean add(Content content) {

      for (Iterator<Content> ci = this.iterator(); ci.hasNext();) {
         if (ci.next().getClass().equals(content.getClass())) {
            ci.remove();
         }
      }
      return super.add(content);
   }

   /**
    * Return the Content type header to assign to the outgoing sip meassage.
    * 
    * @return
    */
   public ContentTypeHeader getContentTypeHeader() {
      if (this.packingSize() > 1)
         return multipartMimeContentTypeHeader;
      else {
         for (Content content : this) {
            if (!content.isDefault())
               return content.getContentTypeHeader();
         }
         return null;
      }
   }

   @Override
   public String toString() {
      StringBuffer stringBuffer = new StringBuffer();
      if (this.packingSize() > 1) {
         for (Content content : this)
            content.boundary = ISSIConstants.CONTENT_BOUNDARY;
      }

      for (Content content : this) {
         if (!content.isDefault())
            stringBuffer.append(content.toString());
      }
      return stringBuffer.toString();
   }

   public String toRtfString() {
      StringBuffer stringBuffer = new StringBuffer();
      if (this.packingSize() > 1) {
         for (Content content : this)
            content.boundary = ISSIConstants.CONTENT_BOUNDARY;
      }
      for (Content content : this) {
         if (!content.isDefault())
            stringBuffer.append(content.toRtfString());
      }
      return stringBuffer.toString();
   }

   /**
    * Get only the specified content from this list of contents. This is used
    * for in-place editing of the SDP
    */
   public Content getContent(String contentType, String contentSubtype) {
      Content retval = null;
      for (Content content : this) {
         ContentTypeHeader contentTypeHeader = content
               .getContentTypeHeader();
         if (contentTypeHeader.getContentType().equals(contentType)
               && contentTypeHeader.getContentSubType().equals(
                     contentSubtype)) {
            retval = content;
         }
      }
      return retval;
   }

   /**
    * unpack a multipart mime packet and return a list of content packets.
    * 
    * @return -- an iterator of Content blocks.
    * 
    */
   private static ContentList createContentList(String body)
         throws ParseException {
         
      String delimiter = ISSIConstants.CONTENT_BOUNDARY;
      String[] fragments = body.split(delimiter);
      ContentList llist = new ContentList();

      if (logger.isDebugEnabled()) {
         logger.debug("nFragments = " + fragments.length);
         logger.debug("delimiter = " + delimiter);
         logger.debug("body = " + body);
      }

      for (String nextPart : fragments) {
         // NOTE - we are not hanlding line folding for the sip header here.

         StringBuffer strbuf = new StringBuffer(nextPart);
         while (strbuf.length() > 0
               && (strbuf.charAt(0) == '\r' || strbuf.charAt(0) == '\n'))
            strbuf.deleteCharAt(0);

         if (strbuf.length() == 0)
            continue;
         nextPart = strbuf.toString();
         int position = nextPart.indexOf("\r\n");
         String rest;
         int off = 4;
         if (position == -1) {
            position = nextPart.indexOf("\n");
            off = 2;
         }
         if (position == -1)
            throw new ParseException("no content type header found in "
                  + nextPart, 0);
         rest = nextPart.substring(position + off);

         if (rest == null)
            throw new ParseException("No content [" + nextPart + "]", 0);
         // logger.debug("rest = [[" + rest + "]]");
         String contentType = nextPart.substring(0, position);
         int pos = contentType.indexOf(":");

         ContentTypeHeader ctHeader = null;
         try {
            ctHeader = (ContentTypeHeader) headerFactory.createHeader(
                  contentType.substring(0, pos), contentType.substring(
                        pos + 1).trim());
         } catch (ClassCastException ex) {
            logger.debug("body = " + body);
            throw new ParseException(
                  "Expecting a content type header got [" + contentType
                        + "]", 0);
         }

         Content content;
         if (ctHeader.getContentType().equals(ISSIConstants.APPLICATION)
               && ctHeader.getContentSubType().equals(ISSIConstants.SDP)) {

            content = new SdpContent(ctHeader, rest);
            // Set the delimiter - this is to be set for a multipart message
            // so that the pack
            // routine will know what to do with it.
            // content.boundary = delimiter;
         } else if (ctHeader.getContentType().equals(
               ISSIConstants.APPLICATION)
               && ctHeader.getContentSubType().equalsIgnoreCase(
                     ISSIConstants.X_TIA_P25_ISSI)) {
            if (rest.startsWith("u-")) {
               content = new UserServiceProfileContent(ctHeader, rest);
            } else if (rest.startsWith("g-")) {
               content = new GroupServiceProfileContent(ctHeader, rest);
            } else if (rest.startsWith("c-")) {
               content = new CallParamContent(ctHeader, rest);
            } else if (rest.startsWith("r-")) {
               content = new RegisterParamContent(ctHeader, rest);
            } else
               throw new ParseException("Unrecognized content ===>> "
                     + rest, 0);

            // content.boundary = delimiter;
         } else {
            throw new ParseException("Unknown content type [" + ctHeader
                  + "]", 0);
         }
         llist.add(content);
      }
      return llist;

   }

   /**
    * Get a desired content with a given content type/subtype from a list of
    * Content
    * 
    * @param contents --
    *            Unpacked list of contents.
    * @param contentType --
    *            Content type we are looking for (i.e. "application")
    * @param contentSubtype --
    *            content subtype we are looking for (ie. sdp)
    * @return the Content unpacked or null
    */
   public static Content getContentByType(ContentList contents,
         String contentType, String contentSubtype) {
      Content retval = null;
      for (Content content : contents) {
         if (content.getContentTypeHeader().getContentType()
               .equalsIgnoreCase(contentType)
               && content.getContentTypeHeader().getContentSubType()
                     .equalsIgnoreCase(contentSubtype)) {
            retval = content;
            break;
         }
      }
      return retval;
   }

   /**
    * Set the content by its type.
    * 
    * @param contentType --
    *            contentType of the content
    * @param contentSubtype --
    *            contentSubtype of the content.
    * @param content
    */
   public void setContent(String type, String subType, Content content) {
      Iterator<Content> it = this.iterator();
      while (it.hasNext()) {
         Content ct = it.next();
         ContentTypeHeader ctHdr = ct.getContentTypeHeader();

         if (ctHdr.getContentType().equalsIgnoreCase(type)
               && ctHdr.getContentSubType().equalsIgnoreCase(subType)) {
            it.remove();
         }
      }
      this.add(content);
   }

   /**
    * Get the SDP Content from this content list.
    * 
    */
   public SdpContent getSdpContent() {
      for (Content content : this) {
         if (content instanceof SdpContent)
            return (SdpContent) content;
      }
      return null;
   }

   /**
    * Get the Group Service Profile content from this list.
    */
   public GroupServiceProfileContent getGroupServiceProfileContent() {
      for (Content content : this) {
         if (content instanceof GroupServiceProfileContent)
            return (GroupServiceProfileContent) content;
      }
      return null;
   }

   /**
    * Get the registration parameters content from this .
    */
   public RegisterParamContent getRegisterParamContent() {
      for (Content content : this) {
         if (content instanceof RegisterParamContent)
            return (RegisterParamContent) content;
      }
      return null;
   }

   /**
    * Get the call param content form this list.
    */
   public CallParamContent getCallParamContent() {
      for (Content content : this) {
         if (content instanceof CallParamContent)
            return (CallParamContent) content;
      }
      return null;
   }

   /**
    * Get the User Service Profile from this message.
    */
   public UserServiceProfileContent getUserServiceProfileContent() {
      for (Content content : this) {
         if (content instanceof UserServiceProfileContent)
            return (UserServiceProfileContent) content;
      }
      return null;
   }

   /**
    * Extracts a list of content from the Request.
    * 
    * @param message --
    *            message with a multipart mime attachment.
    * @return -- a ContentList with a list of Content - one for each content
    *         type/subtype.
    * 
    */
   public static ContentList getContentListFromMessage(Message message)
         throws ParseException {
      if (message.getContentLength().getContentLength() == 0)
         return new ContentList();
      ContentTypeHeader contentTypeHeader = (ContentTypeHeader) message
            .getHeader(ContentTypeHeader.NAME);
      if (contentTypeHeader == null)
         throw new ParseException("Missing ContentType Header in message \n"
               + message.toString(), 0);
      byte[] rawContent = message.getRawContent();
      String body = new String(rawContent); // .toLowerCase();

      // logger.debug("getContentListFromMesge(): body = " + body);
      ContentList contents;

      if (contentTypeHeader.getContentType().equalsIgnoreCase("multipart")
            && contentTypeHeader.getContentSubType().equalsIgnoreCase(
                  "mixed")) {
         //String boundary = contentTypeHeader.getParameter("boundary");
         try {
            contents = createContentList(body);
         } catch (ParseException ex) {

            logger.error("Error parsing " + message, ex);
            throw ex;
         }

      } else if (contentTypeHeader.getContentType().equalsIgnoreCase(
            "application")
            && contentTypeHeader.getContentSubType()
                  .equalsIgnoreCase("sdp")) {
         SdpContent sdpContent = new SdpContent(contentTypeHeader, body);
         contents = new ContentList();
         contents.add(sdpContent);
      } else if (contentTypeHeader.getContentType().equalsIgnoreCase(
            "application")
            && contentTypeHeader.getContentSubType().equalsIgnoreCase(
                  ISSIConstants.X_TIA_P25_ISSI)) {
         contents = new ContentList();
         Content content;
         if (body.startsWith("u-")) {
            content = new UserServiceProfileContent(contentTypeHeader, body);

         } else if (body.startsWith("g-")) {
            content = new GroupServiceProfileContent(contentTypeHeader,
                  body);
         } else if (body.startsWith("c-")) {
            content = new CallParamContent(contentTypeHeader, body);
         } else if (body.startsWith("r-")) {
            content = new RegisterParamContent(contentTypeHeader, body);
         } else
            throw new ParseException("Unrecognized content ===>> " + body,
                  0);
         contents.add(content);

      } else {
         throw new ParseException("Unrecognized Content Type [ "
               + contentTypeHeader + "]", 0);
      }
      return contents;
   }

   /**
    * Compare a content list with another content list.
    * 
    * @param that --
    *            the content list to compare with.
    * @return
    */
   public boolean match(ContentList template) {
      boolean compareCallParam = true;
      boolean compareRegisterParam = true;
      boolean matchFound = false;

      // Check to see if the template is the default. If so then dont encode
      // it.
      if (template.getCallParamContent() != null
            && template.getCallParamContent().getCallParam().isDefault()
            && this.getCallParamContent() == null) {
         compareCallParam = false;

      }

      if (template.getRegisterParamContent() != null
            && template.getRegisterParamContent().getRegisterParam()
                  .isDefault() && this.getRegisterParamContent() == null) {
         compareRegisterParam = false;
      }
      for (Content content : template) {
         if (content instanceof RegisterParamContent
               && !compareRegisterParam) {
            continue;
         }
         if (content instanceof CallParamContent && !compareCallParam) {
            continue;
         }
         matchFound = false;
         for (Content matchContent : this) {

            logger.debug("matchContent = " + matchContent);
            if (content.match(matchContent)) {
               matchFound = true;
               break;
            }
         }
         if (!matchFound) {
            logger.error("Match not found for " + content);
            logger.error("Content to check = " + this);
            //M1012 Throws an exception ?
            //throw new RuntimeException("Cannot match "+content);
            unmatchedContent = content;

            return false;
         } else {
            logger.debug("Found a match");
            logger.debug("Match found for " + content);
         }
      }
      return true;
   }
}
