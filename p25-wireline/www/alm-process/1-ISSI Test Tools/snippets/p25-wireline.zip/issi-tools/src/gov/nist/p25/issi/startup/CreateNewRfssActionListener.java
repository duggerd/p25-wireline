package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SystemConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

/**
 * Create a new RFSS node interactively and add it to the topology graph.
 * 
 * @author mranga
 * 
 */
public class CreateNewRfssActionListener extends CreateActionListener {

   private static Logger logger = Logger.getLogger(CreateNewRfssActionListener.class);
   
	private ClusterConfigurationEditor configEditor;
	private ConfigTableModel tableModel;

	public CreateNewRfssActionListener(ClusterConfigurationEditor configEditor,
			ConfigTableModel tableModel) {
		this.configEditor = configEditor;
		this.tableModel = tableModel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			TopologyConfig topologyConfig = configEditor.getTopologyConfig();
			String rfssName = tableModel.getDataAsString("rfssName");
			int rfssId = tableModel.getDataAsHexInt("rfssId");
			String systemName = tableModel.getDataAsString("systemName");
			boolean isEmulated = tableModel.getDataAsBoolean("isEmulated");
			String ipAddress = tableModel.getDataAsString("ipAddress");
			int port = tableModel.getDataAsInt("sipPort");
					
			if (isNullOrEmpty(rfssName) || isNullOrEmpty(systemName) || 
			    isNullOrEmpty(ipAddress)) {
				JOptionPane.showMessageDialog(
						configEditor.getJFrame(),
						"Error in creating the RFSS definition missing a required Parameter",
						"Node Creation Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			if ( topologyConfig.getRfssConfigByName(rfssName) != null ) {
				JOptionPane.showMessageDialog(
						configEditor.getJFrame(),
						"Error in creating the RFSS -- already exists. Assign a new name " ,
						"Node Creation Error",
						JOptionPane.ERROR_MESSAGE);
				return;			
			}
			
			SystemConfig systemConfig = topologyConfig.getSystemConfigByName(systemName);		
			RfssConfig rfssConfig = new  RfssConfig( topologyConfig,  systemConfig,
					rfssId, ipAddress, port,  rfssName,  isEmulated ) ;
			
			ISSITesterConfiguration testerConfig = this.configEditor.getTesterConfig();

			for ( gov.nist.p25.issi.issiconfig.DaemonWebServerAddress da : 
			   testerConfig.getDaemonAddresses() ) {
				if ( da.getIpAddress().equals(ipAddress)) {
					da.addRefId(rfssConfig.getTag());
				}			 
			}
					
			topologyConfig.addRfssConfig(rfssConfig);
			this.configEditor.redraw();
		} catch (Exception ex) {
			logger.error("Create new Rfss error ", ex);
			JOptionPane.showMessageDialog(configEditor.getJFrame(),
					"Error in creating the RFSS definition " + ex.getClass()
							+ " : " + ex.getMessage(), "Node Creation Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

}
