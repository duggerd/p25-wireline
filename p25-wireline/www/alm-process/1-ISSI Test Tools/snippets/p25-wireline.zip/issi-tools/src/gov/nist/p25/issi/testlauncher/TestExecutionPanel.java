//
package gov.nist.p25.issi.testlauncher;


//import gov.nist.p25.common.util.HexDump;
import gov.nist.p25.common.util.FileUtility;

import gov.nist.p25.issi.analyzer.config.XmlPttmessages;
import gov.nist.p25.issi.constants.ISSIDtdConstants;
import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.GlobalTopologyParser;
import gov.nist.p25.issi.issiconfig.SystemTopologyParser;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfigParser;
import gov.nist.p25.issi.rfss.tester.TestScript;
import gov.nist.p25.issi.rfss.tester.TestScriptParser;
import gov.nist.p25.issi.traceviewer.MessageData;
import gov.nist.p25.issi.traceviewer.PttSessionInfo;
//import gov.nist.p25.issi.traceviewer.PttTraceLoader;
import gov.nist.p25.issi.traceviewer.RfssData;
import gov.nist.p25.issi.traceviewer.RfssRuntimeDataParser;
import gov.nist.p25.issi.traceviewer.SipTraceLoader;
import gov.nist.p25.issi.traceviewer.TestConfigPanel;
import gov.nist.p25.issi.traceviewer.TraceLogTextPane;
import gov.nist.p25.issi.traceviewer.TracePanel;

import gov.nist.p25.issi.xmlconfig.PttmessagesDocument.Pttmessages;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane; 
//import javax.swing.JTextPane;
import javax.swing.border.TitledBorder;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

/**
 * Test execution panel.
 * 
 * @author mranga@nist.gov
 * @author echang@associate.its.bldrdoc.gov
 * 
 */
public class TestExecutionPanel extends JPanel implements MouseListener,
      ActionListener {

   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(TestExecutionPanel.class);

   public static void showln(String s) { System.out.println(s); }

   // public static final int TEST_TIMEOUT = ISSITesterConstants.TEST_RUNS_FOR +
   // 5 * 1000;
   public static final int TEST_TIMEOUT = ISSITesterConstants.TEST_RUNS_FOR;
   
   public static SimpleAttributeSet ERROR_MESSAGE_TEXT = new SimpleAttributeSet();
   public static SimpleAttributeSet STACK_TRACE_TEXT = new SimpleAttributeSet();
   public static SimpleAttributeSet INFO_TEXT = new SimpleAttributeSet();
   public static SimpleAttributeSet FATAL_MESSAGE_TEXT = new SimpleAttributeSet();
   
   private static String baseDir = System.getProperty("user.dir");

   static {
      StyleConstants.setForeground(ERROR_MESSAGE_TEXT, Color.red);
      StyleConstants.setForeground(STACK_TRACE_TEXT, Color.blue);
      StyleConstants.setForeground(INFO_TEXT, Color.black);
      StyleConstants.setForeground(FATAL_MESSAGE_TEXT, Color.red);
      StyleConstants.setUnderline(FATAL_MESSAGE_TEXT, true);
      StyleConstants.setFontSize(FATAL_MESSAGE_TEXT, 14);
   }
   
   /** The timer for TimerTasks associated with this receiver. */
   static Timer timer = new Timer();
   private TestExecutionTimerTask testExecutionTimerTask;

   private DietsGUI gui;
   private String currentTestName = "";
   private String localTopologyName = "";
   private String currentTopologyName = "";

   private JList jlist;
   private JButton runButton;
   private JButton runInteractiveButton;
   private TraceLogTextPane descriptionPane;
   private TraceLogTextPane systemTopologyPane;
   private TraceLogTextPane globalTopologyPane;
   private TraceLogTextPane configurePane;
   private TraceLogTextPane scriptPane;
   private TraceLogTextPane statusLogPane;
   private TestConfigPanel testConfigPanel;

   private TracePanel sipTracePanel;
   private TracePanel pttTracePanel;
   private String progressScreenMessage = "";
   private ProgressMonitor progressMonitor;

   private JTabbedPane tabbedPane;
   private JScrollPane statusLogScrollPane;
   private int refTestNumber = 0;
   private int runTestNumber = 0;
   private String sipErrorMsg = "";
   private String pttErrorMsg = "";

   // accessors
   // --------------------------------------------------------------------------
   public String getCurrentTopologyName() {
      return currentTopologyName;
   }

   public void setCurrentTopologyName(String currentTopologyName) {
      this.currentTopologyName = currentTopologyName;
   }

   // public void setConfigurePane(TraceLogTextPane configurePane) {
   // this.configurePane = configurePane;
   // }
   // public TraceLogTextPane getConfigurePane() {
   // return configurePane;
   // }

   public TestCaseDescriptor getCurrentTestCaseDescriptor() {
      return (TestCaseDescriptor) jlist.getSelectedValue();
   }

   public void setCurrentTest(String testDir, String topologyFileName) {
      this.currentTestName = testDir + "/testscript.xml";
      this.currentTopologyName = topologyFileName;
   }

   public void newProgressMonitor() {
      setProgressMonitor(new ProgressMonitor(gui));
   }

   public ProgressMonitor getProgressMonitor() {
      return progressMonitor;
   }

   public void setProgressMonitor(ProgressMonitor monitor) {
      this.progressMonitor = monitor;
   }

   public void stopProgressMonitor() {
      setProgressScreenMessage("Done.");
      if (getProgressMonitor() != null) {
         getProgressMonitor().done();
         setProgressMonitor(null);
      }
      enableAllButtons();
   }

   public String getProgressScreenMessage() {
      return progressScreenMessage;
   }

   public void setProgressScreenMessage(String progressScreenMessage) {
      this.progressScreenMessage = progressScreenMessage;
      if (getProgressMonitor() != null) {
         synchronized (getProgressMonitor()) {
            getProgressMonitor().notify();
         }
      }
   }

   public TracePanel getSipTracePanel() {
      return sipTracePanel;
   }

   public TracePanel getPttTracePanel() {
      return pttTracePanel;
   }

   public String getSipTestError() {
      return sipErrorMsg;
   }

   public void setSipTestError(String errorMsg) {
      this.sipErrorMsg = errorMsg;
   }

   public String getPttTestError() {
      return pttErrorMsg;
   }

   public void setPttTestError(String errorMsg) {
      this.pttErrorMsg = errorMsg;
   }

   public void incrementRunTestNumber() {
      runTestNumber++;
      setSipTestError(null);
      setPttTestError(null);
   }

   public void incrementRefTestNumber() {
      refTestNumber++;
      setSipTestError(null);
      setPttTestError(null);
   }

   public void clearTestTraces() {
      refTestNumber = 0;
      runTestNumber = 0;
      setSipTestError(null);
      setPttTestError(null);
      gui.getJTabbedPane().removeAll();
   }

   /**
    * A class that waits for test execution to complete. This is basically an
    * open loop timer. It is used in non-interactive execution.
    * 
    */
   class TestExecutionTimerTask extends TimerTask {

      private boolean interactive;
      private int secondsRemaining;
      private DietsGUI gui;

      public int getSecondsRemaining() {
         return secondsRemaining;
      }

      public TestExecutionTimerTask(DietsGUI gui, int seconds,
            boolean interactive) {
         this.gui = gui;
         this.secondsRemaining = seconds;
         this.interactive = interactive;
         gui.getStatusProgressBar().setIndeterminate(true);
         //setProgressMonitor(new ProgressMonitor(gui));
         newProgressMonitor();
      }

      public void run() {
         //setProgressScreenMessage("Ready");
         secondsRemaining = secondsRemaining - 1000;
         if (secondsRemaining > 0)
            setProgressScreenMessage("Running.  Time remaining: "
                  + (secondsRemaining / 1000) + " seconds");
         
         boolean completed = false;
         try {
            completed = gui.getRemoteController().isTestCompleted();
            // New
            //completed &= gui.getRemoteController().isSaveTraceCompleted();           
         } 
         catch(Exception ex) {}
         showln("MMM check for test completed="+completed+" remains="+secondsRemaining);        
         if( completed) secondsRemaining = 0;
         if (secondsRemaining == 0) {
            showln("CANCEL timer: secondsRemaining="+secondsRemaining);
            cancel();
            if (!interactive)
               getSipPttTraces(interactive);
         }
      }
   }

   // constructor
   // --------------------------------------------------------------------------
   public TestExecutionPanel(Vector<TestCaseDescriptor> tests, DietsGUI gui) {

      super();
      this.gui = gui;

      setLayout(new BorderLayout());
      setBorder(new TitledBorder("Conformance Tests"));

      JPanel listPanel = new JPanel();
      listPanel.setMinimumSize(new Dimension(325, 300));
      listPanel.setPreferredSize(new Dimension(400, 300));
      listPanel.setMaximumSize(new Dimension(400, 300));
      listPanel.setLayout(new BorderLayout());
      jlist = new JList(tests);
      jlist.addMouseListener(this);
      jlist.setSelectedIndex(0);
      JScrollPane scrollList = new JScrollPane(jlist);

      runButton = new JButton("Generate Trace");
      runButton.setToolTipText("Generate Reference Trace");
      runButton.addActionListener(this);

      runInteractiveButton = new JButton("Run Test");
      runInteractiveButton
            .setToolTipText("Run in interactive mode - simulates actual operation");
      runInteractiveButton.addActionListener(this);

      /*
       * configureButton = new JButton("Edit Topology");
       * configureButton.setToolTipText("Edit Global Topology");
       * configureButton.addActionListener(this);
       */

      JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
      buttonPanel.add(runButton);
      buttonPanel.add(runInteractiveButton);
      // buttonPanel.add(configureButton);

      listPanel.add(scrollList, BorderLayout.CENTER);
      listPanel.add(buttonPanel, BorderLayout.SOUTH);

      TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
      String testDesc = selectedTest.toString();
      String testNo = selectedTest.getTestNumber();
      
      // Description
      descriptionPane = new TraceLogTextPane( );
      TestCaseDescriptor descriptor = (TestCaseDescriptor) jlist.getModel()
            .getElementAt(0);
      descriptionPane.setText("Test Number : " + descriptor.getTestNumber()
            + "\n\n" + descriptor.getTestDescription());
      JScrollPane descriptionScrollPane = new JScrollPane(descriptionPane);
      
      // System
      systemTopologyPane = new TraceLogTextPane( );
      JScrollPane systemTopologyScrollPane = new JScrollPane(systemTopologyPane);

      // Global
      globalTopologyPane = new TraceLogTextPane( );
      JScrollPane globalTopologyScrollPane = new JScrollPane(globalTopologyPane);

      // Test Script
      scriptPane = new TraceLogTextPane( );
      JScrollPane scriptScrollPane = new JScrollPane(scriptPane);

      currentTestName = (String) selectedTest.getFileName();
      currentTopologyName = selectedTest.getTopologyFileName();
      String testFileName = ISSITesterConstants.getScenarioDir() + "/"
            + currentTestName;
      try {
         String ftext = FileUtility.loadFromFileAsString(testFileName);
         scriptPane.logMessage(true, ftext);

      } catch (Exception ex) {
         String msg = "Error in open/reading Test Script: " + testFileName;
         logger.debug( msg, ex);
         JOptionPane.showMessageDialog(null, msg,
               "Test Script Status",
               JOptionPane.ERROR_MESSAGE);
	 // just move-on
         //return;
      }

      // Test Configuration   
      configurePane = new TraceLogTextPane( );
      JScrollPane configureScrollPane = new JScrollPane(configurePane);
      String localTopology = formatLocalTopology();
      configurePane.logMessage(true, localTopology);
 
      statusLogPane = new TraceLogTextPane( );
      statusLogScrollPane = new JScrollPane(statusLogPane);
      
      testConfigPanel = new TestConfigPanel( );
      JScrollPane testConfigScrollPane = new JScrollPane(testConfigPanel);
      try {
         TopologyConfig testTopology = getTopologyConfig(currentTopologyName);
         testConfigPanel.setTopologyConfig( testDesc, testNo, testTopology);
      } catch(Exception ex) { 
         // ignore ?
      }
      
      // initialize the output filename
      updateSuggestedFile( baseDir, testNo);

      // setup tabbed pane
      tabbedPane = new JTabbedPane();
      tabbedPane.add("Description", descriptionScrollPane);
      tabbedPane.setSelectedComponent(descriptionScrollPane);
      tabbedPane.add("System Topology", systemTopologyScrollPane);
      tabbedPane.add("Global Topology", globalTopologyScrollPane);

      tabbedPane.add("Test Configuration", configureScrollPane);
      tabbedPane.add("Test Script", scriptScrollPane);
      tabbedPane.add("Test Status", statusLogScrollPane);
      tabbedPane.add("Test Layout", testConfigScrollPane);

      JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
            listPanel, tabbedPane);
      splitPane.setOneTouchExpandable(true);
      splitPane.setDividerSize(7);
      add(splitPane, BorderLayout.CENTER);
   }

   public void logError(String failureMessage, String errorTrace) {
      statusLogPane.logMessage(true, failureMessage);
      statusLogPane.logMessage(false, errorTrace);
      tabbedPane.setSelectedComponent(statusLogScrollPane);
   }

   public void logError(String failureMessage) {
      statusLogPane.logMessage(true, failureMessage + "\n");
      tabbedPane.setSelectedComponent(statusLogScrollPane);
   }

   public void logFatal(String failureMessage, String stackTrace) {
      statusLogPane.logMessage(true, failureMessage + "\n");
      statusLogPane.logMessage(false, stackTrace);
      tabbedPane.setSelectedComponent(statusLogScrollPane);
   }

   public void logStatusMessage(String statusMessage) {
      statusLogPane.logMessage(true, statusMessage + "\n");
   }
   
   public void updateSuggestedFile(String baseDir, String testNo) { 
    
      // make testcase specific output/testNo directory
      String outDir = baseDir + File.separator + "output" + File.separator + testNo;
      FileUtility.makeDir( outDir);
      
      String suggestFile;      
      // Description
      suggestFile = outDir + File.separator + "test-description-" +testNo +".txt";
      descriptionPane.setSuggestedFile( suggestFile);
      
      // System
      suggestFile = outDir + File.separator + "system-topology-" +testNo +".txt";
      systemTopologyPane.setSuggestedFile( suggestFile);
      
      // Global
      suggestFile = outDir + File.separator + "global-topology-"+testNo+".txt";
      globalTopologyPane.setSuggestedFile( suggestFile);      
      
      // Test Script
      suggestFile = outDir + File.separator + "test-script-"+testNo+".txt";
      scriptPane.setSuggestedFile( suggestFile);
      
      // Test Configuration
      suggestFile = outDir + File.separator + "test-configuration-"+testNo+".txt";
      //showln("updateSuggestedFile: "+suggestFile);
      configurePane.setSuggestedFile( suggestFile);
      
      // Test Status
      suggestFile = outDir + File.separator + "test-status-"+testNo+".txt";
      statusLogPane.setSuggestedFile( suggestFile);     
   }

   // implementation of ActionListener
   // -------------------------------------------------------------------
   public void actionPerformed(ActionEvent actionEvent) {

      DietsGUI.updateGlobalTopologyValues();
      Object source = actionEvent.getSource();
      if (source == runButton) {

         // Generate Ref Trace
         disableAllButtons();
         incrementRefTestNumber();

         try {
            TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
            currentTestName = (String) selectedTest.getFileName();
            localTopologyName = selectedTest.getTopologyFileName();
            
            showln(">>>>>>>>>>>>>> Generate Ref >>>>>>>>>>>>>>>>>>>>");
            logger.debug("globalTopology = " + gui.getGlobalTopologyName());
            logger.debug("systemTopology = " + gui.getSystemTopologyName());
            logger.debug("currentTestName = " + currentTestName);
            logger.debug("localTopologyName = " + localTopologyName);
            showln("********* tearDown ********");
            gui.getRemoteController().tearDownCurrentTest();
            showln("********* loadTest ********");

            TestScriptParser parser = new TestScriptParser(ISSITesterConstants
                  .getScenarioDir()
                  + "/" + currentTestName, ISSITesterConstants.getScenarioDir()
                  + "/" + localTopologyName, gui.getGlobalTopologyName(), gui
                  .getSystemTopologyName(), false);
            // TestScript testScript = parser.parse();
            parser.parse();
            logger.debug("loadTest(): currentTestName=" + currentTestName);
            gui.getRemoteController().loadTest(
                  ISSITesterConstants.getScenarioDir(), currentTestName,
                  selectedTest.getTestNumber(), localTopologyName,
                  gui.getGlobalTopologyName(), gui.getSystemTopologyName(),
                  false, gui.getEvaluatePassFail());
            //Thread.sleep(1000);
            logger.debug("runTest()...");
            gui.getRemoteController().runTest();

            startTestExecutionTimerTask(TEST_TIMEOUT, false);
            // ISSITesterConstants.TEST_RUNS_FOR + 5 * 1000, false);

         } catch (Exception e) {
            e.printStackTrace();
            logger.debug("Error communicating with the tester!!", e);
            JOptionPane.showMessageDialog(
               null,
               "Error occured in generating trace. \nCheck the configuration file for the tester",
               "Communication Error", 
               JOptionPane.ERROR_MESSAGE);
            enableAllButtons();
         }

      } else if (source == runInteractiveButton) {

         // Run Test
         disableAllButtons();
         incrementRunTestNumber();

         try {
            TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
            currentTestName = (String) selectedTest.getFileName();
            localTopologyName = selectedTest.getTopologyFileName();

            showln(">>>>>>>>>>>>>>>>> Run Test >>>>>>>>>>>>>>>>>>>>");
            showln("RT  scenarioDir=" + ISSITesterConstants.getScenarioDir());
            showln("RT  currentTestName=" + currentTestName);
            showln("RT  localTopologyName=" + localTopologyName);
            showln("-----------------------------------");
                        
            showln("********* tearDown ********");
            gui.getRemoteController().tearDownCurrentTest();
            showln("********* loadTest ********");
            
            // After generate traces, it takes time to create trace files
            // see refmessages/conformance/<testname>/...
            Thread.sleep(3000);    
            gui.getRemoteController().loadTest(
                  ISSITesterConstants.getScenarioDir(), currentTestName,
                  selectedTest.getTestNumber(), localTopologyName,
                  gui.getGlobalTopologyName(), gui.getSystemTopologyName(),
                  true, gui.getEvaluatePassFail());
            Thread.sleep(1000);
            gui.getRemoteController().runTest();

            TestScript testScript = new TestScriptParser(ISSITesterConstants
                  .getScenarioDir()
                  + "/" + currentTestName, ISSITesterConstants.getScenarioDir()
                  + "/" + localTopologyName, gui.getGlobalTopologyName(), gui
                  .getSystemTopologyName(), true).parse();
            //showln("********* ScenarioPrompter ********");
            new ScenarioPrompter(gui, gui.getRemoteController(), testScript,
                  gui.getScenarioPrompterState()).startPrompting();

            // Wait TEST_TIMEOUT before trying to retrieve traces.
            // testExecutionTimerTask = new TestExecutionTimerTask(gui);
            // timer.schedule(testExecutionTimerTask, 0, 1000);

         } catch (Exception ex) {
            try {
               showln("********* tearDown ********");
               gui.getRemoteController().tearDownCurrentTest();
            } catch(Exception ex2) { }
            
            logger.error("Communication error running test! ", ex);
            gui.showWarning(
               "Error Communicaticating with the tester or running the test!\n"
                     + "Exception message : "
                     + ex.getMessage()
                     + "\n"
                     + "Make sure test daemons are running (check tester configuration)\n"
                     + "Make sure reference traces are generated before running the test!",
                     "Test Execution Error!");
            enableAllButtons();
         }
      }
   }

   public void mouseClicked(MouseEvent me) { }
   public void mouseEntered(MouseEvent me) { }
   public void mouseReleased(MouseEvent me) { }
   public void mouseExited(MouseEvent me) { }
   
   public void mousePressed(MouseEvent me) {

      clearTestTraces();
      int index = jlist.locationToIndex(me.getPoint());
      jlist.setSelectedIndex(index);

      TestCaseDescriptor descriptor = (TestCaseDescriptor) jlist.getModel()
            .getElementAt(index);

      descriptionPane.setText("Category : " + descriptor.getCategory()
            + "\nTest Number : " + descriptor.getTestNumber() + "\n\n"
            + descriptor.getTestDescription());

      try {
         TestCaseDescriptor selectedTest = getCurrentTestCaseDescriptor();
         currentTestName = (String) selectedTest.getFileName();
         currentTopologyName = selectedTest.getTopologyFileName();

         String testFileName = ISSITesterConstants.getScenarioDir() + "/"
               + currentTestName;
         updateSuggestedFile( baseDir, selectedTest.getTestNumber());
         
         String ftext = FileUtility.loadFromFileAsString(testFileName);        
         scriptPane.logMessage(true, ftext);
         
         //showln("*** mousePressed: renderRefTraceLogs ***");
         gui.renderRefTraceLogs();

      } catch (Exception ex) {
         logger.error("An unexpected execution error occured", ex);
         JOptionPane.showMessageDialog(
               null,
               "Error in rendering reference trace logs: "+currentTestName,
               "Render Reference Trace Error", 
               JOptionPane.ERROR_MESSAGE);
         return;
      }

      //showln("*** mousePressed: configurePane, testLayout");
      String ftext = formatLocalTopology();
      configurePane.logMessage(true, ftext);
      
      // regenerate the test layout
      try {
         TopologyConfig testTopology = getTopologyConfig(currentTopologyName);
         String testDesc = getCurrentTestCaseDescriptor().toString();
         String testNo = getCurrentTestCaseDescriptor().getTestNumber();
         //showln("*** mousePressed: testNo="+testNo);
         testConfigPanel.setTopologyConfig( testDesc, testNo, testTopology);
         
      } catch(Exception ex) { 
         // ignore
      }
      //showln("*** mousePressed: DONE.......");
   }

   public void disableAllButtons() {
      runButton.setEnabled(false);
      runInteractiveButton.setEnabled(false);
   }

   public void enableAllButtons() {
      runButton.setEnabled(true);
      runInteractiveButton.setEnabled(true);
   }

   /**
    * Get the PTT mmf/smf allocation information from the Emulated RFSS.
    * 
    * @return
    * @throws Exception
    */
   public Hashtable<String, HashSet<PttSessionInfo>> getPttSessionInfo() {

      Hashtable<String, HashSet<PttSessionInfo>> retval = null;
      String urlStr = ISSIDtdConstants.URL_ISSI_DTD_RUNTIME_DATA;
      try {
         StringBuffer toParse = new StringBuffer();
         toParse.append("<?xml version=\"1.0\" ?>\n");

         //toParse.append("<!DOCTYPE issi-runtime-data SYSTEM \"http://www-x.antd.nist.gov:8080/p25/issi-emulator/dtd/issi-runtime-data.dtd\">\n");
         toParse.append("<!DOCTYPE issi-runtime-data SYSTEM \"" +
             urlStr +"\">\n");

         toParse.append("<issi-runtime-data>\n");
         toParse.append(gui.getRemoteController().getRfssPttSessionInfo());

         toParse.append("\n</issi-runtime-data>");
         InputSource inputSource = new InputSource(new ByteArrayInputStream(
               toParse.toString().getBytes()));
         RfssRuntimeDataParser parser = new RfssRuntimeDataParser(inputSource);
         retval = parser.parse();

      } catch (Exception e) {
         logger.fatal("An unexpected parse exception occured", e);
      }
      return retval;
   }

   public void getSipPttTraces(boolean isInteractive) {

      //showln("getSipPttTraces: isInteractive=" + isInteractive);
      String sipTraces = null;
      setProgressScreenMessage("Getting SIP traces...");
      StringBuffer sbuf = new StringBuffer();
      sbuf.append("<messages>\n");

      if (isInteractive) {
         try {
            if (gui.getTraceSource().equals("packet-monitor")) {
               sbuf.append(gui.getRemoteController().getSipTraces());
            } else {
               sbuf.append(gui.getRemoteController().getStackSipLogs());
            }
         } catch (Exception e) {
            logger.error("trace fetch error", e);
            gui.showError("could not get sip traces - unexpected exception "
                  + e.getMessage(), "Trace fetch error");
            return;
         }

      } else {
         try {
            sbuf.append(gui.getRemoteController().getStackSipLog());
         } catch (Exception e) {
            logger.error("could not get sip traces - unexpected exception ", e);
            gui.showError("could not get sip traces - unexpected exception "
                  + e.getMessage(), "Trace fetch error");
            return;
         }
      }
      sbuf.append("</messages>");
      sipTraces = sbuf.toString();
      logger.debug("=== SIP TRACES: START ===\n");
      logger.debug(sipTraces);
      logger.debug("=== SIP TRACES: END ===\n");

      String pttTraces = null;
      sbuf = new StringBuffer();
      sbuf.append("<pttmessages>\n");

      if (isInteractive) {
         try {
            if (gui.getTraceSource().equals("packet-monitor")) {
               sbuf.append(gui.getRemoteController().getPttTraces());
            } else {
               sbuf.append(gui.getRemoteController().getStackPttLogs());
            }
         } catch (Exception e) {
            logger.error("trace fetch error", e);
            gui.showError("could not get ptt traces " + e.getMessage(),
                  "Trace fetch error");
            return;
         }
      } else {
         try {
            sbuf.append(gui.getRemoteController().getStackPttLog());
         } catch (Exception ex) {
            logger
                  .error("could not get Ptt traces -- unexpected exception", ex);
            gui.showError("could not get sip traces - unexpected exception "
                  + ex.getMessage(), "Trace fetch error");
            return;
         }
      }
      sbuf.append("</pttmessages>\n");
      pttTraces = sbuf.toString();
      logger.debug("=== PTT TRACES: START ===\n");
      logger.debug(pttTraces);
      logger.debug("=== PTT TRACES: END ===\n");

      Hashtable<String, HashSet<PttSessionInfo>> rfssSessionData = getPttSessionInfo();

      //logger.debug("TestExec: just about renderSipPttTraces... ");
      renderSipPttTraces(sipTraces, pttTraces, rfssSessionData, isInteractive,
            !isInteractive);
      //showln("return from renderSipPttTraces... wait for isSave ?");

      gui.resetRemoteController();
      setProgressScreenMessage("Done.");

   }

   public void renderSipPttTraces(String sipTraces, String pttTraces,
         Hashtable<String, HashSet<PttSessionInfo>> rfssSessionData,
         boolean isInteractive, boolean toSave) {

      //showln("TestExecutionPanel: renderSipPttTraces...");
      //showln(" gui-global="+gui.getGlobalTopologyName());
      //showln(" gui-system="+gui.getSystemTopologyName());
      
      logger.debug("renderSipPttTraces: isInteractive " + isInteractive
            + " toSave " + toSave);
      boolean remoteRetrievalSucceeded = true;

      // First cancel the polling task
      if (testExecutionTimerTask != null)
         testExecutionTimerTask.cancel();

      Collection<RfssData> rfssList = null;
      String sipTab = "SIP-Ref-" + refTestNumber;
      String pttTab = "PTT-Ref-" + refTestNumber;
      if (isInteractive) {
         sipTab = "SIP-Test-" + runTestNumber;
         pttTab = "PTT-Test-" + runTestNumber;
      }
      try {
         try {
            Hashtable<String, Color> colorMap = new Hashtable<String, Color>();

            byte[] stringAsBytes = sipTraces.getBytes();
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
                  stringAsBytes);

            TopologyConfig systemTopology = new SystemTopologyParser(gui
                  .getIssiTesterConfiguration()).parse( 
                  gui.getSystemTopologyName());
            TopologyConfig globalTopology = new GlobalTopologyParser(
                  isInteractive).parse(systemTopology, gui
                  .getGlobalTopologyName());
            TopologyConfig topologyConfig = new TopologyConfigParser().parse(
                  globalTopology, ISSITesterConstants.getScenarioDir() + "/"
                        + currentTopologyName);
            
            SipTraceLoader traceLoader = new SipTraceLoader(
                  byteArrayInputStream, rfssSessionData, colorMap,
                  topologyConfig);

            rfssList = traceLoader.getSortedRfssList();

            List<MessageData> records = traceLoader.getRecords();
            String msgData = traceLoader.getMessageData();

            logger.debug("renderSipPttTraces: RTF SIP Traces... ");
            /*
             * Generate the RTF traces for SIP.
             */
//            StringBuffer rtfBuffer = new StringBuffer();
//            for (MessageData messageData : records) {
//               String rtf = messageData.getRtfText();
//               rtfBuffer.append(rtf);
//            }
            // sipTraceLogPane.setRtfTrace(
            // TraceLogTextPane.buildRtfMessage(rtfBuffer.toString()));
            // sipTraceLogPane.logMessage( true, sbuf.toString());

            // logger.debug("renderSipPttTraces: SIP TracePanel... ");

            // Create a new tabbed panel
            sipTracePanel = new TracePanel(gui, gui.getJTabbedPane(),
                  currentTestName, rfssList, records, colorMap);

            // M1001
            sipTracePanel.setTitle(sipTab);
            sipTracePanel.setTestNumber(getCurrentTestCaseDescriptor().getTestNumber());
            sipTracePanel.setDataTextArea(TracePanel.DATA_ALL_MSG, msgData);


            // String sbufHex = HexDump.toHex( stringAsBytes, 16);
            // sipTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sbufHex);
            sipTracePanel.setDataTextArea(TracePanel.DATA_RAW_MSG, sipTraces);

            if (getSipTestError() != null) {
               sipTracePanel.setDataTextArea(TracePanel.DATA_ERROR_MSG,
                     getSipTestError());
            }

            if (gui.getRemoteController() != null) {
               sipTracePanel.setTestResultLabel(gui.getRemoteController()
                     .getTestResults());
            }

            // close existing tabs.
            addTraceToTabbedPanel(gui.getJTabbedPane(), sipTab, sipTracePanel);

            gui.getCloseMenuItem().setEnabled(true);
            gui.getCloseAllMenuItem().setEnabled(true);

         } catch (Exception ex) {
            logger.debug("Error Fetching SIP Trace: ", ex);
            ex.printStackTrace();
            remoteRetrievalSucceeded = false;
            // MMM stopProgressMonitor();

            String msg = "Error Fetching SIP Trace From Packet Monitor. "
                  + "Use File/Open to open SIP and PTT messages manually.\n";
            // sipTraceLogPane.logMessage( true, msg);
            statusLogPane.logMessage(true, msg);
         }
         // logger.debug("remoteRetrievalSucceeded="+remoteRetrievalSucceeded);

         // If remote retrieval of SIP traces failed, return here
         if (!remoteRetrievalSucceeded) {
            logger.debug("renderSipPttTraces: remoteRetrievalSucceeded... ");
            stopProgressMonitor();
            return;
         }

         // Now get PTT traces
         setProgressScreenMessage("Getting PTT traces...");

         try {
            if (pttTraces == null) {
               // There are no PTT traces so just return.
               stopProgressMonitor();
               return;
            }
            Hashtable<String, Color> colorMap = new Hashtable<String, Color>();

            logger.debug("ptt traces = " + pttTraces);

            //byte[] stringAsBytes = pttTraces.getBytes();
            //ByteArrayInputStream bais = new ByteArrayInputStream(stringAsBytes);
            //PttTraceLoader traceLoader = new PttTraceLoader(bais,colorMap);
            //List<MessageData> records = traceLoader.getRecords();
            //String msgData = traceLoader.getMessageData();

            // NOTE: use new PTT format
            //----------------------------
            //boolean keepHeader = false;
            boolean keepHeader = gui.getShowPttHeaderState();

            String title = "*** PTT Messages ***";
            XmlPttmessages xmlmsg = new XmlPttmessages(colorMap);
            Pttmessages pttmsg = xmlmsg.loadPttmessages(pttTraces);
            xmlmsg.getPttMessageData(pttmsg, keepHeader);
            List<MessageData> records = xmlmsg.getRecords();
            String msgData = xmlmsg.toISSIString( title, pttmsg, keepHeader);
            //----------------------------

            logger.debug("renderSipPttTraces: PTT TracePanel... ");

            // Create a new tabbed panel
            pttTracePanel = new TracePanel(gui, gui.getJTabbedPane(),
                  currentTestName, rfssList, records, colorMap);

            // M1001 <<<<<<< JTextPane
            pttTracePanel.setTitle(pttTab);
            pttTracePanel.setTestNumber(getCurrentTestCaseDescriptor().getTestNumber());
            pttTracePanel.setDataTextArea(TracePanel.DATA_ALL_MSG, msgData);

            // String sbufHex = HexDump.toHex( stringAsBytes, 16);
            // pttTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sbufHex);
            pttTracePanel.setDataTextArea(TracePanel.DATA_RAW_MSG, pttTraces);

            // M1001 Match up with SIP trace
            if (gui.getRemoteController() != null) {
               pttTracePanel.setTestResultLabel(gui.getRemoteController()
                     .getTestResults());
            }

            addTraceToTabbedPanel(gui.getJTabbedPane(), pttTab, pttTracePanel);
            gui.getCloseMenuItem().setEnabled(true);
            gui.getCloseAllMenuItem().setEnabled(true);

         } catch (Exception ex) {
            String msg = "Error fetching PTT trace from PacketMonitor or Tester";
            setProgressScreenMessage(msg);
            msg += "\n" + ex.toString() + "\n";
            statusLogPane.logMessage(true, msg);
         }

      } catch (Throwable ex) {
         logger.debug("renderSipPttTraces: Throwable ex= " + ex);

      } finally {

         logger.debug("renderSipPttTraces: finally doing saveFiles... ");
         stopProgressMonitor();
         try {
            if (toSave)
               DietsGUI.saveFiles(false);
         } catch (Exception ex) {
            logger.error("Error saving files", ex);
         }
      }
   }

   private void addTraceToTabbedPanel(JTabbedPane tabbedPane, String tab,
         TracePanel tracePanel) {

      javax.swing.SwingUtilities.invokeLater(new Runnable() {
         private JTabbedPane tabbedPane;
         private String tab;
         private TracePanel tracePanel;

         public Runnable setParams(JTabbedPane tabbedPane, String tab,
               TracePanel tracePanel) {
            this.tabbedPane = tabbedPane;
            this.tab = tab;
            this.tracePanel = tracePanel;
            return this;
         }

         public void run() {
            tabbedPane.add(tab, tracePanel);
            tabbedPane.setSelectedComponent(tracePanel);
         }
      }.setParams(tabbedPane, tab, tracePanel));
   }

   private TopologyConfig getTopologyConfig(String curTopologyName)
      throws Exception {

      String topologyFileName = ISSITesterConstants.getScenarioDir() + "/"
            + curTopologyName;

      showln("\n*** formatLocalTopology ***");
      showln("  SystemTopologyName: " + gui.getSystemTopologyName());
      showln("  GlobalTopologyName: " + gui.getGlobalTopologyName());
      showln("  topologyFileName  : " + topologyFileName);

         GlobalTopologyParser globalTopologyParser = new GlobalTopologyParser(
               true);
         TopologyConfig systemTopology = new SystemTopologyParser(gui
               .getIssiTesterConfiguration()).parse(
               gui.getSystemTopologyName());
         TopologyConfig globalTopology = globalTopologyParser.parse(
               systemTopology, gui.getGlobalTopologyName());
         TopologyConfigParser parser = new TopologyConfigParser();
         TopologyConfig testTopology = parser.parse(globalTopology,
               topologyFileName);
         return testTopology;
   }
         
   private String formatLocalTopology() {

      try {
         TopologyConfig testTopology = getTopologyConfig(currentTopologyName);
         return testTopology.getDescription();

      } catch (Exception ex) {
         String msg = "Could not parse topology config file: "
               + currentTopologyName;
         logger.error(msg, ex);
         JOptionPane.showMessageDialog(null, msg, "Parse File Status",
               JOptionPane.ERROR_MESSAGE);
         return "";
      }
   }

   private void startTestExecutionTimerTask(int milisec, boolean interactive) {
      // Wait TEST_TIMEOUT before trying to retrieve traces.
      testExecutionTimerTask = new TestExecutionTimerTask(gui, milisec,
            interactive);
      timer.schedule(testExecutionTimerTask, 0, 1000);
   }

   // logging
   public void logSystemTopologyPane(boolean isClear, String message) {
      systemTopologyPane.logMessage(isClear, message);
   }

   public void logGlobalTopologyPane(boolean isClear, String message) {
      globalTopologyPane.logMessage(isClear, message);
   }

   public void logConfigurePane(boolean isClear, String message) {
      configurePane.logMessage(isClear, message);
   }

   public void logStatusPane(boolean isClear, String message) {
      statusLogPane.logMessage(isClear, message);
   }

   // public void saveSipJpegTraces(String fileName) {
   // sipTracePanel.getDiagramPanel().saveAs(fileName);
   // }
   // public void savePttJpegTraces(String fileName) {
   // pttTracePanel.getDiagramPanel().saveAs(fileName);
   // }

}
