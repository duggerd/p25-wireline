//
package gov.nist.p25.issi.traceviewer;

import gov.nist.p25.issi.issiconfig.TopologyConfig;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

//import org.apache.log4j.Logger;

/**
 * This class implements a SIP XML trace file loader.
 * 
 * @author mranga@nist.gov
 * @author steveq@nist.gov
 * @version $Revision: 1.5 $, $Date: 2007/10/25 21:27:54 $
 * @since 1.5
 */
public class SipTraceLoader implements TraceLoader {
   
   //private static Logger logger = Logger.getLogger(SipTraceLoader.class);
   
// int[][] messageColors = { { 117, 4, 0 }, { 96, 93, 0 }, { 96, 0, 87 },
// { 31, 104, 0 }, { 27, 0, 96 }, { 0, 159, 109 }, { 0, 145, 159 },
// { 96, 0, 38 }, { 0, 0, 255 }, { 95, 0, 127 }, { 255, 0, 201 },
// { 191, 0, 40 } };

   private static final int MAX_COLOR_INDEX = 11;
   
   private String transactionId = "";
   private int messageColorIndex = 0;
   private HashSet<RfssData> rfssList = new HashSet<RfssData>();
   private Collection<RfssData> sortedRfssList;
   private TopologyConfig topologyConfig;
   private SipTraceFileParser sipTracefileParser;
   private List<SipMessageData> messageData;
   
   // /////////////////////////////////////////////////////////////////////
   // Constructor
   // /////////////////////////////////////////////////////////////////////

   public SipTraceLoader(ByteArrayInputStream byteArrayInputStream,
         Hashtable<String, HashSet<PttSessionInfo>> runtimeData,
         Hashtable<String, Color> colorMap, TopologyConfig topologyConfig)
         throws Exception {

      this.topologyConfig = topologyConfig;
      sipTracefileParser = new SipTraceFileParser(byteArrayInputStream,
            runtimeData, getTopologyConfig());
      sipTracefileParser.parse();

      messageData = sipTracefileParser.getRecords();
      rfssList = sipTracefileParser.getRfssList();
      
      if (topologyConfig.getTraceOrder().size() != rfssList.size()) {
         sortedRfssList = new TreeSet<RfssData>();
         sortedRfssList.addAll(rfssList);
      } else {
         // User has specified a sorting order.
         sortedRfssList = new LinkedList<RfssData>();
         for (String name : topologyConfig.getTraceOrder()) {

            boolean added = false;
            for (RfssData rfssData : rfssList) {
               if (rfssData.getRfssConfig().getRfssName().equals(name)) {
                  sortedRfssList.add(rfssData);
                  added = true;
                  break;
               }
            }
            if (!added) {
               sortedRfssList = new TreeSet<RfssData>();
               sortedRfssList.addAll(rfssList);
               break;
            }
         }
      }
      
      if( colorMap != null)
      for (SipMessageData sipMessageData : messageData) {
         transactionId = sipMessageData.getTransactionId();

         if (!colorMap.containsKey(transactionId)) {

            if (messageColorIndex > MAX_COLOR_INDEX)
               messageColorIndex = 0;

            // disabled - use all black
            //int[] rgb = messageColors[messageColorIndex];         
            //colorMap.put(transactionId, new Color(rgb[0], rgb[1], rgb[2]));
            
            colorMap.put(transactionId, Color.black);   
            messageColorIndex++;

         }
      }
   }

   // /////////////////////////////////////////////////////////////////////
   // Methods
   // /////////////////////////////////////////////////////////////////////
   public Collection<RfssData> getSortedRfssList() {
      return sortedRfssList;
   }
   public TopologyConfig getTopologyConfig() {
      return topologyConfig;
   }

   @Override
   public List<MessageData> getRecords() {   
      ArrayList <MessageData> retval = new ArrayList<MessageData>();
      retval.addAll(messageData);
      return retval;
   }
   
   public String getMessageData() {
      StringBuffer sbuf = new StringBuffer();
      for (MessageData messageData : getRecords()) {
         sbuf.append("F" + messageData.getId() + ":\n");
         sbuf.append(messageData.getData().trim());
         sbuf.append("\n\n");
      }
      return sbuf.toString();
   }
}
