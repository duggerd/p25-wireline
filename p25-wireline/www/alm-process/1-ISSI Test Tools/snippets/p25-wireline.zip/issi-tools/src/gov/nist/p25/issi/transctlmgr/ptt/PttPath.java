/* This software was developed by employees of the National Institute of
 * Standards and Technology (NIST), an agency of the Federal Government.
 * Pursuant to title 15 United States Code Section 105, works of NIST
 * employees are not subject to copyright protection in the United States
 * and are considered to be in the public domain.  As a result, a formal
 * license is not needed to use the software.
 * 
 * The ISSI Emulator is provided by NIST as a service and is expressly
 * provided "AS IS".  NIST MAKES NO WARRANTY OF ANY KIND, EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT
 * AND DATA ACCURACY.  NIST does not warrant or make any representations
 * regarding the use of the software or the results thereof including, but
 * not limited to, the correctness, accuracy, reliability or usefulness of
 * the software.
 * 
 * Permission to use this software is contingent upon your acceptance
 * of the terms of this agreement.
 */
package gov.nist.p25.issi.transctlmgr.ptt;

import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import gov.nist.p25.issi.p25payload.PacketType;

/**
 * This class defines a path for PTT state machine.
 * 
 * @author steveq@nist.gov
 * @version $Revision: 1.7 $, $Date: 2007/07/24 03:20:36 $
 * @since 1.5
 */
abstract class PttPath {

	/***************************************************************************
	 * Variables
	 **************************************************************************/

	PttState currentState = null;

	PttStateTransition transition = null;

	PttState nextState = null;

	PacketType inPttMsgType = null;

	PacketType outPttMsgType = null;

	private static Hashtable<PttState, List<PttPath>> transitionTable = new Hashtable<PttState, List<PttPath>>();

	/***************************************************************************
	 * Constructors
	 **************************************************************************/

	PttPath(PttState currentState, PttStateTransition transition,
			PttState nextState) {

		this.currentState = currentState;
		this.transition = transition;
		this.nextState = nextState;

	}

	static void add(PttPath pttPath) {
		List<PttPath> transitions = transitionTable.get(pttPath.currentState);
		if (transitions == null) {
			transitions = new LinkedList<PttPath>();
			transitions.add(pttPath);
			transitionTable.put(pttPath.currentState, transitions);
		}
		transitions.add(pttPath);
	}

	public static PttState getNextState(PttState currentState,
			PttStateTransition transition) throws IllegalStateException {
		if (transitionTable.get(currentState) == null)
			throw new IllegalStateException("Could not find transition for "
					+ currentState);
		for (PttPath pathElement : transitionTable.get(currentState)) {
			if (pathElement.transition.equals(transition))
				return pathElement.nextState;

		}
		throw new IllegalStateException(String.format(
				"Cannot find transition for %s %s ", currentState, transition));

	}

	/***************************************************************************
	 * Method Declarations
	 **************************************************************************/

	abstract Enum getCurrentState();

	abstract Enum getTransition();

	abstract Enum getNextState();

	public abstract String toString();

}
