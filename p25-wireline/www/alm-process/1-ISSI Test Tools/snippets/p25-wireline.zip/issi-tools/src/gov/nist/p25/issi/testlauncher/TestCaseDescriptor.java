//
package gov.nist.p25.issi.testlauncher;

/**
 * This describes a stanza in the test case registry. Each test case has a
 * directory and is described by some text (pulled out of the test document) and
 * has a test number which corresponds to the test document.
 * 
 * @author mranga@nist.gov
 * 
 */
public class TestCaseDescriptor {
   
   private String directoryName;
   private String testNumber;
   private String testDescription;   
   private String localTopologyName;
   private String category;

   public TestCaseDescriptor(String dir, String topologyName, String testNum,
      String category) {
      this.directoryName = dir;
      this.testNumber = testNum;
      this.category = category;
      this.localTopologyName = topologyName;   
   }

   /**
    * Get the category.
    * 
    * @return Return the category
    */
   public String getCategory() {
      return category;
   }

   /**
    * @return Returns the directoryName.
    */
   public String getDirectoryName() {
      return directoryName;
   }

   /**
    * @return Returns the testNumber.
    */
   public String getTestNumber() {
      return testNumber;
   }

   /**
    * @param testDescription
    *            The testDescription to set. Insert new lines into the text to
    *            enhance readability from the GUI.
    */
   public void setTestDescription(String testDescription) {
      this.testDescription = testDescription.trim();
   }

   /**
    * @return Returns the testDescription.
    */
   public String getTestDescription() {
      return testDescription + 
         "\nNOTE: ADDITIONAL SIGNALING FOR SETUP AND TEARDOWN\n" +
         "OF TEST IS INCLUDED IN CALL FLOW";
   }

   public String toString() {
      return testNumber + " : " + directoryName;
   }

   public String getFileName() {
      return directoryName + "/testscript.xml";
   }

   public String getTopologyFileName() {
      return directoryName + "/" + localTopologyName;
   }   
}
