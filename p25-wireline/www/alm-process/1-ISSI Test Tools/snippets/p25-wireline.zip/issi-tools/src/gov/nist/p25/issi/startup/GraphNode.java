package gov.nist.p25.issi.startup;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

import att.grappa.Graph;
import att.grappa.GrappaConstants;
import att.grappa.Node;

abstract class GraphNode extends Node {
   
	protected ClusterConfigurationEditor clusterEditor;
	protected Graph graph;
	private int xPosition;
	private int yPosition;
	
	protected int WACN_YPOSITION = ClusterConfigurationEditor.VERTICAL_SPACING * 6;
	protected int SYSTEMNODE_YPOSITION = ClusterConfigurationEditor.VERTICAL_SPACING * 5;
	protected int RFSSNODE_YPOSITION = ClusterConfigurationEditor.VERTICAL_SPACING * 4;
	protected int DAEMON_YPOSITION = ClusterConfigurationEditor.VERTICAL_SPACING * 3;
	protected int GROUP_YPOSITION  = ClusterConfigurationEditor.VERTICAL_SPACING * 2;
	protected int GROUPNODE_YPOSITION = ClusterConfigurationEditor.VERTICAL_SPACING * 1;
	protected int SUNODE_YPOSITION = 0;

	public GraphNode(ClusterConfigurationEditor clusterManager, Graph graph) {
		super(graph);
		this.clusterEditor = clusterManager;
		this.graph = graph;
	}

	public void setXPosition(int pos) {
		this.xPosition = pos;
		setAttribute(GrappaConstants.POS_ATTR, (pos + "," + yPosition));

	}

	protected void setYPosition(int pos) {
		this.yPosition = pos;
	}

	public int getXPosition() {
		return this.xPosition;
	}

	public int getYPosition() {
		return this.yPosition;
	}

	protected static void showTable(ClusterConfigurationEditor clusterManager,
			ConfigTableModel tableModel, CreateActionListener updateListener,
			GraphNode graphNode) {
		JTable jtable = new JTable(tableModel);
		
		jtable.setCellSelectionEnabled(true);
		TableColumn col = jtable.getColumnModel().getColumn(1);
		col.setPreferredWidth(100);
	    col.setCellRenderer(new MyTableCellRenderer( tableModel));
	  
	    
	    col = jtable.getColumnModel().getColumn(0);
	    col.setPreferredWidth(200);
	    
	  	JDialog dialog = new JDialog(clusterManager.getJFrame());

		updateListener.setDialog(dialog);
		updateListener.setJTable(jtable);
	
		dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Container contentPane = dialog.getContentPane();

		dialog.setModal(true);

		Rectangle rectangle = dialog.getBounds();

		int width = clusterManager.getJFrame().getWidth() / 2;
		int height = clusterManager.getJFrame().getHeight() / 2;
		rectangle.setLocation(clusterManager.getJFrame().getX() + width, clusterManager
				.getJFrame().getY()
				+ height);
		rectangle.width = 400;

		dialog.setBounds(rectangle);
		dialog.setAlwaysOnTop(true);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

		contentPane.add(jtable);

		JPanel buttonPanel = new JPanel();
		contentPane.add(buttonPanel);
		buttonPanel.setLayout(new GridLayout(1, 2));

		JButton jbutton = new JButton("Update");
		jbutton.addActionListener(updateListener);
	
		buttonPanel.add(jbutton);
		jbutton = new JButton("Done");

		jbutton.addActionListener(new ActionListener() {
			private JDialog frame;
			private GraphNode graphNode;

			public ActionListener setFrame(JDialog frame, GraphNode graphNode) {
				this.frame = frame;
				this.graphNode = graphNode;

				return this;
			}

			@Override
			public void actionPerformed(ActionEvent actionEvent) {
				frame.dispose();
				if (graphNode != null) {
					graphNode.cleanupAction();
				}

			}

		}.setFrame(dialog, graphNode));

		buttonPanel.add(jbutton);
		dialog.pack();
		dialog.setVisible(true);
	}

	protected static void showTable(ClusterConfigurationEditor clusterManager,
			ConfigTableModel tableModel, CreateActionListener updateListener) {
		showTable(clusterManager, tableModel, updateListener, null);
	}

	/**
	 * Show the editable attributes.
	 */
	public abstract void showAttributes();

	public abstract void cleanupAction();

}
