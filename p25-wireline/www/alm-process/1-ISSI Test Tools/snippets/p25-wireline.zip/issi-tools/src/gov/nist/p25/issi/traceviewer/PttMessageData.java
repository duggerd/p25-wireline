//
package gov.nist.p25.issi.traceviewer;

import java.util.Properties;

import gov.nist.p25.issi.constants.RtfConstants;

/**
 * This class adds functionality to SIP and PTT message data.
 * 
 * @author mranga@nist.gov
 * @author steveq@nist.gov
 * @version $Revision: 1.5 $, $Date: 2007/10/27 03:23:33 $
 * @since 1.5
 */
public class PttMessageData extends MessageData 
      implements Comparable<PttMessageData>, RtfConstants {
   
   private String sequenceNumber;   
   //private String rtfData ;
   private Properties properties;

   // accessor
   public String getSequenceNumber() {
      return sequenceNumber;
   }
//   public String getRtfData() {
//      return rtfData;
//   }
   public Properties getProperties() {
      return properties;
   }
   
   // constructor
   public PttMessageData(
         String remoteRfssId,
         String myRfssId, 
         String myRtpRecvPort, 
         String remoteRtpRecvPort, 
         String messageType, 
         String data, 
         String time, 
         String sequenceNumber,
         String rtfData ,
         boolean selected,
         boolean isSender,
         Properties props) {
      
      super(remoteRfssId, myRfssId, remoteRtpRecvPort, myRtpRecvPort, 
            messageType, data, time, messageType, selected,isSender);
      this.sequenceNumber = sequenceNumber;
      //this.rtfData = rtfData;
      this.properties = props;   
   }

   /*****
   @Override
   public String getRtfText() {
      StringBuffer sbuf = new StringBuffer();
      sbuf.append("{\\par F" + getId()+ "\\par }\n");
      //
      // Dunno what the bloody hell this is but I cut and paste from a
      // word document.
       //
      sbuf.append(PREAMBLE);
      sbuf.append(this.rtfData);
      sbuf.append(END_MESSAGE);
      return sbuf.toString();
   }
    *****/

   public int compareTo(PttMessageData m2) {
      
      PttMessageData m1 = this;
      try {
         long ts1 = Long.parseLong(m1.getTime());
         long ts2 = Long.parseLong(m2.getTime());
         if (ts1 < ts2)
            return -1;
         else if (ts1 > ts2)
            return 1;
         else {
            // M1022: add m1
            int sq1 = Integer.parseInt(m1.sequenceNumber);
            int sq2 = Integer.parseInt(m2.sequenceNumber);
            if ( sq1 < sq2) return -1;
            else if (sq1 > sq2) return 1;
            else return 0;            
         }
      } catch (NumberFormatException ex) {
         ex.printStackTrace();
         //System.exit(0);
         return 0;
      }
   }

   // Use by PttTraceVerifier only ?
   public boolean match(PttMessageData that) {
       
       for ( String name : that.properties.stringPropertyNames() ) {
          if ( this.properties.get(name) == null) 
             return false;
          if ( !this.properties.get(name).equals(that.properties.get(name)))
             return false;
       }
       return true;
   }
    
}
