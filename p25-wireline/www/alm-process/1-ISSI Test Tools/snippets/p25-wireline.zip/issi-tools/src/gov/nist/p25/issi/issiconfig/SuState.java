//
package gov.nist.p25.issi.issiconfig;

/**
 * @author M. Ranganathan
 * 
 */
public enum SuState {

   ON, OFF;

   @Override
   public String toString() {
      if (this == ON)
         return "ON";
      else
         return "OFF";
   }
}
