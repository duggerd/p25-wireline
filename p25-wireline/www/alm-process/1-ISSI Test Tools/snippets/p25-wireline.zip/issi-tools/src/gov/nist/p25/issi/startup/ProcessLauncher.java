//
package gov.nist.p25.issi.startup;

//import gov.nist.p25.issi.traceverifier.Verifier;

import java.io.File;

/**
 * A platform independent launcher that reads the eclipse .classpath and
 * generates a runtime classpath from it.
 * 
 * @author mranga@nist.gov
 * 
 */
public class ProcessLauncher {

	public static Process runCommand(String className) throws Exception {

		String classPath = new ParseDotClasspath().parseDotClassPath()
				+ File.pathSeparator + "./diets-1.0.rc2.jar";
		
//		String classPath = System.getProperty("user.dir") + 
//		   File.separator + "lib/*.jar" +
//         File.pathSeparator + "./diets-1.0.rc2.jar";

      System.out.println("ProcessLauncher: ");
      String program = System.getenv().get("JAVA_HOME") + "/bin/java";
      
		// -Djava.library.path=./bin/native/jpcap
		String libpath = "-Djava.library.path="+ System.getProperty("user.dir") +
		                 "/bin/native/jpcap";
      System.out.println(program + " -classpath " + classPath + 
            " " + libpath + " " + className);
		
      //System.out.println("java  -classpath " + classPath + " " + className);
		//String commands[] = { "java", "-classpath", classPath, className };
		String commands[] = { program, "-classpath", classPath, libpath, className };

		return Runtime.getRuntime().exec(commands);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		try {			
			String className = System.getProperties().getProperty("className");		
			//className = DietsStartup.class.getCanonicalName();
					
			runCommand(className);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
