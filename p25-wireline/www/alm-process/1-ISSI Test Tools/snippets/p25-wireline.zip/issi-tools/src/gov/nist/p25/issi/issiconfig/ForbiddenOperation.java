//
package gov.nist.p25.issi.issiconfig;

/**
 * @author M. Ranganathan
 *
 */
public class ForbiddenOperation {
   
   private String operation;
   private RfssConfig rfssConfig;
   
   // accessor
   public String getOperation() {
      return operation;
   }
   public RfssConfig getRfssConfig() {
      return rfssConfig;
   }
   
   public ForbiddenOperation (String operation, RfssConfig rfssConfig ) {
      this.operation = operation;
      this.rfssConfig = rfssConfig;
   }
   
   public boolean isOperationForbidden ( String operation, RfssConfig rfssConfig) {
      return rfssConfig == rfssConfig && operation.equals( operation);
   }
}
