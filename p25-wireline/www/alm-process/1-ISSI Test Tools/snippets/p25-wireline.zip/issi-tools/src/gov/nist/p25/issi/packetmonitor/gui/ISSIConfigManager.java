//
package gov.nist.p25.issi.packetmonitor.gui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import gov.nist.p25.issi.issiconfig.SystemTopologyParser;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
//import gov.nist.p25.issi.rfss.ISSITesterConstants;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfigurationParser;
import gov.nist.p25.issi.startup.DietsConfigProperties;

import org.apache.log4j.Logger;

/**
 * ISSI Configuration Manager class.
 * 
 * @author echang@associate.its.bldrdoc.gov
 *
 */
public class ISSIConfigManager {
   
   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ISSIConfigManager.class);

   private String startupFile;
   private Properties props;

   private ISSITesterConfiguration issiTesterConfiguration;
   private TopologyConfig systemTopologyConfig;


   // accessor
   public String getStartupFile()
   {
      return startupFile;
   }

   public String getSystemTopologyFile() throws FileNotFoundException
   {
      String name = props.getProperty( DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
      if (name == null) {
         throw new FileNotFoundException( "Bad or missing system topology file: "+name);
      }
      return name;
   }
   public void setSystemTopologyFile(String name) throws Exception
   {
      if (name == null || name.length() == 0) {
         throw new FileNotFoundException("Bad input system topology file: "+name);
      }
      props.setProperty( DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY, name);
   }

   public String getTesterConfigurationFile() throws FileNotFoundException
   {
      String name = props.getProperty( DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
      if (name == null) {
         throw new FileNotFoundException("Bad or missing tester config file: "+name);
      }
      return name;
   }
   public void setTesterConfigurationFile(String name) throws Exception
   {
      if (name == null || name.length() == 0) {
         throw new FileNotFoundException("Bad input tester config file: "+name);
      }
      props.setProperty( DietsConfigProperties.DAEMON_CONFIG_PROPERTY, name);
   }

   public ISSITesterConfiguration getIssiTesterConfiguration() {
      return issiTesterConfiguration;
   }
   public TopologyConfig getSystemTopologyConfig() {
      return systemTopologyConfig;
   }

   // constructor
   // --------------------------------------------------------------------------
   public ISSIConfigManager()
   {
      props = new Properties();
   }
   public ISSIConfigManager(String startupFile) throws Exception
   {
      initProperties(startupFile);
   }

   public void initProperties(String startupFile) throws Exception
   {
      // typical diets.properties
      // diets.tester.testsuite=conformance
      // diets.daemon.configuration=testerconfig/local-configuration.xml
      // diets.packetmonitor.systemTopology=testsuites/conformance/systemtopology.xml
      //
      this.startupFile = startupFile;
      props = new Properties();
      FileInputStream inStream = new FileInputStream(new File(startupFile));
      props.load(inStream);

      initTopologyConfig();
   }

   public void initTopologyConfig() throws Exception
   {
      // PacketMonitor: diets.properties
      //  testerConfigurationFile=DIETS-IWCE-CAPTURES/local-configuration.xml
      //  systemTopologyFile=DIETS-IWCE-CAPTURES/systemtopology.xml
      
      logger.debug("initTopologyConfig from startupFile: "+startupFile);
      try {
         String testerConfigurationFile = getTesterConfigurationFile();
         issiTesterConfiguration = new ISSITesterConfigurationParser(
               testerConfigurationFile).parse();

         String systemTopologyFile = getSystemTopologyFile();
         systemTopologyConfig = new SystemTopologyParser(issiTesterConfiguration)
               .parse(systemTopologyFile);

      } catch (Exception ex) {
         logger.error("Error in parsing configuration files", ex);
         throw ex;
      }
   }

   //==========================================================================
   public static void main(String[] args) throws Exception 
   {

      String startupFile = "c:/project/issi-emulator/DIETS-IWCE-CAPTURES/diets.properties";
      if( args.length > 0) {
         startupFile = args[0];
      }
      ISSIConfigManager configMgr = new ISSIConfigManager(startupFile);

      System.out.println("\nstartupFile="+configMgr.getStartupFile());
      System.out.println("\nIssiTesterConfiguration=" + configMgr.getIssiTesterConfiguration());
      System.out.println("\nSystemTopologyConfig=" + configMgr.getSystemTopologyConfig());

   }
}
