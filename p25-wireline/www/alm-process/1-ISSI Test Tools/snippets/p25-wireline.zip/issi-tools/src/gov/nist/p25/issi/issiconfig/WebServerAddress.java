package gov.nist.p25.issi.issiconfig;

public interface WebServerAddress {

   public abstract String getIpAddress();
   public abstract int getHttpPort();
   public abstract String getHttpControlUrl();
}
