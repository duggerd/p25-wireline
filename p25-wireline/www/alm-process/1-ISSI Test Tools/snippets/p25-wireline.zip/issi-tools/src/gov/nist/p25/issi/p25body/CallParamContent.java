//
package gov.nist.p25.issi.p25body;

import java.text.ParseException;
import javax.sip.header.ContentTypeHeader;

import gov.nist.p25.issi.p25body.params.CallParam;

/**
 * @author M. Ranganathan
 * 
 */
public class CallParamContent extends Content {

   private CallParam callParam;

   CallParamContent(ContentTypeHeader contentType, String callParamContent)
         throws ParseException {
      super(contentType, callParamContent);
      this.callParam = CallParam.createCallParam(callParamContent);
      super.setContent(callParamContent);
   }
   
   CallParamContent(ContentTypeHeader contentType) {
      super(contentType,null);
      this.callParam = new CallParam();
   }

   /**
    * Create an instance of this object given a string containing the call
    * param body.
    * 
    * @param callParamContent
    * @return
    * @throws ParseException
    */
   public static CallParamContent createCallParamContent(
         String callParamContent) throws ParseException {
      return new CallParamContent(p25ContentTypeHeader, callParamContent);
   }
   
   /**
    * Create a default call param content header.
    * This has a default call param assigned.
    */
   public static CallParamContent createCallParamContent() {
      return new CallParamContent(p25ContentTypeHeader);
      
   }

   /**
    * @return Returns the callParam.
    */
   public CallParam getCallParam() {
      return callParam;
   }

   @Override
   public String toString() {

      if (super.boundary == null)
         return this.callParam.toString();
      else {
         return new StringBuffer().append(
               super.boundary + "\r\n" + getContentTypeHeader() + "\r\n"
                     + this.callParam.toString()).toString();
      }
   }

   @Override
   public String toRtfString() {
      
      if ( super.boundary == null) return this.callParam.toRtfString();
      else {
         return new StringBuffer().append(
               HEADER_START +
               super.boundary + 
               HEADER_END  +
               "\r\n" +
               HEADER_START + getContentTypeHeader() +  HEADER_END +  LINE_FEED + "\r\n"
                     + this.callParam.toRtfString()).toString();
      }
   }

   @Override
   public boolean match(Content template) {
      if (! ( template instanceof CallParamContent)) return false;
      CallParam templateContent = ((CallParamContent) template).callParam;
      return callParam.match( templateContent);
   }

   @Override
   public boolean isDefault() {
      return this.callParam.isDefault();
   }
}
