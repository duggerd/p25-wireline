package gov.nist.p25.issi.rfss;

import javax.sip.address.URI;

/**
 * Exported binding. You can use RMI to get the bindings as an array of such
 * values.
 */
public class ExportedBinding implements java.io.Serializable {

   private static final long serialVersionUID = -1L;
   
   protected long expiryTime;
   protected String requestURI;
   protected String contactAddress;
   protected URI key;

   public String getRequestURI() {
      return requestURI;
   }

   public String getContactAddress() {
      return contactAddress;
   }

   public long getExpiryTime() {
      return expiryTime;
   }

   public String getKey() {
      return key.toString();
   }
}
