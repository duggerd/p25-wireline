//
package gov.nist.p25.issi.startup;

import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JTable;


public abstract class CreateActionListener implements ActionListener {

   protected JDialog dialog;   
   protected JTable jtable;
   
   public void setDialog( JDialog frame) {
      this.dialog = frame;
   }
   
   public void setJTable( JTable jtable) {
      this.jtable  = jtable;
   }
   
   protected static boolean isNullOrEmpty(String arg) {
      return arg == null || arg.equals("");
   }   
}
