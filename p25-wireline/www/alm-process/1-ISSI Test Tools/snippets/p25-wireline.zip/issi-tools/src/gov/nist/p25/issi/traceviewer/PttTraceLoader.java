//
package gov.nist.p25.issi.traceviewer;

import java.awt.Color;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Hashtable;
import java.util.TreeSet;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;

//import org.apache.log4j.Logger;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;


/**
 * This class implements a PTT XML trace file loader.
 * 
 * @author steveq@nist.gov
 * @author mranga@nist.gov
 * @version $Revision: 1.6 $, $Date: 2007/10/27 03:23:33 $
 * @since 1.5
 */
public class PttTraceLoader extends DefaultHandler 
   implements TraceLoader {

   //private static Logger logger = Logger.getLogger(PttTraceLoader.class);

   // /////////////////////////////////////////////////////////////////////
   // Variables
   // /////////////////////////////////////////////////////////////////////

   private Properties props = new Properties();
   private TreeSet<MessageData> messageList = null;
   private Hashtable<String, Color> colorMap = null;
   private String myIpAddress = "";
   private String myRtpRecvPort = "";
   private String myRfssId = "";
   private String remoteRtpRecvPort = "";
   private String remoteRfssId = "";
   private String messageType = "";
   private String pttMessageData = "";
   private String rtfData = "";
   private String receptionTime = "";

//   private int messageColorIndex = 0;
//   private static final int MAX_COLOR_INDEX = 11;
//
//   int[][] messageColors = { { 117, 4, 0 }, { 96, 93, 0 }, { 96, 0, 87 },
//         { 31, 104, 0 }, { 27, 0, 96 }, { 0, 159, 109 }, { 0, 145, 159 },
//         { 96, 0, 38 }, { 0, 0, 255 }, { 95, 0, 127 }, { 255, 0, 201 },
//         { 191, 0, 40 } };

   private boolean isSender;
   private boolean inRtfFormat;
   private String sequenceNumber;
   
   public String getMyIpAddress() {
      return myIpAddress;
   }

   // /////////////////////////////////////////////////////////////////////
   // Constructors
   // /////////////////////////////////////////////////////////////////////

   /**
    * This constructor gets called when we are loading the traces at the end of
    * a test case.
    * 
    * @param inputStream --
    *            input stream from which to read the messages.
    * @param colorMap --
    *            color map to color the horizontal arcs.
    */
   public PttTraceLoader(InputStream inputStream) {
      this( inputStream, new Hashtable<String, Color>());
   }
   
   public PttTraceLoader(InputStream inputStream,
         Hashtable<String, Color> colorMap) {
      this.messageList = new TreeSet<MessageData>();
      this.colorMap = colorMap;

      SAXParserFactory factory = SAXParserFactory.newInstance();
      try {
         SAXParser saxParser = factory.newSAXParser();
         saxParser.parse(inputStream, this);
      } catch (Exception ex) {
         ex.printStackTrace();
      }
   }

   // /////////////////////////////////////////////////////////////////////
   // Methods
   // /////////////////////////////////////////////////////////////////////

   public void startElement(String namespaceURI, String localName,
         String qualifiedName, Attributes attrs) throws SAXException {

      String elementName = localName;
      if ("".equals(elementName)) {
         elementName = qualifiedName;
      }

      if (!elementName.equals("rtf-format") && 
            !elementName.equals("trace") &&
            !elementName.equals("pttmessages"))
         pttMessageData += elementName + "\n";

      if (elementName.equals("rtf-format"))
         inRtfFormat = true;

      if (attrs != null && !elementName.equals("rtf-format")) {

         for (int i = 0; i < attrs.getLength(); i++) {

            String attributeName = attrs.getLocalName(i);
            if ("".equals(attributeName)) {
               attributeName = attrs.getQName(i);
            }

            //XXX: Here is the key:value pair that user sees
            pttMessageData += "\t" + attributeName + " = "
                  + attrs.getValue(i) + "\n";
            String propname = elementName + "." + attributeName;

            // Capture the fields for pattern matching.
            // M2001: add padding, csrcCount
            if (propname.equals("ptt-packet.receivingRfssId")
                  || propname.equals("ptt-packet.sessionType")
                  || propname.equals("rtp-header.version")
                  || propname.equals("rtp-header.padding")
                  || propname.equals("rtp-header.marker")
                  || propname.equals("rtp-header.headerExtension")
                  || propname.equals("rtp-header.csrcCount")
                  || propname.equals("rtp-header.payloadType")
                  || propname.equals("rtp-header.SSRC")
                  || propname.equals("control-octet.signalBit")
                  || propname.equals("control-octet.compactBit")
                  || propname.equals("block-header.payloadType")
                  || propname.equals("block-header.blockType")
                  || propname.equals("issi-packet-type.muteStatus")
                  || propname.equals("issi-packet-type.losingAudio")
                  || propname.equals("issi-packet-type.serviceOptions")
                  || propname.equals("issi-packet-type.packetType")) {
               props.setProperty(elementName + "." + attributeName,
                     attrs.getValue(i));
            }
            handleAttribute(attributeName, attrs.getValue(i));
         }
      }
   }

   public void handleAttribute(String attrName, String attrValue) {

      if (attrName.equals("myIpAddress")) {
         myIpAddress = attrValue;
      } else if (attrName.equals("receivingRfssId")) {
         myRfssId = attrValue;
      } else if (attrName.equals("isSender")) {
         this.isSender = attrValue.equals("true");
      } else if (attrName.equals("myRtpRecvPort")) {
         myRtpRecvPort = attrValue;
      } else if (attrName.equals("sendingRfssId")) {
         remoteRfssId = attrValue;
      } else if (attrName.equals("remoteRtpRecvPort")) {
         remoteRtpRecvPort = attrValue;
      } else if (attrName.equals("packetType")) {
         messageType = attrValue;
         if (colorMap != null) {
            if (!colorMap.containsKey(attrValue)) {
               //if (messageColorIndex > MAX_COLOR_INDEX)
               //   messageColorIndex = 0;
               //int[] rgb = messageColors[messageColorIndex++];
               //colorMap.put(attrValue, new Color(rgb[0], rgb[1], rgb[2]));           
               colorMap.put(attrValue, Color.black);
            }
         }
      } else if (attrName.equals("packetNumber")) {
         sequenceNumber = attrValue;
      } else if (attrName.equals("receptionTime")) {
         receptionTime = attrValue;
      }
   }

   public void endElement(String namespaceURI, String simpleName,
         String qualifiedName) throws SAXException {

      if (qualifiedName.equals("rtf-format")) {
         inRtfFormat = false;
      }
      if (qualifiedName.equals("ptt-packet")) {

         if (!pttMessageData.equals("")) {

            PttMessageData messageData = new PttMessageData(remoteRfssId,
                  myRfssId, myRtpRecvPort, remoteRtpRecvPort,
                  messageType, pttMessageData, receptionTime, sequenceNumber,
                  rtfData, false, isSender, props);
            messageList.add(messageData);

            // Reset data
            props = new Properties();
            isSender = false;
            myIpAddress = "";
            myRfssId = "";
            myRtpRecvPort = "";
            remoteRtpRecvPort = "";
            messageType = "";
            pttMessageData = "";
            receptionTime = "";
            sequenceNumber = "";
            remoteRfssId = "";
            rtfData = "";
         }
      }
   }

   public void characters(char buf[], int offset, int len) throws SAXException {
      String s = new String(buf, offset, len);
      if (!inRtfFormat) {
         if (s.length() > 8)
            pttMessageData += "\t" + s + "\n";
      } else {
         this.rtfData += s;
      }
   }

   public List<MessageData> getRecords(String rfssDomainName) {
      ArrayList<MessageData> alist = new ArrayList<MessageData>();
      for (MessageData mdata : messageList) {
         if ( mdata.getToRfssId().equals(rfssDomainName))
            alist.add(mdata);
      }
      return alist;
   }

   public List<MessageData> getRecords() {
      int counter = 0;
      ArrayList<MessageData> alist = new ArrayList<MessageData>();
      for (MessageData mdata: messageList) {
         mdata.setId(++counter);
         alist.add(mdata);
      }
      return alist;
   }
   
   public String getMessageData() {
      StringBuffer sbuf = new StringBuffer();
      for (MessageData mdata: getRecords()) {
         sbuf.append("F" + mdata.getId() + ":\n");
         sbuf.append(mdata.getData().trim());
         sbuf.append("\n\n");
      }
      return sbuf.toString();
   }
}
