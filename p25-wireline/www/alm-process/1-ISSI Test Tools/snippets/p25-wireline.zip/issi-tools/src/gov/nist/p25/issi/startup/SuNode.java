//
package gov.nist.p25.issi.startup;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.util.HashSet;

import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import att.grappa.Edge;
import att.grappa.Graph;
import att.grappa.GrappaColor;
import att.grappa.GrappaConstants;

public class SuNode extends GraphNode {
   
	private SuConfig suConfig;
	private HashSet<Edge> edges = new HashSet<Edge>();

	public SuNode(ClusterConfigurationEditor clusterManager, SuConfig suConfig, Graph graph ) {
		super(clusterManager,graph);
		this.suConfig = suConfig;
		super.setYPosition(SUNODE_YPOSITION);
		super.setName(suConfig.getSuName());
	}
	
	class UpdateActionListener extends CreateActionListener {
		
		private ConfigTableModel tableModel;

		public UpdateActionListener( ConfigTableModel tableModel) {
			this.tableModel = tableModel;
		}

		@Override
		public void actionPerformed(ActionEvent ae) {
			if ( jtable.isEditing()) {
        		jtable.editCellAt(0,0); // Move the focus out so the value takes.
        	}
        	tableModel.fireTableDataChanged();
        	jtable.requestFocus();
        	       	
			int suId = tableModel.getDataAsHexInt("suId");
			suConfig.setSuId(suId);					
		}	
	}
		
	@Override
	public void showAttributes() {
		
		clusterEditor.clear();		
		clusterEditor.drawRfssNodes();		
		clusterEditor.drawSuNodes();
				
		RfssConfig homeRfssConfig = suConfig.getHomeRfss();	
		RfssNode homeRfssNode = clusterEditor.rfssToNodeMap.get(homeRfssConfig);
		Edge edge = new Edge(graph,this,homeRfssNode);
		this.edges.add(edge);
		
		RfssConfig initialServingRfss = suConfig.getInitialServingRfss();
		RfssNode servingRfssNode = clusterEditor.rfssToNodeMap.get(initialServingRfss);
		edge = new Edge(graph,this,servingRfssNode);
		this.edges.add(edge);
		edge.setAttribute(GrappaConstants.COLOR_ATTR,  GrappaColor
					.getColor("RED", Color.RED));
		
		graph.repaint();	
		ConfigTableModel tableModel = new ConfigTableModel("SuConfig");
		tableModel.setUnEditable("suName");
		tableModel.setUnEditable("homeRfssName");
		tableModel.setUnEditable("servingRfssName");
		
		tableModel.setData("suName", suConfig.getSuName());
		tableModel.setData("homeRfssName", suConfig.getHomeRfss().getRfssName());
		tableModel.setData("servingRfssName", suConfig.getInitialServingRfss().getRfssName());
		tableModel.setData("suId", Integer.toHexString(suConfig.getSuId()));
		
		super.showTable(this.clusterEditor,tableModel,new UpdateActionListener(tableModel),this);		
	}

	@Override
	public void cleanupAction() {		
		for ( Edge edge : this.edges) {
			graph.removeEdge(edge.getName());
		}
		clusterEditor.redraw();		
		graph.repaint();		
	}
}
