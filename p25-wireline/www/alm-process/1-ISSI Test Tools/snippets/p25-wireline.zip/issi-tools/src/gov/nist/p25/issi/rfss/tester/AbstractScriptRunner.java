package gov.nist.p25.issi.rfss.tester;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.RfssConfig;

public abstract class AbstractScriptRunner extends AbstractSipSignalingTest {

   //TODO: need to use getter/setter
   protected static String scriptName;
   protected static String localTopologyName;
   
   public void setUp() throws Exception {

      TestScript testConfig = new TestScriptParser(
         ISSITesterConstants.getScenarioDir() + "/"+scriptName + "/testscript.xml",
         ISSITesterConstants.getScenarioDir() + "/"+scriptName +  "/" +  localTopologyName,
         ISSITesterConstants.getScenarioDir() + "/globaltopology.xml",
         ISSITesterConstants.getScenarioDir() + "/../systemtopology.xml",false).parse();
      testConfig.setTraceCaptureEnabled(true);
      //assertTrue(testConfig != null);
      super.setUp(testConfig);
   }

   @Override
   public RfssConfig getRfssConfig() {
      return null;
   }
}
