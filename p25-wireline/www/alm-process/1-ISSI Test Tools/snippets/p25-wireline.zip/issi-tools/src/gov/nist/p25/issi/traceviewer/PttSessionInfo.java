//
package gov.nist.p25.issi.traceviewer;

/**
 * Corresponds to information retrieved from the Ptt session
 * 
 * @author M. Ranganathan
 *
 */
public class PttSessionInfo {
   
   private String sessionType;
   private String rfssId;
   private String myRtpRecvPort;
   private String remoteIpAddress;
   private String remoteRtpRecvPort;
   private String unitId;
   private String linkType;
   
   public PttSessionInfo (String sessionType, String rfssId,
         String myRtpRecvPort, String remoteRtpRecvPort,
         String remoteIpAddress, String unitId, String linkType ) {
      this.sessionType = sessionType;
      this.rfssId = rfssId;
      this.myRtpRecvPort = myRtpRecvPort;
      this.remoteRtpRecvPort = remoteRtpRecvPort;
      this.remoteIpAddress = remoteIpAddress;
      this.unitId = unitId;
      this.linkType = linkType;
   }
   
   @Override
   public String toString() {
      return new StringBuffer().append("sessionType=" + sessionType)
      .append("\nmyRtpRecvPort=" + myRtpRecvPort )
      .append("\nremoteRtpRecvPort=" + remoteRtpRecvPort)
      .append("\nremoteIpAddress=" + remoteIpAddress)
      .append("\nunitId=" + unitId)
      .append("\nlinkType=" + linkType).toString();
   }

   public String getSessionType() {
      return sessionType;
   }

   public String getRfssId() {
      return rfssId;
   }

   public String getMyRtpRecvPort() {
      return myRtpRecvPort;
   }

   public String getRemoteRtpRecvPort() {
      return remoteRtpRecvPort;
   }

   public String getRemoteIpAddress() {
      return remoteIpAddress;
   }

   public String getUnitId() {
      return unitId;
   }

   public String getLinkType() {
      return linkType;
   }
}
