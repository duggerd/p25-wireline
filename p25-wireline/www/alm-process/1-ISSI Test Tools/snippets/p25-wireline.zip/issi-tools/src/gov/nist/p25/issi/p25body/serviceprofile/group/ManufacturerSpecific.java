//
package gov.nist.p25.issi.p25body.serviceprofile.group;

import gov.nist.p25.issi.p25body.serviceprofile.ServiceProfileLine;

/**
 * @author M. Ranganathan
 * 
 */
public class ManufacturerSpecific extends ServiceProfileLine {

   // TODO -- this needs to be completed.
   ManufacturerSpecific(String name, String value) {
      super(name, value);
   }
}
