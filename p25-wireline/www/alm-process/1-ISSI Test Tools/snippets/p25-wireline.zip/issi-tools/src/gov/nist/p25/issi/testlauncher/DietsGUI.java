//
package gov.nist.p25.issi.testlauncher;

import gov.nist.p25.issi.ISSITimer;
import gov.nist.p25.common.util.FileUtility;

import gov.nist.p25.issi.constants.ISSILogoConstants;
import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.GlobalTopologyParser;
import gov.nist.p25.issi.issiconfig.SystemTopologyParser;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfigurationParser;
import gov.nist.p25.issi.rfss.tester.RfssController;
import gov.nist.p25.issi.rfss.tester.TestRFSS;
import gov.nist.p25.issi.startup.DietsConfigProperties;
import gov.nist.p25.issi.traceverifier.PttTraceVerifier;
import gov.nist.p25.issi.traceverifier.SipTraceVerifier;
import gov.nist.p25.issi.utils.Zipper;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Properties;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
//import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileFilter;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;

/**
 * This class implements the front end test controller and trace viewer GUI for
 * ISSI Tester.
 * 
 * @author mranga@nist.gov
 * @author steveq@nist.gov
 * @author echang@associate.its.bldrdoc.gov
 * 
 */
public class DietsGUI extends JFrame 
   implements ActionListener, MouseListener, TestStatusInterface
{
   private static final long serialVersionUID = -1L;

   static {
      PropertyConfigurator.configure("log4j.properties");
   }
   private static Logger logger = Logger.getLogger(DietsGUI.class);
   public static void showln(String s) { System.out.println(s); }

   /***************************************************************************
    * Constants
    **************************************************************************/

   private static final String VERSION = ISSITesterConstants.VERSION;
   private static final String BUILD = ISSITesterConstants.BUILD;
   private static int PREFERRED_WIDTH = 1050;
   private static int PREFERRED_HEIGHT = 850;   

   private static boolean evaluatePassFail = true;   
   private static boolean standalone = false;
   private static String testerConfigurationFile;
   private static String globalTopologyFileName;
   
   private static String startupPropertiesFileName = ISSITesterConstants.STARTUP_PROPERTIES_FILENAME;
   private static String testRegistry = ISSITesterConstants.getScenarioDir()
         + "/" + ISSITesterConstants.TEST_REGISTRY_XML;
   private static String systemTopologyFileName = ISSITesterConstants.TESTSUITES_DIR
         + "/" + ISSITesterConstants.getTestSuite()
         + "/" + ISSITesterConstants.SYSTEM_TOPOLOGY_XML;

   private static String testSuite = ISSITesterConstants.getTestSuite();   
   private static ISSITesterConfiguration issiTesterConfiguration;
   private static Collection<String> ipAddresses;
   private static String traceSource;
   private static Vector<TestCaseDescriptor> tests;
   
   //private String traceSource;
   /***************************************************************************
    * Variables
    **************************************************************************/
  
   private TestControllerInterface remoteController;
   private TestExecutionPanel testExecutionPanel;

   private JCheckBoxMenuItem prompterCheckBox;  
   private JCheckBoxMenuItem showPttHeaderCheckBox;  
   private JCheckBoxMenuItem showAllPttCheckBox;  
   private JMenuItem clearRefMsgMenuItem;  
   private JFileChooser fileChooser;
   private JLabel statusLabel;   
   private JMenuItem closeMenuItem;
   private JMenuItem closeAllMenuItem;
   private JMenuItem exitMenuItem;
   private JMenuItem openMenuItem;
   private JMenuItem aboutMenuItem;
   private JMenuItem saveMenuItem;   
   private JMenuItem createTestrunZip;
   private JMenuItem verifyTraceMenuItem;
   private JMenuItem systemTopologyMenuItem;
   private JMenuItem startupPropertiesMenuItem;
   private JMenuItem loadPropertiesMenuItem;
   private JProgressBar statusProgressBar;
   private JTabbedPane tabbedPane;
   
   // accessors
   public String getTraceSource() {
      return traceSource;
   }
   public static void setTraceSource(String traceSource) {
      DietsGUI.traceSource = traceSource;
   }

   public JTabbedPane getJTabbedPane() {
      return tabbedPane;
   }
   public boolean getScenarioPrompterState() {
      return prompterCheckBox.getState();
   }
   public boolean getShowPttHeaderState() {
      return showPttHeaderCheckBox.getState();
   }
   public boolean getShowAllPttState() {
      return showAllPttCheckBox.getState();
   }

   private static Vector<TestCaseDescriptor> getAvailableTestCases()
         throws Exception {
      TestRegistryParser parser = new TestRegistryParser(testRegistry);
      parser.parse();
      return parser.getTestCaseList();
   }

   public static String getStartupPropertiesFileName() {
      return startupPropertiesFileName;
   }
   public static void setStartupPropertiesFileName(String fileName) {
      DietsGUI.startupPropertiesFileName = fileName;
   }
   /***************************************************************************
    * Private methods.
    **************************************************************************/
   private void setStatusLabel(JLabel statusLabel) {
      this.statusLabel = statusLabel;
   }

   private Point centerComponent(Component c) {
      Rectangle rc = new Rectangle();
      rc = c.getBounds(rc);
      Rectangle rs = new Rectangle(Toolkit.getDefaultToolkit()
            .getScreenSize());
      return new Point((int) ((rs.getWidth() / 2) - (rc.getWidth() / 2)),
            (int) ((rs.getHeight() / 2) - (rc.getHeight() / 2)));
   }

   private void setStatusProgressBar(JProgressBar statusProgressBar) {
      this.statusProgressBar = statusProgressBar;
   }

   public void updateGlobalTopologyPane() throws IOException {
      String ftext = FileUtility.loadFromFileAsString(globalTopologyFileName);
      testExecutionPanel.logGlobalTopologyPane(true, ftext);
   }

   public void updateSystemTopologyPane() throws IOException {
      String ftext = FileUtility.loadFromFileAsString(systemTopologyFileName);         
      testExecutionPanel.logSystemTopologyPane(true, ftext);
   }

   /***************************************************************************
    * Constructors
    **************************************************************************/
   public DietsGUI() throws Exception {

      super();
      initGui();

      try {
         if (standalone) {
            remoteController = new RfssController(ipAddresses);
         } else {
            remoteController = new RemoteTestController(this);
         }

      } catch (Exception e) {
         e.printStackTrace();
         throw e;
      }
   }

   /***************************************************************************
    * Methods
    **************************************************************************/
   public void initGui() throws Exception {

      logger.info("GUI system initializing!");
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

      // File chooser used to open the trace file.
      fileChooser = new JFileChooser(System.getProperty("user.dir"));
      fileChooser.setDialogTitle("Open trace directory in /testrun");
      fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      FileFilter traceFilter = new FileFilter() {

         @Override
         public boolean accept(File pathname) {
            if (pathname.isDirectory())
               return true;
            else
               return false;
         }

         @Override
         public String getDescription() {
            return "tracedir";
         }

      };
      fileChooser.setFileFilter(traceFilter);

      JMenuBar menuBar = new JMenuBar();
      // ---------------------- File ----------------------------
      JMenu fileMenu = new JMenu("File");

      openMenuItem = new JMenuItem("Open trace directory");
      openMenuItem.addActionListener(this);
      openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
            ActionEvent.CTRL_MASK));

      loadPropertiesMenuItem = new JMenuItem("Load startup properties");
      loadPropertiesMenuItem.addActionListener(this);
      loadPropertiesMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,
            ActionEvent.CTRL_MASK));

      saveMenuItem = new JMenuItem("Save current test trace");
      saveMenuItem.addActionListener(this);
      saveMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
            ActionEvent.CTRL_MASK));
      
      createTestrunZip = new JMenuItem("Create testrun zip");
      createTestrunZip.addActionListener(this);
      createTestrunZip.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
            ActionEvent.CTRL_MASK));

      verifyTraceMenuItem = new JMenuItem("Verify saved trace");
      verifyTraceMenuItem.addActionListener(this);
      verifyTraceMenuItem.setAccelerator(KeyStroke.getKeyStroke(
            KeyEvent.VK_V, ActionEvent.CTRL_MASK));

      closeMenuItem = new JMenuItem("Close");
      closeMenuItem.setEnabled(false);
      closeMenuItem.addActionListener(this);
      closeMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,
            ActionEvent.CTRL_MASK));

      closeAllMenuItem = new JMenuItem("Close All");
      closeAllMenuItem.setEnabled(false);
      closeAllMenuItem.addActionListener(this);
      closeAllMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
            ActionEvent.CTRL_MASK));

      exitMenuItem = new JMenuItem("Exit");
      exitMenuItem.addActionListener(this);
      exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
            ActionEvent.CTRL_MASK));

      fileMenu.add(loadPropertiesMenuItem);
      fileMenu.addSeparator();
      fileMenu.add(openMenuItem);
      fileMenu.addSeparator();
      fileMenu.add(saveMenuItem);
      fileMenu.addSeparator();
      fileMenu.add(verifyTraceMenuItem);
      fileMenu.addSeparator();
      fileMenu.add(createTestrunZip);
      fileMenu.addSeparator();

      // ---------------------- Options ----------------------------
      JMenu preferencesMenu = new JMenu("Edit");
      preferencesMenu.setEnabled(true);
      startupPropertiesMenuItem = new JMenuItem("Startup Properties");
      startupPropertiesMenuItem.addActionListener(this);
      
      systemTopologyMenuItem = new JMenuItem("System Topology");
      systemTopologyMenuItem.addActionListener(this);

      preferencesMenu.add(startupPropertiesMenuItem);
      preferencesMenu.add(systemTopologyMenuItem);
      
      fileMenu.add(preferencesMenu);
      fileMenu.addSeparator();
      fileMenu.add(exitMenuItem);
      
      // ---------------------- Config --------------------------
      JMenu configMenu = new JMenu("Config");
      prompterCheckBox = new JCheckBoxMenuItem("Scenario Prompter");
      prompterCheckBox.addActionListener(this);
      configMenu.add( prompterCheckBox);
      configMenu.addSeparator();

      showPttHeaderCheckBox = new JCheckBoxMenuItem("Show PTT Header");
      showPttHeaderCheckBox.addActionListener(this);
      configMenu.add( showPttHeaderCheckBox);

      //showAllPttCheckBox = new JCheckBoxMenuItem("Show All PTT");
      //showAllPttCheckBox.addActionListener(this);
      //configMenu.add( showAllPttCheckBox);
      configMenu.addSeparator();

      clearRefMsgMenuItem = new JMenuItem("Clear Current Ref Trace");
      clearRefMsgMenuItem.addActionListener(this);
      configMenu.add( clearRefMsgMenuItem);
      
      // ---------------------- Help ----------------------------
      JMenu helpMenu = new JMenu("Help");
      helpMenu.setEnabled(true);

      aboutMenuItem = new JMenuItem("About ISSI Tester");
      aboutMenuItem.setActionCommand("About");
      aboutMenuItem.addActionListener(this);

      helpMenu.add(aboutMenuItem);

      //==========================================================
      menuBar.add(fileMenu);
      menuBar.add(configMenu);
      menuBar.add(helpMenu);
      setJMenuBar(menuBar);

      testExecutionPanel = new TestExecutionPanel(tests, this);
      updateGlobalTopologyPane();
      updateSystemTopologyPane();

      testExecutionPanel.setMinimumSize(new Dimension( DietsGUI.PREFERRED_WIDTH, 200));
      testExecutionPanel.setPreferredSize(new Dimension( DietsGUI.PREFERRED_WIDTH, 225));
      testExecutionPanel.setMaximumSize(new Dimension( DietsGUI.PREFERRED_WIDTH, 325));

      JPanel tabbedPanel = new JPanel();
      tabbedPanel.setLayout(new BorderLayout());
      tabbedPanel.setBorder(new TitledBorder("Test Traces"));
      tabbedPane = new JTabbedPane();
      tabbedPanel.add(tabbedPane, BorderLayout.CENTER);

      setIconImage(new ImageIcon(ISSILogoConstants.ISSI_TESTER_LOGO).getImage());
      setTitle("ISSI Tester v" + VERSION);

      getContentPane().setLayout(new BorderLayout());
      getContentPane().add(testExecutionPanel, BorderLayout.NORTH);

      JPanel statusPanel = new JPanel();
      statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
      statusPanel.setPreferredSize(new Dimension(PREFERRED_WIDTH, 22));
      
      setStatusLabel(new JLabel("Ready"));
      getStatusLabel().setMinimumSize(new Dimension(300, 16));
      getStatusLabel().setPreferredSize(new Dimension(700, 16));
      getStatusLabel().setMaximumSize(new Dimension(900, 16));
      
      setStatusProgressBar(new JProgressBar());
      getStatusProgressBar().setMinimumSize(new Dimension(100, 16));
      getStatusProgressBar().setPreferredSize(new Dimension(150, 16));
      getStatusProgressBar().setMaximumSize(new Dimension(200, 16));
      getStatusProgressBar().setIndeterminate(false);

      statusPanel.add(getStatusLabel());
      statusPanel.add(getStatusProgressBar());

      JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
            testExecutionPanel, tabbedPanel);
      splitPane.setOneTouchExpandable(true);
      splitPane.setDividerSize(7);
      
      getContentPane().add(splitPane, BorderLayout.CENTER);
      getContentPane().add(statusPanel, BorderLayout.SOUTH);

      setSize(PREFERRED_WIDTH, PREFERRED_HEIGHT);
      Point upperLeftPoint = centerComponent(this);
      setLocation(upperLeftPoint);
      setAlwaysOnTop(true);

      ISSITimer.getTimer().schedule(new TimerTask() {
         @Override
         public void run() {
            setAlwaysOnTop(false);
         }

      }, 1000);

      setVisible(true);
      Dimension z = getStatusProgressBar().getSize();
      double height = z.getHeight();
      double width = z.getWidth();
      logger.info("height: " + height + ", width: " + width);

      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e) {
            DietsGUI.this.dispose();
         }
      });
   }

   public JMenuItem getCloseMenuItem() {
      return closeMenuItem;
   }

   public JProgressBar getStatusProgressBar() {
      return statusProgressBar;
   }

   public JLabel getStatusLabel() {
      return statusLabel;
   }

   public TestExecutionPanel getTestExecutionPanel() {
      return testExecutionPanel;
   }

   public JMenuItem getCloseAllMenuItem() {
      return closeAllMenuItem;
   }

   public void resetRemoteController() {
      remoteController.reset();
   }

   public TestControllerInterface getRemoteController() {
      return remoteController;
   }

   public String getWebConfigurationFileName() {
      return testerConfigurationFile;
   }

   //---------------------------------------------------------------------------
   public void actionPerformed(ActionEvent ae) {

      // Using the command is not a good idea - if you change the command in
      // one place, your code will break.
      if (ae.getSource() == exitMenuItem) {
         DietsGUI.this.dispose();
         // System.exit(0);
      } else if (ae.getSource() == openMenuItem) {
         try {
            openFile();
         } catch (Exception ex) {
            logger.error("Exception caught", ex);
            showError("Error in opening trace directory",
                  "Load trace error");
         }

      } else if (ae.getSource() == loadPropertiesMenuItem) {
         try {
            loadProperties();
         } catch (Exception ex) {
            logger.error("Exception caught", ex);
         }
      } else if (ae.getSource() == saveMenuItem) {
         try {
            saveFiles(true);
         } catch (Exception ex) {
            logger.error("Exception caught", ex);
            showError("Error saving traces  " + ex.getMessage(),         
               "Save trace error");
         }

      } else if ( ae.getSource() == createTestrunZip) {
         try {
            zipFiles();
         } catch (Exception ex) {
            logger.error("Exception caught", ex);
            showError("Error zipping testrun " + ex.getMessage(),
               "Zip Error");
         }
      } else if (ae.getSource() == verifyTraceMenuItem) {
         try {
            TestCaseDescriptor testCaseDescriptor = testExecutionPanel.getCurrentTestCaseDescriptor();
            String testSuiteName = testSuite;
            String topologyFileName = testCaseDescriptor.getTopologyFileName();
            ISSITesterConfiguration config = new ISSITesterConfigurationParser(
                  testerConfigurationFile).parse();
            String testName = testCaseDescriptor.getDirectoryName();
            
            SipTraceVerifier.testCapturedMessages(config, "./",
                  testSuiteName, testName, topologyFileName);

            PttTraceVerifier.testCapturedMessages(config, "./",
                  testSuiteName, testName, topologyFileName);
            
            JOptionPane.showMessageDialog( null,          
               "Completed verifying test trace:\n\n" + testCaseDescriptor +
	       "\n\n");
            
         } catch (Exception ex) {
            logger.error("An unepected exception occured", ex);
            showError("Error in verifying test trace: " + ex.getMessage(),
               "Verification Error");
         }

      } else if (ae.getSource() == closeMenuItem) {

         int showing = tabbedPane.getSelectedIndex();
         //System.out.println("tab #" + showing);
         tabbedPane.remove(showing);

         if (tabbedPane.getComponentCount() == 0) {
            getCloseMenuItem().setEnabled(false);
            getCloseAllMenuItem().setEnabled(false);
         }

      } else if (ae.getSource() == clearRefMsgMenuItem) {

         try {
            TestCaseDescriptor descriptor = testExecutionPanel.getCurrentTestCaseDescriptor();
            String testSuiteName = testSuite;
            String topologyFileName = descriptor.getTopologyFileName();
            String refDirName = "refmessages/" + testSuiteName + "/"
               + topologyFileName.substring(0, topologyFileName.indexOf("/"));
            //showln("Clear Ref Msg: "+refDirName);
            FileUtility.deleteDir( new File(refDirName), true);

         } catch(Exception ex) { }

      } else if (ae.getSource() == aboutMenuItem) {

         AboutDialog about_dialog = new AboutDialog(this, VERSION, BUILD);
         about_dialog.setSize(600, 500);
         about_dialog.setLocationRelativeTo(this);
         about_dialog.setVisible(true);

      } else if (ae.getSource() == systemTopologyMenuItem) {
         try {

            testExecutionPanel.disableAllButtons();
            String topologyFileName = getSystemTopologyName();
            File file = new File(topologyFileName);
            ConfigDialog customDialog = new ConfigDialog(file,
                  "System Topology: " + topologyFileName);            
            customDialog.setLocationRelativeTo(this);
            customDialog.setVisible(true);

            /* Dialog returns here. */
            if (customDialog.isSaved()) {               
               String ftext = FileUtility.loadFromFileAsString(getSystemTopologyName());
               testExecutionPanel.logConfigurePane(true,ftext);
            }
            updateSystemTopologyPane();

         } catch (Exception ex) {
            ex.printStackTrace();
            showWarning("Make sure the file is writable!",
                  "Edit error");
         } finally {
            testExecutionPanel.enableAllButtons();
         }
      } else if (ae.getSource() == startupPropertiesMenuItem) {
         char[] rbuf = null;
         try {
            FileReader reader = new FileReader( getStartupPropertiesFileName());
            File topologyFile = new File( getStartupPropertiesFileName());
            int length = (int) topologyFile.length();
            rbuf = new char[length];
            reader.read(rbuf);
            reader.close();
         } catch (Exception ex) {
            showError("could not read startup props file", "File read error");
            return;
         }

         String fileName = getStartupPropertiesFileName();
         try {
            testExecutionPanel.disableAllButtons();

            File file = new File(fileName);
            ConfigDialog customDialog = new ConfigDialog(file,
                  "Startup Properties: " + fileName);
            customDialog.setLocationRelativeTo(this);
            customDialog.setVisible(true);

            /* Dialog returns here. */
            if (customDialog.isSaved()) {

               Properties props = FileUtility.loadProperties(fileName);
               DietsGUI.doStaticReIniitialization(props);
               dispose();

               javax.swing.SwingUtilities.invokeLater(new Runnable() {
                  public void run() {
                     try {
                        new DietsGUI();
                     } catch (Exception ex) {
                        logger.error("Exception starting the GUI", ex);
                     }
                  }
               });
            }

         } catch (Exception ex) {

            try {
               FileWriter fwriter = new FileWriter(new File( fileName));
               fwriter.write(rbuf);
               fwriter.close();

               Properties props = FileUtility.loadProperties( fileName);
               DietsGUI.doStaticReIniitialization(props);
               testExecutionPanel.enableAllButtons();

            } catch (Exception ex1) {
               showError("Could not restore to old state", "Catastrophic error");
               ex1.printStackTrace();
               // System.exit(0);
            }

         } finally {
             // nothing todo ?
         }
      }   
   }

   /**
    * zip the current traces into a directory for shipment to the ISSI remote
    * verifier.
    */
   public void zipFiles() throws Exception {
      // These are the files to include in the ZIP file
      String[] filenames = new String[] { 
            "testrun",
            testerConfigurationFile , 
            startupPropertiesFileName
      };
      Zipper.zipAll(filenames,"testrun.zip");
         
      // Visit http://antd.nist.gov/submit to verify.
      String msg = "Completed creating test run zip file.\n\nOutput file: testrun.zip.\n\n";
      JOptionPane.showMessageDialog(null, msg);
   }
   
   public static void saveFiles(boolean verbose) throws Exception {

      //M1001 file doesnot exist until test is run
      String currentTestCaseFile = "";
      try {
         String directoryName = ISSITesterConstants.DEFAULT_LOGS_DIR;
         logger.debug("saveFiles(): directoryName="+directoryName);         

         File logDir = new File(directoryName);
         currentTestCaseFile =  new File(logDir.getCanonicalPath()
            + "/" + ISSITesterConstants.CURRENT_TEST_CASE_XML).toURI().toURL().toString();
         logger.debug("currentTestCaseFileName " + currentTestCaseFile);
//showln("*** saveFiles: currentTestCaseFileName " + currentTestCaseFile);
         
         // FileNotFoundException if test is not run yet
         TestRunInfo testRun = new CurrentTestCaseParser().parse(currentTestCaseFile);
         boolean interactive = testRun.isInteractive();
         String testSuiteName = new File(testRun.getTestDirectory())
               .getParentFile().getName();
         String targetDirName = (interactive ? ISSITesterConstants.DEFAULT_TEST_RUN_DIRECTORY
               : ISSITesterConstants.DEFAULT_TRACES_DIR)
               + "/"
               + testSuiteName
               + "/"
               + testRun.getTopology().substring(0, testRun.getTopology()
                     .indexOf(".xml")) + ".logs";
//showln("*** DietsGUI saveFiles: refmessages dir= " + targetDirName);
//showln("*** DietsGUI saveFiles: testRun.isInteractive= " + interactive);

         logger.debug("Saving files to refmessages directory " + targetDirName);
         File targetDir = new File(targetDirName);
         targetDir.mkdirs();

         /* Copy *.ptt , *.xml, *.sip to the target location */
//showln("*** DietsGUI saveFiles: copy .ptt .xml .sip to refmsg dir...");
//showln("*** DietsGUI from logDir="+directoryName);

         for (File file : logDir.listFiles(new FilenameFilter() {

            public boolean accept(File file, String name) {
//showln("MMM accept: file="+file.getAbsolutePath()+"  name="+name);
               return name.endsWith("sip") || name.endsWith("ptt")
                     || name.endsWith("xml");
            }
         })) {

//showln("MMM targetName="+targetDirName + "/" + file.getName());
//showln("MMM copyFile="+file.getAbsolutePath());
            File targetFile = new File(targetDirName + "/" + file.getName());
            if (targetFile.exists())
               targetFile.delete();

            // NOTE: the SipStack owns the message files, cannot rename
            FileUtility.copyFile( file, targetFile);
            file.delete();
         }
         if( verbose) {
            JOptionPane.showMessageDialog( null,
               "Completed saving test traces to:\n\n"+targetDir.getAbsolutePath());
	 }

         // cleanup
         targetDir = null;
         logDir = null;
         
       } catch (FileNotFoundException ex) {

          String msg = "Cannot find file: " + currentTestCaseFile;            
          logger.error( msg, ex);
          JOptionPane.showMessageDialog( null,
               msg + "\n\nYou must run or re-run at least one test...\n\n",
               "Save Current Test Trace",
               JOptionPane.ERROR_MESSAGE);

      } catch (Exception ex) {
         
         logger.error("An unepxected exception occured" , ex);
         ex.printStackTrace();
         JOptionPane.showMessageDialog( null,
               "Unexpected exception: "+ex,
               "Unexpected Error",
               JOptionPane.ERROR_MESSAGE);
      }
      //showln("DietsGUI: saveFiles(): DONE...");
   }

   private void loadProperties() {

      JFileChooser fileChooser = new JFileChooser(System.getProperty("user.dir"));
      fileChooser.setDialogTitle("Load startup properties");
      fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
      FileFilter traceFilter = new FileFilter() {

         @Override
         public boolean accept(File pathname) {
            if (pathname.getName().endsWith(".properties")
                  || pathname.isDirectory())
               return true;
            else
               return false;
         }

         @Override
         public String getDescription() {
            return "Startup Properties";
         }

      };
      fileChooser.setFileFilter(traceFilter);

      int returnValue = fileChooser.showOpenDialog(this);
      String savedName = getStartupPropertiesFileName();
      try {

         if (returnValue == JFileChooser.APPROVE_OPTION) {

            String selFileName = fileChooser.getSelectedFile().getAbsolutePath();
            setStartupPropertiesFileName( selFileName);

            Properties props = FileUtility.loadProperties( selFileName);
            DietsGUI.doStaticReIniitialization(props);
            dispose();

            javax.swing.SwingUtilities.invokeLater(new Runnable() {
               public void run() {
                  try {
                     new DietsGUI();
                  } catch (Exception ex) {
                     logger.error("Exception starting the GUI", ex);
                  }
               }
            });
         }
      } catch (Exception ex) {
         showError("Error loading startup properties", "Reconfiguration Error");
         setStartupPropertiesFileName( savedName);
         testExecutionPanel.enableAllButtons();
      }
   }

   private void renderTraces(String directoryName, boolean toSave)
         throws Exception {
      
//showln("MMMMM-00000: directoryName="+directoryName);
      File directoryFile = new File(directoryName);
      globalTopologyFileName = directoryFile.getAbsolutePath() + "/globaltopology.xml";
      systemTopologyFileName = directoryFile.getAbsolutePath() + "/systemtopology.xml";
//showln("MMMMM-1111: global="+globalTopologyFileName);
//showln("MMMMM-1111: system="+systemTopologyFileName);

      if (!new File(globalTopologyFileName).exists()) {
         String msg = "Cannot find " + systemTopologyFileName;
         logger.error( msg);
         throw new FileNotFoundException(msg);
      }
      if (!new File(systemTopologyFileName).exists()) {
         String msg = "Cannot find" + systemTopologyFileName;
         logger.error( msg);
         throw new FileNotFoundException(msg);        
      }
      
      String testCaseXmlName = directoryFile.getAbsolutePath() + "/"
               + ISSITesterConstants.CURRENT_TEST_CASE_XML;      
      if (!new File( testCaseXmlName).exists()) {
         String msg = "Cannot find " + testCaseXmlName;
         logger.error( msg);
         throw new FileNotFoundException(msg); 
      }

      //+++++++++++++++++++++++++++++++++++++++
      updateGlobalTopologyPane();
      updateSystemTopologyPane();
      TestRunInfo testRunInfo = new CurrentTestCaseParser()
            .parse(new File (testCaseXmlName).toURI().toURL().toString());
      String currentTestDir = testRunInfo.getDirectory();
      String currentTopology = testRunInfo.getTopology();

      testExecutionPanel.incrementRunTestNumber();
      testExecutionPanel.setCurrentTest(currentTestDir, currentTopology);

      // Add XML begin and end tags to the selected file since these
      // are not generated by the ISSI emulator
      StringBuffer sbuf = new StringBuffer();
      String c = null;
      sbuf.append("<sipmessages>\n");

      for (File file : directoryFile.listFiles(new FilenameFilter() {
         public boolean accept(File dir, String name) {
//showln(" >>>>>>>>>>>>>>  name="+name);
            return name.endsWith("sip");
         }
      })) {
//showln(" >>>>>>>>>>>>>>  file="+file.getAbsolutePath());
         BufferedReader fileReader = new BufferedReader(new FileReader(file));
         while ((c = fileReader.readLine()) != null) {
            //sbuf.append(c + "\r\n");
            sbuf.append(c);
	    sbuf.append("\n");
	 }
         fileReader.close();
      }
      sbuf.append("</sipmessages>\n");

      String pttMsgFile = directoryName + "/messagelog.ptt";
//showln(" >>>>>>>>>> pttMsgFile: "+ pttMsgFile);

      File pttTrace = new File( pttMsgFile);
      boolean isInteractive = testRunInfo.isInteractive();
      if (pttTrace.exists()) {
         BufferedReader breader = new BufferedReader( new FileReader(pttTrace));
         StringBuffer tracebuf = new StringBuffer();
         tracebuf.append("<pttmessages>\n");
         String line = null;
         while ((line = breader.readLine()) != null) {
            //tracebuf.append(line + "\r\n");
            tracebuf.append(line);
	    tracebuf.append("\n");
	 }
         tracebuf.append("</pttmessages>\n");
	 breader.close();

         testExecutionPanel.renderSipPttTraces(sbuf.toString(),
               tracebuf.toString(), null, isInteractive,
               toSave);
      } else {
         testExecutionPanel.renderSipPttTraces(sbuf.toString(), null,
               null, isInteractive, toSave);
      }
      getCloseMenuItem().setEnabled(true);
      getCloseAllMenuItem().setEnabled(true);
   }

   /**
    * Open and render the current saved log information in the ref traces
    * directory.
    * 
    */

   public void renderRefTraceLogs() {
      //String testName = testExecutionPanel.getCurrentTest().getDirectoryName();
      
      //showln("renderRefTraceLogs(1): "+ testExecutionPanel.getCurrentTopologyName());
      String topology = testExecutionPanel.getCurrentTopologyName()
            .substring( 0,
                  testExecutionPanel.getCurrentTopologyName() .indexOf(".xml"));
      //showln("renderRefTraceLogs(2): topology="+ topology);

      String dir = ISSITesterConstants.DEFAULT_TRACES_DIR + "/" + testSuite
            + "/" + topology + ".logs";
      logger.debug("renderRefTraceLogs(3): " + dir);
      //showln("renderRefTraceLogs: dir = " + dir);
      
      if (!new File(dir).exists()) {
         logger.debug("renderRefTraceLogs(): no trace dir found " + dir);
         //showln("renderRefTraceLogs: no trace dir= " + dir);
         tabbedPane.removeAll();
         return;
      } 
      try {
         //showln("renderRefTracesLog(4): call renderTraces() dir= " + dir);
         //Could not find an RFSS (fromRfss) 01.002.00002.p25dr:25002
         renderTraces( dir, false);
         //showln("renderRefTracesLog(4): DONE renderTraces()");         
      } 
      catch (Exception ex) {
         ex.printStackTrace();
         logger.debug("Error rendering reference trace -- need to generate one.",ex);
      }
   }

   /**
    * Open a previously stored trace. The trace directory contains
    * <ul>
    * <li> the current test name in a file called current-test-case.xml
    * <li> the global topology used to run the test in a file called
    * globaltopology.xml
    * <li> the sip llogs.
    * <li> the ptt logs.
    * </ul>
    * 
    * @throws Exception --
    *             if problems were encountered in opening the log.
    */
   public void openFile() throws Exception {

      int rc = fileChooser.showOpenDialog(this);
      if (rc == JFileChooser.APPROVE_OPTION) {
         String dirName = fileChooser.getSelectedFile().getAbsolutePath();         
         renderTraces(dirName, false);
      }
   }

   public void showWarning(String text, String title) {
      JOptionPane.showMessageDialog(this, text, title,
            JOptionPane.WARNING_MESSAGE);
   }

   public void showError(String text, String title) {
      JOptionPane.showMessageDialog(this, text, title,
            JOptionPane.ERROR_MESSAGE);
   }

   //------------------------------------------------------------------------------
   public void mouseClicked(MouseEvent e) { }
   public void mousePressed(MouseEvent e) { }
   public void mouseReleased(MouseEvent e) { }

   public void mouseEntered(MouseEvent e) {
      JButton button = (JButton) e.getSource();
      button.setBorderPainted(true);
   }

   public void mouseExited(MouseEvent e) {
      JButton button = (JButton) e.getSource();
      button.setBorderPainted(false);
   }

   //----------------------------------------------------------------------------
   public String getSystemTopologyName() {
      return DietsGUI.systemTopologyFileName;
   }
   public String getGlobalTopologyName() {
      return globalTopologyFileName;
   }
   
   public boolean getEvaluatePassFail() {
      return evaluatePassFail;
   }

//   static void setIssiHttpServerConfig(
//         ISSITesterConfiguration issiHttpServerConfig) {
//      DietsGUI.issiTesterConfiguration = issiHttpServerConfig;
//   }

   public ISSITesterConfiguration getIssiTesterConfiguration() {
      return issiTesterConfiguration;
   }

   //----------------------------------------------------------------------------
   public static void updateGlobalTopologyValues() {
      globalTopologyFileName = ISSITesterConstants.getScenarioDir() + "/"
            + ISSITesterConstants.GLOBAL_TOPOLOGY_XML;
      systemTopologyFileName = ISSITesterConstants.TESTSUITES_DIR + "/"
            + testSuite + "/" + ISSITesterConstants.SYSTEM_TOPOLOGY_XML;
   }

   //----------------------------------------------------------------------------
   public static void doStaticReIniitialization(Properties props)
         throws Exception {

      testerConfigurationFile = props.getProperty(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
      if (testerConfigurationFile == null) {
         JOptionPane.showMessageDialog( null,
            "Missing Property! tester configuration file not specified",
            "ISSI Tester startup error", JOptionPane.ERROR_MESSAGE);
         throw new Exception("Missing a required Parameter "
            + DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
      }

      testSuite = props.getProperty(DietsConfigProperties.TESTSUITE_PROPERTY, "conformance");
      ISSITesterConstants.setTestSuite(testSuite);
      logger.info("doStaticInitialization: setTestSuite ="+testSuite);

      String param = props.getProperty(DietsConfigProperties.STANDALONE_PROPERTY);
      standalone = (param != null) ? "true".equals(param) : false;

      String notest = props.getProperty("diets.notest");
      evaluatePassFail = (notest != null) ?  "true".equals(notest) : true;
      //showln("doStaticInitialization: standalone="+standalone);
      
     /****
      Strint widthStr = props.getProperty(DietsConfigProperties.DIETSGUI_WIDTH);
      DietsGUI.PREFERRED_WIDTH = widthStr != null ? Integer.parseInt(widthStr)
            : DietsGUI.PREFERRED_WIDTH;

      String heightStr = props.getProperty(DietsConfigProperties.DIETSGUI_HEIGHT);
      DietsGUI.PREFERRED_HEIGHT = heightStr != null ? Integer.parseInt(heightStr)
            : DietsGUI.PREFERRED_HEIGHT;
       ***/

      testRegistry = ISSITesterConstants.getScenarioDir() + "/"
            + ISSITesterConstants.TEST_REGISTRY_XML;
      //showln("doStaticInitialization: testRegistry="+testRegistry);

      //DietsGUI.traceSource = props.getProperty("dietsgui.traceSource", "conformance-tester");
      setTraceSource( props.getProperty("dietsgui.traceSource", "conformance-tester"));
      updateGlobalTopologyValues();

      try {
         issiTesterConfiguration = new ISSITesterConfigurationParser(testerConfigurationFile).parse();
      }
      catch (Exception ex) {
         logger.error("Error parsing config file ", ex);
         JOptionPane.showMessageDialog(null,
            "Error parsing configuration file " + testerConfigurationFile,
            "ISSI Tester startup error",
            JOptionPane.ERROR_MESSAGE);
         throw ex;
      }

      TestRFSS.setTesterConfiguration(issiTesterConfiguration);
      globalTopologyFileName = ISSITesterConstants.getScenarioDir() + "/globaltopology.xml";
      logger.debug("global topology = " + globalTopologyFileName);

      DietsGUI.ipAddresses = issiTesterConfiguration.getLocalAddresses();
      if ((ipAddresses == null || ipAddresses.isEmpty()) && standalone) {
         JOptionPane.showMessageDialog( null,
            "No local ip addresses could be configured -- cannot run standalone !",
            "ISSI Tester startup error", JOptionPane.ERROR_MESSAGE);
         throw new Exception("Configuration Exception -- startup");
      }

      SystemTopologyParser systemTopologyParser = new SystemTopologyParser(issiTesterConfiguration);

      TopologyConfig systemTopology = null;
      try {
         systemTopology = systemTopologyParser.parse(systemTopologyFileName);
      } catch (Exception ex) {
         logger.error("Error occured while parsing system topology " + systemTopologyFileName);
         JOptionPane.showMessageDialog( null,
            "Error in system topology " + systemTopologyFileName
            + "\nException Message is : " + ex.getMessage()
            + "\nCheck Tester Configuration file " + testerConfigurationFile
            + "\nCheck System topology file and make sure node identifiers are mapped for the entire file",
            "ISSI Tester startup error",
            JOptionPane.ERROR_MESSAGE);
         throw ex;
      }

      //TopologyConfig globalTopology = null;
      try {
         //globalTopology = new GlobalTopologyParser(true)
         new GlobalTopologyParser(true).parse(systemTopology, globalTopologyFileName);
      } catch (Exception ex) {
         logger.error( "Error occured while parsing test suite global topology "
               + globalTopologyFileName, ex);
         JOptionPane.showMessageDialog( null,
            "Error occured while parsing test suite global topology "
               + globalTopologyFileName
               + "\nException type is : " + ex.getClass().getName()
               + "\nException message is :" + ex.getMessage()
               + "\nMake sure that the file exists, is valid syntax "
               + " RFSSs referenced in " + globalTopologyFileName
               + "\nare defined in " + systemTopologyFileName,
            "ISSI Tester startup error",
            JOptionPane.ERROR_MESSAGE);
         throw ex;
      }

      try {
         DietsGUI.tests = getAvailableTestCases();
         //showln("doStaticInitialization: getAvailableTestCases.size="+tests.size());

      } catch (Exception e) {
         logger.error("Unexpected error getting test cases", e);
         JOptionPane.showMessageDialog(null,
            "Error in getting test cases - check test suite",
            "ISSI Tester startup error",
            JOptionPane.ERROR_MESSAGE);
         throw e;
      }

      if (DietsGUI.issiTesterConfiguration.getEmulatorConfigurations().size() == 0
            && !DietsGUI.standalone) {
         JOptionPane.showMessageDialog( null,
            "Error in configuration file - no web servers were defined so must specify standalone",
            "ISSI Tester startup error",
            JOptionPane.ERROR_MESSAGE);
         throw new Exception( "Error in configuration file - should specify standalone flag");
      }
   }

   // implementation of TestStatusInterface
   //------------------------------------------------------------------
   public void saveTestFiles(boolean verbose) throws Exception {
      saveFiles(verbose);
   }

   public void logError(String failureMessage, String errorTrace) {
      getTestExecutionPanel().logError(failureMessage, errorTrace);
   }
   public void logError(String failureMessage) {
      getTestExecutionPanel().logError(failureMessage);
   }
   public void logStatusMessage(String statusMessage) {
      getTestExecutionPanel().logStatusMessage( statusMessage);
   }
   public void logFatal(String failureMessage, String stackTrace) {
      getTestExecutionPanel().logFatal(failureMessage, stackTrace);
   }

   public void setStatusLabelText( String msg) {
      getStatusLabel().setText(msg);
   }

   public String getProgressScreenMessage() {
      return getTestExecutionPanel().getProgressScreenMessage();
   }
   public void setProgressScreenMessage(String progressMessage) {
      getTestExecutionPanel().setProgressScreenMessage(progressMessage);
   }

   public void setStatusProgressBarIndeterminate( boolean state) {
      getStatusProgressBar().setIndeterminate(state);
   }

   //=========================================================================
   public static void main(String[] args) throws Exception {

      Properties props = new Properties();
      String fileName = null;

      for (int i = 0; i < args.length; i++) {

         if (args[i].equals("-startup")) {
            fileName = args[++i];
            DietsGUI.setStartupPropertiesFileName( fileName);
            InputStream inStream = new FileInputStream(new File(fileName));
            props.load(inStream);
            inStream.close();
            
         } else {
            JOptionPane.showMessageDialog(null,
               "invalid argument " + args[i],
               "ISSI Tester startup error",
               JOptionPane.ERROR_MESSAGE);
            return;
         }
      }

      if (DietsGUI.getStartupPropertiesFileName() == null) {
         JOptionPane.showMessageDialog(null,
            "missing startup parameter ",
            "ISSI Tester startup error",
            JOptionPane.ERROR_MESSAGE);
         return;
      }

      DietsGUI.doStaticReIniitialization(props);
      if (!standalone) {
         Logger logger = Logger.getLogger("gov.nist.p25.issi.testlauncher");
         logger.addAppender(new FileAppender(new SimpleLayout(),
            "logs/guidebuglog.txt"));
      }

      // Schedule a job for the event-dispatching thread
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            try {
               DietsGUI gui = new DietsGUI();
               gui.addWindowListener(new WindowAdapter() {
                  public void windowClosing(WindowEvent e) {
                     System.exit(0);
                  }
               });
            } catch (Exception ex) {
               logger.error("Exception starting the GUI", ex);
            }
         }
      });
   }
}
