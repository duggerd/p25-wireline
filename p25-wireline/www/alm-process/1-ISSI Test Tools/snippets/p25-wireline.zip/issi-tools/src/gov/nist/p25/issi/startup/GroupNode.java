package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;
import java.util.HashSet;

import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import att.grappa.Edge;
import att.grappa.Graph;


/**
 * Group node representation in the editor graph.
 * 
 * @author mranga
 * 
 */
public class GroupNode extends GraphNode {
	private GroupConfig groupConfig;
	private HashSet<Edge> edges = new HashSet<Edge>();

	public GroupNode(ClusterConfigurationEditor clusterManager,
			GroupConfig groupConfig, Graph graph) {
		super(clusterManager, graph);
		this.groupConfig = groupConfig;
		super.setYPosition(GROUPNODE_YPOSITION);
		super.setName(groupConfig.getGroupName());
	}

	class UpdateActionListener extends CreateActionListener {

		private ConfigTableModel tableModel;
		
		public UpdateActionListener(ConfigTableModel tableModel) {
			this.tableModel = tableModel;
		}

		@Override
		public void actionPerformed(ActionEvent ae) {
			if ( jtable.isEditing()) {
        		jtable.editCellAt(0,0); // Move the focus out so the value takes.
        	}
        	tableModel.fireTableDataChanged();
        	jtable.requestFocus();        	      	
			int sgId = tableModel.getDataAsHexInt("groupId");
			groupConfig.setGroupId(sgId);			
		}
	}

	@Override
	public void cleanupAction() {
		for (Edge edge : this.edges) {
			graph.removeEdge(edge.getName());
		}
		clusterEditor.redraw();
		graph.repaint();
	}

	@Override
	public void showAttributes() {

		clusterEditor.clear();
		clusterEditor.drawRfssNodes();
		clusterEditor.drawGroupNodes();

		RfssConfig homeRfssConfig = groupConfig.getHomeRfss();
		RfssNode homeRfssNode = clusterEditor.rfssToNodeMap.get(homeRfssConfig);
		Edge edge = new Edge(graph, this, homeRfssNode);
		this.edges.add(edge);
		graph.repaint();

		ConfigTableModel tableModel = new ConfigTableModel("SgConfig");
		tableModel.setUnEditable("groupName");
		tableModel.setUnEditable("homeRfssName");

		tableModel.setData("groupName", groupConfig.getGroupName());
		tableModel.setData("homeRfssName", groupConfig.getHomeRfss()
				.getRfssName());
		tableModel.setData("groupId", Integer.toHexString(groupConfig
				.getGroupId()));

		super.showTable(this.clusterEditor, tableModel,
				new UpdateActionListener(tableModel), this);
	}
}
