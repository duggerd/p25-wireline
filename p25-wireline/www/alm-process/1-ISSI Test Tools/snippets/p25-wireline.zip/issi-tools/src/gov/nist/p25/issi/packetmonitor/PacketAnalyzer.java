//
package gov.nist.p25.issi.packetmonitor;

import gov.nist.p25.issi.constants.ISSIDtdConstants;
import gov.nist.p25.issi.p25payload.ISSIPacketType;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Vector;

import javax.sip.header.FromHeader;
import javax.sip.address.SipURI;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

/**
 * This class implements an packet analyzer.
 * 
 * @author niepin@nist.gov
 */
public class PacketAnalyzer {

   public static Logger logger = Logger.getLogger(PacketMonitor.class
         .getPackage().getName());
   static {
      try {
         logger.addAppender(new FileAppender(new SimpleLayout(),
               "logs/packetdebug.txt"));
         logger.setLevel(Level.DEBUG);
      } catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }

   //private String resultTableString = "<?xml version=\"1.0\"?>\n"
   //  + "<!DOCTYPE performance-parameter SYSTEM \"http://www-x.antd.nist.gov:8080/p25/issi-emulator/dtd/parameter.dtd\">\n";
   private String resultTableString = "<?xml version=\"1.0\"?>\n"
      + "<!DOCTYPE performance-parameter SYSTEM \"" 
      + ISSIDtdConstants.URL_ISSI_DTD_PARAMETER + "\">\n";

   private Vector<Long> transactionTimeRecords = null;
   private Vector<Long> dialogTimeRecords = null;
   private Vector<Long> msgRelay = null;
   private Vector<Long> pttSessionTimeRecords = null;
   private final PacketMonitor packetMonitor;

   public PacketAnalyzer(PacketMonitor packetMonitor) {
      logger.debug("PacketAnalyzer initializing...");
      this.packetMonitor = packetMonitor;
      this.transactionTimeRecords = new Vector<Long>();
      this.msgRelay = new Vector<Long>();
      this.dialogTimeRecords = new Vector<Long>();
      this.pttSessionTimeRecords = new Vector<Long>();
   }

   private void measure() {
      long time = 0;
      // record the timestamp of all INVITEs, OKs and ACKs
      // long [][] temp = new
      // long[2][packetMonitor.inviteTransactions.size()];
      long[][] temp = new long[3][packetMonitor.inviteTransactions.size()];
      int count = 0;
      String userTag = "";

      logger.debug("###########inviteTransactions list: "
            + packetMonitor.inviteTransactions.size() + "###############");
      for (LinkedList<CapturedSipMessage> sipMessages : packetMonitor.inviteTransactions
            .values()) {
         // test the call type, group call or su-to-su
         userTag += ((SipURI) ((FromHeader) sipMessages.get(0).message
               .getHeader("From")).getAddress().getURI())
               .getParameter("user");
         resultTableString += "<call type=\"" + userTag
               + "\" />\n<parameter-list>\n";
         break;
      }

      // calculate the time difference of all INVITE transactions
      for (LinkedList<CapturedSipMessage> sipMessages : packetMonitor.inviteTransactions
            .values()) {
         if (sipMessages.size() < 2) {
            logger.error("INVITE transaction is incomplete, drop!!");
            continue;
         }
         for (CapturedSipMessage sipMsg : sipMessages) {
            logger.debug("####SIP msg: \n" + sipMsg.toString());
         }

         time = sipMessages.get(1).timeStamp
               - sipMessages.getFirst().timeStamp;
         temp[0][count] = sipMessages.getFirst().timeStamp;
         temp[1][count++] = sipMessages.get(1).timeStamp;
         transactionTimeRecords.add(time);
         logger.debug("----------Time of the transaction: " + time);
      }

      // calculate the time different between neighbor INVITEs and OKs
      for (int j = 0; j < 2; j++) {
         for (int i = 0; i < (packetMonitor.inviteTransactions.size() - 1); i++) {
            msgRelay.add(new Long(Math.abs(temp[j][i] - temp[j][i + 1])));
         }
      }
      count = 0;

      // calculate the time difference of all ACK dialogs for SU-to-SU call
      if (userTag.equals("TIA-P25-SU")) {
         logger.debug("###########ackDialog list: "
               + packetMonitor.ackDialog.size() + "############");
         for (LinkedList<CapturedSipMessage> sipMessages : packetMonitor.ackDialog
               .values()) {
            if (sipMessages.size() < 2) {
               logger.error("ACK dialog is incomplete, drop!!");
               continue;
            }
            for (CapturedSipMessage sipMsg : sipMessages) {
               logger.debug("####SIP msg: \n" + sipMsg.toString());
            }

            time = sipMessages.get(1).timeStamp
                  - sipMessages.getFirst().timeStamp;
            // temp[0][count] = sipMessages.getFirst().timeStamp;
            temp[2][count++] = sipMessages.get(1).timeStamp;
            dialogTimeRecords.add(time);
            logger.debug("----------Time of the dialog: " + time);
         }
         // calculate the time different between neighbor ACKs
         for (int i = 0; i < (packetMonitor.ackDialog.size() - 1); i++) {
            msgRelay.add(new Long(Math.abs(temp[2][i] - temp[2][i + 1])));
         }
      }

      // calculate the time difference of PTT-specific parameters for group
      // call
      if (userTag.equals("TIA-P25-SG")) {
         logger.debug("###########pttSession list: "
               + packetMonitor.pttSessions.size() + "############");
         long value = 0;
         if (packetMonitor.pttSessions.size() < 3) {
            logger.error("PTT session is incomplete, drop!!");
         } else {
            // Tg5
            try {
            value = temp[1][0]
                  - packetMonitor.pttSessions
                        .get(ISSIPacketType.PTT_TRANSMIT_REQUEST).timeStamp;
            } catch ( Exception ex) {
               value = 0;
            }
            pttSessionTimeRecords.add(Math.abs(value));
            
            // Tg6
            try {
               value = packetMonitor.pttSessions
                     .get(ISSIPacketType.PTT_TRANSMIT_REQUEST).timeStamp
                     - packetMonitor.pttSessions
                           .get(ISSIPacketType.PTT_TRANSMIT_GRANT).timeStamp;
            } catch (Exception ex) {
               value = 0;
            }
            pttSessionTimeRecords.add(Math.abs(value));
            // Tg7
            try {
               value = packetMonitor.pttSessions
                     .get(ISSIPacketType.PTT_TRANSMIT_REQUEST).timeStamp
                     - packetMonitor.pttSessions
                           .get(ISSIPacketType.PTT_TRANSMIT_START).timeStamp;
            } catch (Exception ex) {
               value = 0;
            }
            pttSessionTimeRecords.add(Math.abs(value));
            // Tg8
            try {
            value = temp[1][1]
                  - packetMonitor.pttSessions
                        .get(ISSIPacketType.PTT_TRANSMIT_START).timeStamp;
            } catch ( Exception ex) {
               value = 0;
            }
            pttSessionTimeRecords.add(Math.abs(value));
            // Tgrant_CallingISSI
            try {
            value = temp[0][0]
                  - packetMonitor.pttSessions
                        .get(ISSIPacketType.PTT_TRANSMIT_GRANT).timeStamp;
            } catch ( Exception ex) {
               value = 0;
            }
            pttSessionTimeRecords.add(Math.abs(value));
            // Tgrant_CalledISSI
            try {
            value = temp[0][0]
                  - packetMonitor.pttSessions
                        .get(ISSIPacketType.PTT_TRANSMIT_START).timeStamp;
            } catch ( Exception ex) {
               value = 0;
            }
            pttSessionTimeRecords.add(Math.abs(value));
         }
      }

      // construct XML format result respectively according to the call type
      if (userTag.equals("TIA-P25-SG")) {
         resultTableString += "<param name=\"Tg2\" value=\""
               +( msgRelay.size() > 0 ? msgRelay.firstElement() : 0 )+ "\" />\n";
         resultTableString += "<param name=\"Tg3\" value=\""
               + (transactionTimeRecords.size() > 0 ? transactionTimeRecords.firstElement():0) + "\" />\n";
         resultTableString += "<param name=\"Tg4\" value=\""
               + (transactionTimeRecords.size() > 0 ? transactionTimeRecords.lastElement() : 0 )+ "\" />\n";
         if (pttSessionTimeRecords.size() != 0) {
            resultTableString += "<param name=\"Tg5\" value=\""
                  + pttSessionTimeRecords.get(0) + "\" />\n";
            resultTableString += "<param name=\"Tg6\" value=\""
                  + pttSessionTimeRecords.get(1) + "\" />\n";
            resultTableString += "<param name=\"Tg7\" value=\""
                  + pttSessionTimeRecords.get(2) + "\" />\n";
            resultTableString += "<param name=\"Tg8\" value=\""
                  + pttSessionTimeRecords.get(3) + "\" />\n";
            resultTableString += "<param name=\"Tgrant_CallingISSI\" value=\""
               + pttSessionTimeRecords.get(4) + "\" />\n";
            resultTableString += "<param name=\"Tgrant_CalledISSI\" value=\""
               + pttSessionTimeRecords.get(5) + "\" />\n";
         } else {
            resultTableString += "<param name=\"Tg5\" value=\"" + 0
                  + "\" />\n";
            resultTableString += "<param name=\"Tg6\" value=\"" + 0
                  + "\" />\n";
            resultTableString += "<param name=\"Tg7\" value=\"" + 0
                  + "\" />\n";
            resultTableString += "<param name=\"Tg8\" value=\"" + 0
                  + "\" />\n";
            resultTableString += "<param name=\"Tgrant_CallingISSI\" value=\"" + 0
            + "\" />\n";
            resultTableString += "<param name=\"Tgrant_CalledISSI\" value=\"" + 0
            + "\" />\n";
         }
      } else if (userTag.equals("TIA-P25-SU")) {
         long value = Math.abs(temp[0][0] - temp[2][0]);
         resultTableString += "<param name=\"Tu2\" value=\""
               + msgRelay.firstElement() + "\" />\n";
         resultTableString += "<param name=\"Tu3\" value=\""
               + msgRelay.get(1) + "\" />\n";
         resultTableString += "<param name=\"Tu6\" value=\""
               + transactionTimeRecords.lastElement() + "\" />\n";
         resultTableString += "<param name=\"Tu7\" value=\""
               + msgRelay.get(2) + "\" />\n";
         resultTableString += "<param name=\"Tu8\" value=\""
               + msgRelay.get(3) + "\" />\n";
         resultTableString += "<param name=\"Tu10\" value=\""
               + dialogTimeRecords.lastElement() + "\" />\n";
         resultTableString += "<param name=\"Tu11\" value=\""
               + msgRelay.get(4) + "\" />\n";
         resultTableString += "<param name=\"Tu12\" value=\""
               + msgRelay.lastElement() + "\" />\n";
         resultTableString += "<param name=\"Tugrant_CallingISSI\" value=\""
               + transactionTimeRecords.firstElement() + "\" />\n";
         resultTableString += "<param name=\"Tugrant_CalledISSI\" value=\""
               + value + "\" />\n";
      }

      resultTableString += "</parameter-list>\n";
   }

   public String getResultString() {
      measure();
      return resultTableString;
   }

   public void clear() {
      resultTableString = "<?xml version=\"1.0\"?>\n"
         + "<!DOCTYPE performance-parameter SYSTEM \"http://www-x.antd.nist.gov:8080/p25/issi-emulator/dtd/parameter.dtd\">\n";
      transactionTimeRecords.clear();
      dialogTimeRecords.clear();
      pttSessionTimeRecords.clear();
   }

}
