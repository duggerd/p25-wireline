/* This software was developed by employees of the National Institute of
 * Standards and Technology (NIST), an agency of the Federal Government.
 * Pursuant to title 15 United States Code Section 105, works of NIST
 * employees are not subject to copyright protection in the United States
 * and are considered to be in the public domain.  As a result, a formal
 * license is not needed to use the software.
 * 
 * The ISSI Emulator is provided by NIST as a service and is expressly
 * provided "AS IS".  NIST MAKES NO WARRANTY OF ANY KIND, EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTY OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT
 * AND DATA ACCURACY.  NIST does not warrant or make any representations
 * regarding the use of the software or the results thereof including, but
 * not limited to, the correctness, accuracy, reliability or usefulness of
 * the software.
 * 
 * Permission to use this software is contingent upon your acceptance
 * of the terms of this agreement.
 */
package gov.nist.p25.issi.transctlmgr.ptt;

import gov.nist.p25.issi.p25payload.P25Payload;
import java.util.*;

/**
 * This abstract class defines a PTT event.
 * 
 * @author steveq@nist.gov
 * @version $Revision: 1.15 $, $Date: 2007/03/29 23:11:44 $
 * @since 1.5
 */
public abstract class PttEvent extends EventObject {

	
	/***************************************************************************
	 * Variables
	 **************************************************************************/
	
	/** The PTT payload associated with this event. */
	protected P25Payload p25Payload = null;

	/** The timestamp for this event. */
	private long receptionTime;

	
	/***************************************************************************
	 * Constructors
	 **************************************************************************/

	/**
	 * Construct a PTT event.
	 * @param pttSession The PTT session associated with this event.
	 * @param p25Payload The PTT payload associated with this event.
	 */
	public PttEvent(PttSession pttSession, P25Payload p25Payload) {

		super(pttSession);
		this.p25Payload = p25Payload;
		receptionTime = System.currentTimeMillis();

	}

	
	/***************************************************************************
	 * Methods
	 **************************************************************************/

	/**
	 * Get the PTT packet associated with this event.
	 */
	public P25Payload getPttPacket() {

		return p25Payload;

	}

	
	/**
	 * Get a string representation of this event.
	 * @return The string representation of this event.
	 */
	public String toString() {
		PttSession session = (PttSession) this.getSource();

		StringBuffer sbuf = new StringBuffer();
		sbuf.append("\n<!-- PTT PACKET BEGIN -->");
		sbuf.append("\n<ptt-packet ");
		sbuf.append("\n receptionTime=\"" + receptionTime + "\"\n");
		sbuf.append(">\n");

		sbuf.append(session.toString());
		sbuf.append("\n");
		sbuf.append(p25Payload.toString());
		sbuf.append("\n</ptt-packet>");
		return sbuf.toString();

	}

}
