//
package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

/**
 * Create a new daemon node in response to a create new action.
 * 
 * @author M. Ranganathan < mranga@nist.gov >
 * 
 */
class CreateNewDaemonNodeActionListener extends CreateActionListener {
   private static final long serialVersionUID = -1L;
	
	private static Logger logger = Logger.getLogger(CreateNewDaemonNodeActionListener.class);

	/*
	 * The table model for this daemon node creator.
	 */
	private ConfigTableModel tableModel;

	/*
	 * The cluster configuration editor.
	 */
	private ClusterConfigurationEditor clusterEditor;

	public CreateNewDaemonNodeActionListener(
			ClusterConfigurationEditor clusterEditor,
			ConfigTableModel tableModel) {
		this.tableModel = tableModel;
		this.clusterEditor = clusterEditor;
	}

	@Override
	public void actionPerformed(ActionEvent ev) {
		try {
			String name = (String) tableModel.getData("daemonName");
			ISSITesterConfiguration testerConfig = clusterEditor
					.getTesterConfig();
			if (testerConfig.getDaemonByName(name) != null) {
				JOptionPane.showMessageDialog(clusterEditor.getJFrame(),
						"Creation Error : Name already exists", "Create Error",
						JOptionPane.ERROR_MESSAGE);
				super.dialog.dispose();
				return;
			}
			String ipAddress = (String) tableModel.getData("ipAddress");

			if (ipAddress == null || ipAddress.equals("")) {
				JOptionPane.showMessageDialog(clusterEditor.getJFrame(),
						"Creation Error : Must Enter Valid IP address",
						"Create Error", JOptionPane.ERROR_MESSAGE);
				super.dialog.dispose();
				return;
			}
			int httpPort = Integer.parseInt((String) tableModel
					.getData("httpPort"));

			boolean isTesterService = Boolean.parseBoolean((String) tableModel
					.getData("isTesterService"));
			boolean isPacketMonitorService = Boolean
					.parseBoolean((String) tableModel
							.getData("isPacketMonitorService"));

			DaemonWebServerAddress daemonWebServerAddress = new DaemonWebServerAddress(
					name, ipAddress, httpPort, isTesterService,
					isPacketMonitorService);
			testerConfig.addDaemonWebServerAddress(daemonWebServerAddress);
			super.dialog.dispose();
			this.clusterEditor.redraw();
			
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(clusterEditor.getJFrame(),
					"Creation Error : Invalid data entered", "Create Error",
					JOptionPane.ERROR_MESSAGE);
			logger.error("Creation Error : Invalid data entered",ex);
			return;
		}
	}
}
