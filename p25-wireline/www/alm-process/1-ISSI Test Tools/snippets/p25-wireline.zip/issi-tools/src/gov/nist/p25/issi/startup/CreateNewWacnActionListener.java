//
package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.issiconfig.WacnConfig;

import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import org.apache.log4j.Logger;


public class CreateNewWacnActionListener extends CreateActionListener {
	private static Logger logger = Logger.getLogger(CreateNewWacnActionListener.class);

	private ConfigTableModel tableModel;
	private ClusterConfigurationEditor clusterEditor;

	public CreateNewWacnActionListener(
			ClusterConfigurationEditor clusterEditor,
			ConfigTableModel tableModel) {
		this.tableModel = tableModel;
		this.clusterEditor = clusterEditor;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		try {		
			int wacnId = tableModel.getDataAsHexInt("wacnId");
			String wacnName = tableModel.getDataAsString("wacnName");
			if (wacnName == null || wacnName.equals("")) {
				JOptionPane.showMessageDialog(this.clusterEditor.getJFrame(),
						"Wacn name not specified", 
						"Wacn creation error",
						JOptionPane.ERROR_MESSAGE);
				dialog.dispose();
				return;
			}
			
			if (this.clusterEditor.getTopologyConfig().getWacnConfig(wacnName) != null) {
				JOptionPane.showMessageDialog(this.clusterEditor.getJFrame(),
						"Wacn already exists", 
						"Wacn creation error",
						JOptionPane.ERROR_MESSAGE);
				dialog.dispose();
				return;
			}
			WacnConfig wacnConfig = new WacnConfig(wacnName, wacnId);
			TopologyConfig topologyConfig = clusterEditor.getTopologyConfig();
			topologyConfig.addWacnConfig(wacnConfig);
			dialog.dispose();
			this.clusterEditor.getJFrame().repaint();
			
		} catch (Exception ex) {
			logger.error("Wacn creation error: ", ex);
			JOptionPane.showMessageDialog(this.clusterEditor.getJFrame(), 
			      ex.getClass().getName(), 
			      "Wacn creation error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

	}

}
