//
package gov.nist.p25.issi.p25body;

import gov.nist.p25.issi.p25body.serviceprofile.user.UserServiceProfile;

import java.text.ParseException;
import javax.sip.header.ContentTypeHeader;

/**
 * @author M. Ranganathan
 * 
 */
public class UserServiceProfileContent extends Content {
   private UserServiceProfile userServiceProfile;

   UserServiceProfileContent(ContentTypeHeader contentType,
         String userServiceProfileContent) throws ParseException {
      super(contentType, userServiceProfileContent);
      this.userServiceProfile = UserServiceProfile
            .createUserServiceProfile(userServiceProfileContent);
      super.setContent(userServiceProfileContent);
   }

   /**
    * @return Returns the userServiceProfile.
    */
   public UserServiceProfile getUserServiceProfile() {
      return userServiceProfile;
   }

   /**
    * create an instance of this object.
    */
   public UserServiceProfileContent createUserServiceProfileContent(
         String uspcontent) throws ParseException {
      return new UserServiceProfileContent(p25ContentTypeHeader, uspcontent);
   }

   @Override
   public String toString() {

      if (super.boundary == null)
         return this.userServiceProfile.toString();
      else {
         return new StringBuffer().append(
               super.boundary + "\r\n" + getContentTypeHeader() + "\r\n"
                     + this.userServiceProfile.toString()).toString();
      }
   }

   @Override
   public String toRtfString() {
      
      if (super.boundary == null)
         return this.userServiceProfile.toRtfString();
      else {
         return new StringBuffer().append(
               HEADER_START +
               super.boundary + 
               HEADER_END + 
               "\r\n" + 
               HEADER_START+ getContentTypeHeader() + HEADER_END + LINE_FEED + 
               "\r\n"
                     + this.userServiceProfile.toRtfString()).toString();
      }
   }
   
   @Override
   public boolean match(Content other) {
      if ( !(other instanceof UserServiceProfileContent)) return false;
      UserServiceProfileContent that = (UserServiceProfileContent) other;
      return this.userServiceProfile.match(that.userServiceProfile);
      
   }

   @Override
   public boolean isDefault() {
      return false;
   }
}
