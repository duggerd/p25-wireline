//
package gov.nist.p25.issi.p25body;

import gov.nist.p25.issi.p25body.params.RegisterParam;

import java.text.ParseException;
import javax.sip.header.ContentTypeHeader;

//import org.apache.log4j.Logger;

/**
 * Register Param Content.
 * 
 * @author M. Ranganathan
 * 
 */
public class RegisterParamContent extends Content {
   
   //private static Logger logger = Logger.getLogger(RegisterParamContent.class);
   
   private RegisterParam registerParam;

   RegisterParamContent(ContentTypeHeader contentType,
         String registerParamContent) throws ParseException {
      super(contentType, registerParamContent);
      this.registerParam = RegisterParam
            .createRegisterParam(registerParamContent);      
   }
   
   private RegisterParamContent(ContentTypeHeader contentTypeHeader,
         RegisterParam registerParam) {
      super(contentTypeHeader,registerParam.toString());
      this.registerParam = registerParam;
   }

   public static RegisterParamContent createRegisterParamContent(
         String registerParamContent) throws ParseException {
      return new RegisterParamContent(p25ContentTypeHeader,
            registerParamContent);
   }
   
   /**
    * @return Returns the registerParam.
    */
   public RegisterParam getRegisterParam() {
      return registerParam;
   }

   @Override
   public String toString() {

      if (super.boundary == null)
         return this.registerParam.toString();
      else {
         return new StringBuffer().append(
               super.boundary + "\r\n" + getContentTypeHeader() + "\r\n"
                     + this.registerParam.toString()).toString();
      }
   }

   @Override
   public String toRtfString() {
      if (super.boundary == null)
         return this.registerParam.toRtfString();
      else {
         return new StringBuffer().append(
               HEADER_START +
               super.boundary + 
               HEADER_END  + HEADER_START + getContentTypeHeader() + 
               HEADER_END + LINE_FEED + "\r\n"
               + this.registerParam.toRtfString()).toString();
      }
   }

   @Override
   public boolean match(Content template) {
         
      if ( !(template instanceof RegisterParamContent)) return false ;
      else  
         return  this.registerParam.equals(((RegisterParamContent)template).getRegisterParam());      
   }

   @Override
   public boolean isDefault() {
      return this.registerParam.isDefault();
   }

   public static Content createRegisterParamContent() {      
      return new RegisterParamContent(p25ContentTypeHeader,new RegisterParam());
   }
}
