//
package gov.nist.p25.issi.packetmonitor;

import org.apache.log4j.Logger;

import gov.nist.p25.issi.p25payload.P25Payload;
import gov.nist.rtp.RtpPacket;

/**
 * Represents a captured PTT message.
 * 
 * @author mranga
 * 
 */
public class CapturedPttMessage {

   private static Logger logger = Logger.getLogger(CapturedPacket.class);

   MediaSession mediaSession;
   long timeStamp;
   byte[] message;
   P25Payload p25Payload;
   RtpPacket rtpPacket;

   CapturedPttMessage( byte[] message, long time,
         MediaSession mediaSession) throws Exception {
         
      try {
         
         this.message = message;
         this.timeStamp = time;
         this.mediaSession = mediaSession;
         this.rtpPacket = new RtpPacket(message, message.length);
         // rtpPacket.set(message, message.length);
         byte[] payload = rtpPacket.getPayload();
         p25Payload = new P25Payload(payload);
      } catch (Exception ex) {
         PacketMonitor.getCurrentInstance().errorFlag = true;
         PacketMonitor.logger.error(
               "PacketMonitor : Could not extract packet ", ex);
         throw ex;
      }
   }

   public byte[] getMessage() {
      return this.message;
   }

   /**
    * Compare a captured packet against a template packet. This is for
    * confromance testing.
    * 
    * @param template
    * @return
    */
   public boolean match(CapturedPttMessage template) {
      assert template != this;
      RtpPacket rtpPacket = template.rtpPacket;
      if (!(rtpPacket.getV() == this.rtpPacket.getV()
            && rtpPacket.getP() == this.rtpPacket.getP()
            && rtpPacket.getX() == this.rtpPacket.getX()
            && rtpPacket.getCC() == this.rtpPacket.getCC()
            && rtpPacket.getM() == this.rtpPacket.getM()
            && rtpPacket.getPT() == this.rtpPacket.getPT() && rtpPacket
            .getSSRC() == this.rtpPacket.getSSRC())) {
         return false;
      }
      P25Payload templatePayload = template.p25Payload;
      boolean retval = false;
      try {
         if (!p25Payload.getISSIPacketType().equals(
               templatePayload.getISSIPacketType()))
            return retval = false;
         if (p25Payload.getISSIHeaderWord() == null
               ^ templatePayload.getISSIHeaderWord() == null)
            return retval = false;
         if (templatePayload.getISSIHeaderWord() != null
               && !templatePayload.getISSIHeaderWord().equals(
                     p25Payload.getISSIHeaderWord()))
            return retval = false;
         if (!p25Payload.getControlOctet().match(
               templatePayload.getControlOctet()))
            return retval = false;
         if (p25Payload.getPTTControlWord() == null
               ^ template.p25Payload.getPTTControlWord() == null)
            return retval = false;
         if (p25Payload.getPTTControlWord() != null
               && !p25Payload.getPTTControlWord().equals(
                     template.p25Payload.getPTTControlWord()))
            return retval = false;
         return retval = true;
      } finally {
         if ( retval ) {
            logger.debug("Match found for " + p25Payload.getISSIPacketType());
            logger.debug("templatePayload = "
               + templatePayload.getISSIPacketType());
         }
      }
   }

   @Override
   public String toString() {
      try {

         StringBuffer sbuf = new StringBuffer();      
         sbuf.append("\n<!-- PTT PACKET BEGIN -->");
         sbuf.append("\n<ptt-packet");
         sbuf.append("\n packetNumber=\"" + mediaSession.packetMonitor.packetNumber++
                     + "\"\n");
         sbuf.append(" receptionTime=\"" + timeStamp + "\"\n");
         sbuf.append(" receivingRfssId=\"" + mediaSession.remoteRfss.getDomainName()
                     + "\"\n");
         sbuf.append(" sendingRfssId=\"" + mediaSession.owningRfss.getDomainName()
                     + "\"\n");
         sbuf.append(" isSender=\"false\"\n>\n");
         sbuf.append( mediaSession.toString());
         sbuf.append( rtpPacket.toString());
         sbuf.append( p25Payload.toString());
         sbuf.append("\n</ptt-packet>");
         return sbuf.toString();
         
      } catch (Exception ex) {
         PacketMonitor.logger.error("Cannot unpack RTP Packet", ex);
         return "";
      }
   }
}
