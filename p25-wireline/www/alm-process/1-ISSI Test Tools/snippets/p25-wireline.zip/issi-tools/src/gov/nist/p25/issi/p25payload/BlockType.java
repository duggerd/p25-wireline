//
package gov.nist.p25.issi.p25payload;

import java.util.Hashtable;

/**
 * A static class for the payload. Use this in getters and setters of
 * blockheader to make the code more readable and to avoid errors and range
 * checking at run time. Making this into an enum is painful because we need to
 * enumerate the 63 manufacturer specific types.
 * 
 * @author mranga@nist.gov
 * @version $Revision: 1.8 $, $Date: 2007/07/24 03:20:38 $
 * @since 1.5
 */

// TODO (steveq) It is not clear that this class is necessary. This 
// information should be moved back into its original class, BlockHeader,
// in v2.
public class BlockType {

   /***************************************************************************
    * Constants
    **************************************************************************/

   /** Constant that identifies an IMBE Voice block type (7 bits). */
   private static final int IMBE_VOICE_INDEX = 0;

   /** Constant that identifies a PacketType block type (7 bits). */
   private static final int PT_INDEX = 1;

   /** Reserved block type (7 bits). */
   private static final int RSVD1_MIN_INDEX = 2; // 2..4

   private static final int RSVD1_MAX_INDEX = 4;

   /** Constant that identifies an ISSI Header Info block type (7 bits). */
   private static final int ISSIHDR_INDEX = 5;

   /** Another reserved block (7 bits). */
   private static final int RSVD2_MIN_INDEX = 6; // 6..10

   private static final int RSVD2_MAX_INDEX = 10;

   /** Constant that identifies a PTTControlWord block type (7 bits). */
   private static final int PTTCTL_INDEX = 11;

   /** Reserved for Fixed Station Interface (7 bits). */
   private static final int FXDSTA_MIN_INDEX = 12; // 12..14

   private static final int FXDSTA_MAX_INDEX = 14;

   /** Reserved for Future Expansion (7 bits). */
   private static final int FUTEXP_MIN_INDEX = 15; // 15..62;

   private static final int FUTEXP_MAX_INDEX = 62;

   /** Reserved for manufacturer specific (7 bits). */
   public static final int MFGSPEC_MIN_INDEX = 63; // 63..127

   private static final int MFGSPEC_MAX_INDEX = 127;

   /** IMBE voice block type. */
   public static final BlockType IMBE_VOICE;

   /** Packet type. */
   public static final BlockType PACKET_TYPE;

   /** Reserved 1. */
   // public static final BlockType RESERVED_1;
   /** ISSI header word. */
   public static final BlockType ISSI_HEADER_INFO;

   /** Reserved 2. */
   // public static final BlockType RESERVED_2;
   /** PTT control word. */
   public static final BlockType PTT_CONTROL_WORD;

   /** Fixed Station. */
   // public static final BlockType RSVD_FIXED_STATION;
   /** Future Expansion. */
   // public static final BlockType RSVD_FUTURE_EXPANSION;
   /** Manufacturer Specific. */
   // public static final BlockType MANUFACTURER_SPECIFIC;
   /***************************************************************************
    * Variables
    **************************************************************************/

   /** The block type as an int. */
   private int type;

   /** The block type description. */
   private String description;

   /** A mapping between type indices and type objects. */
   private static Hashtable<Integer, BlockType> ptHash;

   static {

      ptHash = new Hashtable<Integer, BlockType>();

      // IMBE Voice (block type 0)
      IMBE_VOICE = new BlockType(IMBE_VOICE_INDEX, "IMBE Voice Block Type");
      ptHash.put(IMBE_VOICE_INDEX, IMBE_VOICE);

      // Packet type (block type 1)
      PACKET_TYPE = new BlockType(PT_INDEX, "Packet Block Type");
      ptHash.put(PT_INDEX, PACKET_TYPE);

      // Reserved 1 (block types 2..4)
      for (int i = RSVD1_MIN_INDEX; i < RSVD1_MAX_INDEX; i++) {

         ptHash.put(i, new BlockType(i, "Reserved 1, type" + i));

      }

      // ISSI header info (block type 5)
      ISSI_HEADER_INFO = new BlockType(ISSIHDR_INDEX, "ISSI Header Information");
      ptHash.put(ISSIHDR_INDEX, ISSI_HEADER_INFO);

      // Reserved 2 (block types 6..10)
      for (int i = RSVD2_MIN_INDEX; i < RSVD2_MAX_INDEX; i++) {

         ptHash.put(i, new BlockType(i, "Reserved 2, type" + i));

      }

      // PTT control word (block type 11)
      PTT_CONTROL_WORD = new BlockType(PTTCTL_INDEX,
            "PTT Control Word Block Type");
      ptHash.put(PTTCTL_INDEX, PTT_CONTROL_WORD);

      // Fixed station (block types 12..14)
      for (int i = FXDSTA_MIN_INDEX; i < FXDSTA_MAX_INDEX; i++) {

         ptHash.put(i, new BlockType(i, "Fixed Station Interface, type" + i));

      }

      // Future expansion (block types 15..62)
      for (int i = FUTEXP_MIN_INDEX; i < FUTEXP_MAX_INDEX; i++) {

         ptHash.put(i, new BlockType(i, "Future Expansion, type" + i));

      }

      // Manufacturer specific (block types 63..127)
      for (int i = MFGSPEC_MIN_INDEX; i < MFGSPEC_MAX_INDEX; i++) {

         ptHash.put(i, new BlockType(i, "Manufacturer Specific, type" + i));

      }

   }

   /***************************************************************************
    * Constructors
    **************************************************************************/

   /**
    * Private constructor.
    * 
    * @param type
    *            the block type.
    * @param description
    *            the block type description.
    */
   private BlockType(int type, String description) {
      this.type = type;
      this.description = description;
   }

   /***************************************************************************
    * Methods
    **************************************************************************/

   /**
    * Get the string representation for this block type.
    * 
    * @return the string representation for this block type.
    */
   @Override
   public String toString() {
      return description;
   }

   /**
    * Get the int value of this block type.
    * 
    * @return the int value of this block type.
    */
   int intValue() {
      return type;
   }

   /**
    * Get the block type for a given int.
    * 
    * @param an
    *            int representation of the block type.
    * @return the block type.
    */
   public static BlockType getInstance(int blockType) {

      if (!ptHash.containsKey(blockType)) {

         throw new IllegalArgumentException("Illegal block type");

      }
      return ptHash.get(blockType);
   }
   
   
   /**
    * Get the block type from the description
    */
   public static int getValueFromDescription(String description) {
      for (BlockType bt : ptHash.values() ) {
         if ( bt.description.equals(description)) 
            return bt.type;
      }
      throw new IllegalArgumentException("bad description : " + description)   ;
   }

}
