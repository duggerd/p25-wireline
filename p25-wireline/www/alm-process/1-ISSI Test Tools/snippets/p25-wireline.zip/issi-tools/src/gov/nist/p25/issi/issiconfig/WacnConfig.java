package gov.nist.p25.issi.issiconfig;

public class WacnConfig {

   private String wacnName;
   private int wacnId;
   private boolean assigned;
   
   public WacnConfig ( String wacnName, int wacnId) {
      if (wacnId > (1 << 21 ) - 1)
         throw new IllegalArgumentException(
               "value too large only 20 bits for wacnId " + wacnId);
      this.wacnName = wacnName;
      this.wacnId = wacnId;
   }

   public String getWacnName() {
      return wacnName;
   }

   public void setWacnId(int wacnId) {
      if (wacnId > (1 << 21 ) - 1)
         throw new IllegalArgumentException(
               "value too large only 20 bits for wacnId " + wacnId);
      this.wacnId = wacnId;
   }

   public int getWacnId() {
      return wacnId;
   }

   public void setAssigned(boolean assigned) {
      this.assigned = assigned;
   }
   
   public boolean isAssigned() {
      return this.assigned;
   }
   
   public String toString () {
      return "<wacn-config\n" +
            "\twacnName = \""+ wacnName + "\"\n" +
            "\twacnId = \"" + Integer.toHexString(wacnId)   + "\"\n" +
            "/>\n";
   }
}
