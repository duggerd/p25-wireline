//
package gov.nist.p25.issi.p25body.serviceprofile;

/**
 * Defines a generic Call permission.
 * 
 * @author M. Ranganathan
 * 
 */
public enum CallPermissionType {
   
   NONE(0, "No  permission", "None"),
   RECEIVE(1, "Receive call permission","Receive"),
   INITIATE(2, "Initiate call permission","Initiate"),
   RECEIVE_AND_INITIATE(3,
         "Receive and Initiate Call permission","ReceiveAndInitiate");

   private int intValue;
   private String description;
   private String shortName ; 

   /*
    * ("None" | "Receive" | "Initiate" | "ReceiveAndInitiate" )
    */
   CallPermissionType(int val, String descr, String shortName) {
      this.intValue = val;
      this.description = descr;
      this.shortName = shortName;
   }

   public int getIntValue() {
      return intValue;
   }

   public static CallPermissionType getInstance(int intVal) {
      for (CallPermissionType p : CallPermissionType.values()) {
         if (p.intValue == intVal)
            return p;
      }
      throw new IllegalArgumentException("Bad inoput arg: " + intVal);
   }

   @Override
   public String toString() {
      return description;
   }

   public static CallPermissionType getInstance(String value) {
      for (CallPermissionType p : CallPermissionType.values()) {
         if (p.shortName.equals(value))
            return p;
      }
      throw new IllegalArgumentException("Bad input arg: " + value);
   }
}
