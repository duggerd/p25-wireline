//
package gov.nist.p25.issi.startup;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.TableColumnModel;

/**
 * Mouse listener for a table that includes buttons.
 * 
 * @author mranga@nist.gov
 *
 */
class JTableButtonMouseListener implements MouseListener {
	
	private JTable jtable;

	JTableButtonMouseListener (  JTable startupPropertiesTable ) {
		this.jtable = startupPropertiesTable;
	}
	
	private void forwardEventToButton(MouseEvent e) {
		TableColumnModel columnModel = jtable
				.getColumnModel();
		int column = columnModel.getColumnIndexAtX(e.getX());
		int row = e.getY() / jtable.getRowHeight();
		Object value;
		JButton button;
		MouseEvent buttonEvent;

		if (row >= jtable.getRowCount() || row < 0
				|| column >= jtable.getColumnCount()
				|| column < 0)
			return;

		value = jtable.getValueAt(row, column);

		if (!(value instanceof JButton))
			return;

		button = (JButton) value;

		buttonEvent = (MouseEvent) SwingUtilities.convertMouseEvent(
				jtable, e, button);
		button.doClick();
		// button.dispatchEvent(buttonEvent);
		// This is necessary so that when a button is pressed and released
		// it gets rendered properly. Otherwise, the button may still appear
		// pressed down when it has been released.
		jtable.repaint();
	}

	public JTableButtonMouseListener() { }
	
	public void mouseClicked(MouseEvent e) {
		forwardEventToButton(e);
	}
	
	public void mouseEntered(MouseEvent e) { }
	public void mouseExited(MouseEvent e) { }
	public void mousePressed(MouseEvent e) { }
	public void mouseReleased(MouseEvent e) { }
}