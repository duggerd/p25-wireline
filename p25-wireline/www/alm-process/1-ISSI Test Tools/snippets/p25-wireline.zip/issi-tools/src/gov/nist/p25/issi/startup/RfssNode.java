package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;
import att.grappa.Graph;
import att.grappa.GrappaConstants;
import att.grappa.GrappaShape;

/**
 * Grappa node representation for RFSS data
 * 
 * @author M. Ranganathan
 * 
 */
class RfssNode extends GraphNode {
	private RfssConfig rfssConfig;
	private ISSITesterConfiguration tsterConfig;

	RfssNode(ClusterConfigurationEditor manager, RfssConfig rfssConfig,
			Graph graph) {
		super(manager, graph);
		this.rfssConfig = rfssConfig;
		super.setName(rfssConfig.getRfssName());
		super.setYPosition(RFSSNODE_YPOSITION);
		super.setAttribute(GrappaConstants.SHAPE_ATTR, GrappaShape.BOX_SHAPE);
	}

	private RfssConfig getRfssConfig() {
		return rfssConfig;
	}

	class UpdateActionListener extends CreateActionListener {

		ConfigTableModel tableModel;

		public UpdateActionListener(ConfigTableModel tableModel) {
			this.tableModel = tableModel;
		}

		@Override
		public void actionPerformed(ActionEvent ae) {

			if (jtable.isEditing()) {
				jtable.editCellAt(0, 0); // Move the focus out so the value
											// takes.
			}
			tableModel.fireTableDataChanged();
			jtable.requestFocus();

			String ipAddress = (String) tableModel.getData("ipAddress");
			boolean emulated = tableModel.getDataAsBoolean("isEmulated");
			String daemonName = tableModel.getDataAsString("dietsDaemonName");

			if (emulated) {
				if (daemonName == null) {
					for (DaemonWebServerAddress dwa : RfssNode.this.tsterConfig
							.getDaemonAddresses()) {
						if (dwa.getIpAddress().equals(ipAddress)) {
							daemonName = dwa.getName();
							break;
						}
					}
				}
				if (daemonName == null) {
					JOptionPane.showMessageDialog(RfssNode.this.clusterEditor
							.getJFrame(),
							"Cannot find daemon defined for IP Address",
							"Data input Error", JOptionPane.ERROR_MESSAGE);
				}
			}
			rfssConfig.setEmulated(emulated);
			if (!rfssConfig.isEmulated())
				rfssConfig.setIpAddress(ipAddress);
			String systemName = (String) tableModel.getData("systemName");
			rfssConfig.setSystemName(systemName);
			int sipPort = tableModel.getDataAsInt("sipPort");
			rfssConfig.setSipPort(sipPort);
			RfssNode.this.tsterConfig.removeRefId(rfssConfig.getTag());

			int rfssId = tableModel.getDataAsHexInt("rfssId");
			rfssConfig.setRfssId(rfssId);

			if (rfssConfig.isEmulated()) {
				DaemonWebServerAddress dwa = RfssNode.this.tsterConfig
						.getDaemonByName(daemonName);
				RfssNode.this.tsterConfig
						.addReference(rfssConfig.getTag(), dwa);
			}
			RfssNode.this.clusterEditor.redraw();
		}
	}

	public void showAttributes() {
		RfssConfig rfssConfig = this.getRfssConfig();

		ConfigTableModel tableModel = new ConfigTableModel("RfssConfig");
		tableModel.setUnEditable("rfssName");
		tableModel.setUnEditable("domainName");

		if (rfssConfig.isEmulated())
			tableModel.setUnEditable("ipAddress");

		tableModel.setData("rfssName", this.getRfssConfig().getRfssName());
		tableModel.setData("domainName", rfssConfig.getDomainName());
		tableModel.setData("systemName", rfssConfig.getSysConfig()
				.getSymbolicName());
		tableModel.setData("rfssId", Integer
				.toHexString(rfssConfig.getRfssId()));
		String address = this.getRfssConfig().getIpAddress();
		tableModel.setData("ipAddress", address);
		int sipPort = rfssConfig.getSipPort();
		tableModel.setData("sipPort", sipPort);
		tableModel.setData("isEmulated", this.getRfssConfig().isEmulated());

		if (rfssConfig.isEmulated()) {
			if (this.tsterConfig.getDaemonByName(this.rfssConfig.getTag()) != null) {
				tableModel.setData("dietsDaemonName", this.tsterConfig
						.getDaemonByName(this.rfssConfig.getTag()).getName());
			} else {
				tableModel.setData("dietsDaemonName", "");
			}
		}
		super.showTable(this.clusterEditor, tableModel,
				new UpdateActionListener(tableModel));
	}

	public void setTsterConfig(ISSITesterConfiguration tsterConfig) {
		this.tsterConfig = tsterConfig;
	}

	@Override
	public void cleanupAction() {
		// TODO Auto-generated method stub
	}

	public static void createNewNode(ClusterConfigurationEditor configEditor,
			Graph graph) {
		ConfigTableModel tableModel = new ConfigTableModel("SystemConfig");
		//ISSITesterConfiguration testerConfig = configEditor.getTesterConfig();

		tableModel.setData("rfssName", "");
		tableModel.setData("systemName", "");
		tableModel.setData("rfssId", "");
		tableModel.setData("ipAddress", "");
		tableModel.setData("sipPort", "");
		tableModel.setData("isEmulated", "false");
		showTable(configEditor, tableModel, new CreateNewRfssActionListener(
				configEditor, tableModel));
	}
}