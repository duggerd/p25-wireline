package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.issiconfig.SystemConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.issiconfig.WacnConfig;

import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

/**
 * An action listener to create a new system Node.
 * 
 * @author mranga@nist.gov
 * 
 */
public class CreateNewSystemActionListener extends CreateActionListener {

	private static Logger logger = Logger.getLogger(CreateNewSystemActionListener.class);
	
	private ClusterConfigurationEditor configEditor;
	private ConfigTableModel tableModel;

	public CreateNewSystemActionListener(
			ClusterConfigurationEditor clusterConfigurationEditor,
			ConfigTableModel tableModel) {
		this.configEditor = clusterConfigurationEditor;
		this.tableModel = tableModel;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		try {
		   
			TopologyConfig topologyConfig = configEditor.getTopologyConfig();
			String systemName = tableModel.getDataAsString("systemName");
			if ( systemName == null || systemName.equals("")) {
				JOptionPane.showMessageDialog(configEditor.getJFrame(), 
				      "Invalid systemName specified!",
						"System Node creation error",
						JOptionPane.ERROR_MESSAGE);
			}
			if (topologyConfig.getSystemConfigByName(systemName) != null) {
				logger.error("System " + systemName + " already exists ");
				JOptionPane.showMessageDialog(configEditor.getJFrame(),
				      "System " + systemName + " already exists ",
						"System Node creation error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			String wacnName = tableModel.getDataAsString("wacnName");
			if (topologyConfig.getWacnConfig(wacnName) == null) {
				logger.error("Wacn " + wacnName + " does not exist ");
				JOptionPane.showMessageDialog(configEditor.getJFrame(),
				      "Wacn " + wacnName + " does not exist ",
						"System Node creation error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			WacnConfig wacnConfig = topologyConfig.getWacnConfig(wacnName);
			int systemId = tableModel.getDataAsHexInt("systemId");
			
			//SystemConfig(TopologyConfig topologyConfig, String systemName, WacnConfig wacnConfig, int systemId)
			SystemConfig systemConfig = new SystemConfig(topologyConfig,systemName,wacnConfig, systemId);
			topologyConfig.addSystemConfiguration(systemConfig);
			configEditor.redraw();
			
		} catch (Exception ex) {
			logger.error("System node creation error", ex);
			JOptionPane.showMessageDialog(configEditor.getJFrame(),
					"System node creation error - see log for details",
					"System Node creation error", JOptionPane.ERROR_MESSAGE);

		}
	}

}
