//
package gov.nist.p25.issi.startup;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

/**
 * Cell renderer for the properties table. 
 * 
 * @author mranga@nist.gov
 *
 */
public class MyTableCellRenderer  implements TableCellRenderer {
	// This method is called each time a cell in a column
	// using this renderer needs to be rendered.

	private ConfigTableModel tableModel;

	public MyTableCellRenderer( ConfigTableModel tableModel) {	
		this.tableModel = tableModel;
	}

	@Override
	public Component getTableCellRendererComponent(JTable table,
			Object value, boolean isSelected, boolean hasFocus, int row,
			int column) {
		JLabel retval;
		if (!tableModel.isCellEditable(row, column)) {
			retval = new JLabel(this.tableModel.getValueAt(row, column)
					.toString());
			retval.setForeground(Color.GRAY);
			
		} else {
			retval = new JLabel(this.tableModel.getValueAt(row, column)
					.toString());
			retval.setForeground(Color.BLACK);
		}
		return retval;
	}
}