//
package gov.nist.p25.issi.rfss.tester;

import gov.nist.p25.issi.constants.ISSIDtdConstants;
import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.PacketMonitorWebServerAddress;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;

import org.apache.log4j.Logger;

/**
 * This class defines where the web servers that launch the emulated RFSSs live.
 * 
 * @author mranga
 * 
 */
public class ISSITesterConfiguration {

   private static Logger logger = Logger.getLogger(ISSITesterConfiguration.class);

   private Hashtable<String, DaemonWebServerAddress> addressMap = new Hashtable<String, DaemonWebServerAddress>();
   private HashSet<DaemonWebServerAddress> addresses = new HashSet<DaemonWebServerAddress>();


   public ISSITesterConfiguration() {
   }

   public Collection<EmulatorWebServerAddress> getEmulatorConfigurations() {
      HashSet<EmulatorWebServerAddress> retval = new HashSet<EmulatorWebServerAddress>();
      for (DaemonWebServerAddress da : addresses) {
         if (da.isTesterService())
            retval.add(new EmulatorWebServerAddress(da.getIpAddress(), da
                  .getHttpPort()));
      }
      return retval;
   }

   public Collection<PacketMonitorWebServerAddress> getPacketMonitors() {
      HashSet<PacketMonitorWebServerAddress> retval = new HashSet<PacketMonitorWebServerAddress>();
      for (DaemonWebServerAddress da : addresses) {
         if (da.isPacketMonitorService())
            retval.add(new PacketMonitorWebServerAddress(da.getIpAddress(),
                  da.getHttpPort()));
      }
      return retval;
   }

   public PacketMonitorWebServerAddress getPacketMonitor(String ipAddress) {

      for (DaemonWebServerAddress da : addresses) {
         if (ipAddress.trim().equals(da.getIpAddress()) && da.isPacketMonitorService()) {
            logger.info("Found configuration for " + ipAddress);
            return new PacketMonitorWebServerAddress(da.getIpAddress(), da
                  .getHttpPort());
         }
      }
      return null;
   }

   public void printPacketMonitorTable() {
      logger.info(getPacketMonitors().toString());
   }

   public String getIpAddressByName(String name) {
      if ( addressMap.get(name) == null)
         return null;
      else {
         if ( addressMap.get(name) == null)
            return null;
         else 
            return addressMap.get(name).getIpAddress();
      }
   }

   public DaemonWebServerAddress getDaemonByName(String name) {
      return addressMap.get(name);
   }

   public Collection<DaemonWebServerAddress> getDaemonAddresses() {
      return addresses;
   }

   public Collection<String> getLocalAddresses() {
      HashSet<String> retval = new HashSet<String>();
      for (DaemonWebServerAddress emulatorAddress : addresses) {
         for (int port = (int) (Math.random() * 10000), j = 0; j < 10; j++) {
            if (emulatorAddress.getIpAddress() != null) {
               try {

                  Socket sock = new Socket();
                  sock.bind(new InetSocketAddress(emulatorAddress
                        .getIpAddress(), port));
                  sock.close();
                  retval.add(emulatorAddress.getIpAddress());
                  break;
               } catch (IOException ex) {
                  // ignore ?
               }
            }
         }
      }
      logger.info("Local addresses " + retval);
      return retval;
   }

   public Collection<DaemonWebServerAddress> getLocalConfigurations() {
      HashSet<DaemonWebServerAddress> retval = new HashSet<DaemonWebServerAddress>();
      for (DaemonWebServerAddress emulatorAddress : addresses) {
         if (emulatorAddress.getHttpPort() > 0) {
            for (int port = (int) (Math.random() * 10000), j = 0; j < 10; j++) {
               try {

                  Socket sock = new Socket();
                  sock.bind(new InetSocketAddress(emulatorAddress
                        .getIpAddress(), port));
                  sock.close();
                  retval.add(emulatorAddress);
                  break;
               } catch (IOException ex) {
                  // ignore ?
               }
            }
         }
      }
      return retval;
   }

   public void addDaemonWebServerAddress(DaemonWebServerAddress daemonWebServerAddress) {
      this.addresses.add(daemonWebServerAddress);
      this.addressMap.put(daemonWebServerAddress.getName(),
            daemonWebServerAddress);
   }

   public void addReference(String id, DaemonWebServerAddress daemonWebServerAddress) {
      addressMap.put(id, daemonWebServerAddress);
      daemonWebServerAddress.addRefId(id);
   }

   public void removeRefId(String tag) {
      for (DaemonWebServerAddress dwa : addresses) {
         dwa.removeRefId(tag);
      }
      addressMap.remove(tag);      
   }
   
   @Override
   public String toString() {
      
      //  "<!DOCTYPE system-topology SYSTEM \"http://www-x.antd.nist.gov:8080/p25/issi-emulator/dtd/issi-tester-config.dtd\">\n" +
      StringBuffer retval = new StringBuffer();
      retval.append ( "<?xml version=\"1.0\"?>\n" +
        "<!DOCTYPE system-topology SYSTEM \"" + 
        ISSIDtdConstants.URL_ISSI_DTD_TESTER_CONFIG + "\">\n" +
        "<issi-tester-config>\n");      
      for ( DaemonWebServerAddress dwa : this.addresses) {
         retval.append(dwa.toString());
      }      
      retval.append("</issi-tester-config>\n");
      return retval.toString();      
   }
}
