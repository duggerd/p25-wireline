//
package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

/**
 * Table where the local host properties are entered.
 * 
 * @author mranga@nist.gov
 *
 */
@SuppressWarnings("unchecked")
class LocalhostPropertiesTableModel extends AbstractTableModel {
	
   private static final long serialVersionUID = -1L;
   
	//String[] columnNames = { "Field", "CurrentValue" };
	private Object[] rowNames = null;

	private Properties properties;
	private Hashtable<String, JButton> indexToButtonTable = new Hashtable<String,JButton>();

	public LocalhostPropertiesTableModel( Properties localhostProperties) {
		this.properties = localhostProperties;
		rowNames = properties.keySet().toArray();
		for (Object pname : this.properties.keySet()) {
			final String propName = (String) pname;
			JButton jbutton = new JButton("What is this?");
			jbutton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent ae) {
					DietsStartup.showHelpText(propName);
					
				}});
			indexToButtonTable.put(propName, jbutton);
			
		}
	}

	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public int getRowCount() {
		return rowNames.length;
	}

	@Override
	public Object getValueAt(int row, int column) {

		if (column == 0) {
			return rowNames[row];
		} else if ( column == 1){
			String propName = (String) rowNames[row];
			return properties.getProperty(propName);
		} else {
			String propName = (String) rowNames[row];		
			return indexToButtonTable.get(propName);
		}
	}

	@Override
	public void setValueAt(Object value, int row, int column) {
		String propName = (String) rowNames[row];
		properties.put(propName, value);
	}

	@Override
	public Class getColumnClass(int column) {
		if ( column == 2) return JButton.class;
		else
		return getValueAt(0, column).getClass();
	}

	@Override
	public boolean isCellEditable(int row, int col) {
		if (col == 0 || col == 2)
			return false;
		else
			return true;
	}

}