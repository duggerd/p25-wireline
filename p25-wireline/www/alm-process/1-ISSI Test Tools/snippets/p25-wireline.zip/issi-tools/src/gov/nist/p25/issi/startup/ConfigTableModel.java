//
package gov.nist.p25.issi.startup;

import java.util.HashSet;
import java.util.Hashtable;

import javax.swing.table.AbstractTableModel;

@SuppressWarnings("unchecked")
public class ConfigTableModel extends AbstractTableModel {
   
   private static final long serialVersionUID = -1L;

   //private String[] columnNames = { "Field Name", "Value" };
   private Hashtable<String, Object> valueTable = new Hashtable<String, Object>();
   private Hashtable<Integer, String> indexTable = new Hashtable<Integer, String>();
   private Hashtable<String, HashSet<Object>> allowedValues = new Hashtable<String, HashSet<Object>>();
   private int index = 0;
   private String tableName;
   private HashSet<String> uneditable = new HashSet<String>();

   public ConfigTableModel(String tableName) {
      this.tableName = tableName;
   }

   public void setData(String name, Object value) {
      valueTable.put(name, value);
      indexTable.put(new Integer(index++), name);
   }

   public void setData(String name, Object value, HashSet<Object> allowedValues) {
      valueTable.put(name, value);
      indexTable.put(new Integer(index++), name);
      this.allowedValues.put(name, allowedValues);
   }

   public Object getData(String name) {
      return valueTable.get(name);
   }

   @Override
   public int getColumnCount() {
      return 2;
   }

   @Override
   public int getRowCount() {
      return valueTable.size();
   }

   @Override
   public Object getValueAt(int row, int column) {

      if (column == 0) {
         return indexTable.get(row);
      } else if (column == 1) {
         String name = indexTable.get(row);
         return valueTable.get(name);
      } else {
         throw new IllegalArgumentException("bad column " + column);
      }
   }

   @Override
   public Class getColumnClass(int c) {
      return getValueAt(1, c).getClass();
   }

   @Override
   public void setValueAt(Object newValue, int row, int column) {
      if (column == 0)
         return; // names are read only.
      else {
         String name = indexTable.get(row);
         valueTable.put(name, newValue);
         fireTableCellUpdated(row, column);
      }
   }

   @Override
   public boolean isCellEditable(int row, int col) {
      if (col == 0)
         return false;
      else {
         if (this.uneditable.contains(indexTable.get(row))) {
            return false;
         } else {
            return true;
         }
      }
   }

   public void setUnEditable(String fieldName) {
      this.uneditable.add(fieldName);
   }

   public String getTableName() {
      return tableName;
   }

   public int getDataAsHexInt(String name) {
      String data = this.getData(name).toString();
      if (data == null)
         return 0;
      else {
         int retval = Integer.parseInt(data, 16);
         if (retval < 0)
            throw new NumberFormatException(
                  "Only positive hex integers allowed.");
         return retval;
      }
   }

   public int getDataAsInt(String name) {
      String data = (String) (this.getData(name).toString());
      if (data == null) {
         return 0;
      } else {
         int retval = Integer.parseInt(data);
         if (retval < 0)
            throw new NumberFormatException("Value is < 0 ");
         return retval;
      }
   }

   public boolean getDataAsBoolean(String name) {
      String data = (String) (this.getData(name).toString());
      if (data == null)
         return false;
      else
         return Boolean.parseBoolean(data);
   }

   public String getDataAsString(String name) {
      if (this.getData(name) == null)
         return null;
      return (String) this.getData(name).toString();
   }

}
