//
package gov.nist.p25.issi.startup;

import java.awt.event.ActionEvent;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import att.grappa.Graph;
import att.grappa.GrappaConstants;
import att.grappa.GrappaShape;


/**
 * Grappa node representation for daemon data.
 * 
 * @author M. Ranganathan
 *
 */
class DaemonNode extends GraphNode {
	private DaemonWebServerAddress daemonWebServerAddress;
	
	DaemonNode(ClusterConfigurationEditor editor,DaemonWebServerAddress config, Graph graph) {
		super(editor,graph);
		this.daemonWebServerAddress = config;
		super.setName(config.getName());
		super.setYPosition(DAEMON_YPOSITION);
		super
		.setAttribute(GrappaConstants.SHAPE_ATTR,
				GrappaShape.OCTAGON_SHAPE);		
	}

	public DaemonWebServerAddress getDaemonWebServerAddress() {
		return daemonWebServerAddress;
	}

	class UpdateActionListener extends CreateActionListener {
		
		ConfigTableModel tableModel;
		
		public UpdateActionListener( ConfigTableModel tableModel) {
			this.tableModel = tableModel;
		}

		@Override
		public void actionPerformed(ActionEvent ae) {
		
			String ipAddress = (String) tableModel.getData("ipAddress");
			daemonWebServerAddress.setIpAddress(ipAddress);
			int httpPort =  tableModel.getDataAsInt("httpPort");
			daemonWebServerAddress.setHttpPort(httpPort);
			boolean isTesterService =  tableModel.getDataAsBoolean("isTesterService");
			daemonWebServerAddress.setTesterService(isTesterService);
			boolean isPacketMonitorService = tableModel.getDataAsBoolean("isPacketMonitorService");
			daemonWebServerAddress.setPacketMonitorService(isPacketMonitorService);
			/*
			 * Reset the ip address to which the emulated daemon is pointing.
			 */
			for ( String tag : DaemonNode.this.daemonWebServerAddress.getRefIds() ) {
					RfssConfig rfssConfig = DaemonNode.this.clusterEditor.getTopologyConfig().getRfssConfigByTag(tag);
					if ( rfssConfig != null && rfssConfig.isEmulated()) rfssConfig.setIpAddress(ipAddress);
			}
		    DaemonNode.this.clusterEditor.redraw();		   			
		}		
	}
		
	public void showAttributes() {
			
			ConfigTableModel tableModel = new ConfigTableModel("DaemonConfig");
			tableModel.setUnEditable("daemonName");
			
			tableModel.setData("daemonName", super.getName());
			tableModel.setData("ipAddress", daemonWebServerAddress.getIpAddress());
			tableModel.setData("httpPort", Integer.toString(daemonWebServerAddress.getHttpPort()));
			tableModel.setData("isTesterService", Boolean.toString(daemonWebServerAddress.isTesterService()));
			tableModel.setData("isPacketMonitorService", Boolean.toString(daemonWebServerAddress.isPacketMonitorService()));
			
			showTable(clusterEditor, tableModel, new UpdateActionListener(tableModel));		
	}
	
	public static void createNewNode(ClusterConfigurationEditor configEditor, Graph graph) {
		
		ConfigTableModel tableModel = new ConfigTableModel("DaemonConfig");
		tableModel.setData("daemonName","");
		tableModel.setData("ipAddress", "");
		tableModel.setData("httpPort", Integer.toString(ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT));
		tableModel.setData("isTesterService",Boolean.TRUE.toString() );
		tableModel.setData("isPacketMonitorService",  Boolean.FALSE.toString());
		showTable(configEditor,tableModel, new CreateNewDaemonNodeActionListener(configEditor, tableModel));	
	}

	@Override
	public void cleanupAction() {
				
	}
}