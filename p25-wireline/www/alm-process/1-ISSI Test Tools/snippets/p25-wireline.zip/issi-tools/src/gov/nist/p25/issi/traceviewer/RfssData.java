//
package gov.nist.p25.issi.traceviewer;

import gov.nist.p25.issi.issiconfig.RfssConfig;

import java.util.*;
import java.awt.*;

/**
 * This class implements an RFSS node and used to display both
 * SIP and PTT traces.
 * 
 * @author steveq@nist.gov
 * @version $Revision: 1.3 $, $Date: 2007/07/05 00:20:59 $
 * @since 1.5
 */
public class RfssData implements Comparable<RfssData> {

   ///////////////////////////////////////////////////////////////////////
   // Variables
   ///////////////////////////////////////////////////////////////////////
   
   /** Radical name. */
   private String id;   
   
   /** IP Address. */
   private String address;
   
   /** Incoming SIP or PTT (RTP) ports. */
   private ArrayList<String> ports;

   /** x coordinate. */
   private int x;

   /** y coordinate. */
   private int y;

   /** Size of RFSS image. */
   private Dimension dimension;

   /** Determines if this RFSS is selected on the screen. */
   private boolean selected = false;

   /** The time we receive the RFSS data. */
   private long time;
   
   /** The rfss configuration if there is one attached to this **/
   private RfssConfig rfssConfig;
   
   /** A set of Sessions retrieved at runtime. */
   private HashSet<PttSessionInfo> pttSessionInfo;

   private int counter;
   

   ///////////////////////////////////////////////////////////////////////
   // Constructors
   ///////////////////////////////////////////////////////////////////////
   
   private RfssData () {
      this.ports = new ArrayList<String>();
      this.pttSessionInfo = new HashSet<PttSessionInfo> ();
   }
   
   /** 
    * Construct an RfssData object with no time attribute.
    */
   public RfssData(String id, String address, String port) {
      this();
      this.setId(id);
      this.setAddress(address);
      this.ports.add(port);      
   }

   private void setId(String id) {
      this.id = id;
   }
   public String getId() {
      return id;
   }

   private void setAddress(String address) {
      this.address = address;
   }
   public String getAddress() {
      return address;
   }

   public ArrayList<String> getPorts() {
      return ports;
   }

   public void setDimension(Dimension dimension) {
      this.dimension = dimension;
   }
   public Dimension getDimension() {
      return dimension;
   }

   public void setSelected(boolean selected) {
      this.selected = selected;
   }
   public boolean isSelected() {
      return selected;
   }

   public void setTime(long time, int counter) {
      this.time = time;
      this.counter = counter;
   }
   public long getTime() {
      return time;
   }

   public void setRfssConfig(RfssConfig rfssConfig) {
      this.rfssConfig = rfssConfig;
   }
   public RfssConfig getRfssConfig() {
      return rfssConfig;
   }

   public void setX(int x) {
      this.x = x;
   }
   public int getX() {
      return x;
   }

   public void setY(int y) {
      this.y = y;
   }
   public int getY() {
      return y;
   }

   /**
    * Add a port to the list of ports that have been seen at this Rfss.
    * Note that this is a small list so linear search is fine.
    * 
    * @param portToAdd
    */
   public void addPort(String portToAdd) {
      for ( String p : ports) {
         if (p.equals(portToAdd)) return;
      }
      ports.add(portToAdd);      
   }

   public void setPttSessionInfo(HashSet<PttSessionInfo> pttSessionInfo) {
      this.pttSessionInfo = pttSessionInfo;
   }
   public HashSet<PttSessionInfo> getPttSessionInfo() {
      return pttSessionInfo;
   }

   public int compareTo(RfssData rfssData) {
      
      if (rfssData.getTime() == getTime()) {
         return counter < rfssData.counter? -1 : 1;
      } else {
         return rfssData.getTime() < getTime() ? 1 : -1;
      }
   }
   
}
