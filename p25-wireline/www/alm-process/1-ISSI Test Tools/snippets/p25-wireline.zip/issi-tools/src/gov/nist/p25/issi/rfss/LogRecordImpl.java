//
package gov.nist.p25.issi.rfss;

import gov.nist.javax.sip.LogRecord;

/**
 * The record that is used by the SIP stack to record messages to the trace log.
 * 
 * @author M. Ranganathan
 *
 */
public class LogRecordImpl implements LogRecord {

   private String fromRfssId;
   private String toRfssId;
   private String message;
   private String source;
   private String destination;
   private long timeStamp;
   private String firstLine;
   private String tid;
   private String callId;
   private long timeStampHeaderValue;
   private boolean isSender;
   
   public void setFromRfssId (String fromRfssId) {
      this.fromRfssId = fromRfssId;
   }
   
   public void setToRfssId(String toRfssId) {
      this.toRfssId = toRfssId;
   }
   
   public boolean equals(Object other) {
      if (!(other instanceof LogRecordImpl)) {
         return false;
      } else {
         LogRecordImpl otherLog = (LogRecordImpl) other;
         return otherLog.message.equals(message)
            && otherLog.timeStamp == timeStamp;
      }
   }
   
   public LogRecordImpl(String message,
         String source, 
         String destination, 
         long timeStamp, 
         boolean isSender, 
         String firstLine, 
         String tid, 
         String callId, 
         long timeStampHeaderVal) {
      this.message = message;
      this.source = source;
      this.destination = destination;
      this.timeStamp = timeStamp;
      this.firstLine = firstLine;
      this.tid = tid;
      this.callId = callId;
      this.timeStampHeaderValue = timeStampHeaderVal;
      this.timeStamp = timeStamp;
      this.isSender = isSender;
   }
   
   public String toString() {
      String log =
         "<message\nfrom=\""
            + source
            + "\" \nfromRfssId=\""
            + fromRfssId
            + "\" \nto=\""
            + destination
            + "\" \ntoRfssId=\""
            + toRfssId
            + "\" \ntime=\""
            + timeStamp
            + "\"" + 
            (this.timeStampHeaderValue != 0 ? "\ntimeStamp = \"" + timeStampHeaderValue + "\"": "")   
            +"\nisSender=\""
            + isSender
            + "\" \ntransactionId=\""
            + tid
            + "\" \ncallId=\""
            + callId
            + "\" \nfirstLine=\""
            + firstLine.trim() + "\"" +
            " \n>\n";
      log += "<![CDATA[";
      log += message;
      log += "]]>\n";
      log += "</message>\n";
      return log;
   }
}
