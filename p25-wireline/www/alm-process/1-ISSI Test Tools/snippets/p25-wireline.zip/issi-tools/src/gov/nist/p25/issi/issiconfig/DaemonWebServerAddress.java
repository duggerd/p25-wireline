package gov.nist.p25.issi.issiconfig;

import java.util.Collection;
import java.util.HashSet;

/**
 * This class represents a machine on which an emulator or packet monitor ( or both) runs. 
 * The emulator is signaled using http.
 * 
 * @author M. Ranganathan <mranga@nist.gov>
 *
 */
public class DaemonWebServerAddress implements WebServerAddress {

   private String ipAddress;
   private int httpPort;
   private boolean isMapped;
   private boolean testerService;
   private boolean packetMonitorService;
   private String name;
   private HashSet <String> refId = new HashSet<String>();
   
   public DaemonWebServerAddress(String name, String ipAddress, int port,
      boolean isTester, boolean isMonitor) {
      this.ipAddress = ipAddress;
      this.httpPort = port;
      this.name = name;
      this.testerService = isTester;
      this.packetMonitorService = isMonitor;
   }

   public String getIpAddress() {
      return ipAddress;
   }

   public String getHttpControlUrl() {
      return "http://" + ipAddress + ":" + httpPort + "/diets/controller";
   }
   
   public int getHttpPort() {
      return httpPort;
   }

   public void setMapped(boolean isMapped) {
      this.isMapped = isMapped;
   }

   public boolean isMapped() {
      return isMapped;
   }

   public void setTesterService(boolean testerService) {
      this.testerService = testerService;
   }

   public boolean isTesterService() {
      return testerService;
   }

   public void setPacketMonitorService(boolean packetMonitorService) {
      this.packetMonitorService = packetMonitorService;
   }

   public boolean isPacketMonitorService() {
      return packetMonitorService;
   }

   public String getName() {
      return name;
   }

   public void setIpAddress(String ipAddress) {
      this.ipAddress = ipAddress;
   }

   public void setHttpPort(int httpPort) {
      this.httpPort = httpPort;
   }
   
   public void addRefId(String ref) {
      this.refId.add(ref);
   }
   
   public void removeRefId(String tag) {
      this.refId.remove(tag);
   }
   
   public Collection<String> getRefIds() {
      return this.refId;
   }
   
   @Override
   public String toString() {
       String retval = "<diets-daemon\n" +
            "\tipAddress = \"" + this.ipAddress + "\"\n" +
            "\thttpPort = \"" + this.httpPort + "\"\n" +
            "\tname = \"" + this.name + "\"\n" +
            "\tisConformanceTester = \"" + this.isTesterService()+ "\"\n" +
            "\tisPacketMonitor = \"" + this.isPacketMonitorService() + "\"\n" +
            ">\n";
       for ( String tag : this.refId) {
          retval += "<refid\n" + "\tid = \"" + tag +  "\"\n" + "/>\n";
       }
       retval += "</diets-daemon>\n";
       return retval;
   }
}
