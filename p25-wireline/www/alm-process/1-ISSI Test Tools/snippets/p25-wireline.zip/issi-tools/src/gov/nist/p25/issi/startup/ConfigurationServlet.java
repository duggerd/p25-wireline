//
package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.packetmonitor.PacketMonitor;
import gov.nist.p25.issi.rfss.tester.TestRFSS;


import java.awt.Color;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.mortbay.jetty.Server;


public class ConfigurationServlet extends HttpServlet {

   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ConfigurationServlet.class);
   
   private static DietsStartup clusterManagerStartup;
   private static Server server;

   public ConfigurationServlet() {      
   }

   @Override
   public void doPost(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
         
      try {
         logger.info("Server Command = " + request.getParameter(ISSITesterConstants.COMMAND ));
         
         if (request.getParameter(ISSITesterConstants.COMMAND).equals(
               ISSITesterConstants.START_SERVICES)) {
            // This contains a fresh copy of tester configuration file.
            logger.debug("Starting services ");
            String topologyFileName = request.getParameter(ISSITesterConstants.TESTER_DAEMON_TOPOLOGY);
            logger.debug("topology file name = " + topologyFileName);
                  
            if (PacketMonitor.isConfigured()) {
               logger.debug("Uncofiguring packet monitor");
               PacketMonitor.unconfigure();
            }
            logger.debug("About to configure packet monitor!");
            int count = PacketMonitor.configure(server, topologyFileName);         
            if (count > 0) {
               clusterManagerStartup.getPacketMonitorStatusLabel().setForeground(Color.GREEN);
               clusterManagerStartup.getPacketMonitorStatusLabel().setText("Monitor Service: Running");
            }

            if ( TestRFSS.isConfigured()) {
               TestRFSS.unconfigure();
            }
            count = TestRFSS.configure(server, topologyFileName);
            if (count > 0) {
               clusterManagerStartup.getTesterStatusLabel().setForeground(Color.GREEN);
               clusterManagerStartup.getTesterStatusLabel().setText("Tester Service: Ready");
            }

   
         }  else if (request.getParameter(ISSITesterConstants.COMMAND).equals(
               ISSITesterConstants.STOP_SERVICES)) {
            if (PacketMonitor.isConfigured()) {
               PacketMonitor.unconfigure();
            }
            if ( TestRFSS.isConfigured()) {
               TestRFSS.unconfigure();
            }
            clusterManagerStartup.getPacketMonitorStatusLabel().setForeground(Color.BLUE);
            clusterManagerStartup.getPacketMonitorStatusLabel().setText("Monitor Service: Stopped");
            clusterManagerStartup.getTesterStatusLabel().setForeground(Color.BLUE);
            clusterManagerStartup.getTesterStatusLabel().setText("Tester Service: Stopped");
            
         } else if ( request.getParameter(ISSITesterConstants.COMMAND).equals(ISSITesterConstants.UPDATE_CONFIGURATION_FILE)) {
            InputStream inputStream =   request.getInputStream();
            int length = request.getContentLength();
            
            byte[] content = new byte[length];            
            int b;         
            for  ( int i = 0; (b = inputStream.read()) != -1  ; i ++) {
               content[i] = (byte)   b;            
            }
            
            String topologyFileContents = new String(content);         
            String topologyFileName = request.getParameter(ISSITesterConstants.FILENAME_TO_UPDATE);
            
            FileWriter fwriter = new FileWriter( new File( topologyFileName));
            fwriter.write(topologyFileContents);
            fwriter.close();
               
         } else if ( request.getParameter(ISSITesterConstants.COMMAND).equals(ISSITesterConstants.REDRAW)) {
            String propertiesFileName = "startup/diets.properties"; // test code.
            DietsConfigProperties props = null;
            String testSuite = null;
            String dietsConfigFileName = null;
            String systemTopologyFileName = null;
            if (propertiesFileName == null
                  || !new File(propertiesFileName).exists()) {

               return;
            } else {

               props = new DietsConfigProperties(propertiesFileName);

               testSuite = props
                     .getProperty(DietsConfigProperties.TESTSUITE_PROPERTY);
               dietsConfigFileName = props
                     .getProperty(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
               if (testSuite != null)
                  systemTopologyFileName = "testsuites/" + testSuite
                        + "/systemtopology.xml";
               else
                  systemTopologyFileName = null;
               
               if (props
                     .getProperty(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY) != null) {
                  systemTopologyFileName = props
                        .getProperty(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
               }
            }
            clusterManagerStartup.setTestSuiteName(testSuite);
            clusterManagerStartup.setSystemTopologyFileName(systemTopologyFileName);
            clusterManagerStartup.setTesterTopologyFileName(dietsConfigFileName);
            clusterManagerStartup.reconfigure();
            
         }
      } catch (Exception ex) {
         ex.printStackTrace();
         logger.error("Unexpected error occured", ex);
         throw new ServletException("Unexpected exception" + ex.getMessage());
      }
   }

   /**
    * @param server the server to set
    */
    static void setServer(Server server) {
      ConfigurationServlet.server = server;
   }

   /**
    * @param clusterManagerStartup the clusterManagerStartup to set
    */
   static void setClusterManagerStartup(DietsStartup clusterManagerStartup) {
      ConfigurationServlet.clusterManagerStartup = clusterManagerStartup;
   }

}
