//
package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.issiconfig.GlobalTopologyParser;
import gov.nist.p25.issi.issiconfig.SystemTopologyParser;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.packetmonitor.PacketMonitor;
import gov.nist.p25.issi.packetmonitor.gui.PacketMonitorGUI;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfigurationParser;
import gov.nist.p25.issi.rfss.tester.TestRFSS;
import gov.nist.p25.issi.testlauncher.DietsGUI;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.TableCellRenderer;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;
import org.mortbay.http.HttpContext;
import org.mortbay.http.SocketListener;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.servlet.ServletHandler;

/**
 * The cluster manager that configures the distributed test system.
 * This the GUI from which you launch various pieces of ISSI Tester.
 * 
 * @author M. Ranganathan <mranga@nist.gov>
 * 
 */
public class DietsStartup extends JFrame {
   
   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ClusterConfigurationEditor.class);

	private StartupPropertiesTableModel startupPropertiesTableModel;
	private JTable startupPropertiesTable;
	private LocalhostPropertiesTableModel localhostPropertiesTableModel;

	private static Server httpServer;
	private static HttpContext httpContext;
	private static int httpPort = ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT;

	private DietsConfigProperties configProperties = null;
	private Properties localhostProperties;
	private JTable localhostPropertiesTable;

	private boolean cancelled;
	protected SocketListener socketListener;

	protected static boolean daemonRunning;

	private ISSITesterConfiguration testerconfig;
	private TopologyConfig topologyConfig;
	private JLabel packetMonitorStatusLabel;
	private JLabel testerStatusLabel;
	private ClusterConfigurationEditor clusterManager;

	// The different buttons that appear in this panel.
	private JButton startTestServicesButton;
	private JButton stopTestServicesButton;
	private JButton saveButton;
	private JButton selectTestSuiteButton;
	private JButton clearSelectTestSuiteButton;
	private JButton selectSystemTopologyButton;
	private JButton clearSystemTopologyButton;
	private JButton selectTesterTopologyButton;
	private JButton clearSelectTesterTopologyButton;
	private JButton testLauncherButton;
	private JButton packetMonitorGuilButton;
	private JButton startDaemonButton;
	private JButton stopDaemonButton;
	private JButton helpButton;
	private JLabel daemonStatusLabel;

	private static Hashtable<String, String> helpText = new Hashtable<String, String>();

	static {
		helpText.put(
			DietsConfigProperties.DAEMON_IP_ADDRESS,
			"The IP address where this daemon will run. \n\n "
					+ "The IP address should be configured on this machine.\n"
					+ "Make sure the firewall is off so that HTTP signaling can be seen by \n"
					+ "this daemon and make sure that other machines in the test cluster can \n"
					+ "route packets to this machine in the ports specified in the systemtopology.");
		helpText.put(
			DietsConfigProperties.DAEMON_HTTP_PORT,
			"The HTTP control port that is used for controlling this daemon.\n\n"
					+ "The cluster controller will POST HTTP  this IP address and port to control test execution.\n"
					+ "If you start a daemon, it will bind to this IP address and port. A Daemon must be \n"
					+ "started at each tester or Packet Monitor IP address. By default, the Daemons are configured\n"
					+ "to recive HTTP signaling at port 8763. If you change this port, you will have to enter the \n"
					+ "port that you choose in the daemon configuration file.");
		helpText.put(
			DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
			"This file includes, RFSS, Wacn and System configuration properties. \n\n"
					+ "It specifies the RFSSs and the IP addresses where the RFSSs will run.\n "
					+ "It does not specify RFSSs or groups. \n"
					+ "Emulated RFSSs should have an associated ISSI Tester daemon that specifies the IP \n "
					+ "address where they are configured to run. Each ISSI Tester daemon can host \n"
					+ "at most one packet monitor and and unlimited number of emulated RFSSs. ");
		helpText.put(
			DietsConfigProperties.TESTSUITE_PROPERTY,
			"The name of the test suite (if any).\n\n"
					+ "The test suite is a directory with a specific structure.\n"
					+ "It includes a system topology and a global topology.\n"
					+ "Hence if you pick a test suite, you are also speicifying its \n"
					+ "associated system topology. You can, however, pick a system topology \n"
					+ "without a test suite being specified - but that implies you are not going to run \n"
					+ "tests. For example, you would not need to specify a test suite if you are only using \n"
					+ "ISSI Tester for packet monitoring. The global topology associated with a test suite specifies \n"
					+ "the logical entities such as SUs and Groups that are \n"
					+ "common to the entire test suite. These have to be made known to the \n"
					+ "IUT in order to successfully run tests. \n");

		helpText.put(
			DietsConfigProperties.DAEMON_CONFIG_PROPERTY,
			"A file that specifies the IP address and ports "
					+ "on which ISSI Tester daemons will run.\n\n"
					+ "You can pick one of the cluster members be the designated cluster controller or designate another machine\n"
					+ "that is not part of the test cluster as the controller. The controller does not have to start a daemon\n"
					+ "if it is not part of the test cluster \n"
					+ "The controller must have knowledge of the test cluster configuration (i.e. the various topology files that\n"
					+ "are managed by this interface). Hence it is the place from which you should edit and ship configuration files.\n"
					+ "You configure and start the daemons on each of the nodes where the controller expects to find them.\n"
					+ "The controller will push configuration information to the other daemons. \n");
	}

	class XmlFileFilter extends FileFilter {

		@Override
		public boolean accept(File file) {
			return file.isDirectory() || file.isFile()
					&& file.getName().endsWith("xml");
		}

		@Override
		public String getDescription() {
			return "Available Test Suites";
		}

	}

	class DirFilter extends FileFilter {

		private File root;
		public File getRoot() {
		   return root;
		}

		public DirFilter(File root) {
			this.root = root;
		}
		@Override
		public boolean accept(File file) {
			return file.isDirectory() && !file.getName().equals("CVS");
		}
		@Override
		public String getDescription() {
			return "Available Test Suites";
		}
	}

	class JTableButtonRenderer implements TableCellRenderer {
		private TableCellRenderer defaultRenderer;

		public JTableButtonRenderer(TableCellRenderer renderer) {
			defaultRenderer = renderer;
		}
		public Component getTableCellRendererComponent(JTable table,
				Object value, boolean isSelected, boolean hasFocus, int row,
				int column) {
			if (value instanceof Component)
				return (Component) value;
			return defaultRenderer.getTableCellRendererComponent(table, value,
					isSelected, hasFocus, row, column);
		}
	}

	private void addStartTestServicesActionListener() {
		this.startTestServicesButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				try {

					StartupHttpClient sc = new StartupHttpClient(
							DietsStartup.this.getTesterTopologyFileName(),
							DietsStartup.this.testerconfig, DietsStartup.this
									.getSystemTopologyFileName(),
							DietsStartup.this.getGlobalTopologyFileName(),
							DietsStartup.this.configProperties,
							DietsStartup.this.topologyConfig);
					sc.shipConfigFiles();
					sc.startServices();
					startTestServicesButton.setEnabled(false);
					stopTestServicesButton.setEnabled(true);
				} catch (Exception ex) {
					logger.error("Error shipping files!", ex);
				}
			}

		});

	}

	private void addStopButtonActionListener() {
		stopDaemonButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				try {
					socketListener.stop();
					httpContext.stop();
					httpServer.removeContext(httpContext);
					httpServer.stop();
					//JButton butt = (JButton) ae.getSource();
					DietsStartup.this.startDaemonButton.setEnabled(true);
					DietsStartup.this.stopDaemonButton.setEnabled(false);
					DietsStartup.daemonRunning = false;
					DietsStartup.this.daemonStatusLabel
							.setForeground(Color.BLUE);
					DietsStartup.this.daemonStatusLabel
							.setText("Daemon: Stopped");
					if (PacketMonitor.isConfigured()) {
						PacketMonitor.unconfigure();
						DietsStartup.this.packetMonitorStatusLabel
								.setText("Monitor Service: Stopped");
						DietsStartup.this.packetMonitorStatusLabel
								.setForeground(Color.BLUE);

					}

					if (TestRFSS.isConfigured()) {
						TestRFSS.unconfigure();
						DietsStartup.this.testerStatusLabel
								.setForeground(Color.BLUE);
						DietsStartup.this.testerStatusLabel
								.setText("Tester Service: Stopped");
					}

					DietsStartup.this.startTestServicesButton.setEnabled(true);
					DietsStartup.this.stopTestServicesButton.setEnabled(false);

				} catch (Exception ex) {
					logger.error("Could not stop server", ex);
					JOptionPane.showMessageDialog(null,
							"Could not stop server", "Daemon Startup Error ",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
	}

	private void addStartDaemonButtonActionListener() {
		startDaemonButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				String ipAddress = null;
				int port = httpPort;

				try {
					httpServer = new Server();

					ipAddress = localhostProperties
							.getProperty(DietsConfigProperties.DAEMON_IP_ADDRESS);
					DietsStartup.this.socketListener = new SocketListener();

					socketListener.setMaxThreads(10);
					socketListener.setMinThreads(3);
					socketListener.setHost(ipAddress);
					socketListener.setPort(port);
					socketListener.start();
					httpServer.addListener(socketListener);
					httpContext = new HttpContext();
					httpContext.setContextPath("/diets/*");
					ServletHandler servletHandler = new ServletHandler();
					// Register a welcome servlet with the Servlet Handler.
					servletHandler.addServlet("controller", "/controller/*",
							ConfigurationServlet.class.getName());
					ConfigurationServlet.setServer(httpServer);
					ConfigurationServlet
							.setClusterManagerStartup(DietsStartup.this);
					// "gov.nist.p25.issi.servlets.ControlServlet");
					httpContext.addHandler(servletHandler);
					httpServer.addContext(httpContext);

					httpContext.start();
					httpServer.start();
					JButton jbutton = (JButton) ae.getSource();
					DietsStartup.daemonRunning = true;
					jbutton.setEnabled(false);
					DietsStartup.this.stopDaemonButton.setEnabled(true);
					DietsStartup.this.daemonStatusLabel
							.setForeground(Color.green);
					DietsStartup.this.daemonStatusLabel
							.setText("Daemon: Running");
				} catch (Exception ex) {
					logger.error("Could not bind to " + ipAddress + ":" + port
							+ "\nconfigure IP address and port", ex);
					JOptionPane.showMessageDialog(null, "Could not bind to "
							+ ipAddress + ":" + port
							+ "\nconfigure IP address and port",
							"Daemon Startup Error ", JOptionPane.ERROR_MESSAGE);

				}

			}

		});

	}

	private void addPacketMonitorGuiButtonActionListener() {
		packetMonitorGuilButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent actionEvent) {

				try {

					PacketMonitorGUI.initProperties(configProperties);
					PacketMonitorGUI packetMonitorGUI = new PacketMonitorGUI();

					JButton jbutton = (JButton) actionEvent.getSource();
					jbutton.setEnabled(false);
					packetMonitorGUI.addWindowListener(new WindowAdapter() {
						private JButton jbutton;

						public WindowAdapter setJButton(JButton button) {
							this.jbutton = button;
							return this;
						}

						@Override
						public void windowClosing(WindowEvent event) {
							jbutton.setEnabled(true);
							//repaint();
							//System.exit(0);
						}
					}.setJButton(jbutton));
					repaint();

				} catch (Exception ex) {
				   System.out.println("DietsStartup: PacketMonitorGUI - ex="+ex);
					logger.error("Unexepcted error ", ex);
				}
			}			

		});

	}

	private void addTestLauncherActionListener() {
		testLauncherButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent actionEvent) {
				try {

					DietsGUI.doStaticReIniitialization(configProperties);
					DietsGUI dietsGui = new DietsGUI();

					JButton jbutton = (JButton) actionEvent.getSource();
					jbutton.setEnabled(false);
					dietsGui.addWindowListener(new WindowAdapter() {
						private JButton jbutton;

						public WindowAdapter setJButton(JButton button) {
							this.jbutton = button;
							return this;
						}

						@Override
						public void windowClosing(WindowEvent event) {
							jbutton.setEnabled(true);
							//repaint();
						}
					}.setJButton(jbutton));
					repaint();

				} catch (Exception ex) {
					logger.error("Unexepcted error ", ex);
				}
			}
		});
	}

	private void addClearSelectTesterTopologyButtonActionListener() {
		clearSelectTesterTopologyButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				DietsStartup.this.testerconfig = new ISSITesterConfiguration();
				DietsStartup.this.startupPropertiesTableModel.setData(
						DietsConfigProperties.DAEMON_CONFIG_PROPERTY, null);
				DietsStartup.this.setTesterTopologyFileName(null);
				DietsStartup.this.clusterManager.redraw();
			}
		});
	}

	private void addSelectTesterTopologyButtonActionListener() {
		selectTesterTopologyButton.addActionListener(new ActionListener() {
			private StartupPropertiesTableModel tableModel;

			public ActionListener setTableModel(
					StartupPropertiesTableModel tableModel) {
				this.tableModel = tableModel;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent event) {
				try {
					String root = ISSITesterConstants.getRootDir() + "/"
							+ ISSITesterConstants.DEFAULT_TESTERCONFIG_DIR;

					JFileChooser fileChooser = new JFileChooser(root);
					fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

					fileChooser.setFileFilter(new XmlFileFilter());

					fileChooser.setVisible(true);
					JFrame frame = new JFrame("Select tester configuration");

					fileChooser.showOpenDialog(frame);
					File topologyName = fileChooser.getSelectedFile();
					if (topologyName != null) {
						this.tableModel.setData(
								DietsConfigProperties.DAEMON_CONFIG_PROPERTY,
								topologyName.getName());
						DietsStartup.this
								.setTesterTopologyFileName(ISSITesterConstants.DEFAULT_TESTERCONFIG_DIR
										+ "/" + topologyName.getName());
						DietsStartup.this.testerconfig = new ISSITesterConfigurationParser(
								DietsStartup.this.getTesterTopologyFileName())
								.parse();
						DietsStartup.this.topologyConfig
								.rebindIpAddresses(DietsStartup.this.testerconfig);
						DietsStartup.this.clusterManager.redraw();
					}
				} catch (Exception ex) {
					logger.error("Error in parsing selected config file", ex);
					JOptionPane.showMessageDialog(DietsStartup.this,
						"Error in parsing selected config file",
						"ISSI Tester Startup Error", JOptionPane.ERROR_MESSAGE);
				}

			}

		}.setTableModel(this.startupPropertiesTableModel));

	}

	private void addClearSystemTopologyActionListener() {
		this.clearSystemTopologyButton.addActionListener(new ActionListener() {
			private StartupPropertiesTableModel tableModel;

			public ActionListener setTableModel(
					StartupPropertiesTableModel tableModel) {
				this.tableModel = tableModel;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent ae) {
				if (DietsStartup.this.getTestSuiteName() != null) {
					JOptionPane.showMessageDialog(DietsStartup.this,
							"Cannot clear this field independently \n"
									+ "when teststuite is specified",
							"Clear error", JOptionPane.ERROR_MESSAGE);
					return;

				} else {
					tableModel.setData(
							DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
							null);
					DietsStartup.this.setSystemTopologyFileName(null);
					DietsStartup.this.topologyConfig = new TopologyConfig();
					DietsStartup.this.clusterManager.redraw();
				}
			}
		}.setTableModel(this.startupPropertiesTableModel));
	}

	private void addSelectSystemTopologyActionListener() {
		selectSystemTopologyButton.addActionListener(new ActionListener() {
			private StartupPropertiesTableModel tableModel;

			public ActionListener setTableModel(
					StartupPropertiesTableModel tableModel) {
				this.tableModel = tableModel;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent event) {
				String root = ISSITesterConstants.getRootDir();
				JFileChooser fileChooser = new JFileChooser(root);

				fileChooser.setFileFilter(new XmlFileFilter());

				fileChooser.setVisible(true);
				JFrame frame = new JFrame("Select test suite");

				fileChooser.showOpenDialog(frame);

				File topologyName = fileChooser.getSelectedFile();
				if (topologyName != null) {
					try {
						String fpath = topologyName.getCanonicalPath();
						String rpath = new File(root).getCanonicalPath();
						if (fpath.indexOf(rpath) == -1) {
							JOptionPane.showMessageDialog(null,
									"Invalid file path!", "File Path Error!",
									JOptionPane.ERROR_MESSAGE);
							return;
						}
						DietsStartup.this.setSystemTopologyFileName(fpath
								.substring(rpath.length()));
						DietsStartup.this.setTestSuiteName(null);
						this.tableModel.setData(
								DietsConfigProperties.TESTSUITE_PROPERTY, null);

						tableModel.setData(
								DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
								DietsStartup.this.getSystemTopologyFileName());
						startupPropertiesTable.repaint();

						DietsStartup.this.topologyConfig = new SystemTopologyParser(
								testerconfig).parse(DietsStartup.this
								.getSystemTopologyFileName());
						DietsStartup.this.clusterManager.redraw();
					} catch (Exception ex) {
						logger.error("Error in setting system topology", ex);
						JOptionPane.showMessageDialog(DietsStartup.this,
								"Error in setting system topology",
								"configuration error",
								JOptionPane.ERROR_MESSAGE);
					}
				}

			}

		}.setTableModel(this.startupPropertiesTableModel));

	}

	void reconfigure() throws Exception {

		if (this.getTesterTopologyFileName() != null) {
			this.testerconfig = new ISSITesterConfigurationParser(this
					.getTesterTopologyFileName()).parse();
		} else {
			this.testerconfig = new ISSITesterConfiguration();
		}

		if (this.getSystemTopologyFileName() != null) {
			this.topologyConfig = new SystemTopologyParser(testerconfig)
					.parse(DietsStartup.this.getSystemTopologyFileName());
		} else {
			this.topologyConfig = new TopologyConfig();
		}

		if (this.getGlobalTopologyFileName() != null) {
			this.topologyConfig = new GlobalTopologyParser(true).parse(
					topologyConfig, this.getGlobalTopologyFileName());
		}
		this.clusterManager.redraw();
	}

	private void addSelectTestSuiteButtonActionListenr() {
		selectTestSuiteButton.addActionListener(new ActionListener() {
			private StartupPropertiesTableModel tableModel;

			public ActionListener setTableModel(
					StartupPropertiesTableModel tableModel) {
				this.tableModel = tableModel;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent event) {

				try {

					String root = ISSITesterConstants.getRootDir()
							+ "/testsuites";
					System.out.println("testSuitesUrl " + root);

					JFileChooser fileChooser = new JFileChooser(root);
					fileChooser
							.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

					fileChooser.setFileFilter(new DirFilter(new File(root)));

					fileChooser.setVisible(true);
					JFrame frame = new JFrame("Select test suite");

					fileChooser.showOpenDialog(frame);
					File testDir = fileChooser.getSelectedFile();
					if (testDir != null) {
						DietsStartup.this.setTestSuiteName(testDir.getName());

						this.tableModel.setData(
								DietsConfigProperties.TESTSUITE_PROPERTY,
								getTestSuiteName());
						DietsStartup.this
								.setSystemTopologyFileName("testsuites/"
										+ getTestSuiteName()
										+ "/systemtopology.xml");
						tableModel.setData(
								DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
								DietsStartup.this.getSystemTopologyFileName());
						startupPropertiesTable.repaint();
						ISSITesterConstants.setTestSuite(getTestSuiteName());
					} else {
						DietsStartup.this.setTestSuiteName(null);
					}

					if (DietsStartup.this.getTesterTopologyFileName() != null) {

						DietsStartup.this.testerconfig = new ISSITesterConfigurationParser(
								DietsStartup.this.getTesterTopologyFileName())
								.parse();
					} else {
						DietsStartup.this.testerconfig = new ISSITesterConfiguration();
					}

					if (DietsStartup.this.getGlobalTopologyFileName() == null) {
						topologyConfig = new SystemTopologyParser(testerconfig)
								.parse(DietsStartup.this
										.getSystemTopologyFileName());
					} else {
						TopologyConfig systemTopology = new SystemTopologyParser(
								testerconfig).parse(DietsStartup.this
								.getSystemTopologyFileName());
						DietsStartup.this.topologyConfig = new GlobalTopologyParser(
								true).parse(systemTopology, DietsStartup.this
								.getGlobalTopologyFileName());
					}

					DietsStartup.this.clusterManager.redraw();
				} catch (Exception ex) {
					logger.error("Error in startup properties setting", ex);
					JOptionPane.showMessageDialog(
							DietsStartup.this,
							"Error in setting the startup properties. See log for details.",
							"Configuration Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		}.setTableModel(this.startupPropertiesTableModel));
	}

	private void addClearSelectTestSuiteButtonActionListener() {

		clearSelectTestSuiteButton.addActionListener(new ActionListener() {
			private StartupPropertiesTableModel tableModel;

			public ActionListener setTableModel(
					StartupPropertiesTableModel tableModel) {
				this.tableModel = tableModel;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent ae) {
				if (DietsStartup.this.getTestSuiteName() != null) {
					tableModel.setData(
							DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
							null);
					tableModel.setData(
							DietsConfigProperties.TESTSUITE_PROPERTY, "");
					DietsStartup.this.setTestSuiteName(null);
					DietsStartup.this.setSystemTopologyFileName(null);
					DietsStartup.this.topologyConfig = new TopologyConfig();
					DietsStartup.this.clusterManager.redraw();
				}
			}
		}.setTableModel(this.startupPropertiesTableModel));
	}

	private void addSaveButtonActionListener() {
		this.saveButton.addActionListener(new ActionListener() {
			private JFrame frame;

			public ActionListener setFrame(JFrame frame) {
				this.frame = frame;
				return this;
			}

			@Override
			public void actionPerformed(ActionEvent actionEvent) {
				try {

					configProperties.store();

					String propertiesFileName = ISSITesterConstants.LOCALHOST_PROPERTIES_FILE;
					File startupFile = new File(propertiesFileName);
					PrintWriter printWriter = new PrintWriter(new FileWriter(
							startupFile));
					localhostProperties.store(printWriter,
						"File generated automatically by ISSI Tester.");
					printWriter.close();
					String fileName = DietsStartup.this
							.getTesterTopologyFileName();
					if (fileName != null) {
						String testerTopology = DietsStartup.this.testerconfig
								.toString();
						FileWriter fw = new FileWriter(new File(fileName));
						fw.write(testerTopology);
						fw.close();
					}

					String systemTopologyFileName = DietsStartup.this
							.getSystemTopologyFileName();
					if (systemTopologyFileName != null) {
						String systemTopology = DietsStartup.this.topologyConfig
								.exportSystemTopology();
						FileWriter fw = new FileWriter(new File(
								systemTopologyFileName));
						fw.write(systemTopology);
						fw.close();
					}

					String globalTopologyFileName = DietsStartup.this
							.getGlobalTopologyFileName();
					if (globalTopologyFileName != null) {
						String globalTopology = DietsStartup.this.topologyConfig
								.exportGlobalTopology();
						FileWriter fw = new FileWriter(new File(
								globalTopologyFileName));
						fw.write(globalTopology);
						fw.close();
					}
					
	            JOptionPane.showMessageDialog( null,
	                  "Configuration saved successfully.");

				} catch (Exception ex) {
					logger.error("An unexpected error occured", ex);
	            JOptionPane.showMessageDialog( frame,
	                  "Failed to save configuration:\n\n" + ex);
				}

			}

		}.setFrame(this));

	}

	protected DietsStartup(DietsConfigProperties props, String testSuite,
			String dietsConfigFileName, String systemTopologyFileName)
			throws Exception {
		super();

		logger.debug("dietsConfigFileName = " + dietsConfigFileName);

		this.configProperties = props == null ? new DietsConfigProperties()
				: props;

		this.localhostProperties = new Properties();
		try {
			localhostProperties.load(new FileInputStream(new File(
					ISSITesterConstants.LOCALHOST_PROPERTIES_FILE)));
			if (localhostProperties
					.getProperty(DietsConfigProperties.DAEMON_HTTP_PORT) == null)
				localhostProperties.setProperty(
						DietsConfigProperties.DAEMON_HTTP_PORT, new Integer(
								ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT)
								.toString());
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Cannot read "
					+ ISSITesterConstants.LOCALHOST_PROPERTIES_FILE
					+ ". Will start daemon on 127.0.0.1 address and port "
					+ ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT,
					"Startup Warning", JOptionPane.WARNING_MESSAGE);
			localhostProperties.setProperty(
					DietsConfigProperties.DAEMON_IP_ADDRESS, "127.0.0.1");
			localhostProperties.setProperty(
					DietsConfigProperties.DAEMON_HTTP_PORT, new Integer(
							ISSITesterConstants.DEFAULT_DIETS_HTTP_PORT)
							.toString());
		}

		this.setTestSuiteName(testSuite);
		this.setSystemTopologyFileName(systemTopologyFileName);
		this.setTesterTopologyFileName(dietsConfigFileName);
		this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));

		this.setTitle("ISSI Tester Console "+ ISSITesterConstants.VERSION);

		if (DietsStartup.this.getTesterTopologyFileName() == null) {
			this.testerconfig = new ISSITesterConfiguration();
		} else {
			this.testerconfig = new ISSITesterConfigurationParser(
					DietsStartup.this.getTesterTopologyFileName()).parse();
		}

		if (this.getGlobalTopologyFileName() == null
				&& this.getSystemTopologyFileName() != null) {

			this.topologyConfig = new SystemTopologyParser(testerconfig)
					.parse(this.getSystemTopologyFileName());
		} else if (this.getSystemTopologyFileName() != null) {
			TopologyConfig systemTopology = new SystemTopologyParser(
					testerconfig).parse(DietsStartup.this
					.getSystemTopologyFileName());
			this.topologyConfig = new GlobalTopologyParser(true).parse(
					systemTopology, this.getGlobalTopologyFileName());
		} else {
			this.topologyConfig = new TopologyConfig();
		}

		this.startupPropertiesTableModel = new StartupPropertiesTableModel(
				this.configProperties);

		this.startupPropertiesTable = new JTable(startupPropertiesTableModel);
		Border border = BorderFactory.createLineBorder(Color.black);

		this.startupPropertiesTable.setBorder(border);
		TableCellRenderer defaultRenderer = startupPropertiesTable
				.getDefaultRenderer(JButton.class);
		startupPropertiesTable.setDefaultRenderer(JButton.class,
				new JTableButtonRenderer(defaultRenderer));
		startupPropertiesTable.addMouseListener(new JTableButtonMouseListener(
				startupPropertiesTable));

		this.localhostPropertiesTableModel = new LocalhostPropertiesTableModel(
				localhostProperties);

		this.localhostPropertiesTable = new JTable(
				localhostPropertiesTableModel);
		localhostPropertiesTable
				.addMouseListener(new JTableButtonMouseListener(
						localhostPropertiesTable));
		TableCellRenderer renderer = localhostPropertiesTable
				.getDefaultRenderer(JButton.class);
		localhostPropertiesTable.setDefaultRenderer(JButton.class,
				new JTableButtonRenderer(renderer));

		this.localhostPropertiesTable
				.setToolTipText("This table determines startup "
						+ " parameters for the daemon that runs on this machine");

		Border border1 = BorderFactory.createLineBorder(Color.blue);
		localhostPropertiesTable.setBorder(border1);
		this.startupPropertiesTable.setBorder(border1);

		JPanel graphPane = new JPanel();
		graphPane.setLayout(new BoxLayout(graphPane, BoxLayout.Y_AXIS));
		this.clusterManager = new ClusterConfigurationEditor(this, graphPane);

		this.addWindowListener(new WindowAdapter() {

			public void windowClosing(WindowEvent e) {
				try {
					System.out.println("Bye Bye!");
					if(socketListener != null) {
						socketListener.stop();
						httpContext.stop();
						httpServer.removeContext(httpContext);
						httpServer.stop();
					}
					DietsStartup.this.dispose();
					System.exit(0);
				} catch (Exception ex) {
				}
			}
		});

		JPanel contentPane = new JPanel();
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

		JPanel statusFrame = new JPanel();
		statusFrame.setLayout(new GridLayout(1, 2));
		Font font = new Font("Serif", Font.BOLD, 20);

		this.daemonStatusLabel = new JLabel();
		this.daemonStatusLabel.setFont(font);
		this.daemonStatusLabel.setForeground(Color.BLUE);
		this.daemonStatusLabel.setText("Daemon: Stopped");
		this.daemonStatusLabel.setBorder(BorderFactory
				.createLineBorder(Color.black));
		statusFrame.add(this.daemonStatusLabel);

		this.packetMonitorStatusLabel = new JLabel();
		this.packetMonitorStatusLabel.setFont(font);
		this.packetMonitorStatusLabel.setForeground(Color.BLUE);
		this.packetMonitorStatusLabel.setText("Monitor Service: Stopped");
		this.packetMonitorStatusLabel.setBorder(BorderFactory
				.createLineBorder(Color.black));

		statusFrame.add(this.packetMonitorStatusLabel);

		this.testerStatusLabel = new JLabel();
		this.testerStatusLabel.setFont(font);
		this.testerStatusLabel.setForeground(Color.BLUE);
		this.testerStatusLabel.setBorder(BorderFactory
				.createLineBorder(Color.black));

		testerStatusLabel.setText("Tester Service: Stopped");
		statusFrame.add(testerStatusLabel);
		contentPane.add(statusFrame);

		JPanel configPanel = new JPanel();
		configPanel.setLayout(new GridLayout(1, 2));
		configPanel.add(localhostPropertiesTable);
		configPanel.add(startupPropertiesTable);
		contentPane.add(configPanel);

		JPanel buttonPanel = new JPanel();

		this.selectTestSuiteButton = new JButton("Select");
		selectTestSuiteButton.setEnabled(true);

		selectTestSuiteButton
				.setToolTipText("Select Test Suite ( only relevant for Tester configuration)");
		this.clearSelectTestSuiteButton = new JButton("Clear Selection");
		if (this.getTestSuiteName() == null)
			startupPropertiesTableModel.setData(
					DietsConfigProperties.TESTSUITE_PROPERTY, "",
					selectTestSuiteButton, clearSelectTestSuiteButton);
		else
			startupPropertiesTableModel.setData(
					DietsConfigProperties.TESTSUITE_PROPERTY,
					getTestSuiteName(), selectTestSuiteButton,
					clearSelectTestSuiteButton);

		this.addClearSelectTestSuiteButtonActionListener();
		this.addSelectTestSuiteButtonActionListenr();
		this.selectSystemTopologyButton = new JButton("Select");

		this.addSelectSystemTopologyActionListener();
		selectSystemTopologyButton
				.setToolTipText("Select System topology ( for Packet monitor)");
		this.clearSystemTopologyButton = new JButton("Clear Selection");
		this.addClearSystemTopologyActionListener();

		if (this.getSystemTopologyFileName() == null) {
			startupPropertiesTableModel.setData(
					DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY, "",
					selectSystemTopologyButton, clearSystemTopologyButton);

		} else {
			startupPropertiesTableModel.setData(
					DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY, this
							.getSystemTopologyFileName(),
					selectSystemTopologyButton, clearSystemTopologyButton);
		}

		this.selectTesterTopologyButton = new JButton("Select");

		this.addSelectTesterTopologyButtonActionListener();

		selectTesterTopologyButton
				.setToolTipText("Select ISSI Tester Topology");

		this.clearSelectTesterTopologyButton = new JButton("Clear Selection");

		this.addClearSelectTesterTopologyButtonActionListener();

		if (getTesterTopologyFileName() == null)
			startupPropertiesTableModel
					.setData(DietsConfigProperties.DAEMON_CONFIG_PROPERTY, "",
							selectTesterTopologyButton,
							clearSelectTesterTopologyButton);
		else
			startupPropertiesTableModel.setData(
					DietsConfigProperties.DAEMON_CONFIG_PROPERTY,
					getTesterTopologyFileName(), selectTesterTopologyButton,
					clearSelectTesterTopologyButton);

		// contentPane.add(buttonPanel);
		buttonPanel.setLayout(new GridLayout(1, 6));

		this.startDaemonButton = new JButton("Start Daemon");
		startDaemonButton
				.setToolTipText("Start the ISSI Tester Daemon on this machine");
		this.addStartDaemonButtonActionListener();
		buttonPanel.add(startDaemonButton);

		this.stopDaemonButton = new JButton("Stop Daemon");
		stopDaemonButton
				.setToolTipText("Stop the ISSI Tester daemon on this machine");
		this.addStopButtonActionListener();
		buttonPanel.add(stopDaemonButton);
		stopDaemonButton.setEnabled(false);

		this.startTestServicesButton = new JButton("Start Services");
		buttonPanel.add(this.startTestServicesButton);
		this.addStartTestServicesActionListener();
		this.startTestServicesButton
				.setToolTipText("Start the test and packet monoitoring services across the cluster.");

		this.stopTestServicesButton = new JButton("Stop Services");
		buttonPanel.add(stopTestServicesButton);
		this.addStopTestServicesButtonActionListener();
		this.stopTestServicesButton.setEnabled(false);
		this.stopTestServicesButton
				.setToolTipText("Stop the test and packet monoitoring services across the cluster");

		this.testLauncherButton = new JButton("Test Runner");
		this.addTestLauncherActionListener();
		buttonPanel.add(testLauncherButton);
		this.testLauncherButton.setToolTipText("Start the test launcher GUI");

		this.packetMonitorGuilButton = new JButton("Monitor");
		this.addPacketMonitorGuiButtonActionListener();
		buttonPanel.add(packetMonitorGuilButton);
		this.packetMonitorGuilButton
				.setToolTipText("Start the Packet Monitor GUI");

		this.saveButton = new JButton("Save Configuration");
		this.addSaveButtonActionListener();
		buttonPanel.add(saveButton);

		this.helpButton = new JButton("Help");
		buttonPanel.add(helpButton);
		this.addHelpButtonActionListener();

		JButton quitButton = new JButton("Quit");
		buttonPanel.add(quitButton);
		quitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					System.out.println("Bye Bye!");
					if(socketListener != null) {
						socketListener.stop();
						httpContext.stop();
						httpServer.removeContext(httpContext);
						httpServer.stop();
					}

					DietsStartup.this.dispose();
					System.exit(0);
				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}
		});

		contentPane.add(buttonPanel);
		Dimension screenSize = getToolkit().getScreenSize();

		this.getContentPane().setSize(screenSize.width, screenSize.height);

		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				graphPane, contentPane);

		this.getContentPane().add(splitPane);
		this.pack();
		this.setVisible(true);

	}

	private void addStopTestServicesButtonActionListener() {
		stopTestServicesButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				try {

					StartupHttpClient sc = new StartupHttpClient(
							DietsStartup.this.getTesterTopologyFileName(),
							DietsStartup.this.testerconfig, DietsStartup.this
									.getSystemTopologyFileName(),
							DietsStartup.this.getGlobalTopologyFileName(),
							DietsStartup.this.configProperties,
							DietsStartup.this.topologyConfig);
					sc.stopServices();
					stopTestServicesButton.setEnabled(false);
					startTestServicesButton.setEnabled(true);
				} catch (Exception ex) {
					logger.error("Error shipping files!", ex);
				}

			}

		});

	}

	private void addHelpButtonActionListener() {
		helpButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				JEditorPane jep = new JEditorPane();

				jep.setEditable(false);
				try {
					jep.setPage("file:doc/helptext.html");
				} catch (IOException e) {
					logger
							.error("Unexpected error - could not read readme!",
									e);
					return;

				}
				JFrame jframe = new JFrame("Help");
				JScrollPane jscrollPane = new JScrollPane(
						ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
						ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				jscrollPane.setViewportView(jep);

				jframe.getContentPane().add(jscrollPane);
				jframe.setSize(640, 480);
				jframe.setVisible(true);

			}

		});

	}

	public String getTestSuiteName() {
		return this.configProperties
				.getProperty(DietsConfigProperties.TESTSUITE_PROPERTY);
	}

	public void setTestSuiteName(String testSuiteName) {
		if (testSuiteName == null) {
			this.configProperties
					.remove(DietsConfigProperties.TESTSUITE_PROPERTY);
		} else {
			this.configProperties.setProperty(
					DietsConfigProperties.TESTSUITE_PROPERTY, testSuiteName);
		}
	}

	public String getSystemTopologyFileName() {
		return this.configProperties
				.getProperty(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
	}

	public String getGlobalTopologyFileName() {
		String testSuite = this.configProperties
				.getProperty(DietsConfigProperties.TESTSUITE_PROPERTY);
		if (testSuite != null)
			return ISSITesterConstants.getGlobalTopologyFileName(testSuite);
		else
			return null;
	}

	public void setSystemTopologyFileName(String systemTopologyFileName) {
		if (systemTopologyFileName == null) {
			this.configProperties
					.remove(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
		} else {
			this.configProperties.setProperty(
					DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY,
					systemTopologyFileName);
		}
	}

	public String getTesterTopologyFileName() {
		return this.configProperties
				.getProperty(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
	}
	public void setTesterTopologyFileName(String testerTopologyFileName) {
		if (testerTopologyFileName != null) {
			this.configProperties.setProperty(
					DietsConfigProperties.DAEMON_CONFIG_PROPERTY,
					testerTopologyFileName);
		} else {
			this.configProperties
					.remove(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
		}
	}

	public JLabel getPacketMonitorStatusLabel() {
		return packetMonitorStatusLabel;
	}

	public JLabel getTesterStatusLabel() {
		return testerStatusLabel;
	}

	public boolean isCancelled() {
		return cancelled;
	}

	public ISSITesterConfiguration getTesterConfiguration() {
		return this.testerconfig;
	}

	public TopologyConfig getTopologyConfig() {
		return this.topologyConfig;
	}

	protected void getInput() {
	}

	public static final void main(String[] args) throws Exception {
		String propertiesFileName = ISSITesterConstants.STARTUP_PROPERTIES_FILENAME;
		PropertyConfigurator.configure("log4j.properties");
		logger.addAppender(new ConsoleAppender(new SimpleLayout()));
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("-startup")) {
				propertiesFileName = args[++i];
			}
		}
		if (propertiesFileName == null) {
			propertiesFileName = System.getProperties().getProperty("startup");
		}
		DietsConfigProperties props = null;
		String testSuite = null;
		String dietsConfigFileName = null;
		String systemTopologyFileName = null;
		if (propertiesFileName == null
				|| !new File(propertiesFileName).exists()) {

			DietsStartup startupbox = new DietsStartup(null, null, null, null);

			testSuite = startupbox.getTestSuiteName();
			dietsConfigFileName = startupbox.getTesterTopologyFileName();
			systemTopologyFileName = startupbox.getSystemTopologyFileName();
			if (startupbox.isCancelled())
				return;

		} else {

			props = new DietsConfigProperties(propertiesFileName);

			testSuite = props
					.getProperty(DietsConfigProperties.TESTSUITE_PROPERTY);
			dietsConfigFileName = props
					.getProperty(DietsConfigProperties.DAEMON_CONFIG_PROPERTY);
			if (testSuite != null)
				systemTopologyFileName = "testsuites/" + testSuite
						+ "/systemtopology.xml";
			else
				systemTopologyFileName = null;

			if (props
					.getProperty(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY) != null) {
				systemTopologyFileName = props
						.getProperty(DietsConfigProperties.SYSTEM_TOPOLOGY_PROPERTY);
			}

		}

		// Schedule a job for the event-dispatching thread
		javax.swing.SwingUtilities.invokeLater(new Runnable() {

			private String testSuite;
			private String dietsConfigFileName;
			private String systemTopologyFileName;
			private DietsConfigProperties props;

			public Runnable setParams(DietsConfigProperties props,
					String testSuite, String dietsConfigFileName,
					String systemTopologyFileName) {
				this.testSuite = testSuite;
				this.dietsConfigFileName = dietsConfigFileName;
				this.systemTopologyFileName = systemTopologyFileName;
				this.props = props;
				return this;
			}

			public void run() {
				try {
					new DietsStartup(props, testSuite, dietsConfigFileName,
							systemTopologyFileName);
				} catch (Exception ex) {
					logger.error("Exception starting the GUI", ex);
				}
			}
		}.setParams(props, testSuite, dietsConfigFileName,
				systemTopologyFileName));
	}

	public static void showHelpText(String propName) {
		String text = helpText.get(propName);
		if (text != null) {
			JOptionPane.showMessageDialog(null, text, "Help",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

}
