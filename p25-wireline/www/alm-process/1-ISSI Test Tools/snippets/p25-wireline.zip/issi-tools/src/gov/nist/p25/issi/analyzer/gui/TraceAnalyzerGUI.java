//
package gov.nist.p25.issi.analyzer.gui;

import gov.nist.p25.common.util.Exec;
import gov.nist.p25.common.util.HexDump;
import gov.nist.p25.common.util.FileUtility;

import gov.nist.p25.issi.analyzer.bo.MessageCapturer;
import gov.nist.p25.issi.analyzer.config.ISSIXmlConfigurator;
import gov.nist.p25.issi.analyzer.config.XmlPttmessages;
import gov.nist.p25.issi.analyzer.util.EndPointHelper;
import gov.nist.p25.issi.analyzer.vo.EndPoint;
import gov.nist.p25.issi.constants.ISSILogoConstants;

//TODO: need to decouple the SystemTopology
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.packetmonitor.PacketMonitor;
import gov.nist.p25.issi.packetmonitor.gui.ISSIConfigManager;
import gov.nist.p25.issi.packetmonitor.gui.LocalPacketMonitorController;
import gov.nist.p25.issi.packetmonitor.gui.MeasurementTable;
import gov.nist.p25.issi.packetmonitor.gui.PacketMonitorController;
import gov.nist.p25.issi.traceviewer.MessageData;
import gov.nist.p25.issi.traceviewer.PttSessionInfo;
//import gov.nist.p25.issi.traceviewer.PttTraceLoader;
import gov.nist.p25.issi.traceviewer.RfssData;
import gov.nist.p25.issi.traceviewer.SipTraceLoader;
import gov.nist.p25.issi.traceviewer.TracePanel;
import gov.nist.p25.issi.xmlconfig.PttmessagesDocument.Pttmessages;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.sip.PeerUnavailableException;

import java.io.File;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.List;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;

/**
 * @author echang@associate.its.bldrdoc.gov
 */
public class TraceAnalyzerGUI extends JPanel
   implements ActionListener
{
   private static final long serialVersionUID = -1L;

   private static Logger logger = Logger.getLogger(TraceAnalyzerGUI.class);
   static {
      try {
         PropertyConfigurator.configure("log4j.properties");
         logger.addAppender(new FileAppender(new SimpleLayout(),
               "logs/traceanalyzer.txt"));
      } catch (Exception ex) {
         // ignore... :-)
      }
   }

   private static String WIRESHARK_EXE = "/ext/WiresharkPortable/WiresharkPortable.exe";
   private static String JPCAPDUMPER_JAR = "./lib/JpcapDumper-0.3.jar";

   private static final String TAG_PCAP_TEST = "pcap-test";
   private static final String TAG_FILE_OPEN = "Open";
   private static final String TAG_FILE_EXIT = "Exit";
   private static final String TAG_ACTION_ANALYZE = "Analyze";
   private static final String TAG_ACTION_EVALUATE = "Evaluate";
   private static final String TAG_ACTION_CLEAR = "Clear";
   private static final String TAG_TOOL_WIRESHARK = "WireShark";
   private static final String TAG_TOOL_JPCAPDUMPER = "JpcapDumper";

   private String[ ] fileItems = new String[] { 
      TAG_FILE_OPEN, 
      TAG_FILE_EXIT,
   };
   private String[ ] editItems = new String[] {
      TAG_ACTION_ANALYZE,
      TAG_ACTION_EVALUATE,
      TAG_ACTION_CLEAR,
   };
   private String[ ] toolItems = new String[] {
      TAG_TOOL_WIRESHARK,
      TAG_TOOL_JPCAPDUMPER,
   };
   private char[] fileShortcuts = { 'O', 'X' };
   private char[] editShortcuts = { 'A','E','C' };
   private char[] toolShortcuts = { 'W','J' };

   private JMenuBar menuBar;
   private JTextField pcapTextField;
   private JTextField wireSharkTextField;

   private JSplitPane splitPane;
   private JTabbedPane tabbedPane;
   private TracePanel sipTracePanel;
   private TracePanel pttTracePanel;
   private PacketMonitorController pmController;
   private MeasurementTable measurementTable;

   private int runTestNumber = 0;
   private MessageCapturer capturer;
   private List<EndPoint> endPointList;
   private JCheckBoxMenuItem showAllPttCheckBox;  
   private JCheckBoxMenuItem showPttHeaderCheckBox;  
   private JCheckBoxMenuItem udpPortCheckBox;
   private JCheckBoxMenuItem validateInputCheckBox; 

   public static void showln(String s) { System.out.println(s); }

   // accessor
   public JMenuBar getJMenuBar() {
      return menuBar;
   }
   public JTabbedPane getJTabbedPane() {
      return tabbedPane;
   }

   // constructor
   public TraceAnalyzerGUI()
      throws PeerUnavailableException, IOException
   {
      capturer = new MessageCapturer();
      menuBar = createJMenuBar();
      pcapTextField = new JTextField( );
      wireSharkTextField = new JTextField( WIRESHARK_EXE);

      setLayout( new BorderLayout());

      tabbedPane = new JTabbedPane();
      tabbedPane.setBorder(BorderFactory.createTitledBorder("Test Traces"));

      splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
      splitPane.setTopComponent(createEndPointPanel());
		splitPane.setBottomComponent( tabbedPane);
      splitPane.setOneTouchExpandable(true);
      splitPane.setDividerLocation(0.25);
      splitPane.setDividerSize(7);
      add(splitPane, BorderLayout.CENTER);
   }

   public EndPointPanel createEndPointPanel() 
      throws IOException
   {
      String pcapFile = pcapTextField.getText();
      if( pcapFile==null || pcapFile.length()==0) {
         return new EndPointPanel();
      }
      capturer.processPcapFile( pcapFile);

      checkUDPPortRange();
      endPointList = capturer.getTargetList();
      return new EndPointPanel( pcapFile, endPointList);
   }

   private JMenuBar createJMenuBar()
   {
      JMenuItem item;
      JMenu fileMenu = new JMenu("File");
      JMenu editMenu = new JMenu("Action");
      JMenu configMenu = new JMenu("Config");
      JMenu toolMenu = new JMenu("Tool");
      ActionListener printListener = this;

      // setup File menus with mnemonics
      for (int i=0; i < fileItems.length; i++)
      {
         item = new JMenuItem(fileItems[i]);
         item.setAccelerator(KeyStroke.getKeyStroke(fileShortcuts[i],
               Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
         item.addActionListener(printListener);
         fileMenu.add(item);
      }

      // setup Action menus with keyboard accelerators
      //---------------------------------------------------------
      for (int i=0; i < editItems.length; i++) {
         item = new JMenuItem(editItems[i]);
         item.setAccelerator(KeyStroke.getKeyStroke(editShortcuts[i],
              Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
         item.addActionListener(printListener);
         editMenu.add(item);
      }
      // Insert a separator in Action menu in Position 1 after "Analyzer".
      //editMenu.insertSeparator(1);

      // setup Config menus
      //---------------------------------------------------------
      showAllPttCheckBox = new JCheckBoxMenuItem("Show all PTT");
      configMenu.add( showAllPttCheckBox);
      showAllPttCheckBox.addActionListener(printListener);

      showPttHeaderCheckBox = new JCheckBoxMenuItem("Show PTT Header");
      configMenu.add( showPttHeaderCheckBox);
      showPttHeaderCheckBox.addActionListener(printListener);
      configMenu.addSeparator();

      udpPortCheckBox = new JCheckBoxMenuItem("Open UDP Port range");
      configMenu.add( udpPortCheckBox);
      udpPortCheckBox.addActionListener(printListener);
      configMenu.addSeparator();      
      validateInputCheckBox = new JCheckBoxMenuItem("Validate Input Data");
      configMenu.add( validateInputCheckBox);
      validateInputCheckBox.addActionListener(printListener);

     /*** save for future
      configMenu.addSeparator();
      ButtonGroup buttonGroup = new ButtonGroup();
      configMenu.add(item = new JRadioButtonMenuItem("Radio 1"));
      item.addActionListener(printListener);
      buttonGroup.add(item);
      configMenu.add(item = new JRadioButtonMenuItem("Radio 2"));
      item.addActionListener(printListener);
      buttonGroup.add(item);
      item.addActionListener(printListener);
      ***/

      // setup Tool menus with keyboard accelerators
      //---------------------------------------------------------
      for (int i=0; i < toolItems.length; i++) {
         item = new JMenuItem(toolItems[i]);
         item.setAccelerator(KeyStroke.getKeyStroke(toolShortcuts[i],
            Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
         item.addActionListener(printListener);
         toolMenu.add(item);
      }

      // setup menubar
      //---------------------------------------------------------
      JMenuBar menuBar = new JMenuBar();
      menuBar.add(fileMenu);
      menuBar.add(editMenu);
      menuBar.add(configMenu);
      menuBar.add(toolMenu);
      return menuBar;
   }

   public void getSipPttTrace(ISSIConfigManager configMgr, String pcapFile)
      throws Exception
   {
      TopologyConfig systemTopology = configMgr.getSystemTopologyConfig();

      PacketMonitor.setTopologyConfig( systemTopology);     
      PacketMonitor packetMonitor = new PacketMonitor();

      boolean keepDup = showAllPttCheckBox.getState();
      packetMonitor.setKeepDuplicateMessage( keepDup);
      packetMonitor.readTraceFromFile( pcapFile);
      pmController = new LocalPacketMonitorController( packetMonitor);
      
      boolean errorFlag = pmController.fetchErrorFlag();   
      if (errorFlag)
      {
         String errorCause = pmController.fetchErrorString();
         JOptionPane.showMessageDialog( null,
               errorCause,
               "Capture Error",
               JOptionPane.ERROR_MESSAGE);
      }
      else
      {
         String sipTraces = pmController.fetchSipTraces();
         String pttTraces = pmController.fetchPttTraces();
        
         // save for xmlbeans
         //FileUtility.saveToFile("logs/sipmessages.xml", sipTraces);
         //FileUtility.saveToFile("logs/pttmessages.xml", pttTraces);
         
         renderSipPttTrace( configMgr, pcapFile, sipTraces, pttTraces, null);
         
         String result = pmController.fetchResult();
         //showln("getSipPttTraces: result=\n"+result);
         if (measurementTable == null)
            measurementTable = new MeasurementTable(new JFrame());
         measurementTable.setData(result);
      }
   }

   public void renderSipPttTrace( ISSIConfigManager configMgr,
         String pcapFile, String sipTraces, String pttTraces,
         Hashtable<String, HashSet<PttSessionInfo>> rfssSessionData)
   {

      String sipTab = "SIP-" + runTestNumber;
      String pttTab = "PTT-" + runTestNumber;
      String pcapFileName = pcapFile;
      
      JTabbedPane tabbedPane = getJTabbedPane();
      Collection<RfssData> rfssList = null;
      Hashtable<String, Color> colorMap = new Hashtable<String, Color>();
      try
      {
         pcapFileName = new File(pcapFile).getName();
         byte[] stringAsBytes = sipTraces.getBytes();
         ByteArrayInputStream bais = new ByteArrayInputStream(stringAsBytes);

         //NOTE: colorMap cannot be null
         TopologyConfig systemTopology = configMgr.getSystemTopologyConfig();   
         SipTraceLoader traceLoader = new SipTraceLoader( bais,
               rfssSessionData, colorMap, systemTopology);
               //null, colorMap, systemTopology);
         
         rfssList = traceLoader.getSortedRfssList();
         List<MessageData> records = traceLoader.getRecords();

//         StringBuffer sbuf = new StringBuffer();
//         for (MessageData messageData : records) {
//            sbuf.append("F" + messageData.getId() + ":\n");
//            sbuf.append(messageData.getData().trim() + "\n\n");
//         }
         String msgData = traceLoader.getMessageData();
         
         //showln("sysTopology=\n"+systemTopology.getDescription());
         //showln("rfssList=\n"+rfssList);

         // Create a new tabbed panel
         sipTracePanel = new TracePanel( null, tabbedPane,
               "", rfssList, records, colorMap);
         sipTracePanel.setTitle( sipTab+"-"+pcapFileName);
         sipTracePanel.setTestNumber( TAG_PCAP_TEST);
         sipTracePanel.setDataTextArea( TracePanel.DATA_ALL_MSG, msgData);

         // dump raw message in hex
         if( pcapFile != null && pcapFile.length() > 0)
         {
            String rawData = FileUtility.loadFromFileAsString( pcapFile);
            String sbufHex = HexDump.dump( rawData.getBytes(), 0, 0);
            sipTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sbufHex);
         }
         else
         {           
            sipTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sipTraces);
         }
         tabbedPane.add( sipTab, sipTracePanel);
         tabbedPane.setSelectedComponent(sipTracePanel);
         
      } catch (Exception ex) {
         String msg = "Error Fetching SIP Trace From Packet Monitor \n"
                + ex.getMessage();
         sipTracePanel.setDataTextArea( TracePanel.DATA_ERROR_MSG, msg);
      }

      try
      {
         if (pttTraces == null || pttTraces.length()==0) {
            return;
         }

//         byte[] stringAsBytes = pttTraces.getBytes();
//         ByteArrayInputStream bais = new ByteArrayInputStream(stringAsBytes);
//         PttTraceLoader traceLoader = new PttTraceLoader(bais, colorMap);
//         List<MessageData> records = traceLoader.getRecords();
//         String msgData = traceLoader.getMessageData();
         
         boolean keepHeader = showPttHeaderCheckBox.getState();
         String title = "*** PTT Messages ***";
         XmlPttmessages xmlmsg = new XmlPttmessages(colorMap);
         Pttmessages pttmsg = xmlmsg.loadPttmessages(pttTraces);
         xmlmsg.getPttMessageData(pttmsg, keepHeader);
         List<MessageData> records = xmlmsg.getRecords();
         String msgData = xmlmsg.toISSIString( title, pttmsg, keepHeader);

         // Create a new tabbed panel
         pttTracePanel = new TracePanel( null, tabbedPane,
               "", rfssList, records, colorMap);

         pttTracePanel.setTitle( pttTab+"-"+pcapFileName);
         pttTracePanel.setTestNumber( TAG_PCAP_TEST);
         pttTracePanel.setDataTextArea( TracePanel.DATA_ALL_MSG, msgData);
         
         //String sbufHex = HexDump.toHex( stringAsBytes, 16);
         //pttTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, sbufHex);
         pttTracePanel.setDataTextArea( TracePanel.DATA_RAW_MSG, pttTraces);
         
         tabbedPane.add( pttTab, pttTracePanel);
         tabbedPane.setSelectedComponent( pttTracePanel);

      } 
      catch (Exception ex)
      {
         String msg = "Error Fetching PTT Trace From Packet Monitor \n"
                      + ex.getMessage();
         pttTracePanel.setDataTextArea( TracePanel.DATA_ERROR_MSG, msg);
      }
   }
   
   public List<EndPoint> filterEndPoint(List<EndPoint> epList)
   {
      List<EndPoint> list = new ArrayList<EndPoint>();
      for( EndPoint ep: epList) {
         if( ep.getEnabled()) {
            list.add( ep);
         }
      }
      return list;
   }

   public String generateStartupProperties( String pcapFile)
      throws Exception
   {
      // Keep only the enabled RFSS
      List<EndPoint> epList = filterEndPoint(endPointList);
      //showln("filterEndPoint():\n"+ epList);
     
      // generate the config and properties files     
      ISSIXmlConfigurator config = new ISSIXmlConfigurator();
      String outProp = config.generateSystemTopology( pcapFile, epList);
      return outProp;
   }

   public void checkUDPPortRange()
   {
      boolean state = udpPortCheckBox.getState();
      if( state )
      {
         int[] ports = new int[] { 1, 32765 };
         capturer.setPortsRange( ports);
      } 
      else {
         capturer.setPortsRange( null);
      }
   }
   
   public void validateEndPoint()
   {
      boolean state = validateInputCheckBox.getState();
      if( !state )
         return;
      System.out.println("validateEndPoint: ...");
      for( EndPoint ep: endPointList)
      {
         String domainName = ep.getDomainName();

         // validate the domain name
         EndPointHelper.decodeDomainName( domainName);
      }     
   }

   // implementation of ActionListener
   //-------------------------------------------------------------
   public void actionPerformed(ActionEvent event)
   {
      String xcmd = event.getActionCommand();
      //showln("\n====================================");
      //showln("Menu item [" + xcmd + "] was pressed.");

      String userdir = System.getProperty( "user.dir");
      if( TAG_FILE_EXIT.equals(xcmd)) {
         // all done
         System.exit(0);
      }
      else if( TAG_FILE_OPEN.equals(xcmd)) {
         // Open pcap file
         JFileChooser fc = new JFileChooser( userdir);
         FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "PCAP file", "pcap");
         fc.setFileFilter( filter);

         int ret = fc.showOpenDialog(null);
         if( ret == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            if( file != null) {
               pcapTextField.setText( file.getAbsolutePath());
               System.out.println( file.getAbsolutePath());
               try { 
                  splitPane.setTopComponent(createEndPointPanel());
                  splitPane.setDividerLocation(0.25);
                  updateUI();
               } catch(Exception ex) { 
                  logger.debug("Error in open pcap file: "+ex);
                  JOptionPane.showMessageDialog( null,
                        "Error in opening pcap file:\n" + ex,
                        "File Open Error",
                        JOptionPane.ERROR_MESSAGE);
               }
            }
         }
      }
      //-----------------------------------
      else if( TAG_ACTION_ANALYZE.equals(xcmd))
      {
         runTestNumber++;
         String pcapFile = pcapTextField.getText();

         ISSIConfigManager configMgr = null;
         try {
            
            validateEndPoint();

            String startupFile = generateStartupProperties( pcapFile);
            // for now use existing code to plot traces
            configMgr = new ISSIConfigManager(startupFile);
            getSipPttTrace( configMgr, pcapFile);
         }
         catch(Exception ex) {
            JOptionPane.showMessageDialog( null,
               "Error in analyzing traces:\n" + ex,
               "Trace Analysis Error",
               JOptionPane.ERROR_MESSAGE);
         }
      }
      else if( TAG_ACTION_EVALUATE.equals(xcmd))
      {
         try {
            if (measurementTable == null)
               measurementTable = new MeasurementTable(new JFrame());
            measurementTable.showTable();
         }
         catch(Exception ex) {
            JOptionPane.showMessageDialog( null,
                  "Error in fetching measurement results:\n" + ex,
                  "Trace Measurements Error",
                  JOptionPane.ERROR_MESSAGE);          
         }
      }
      else if( TAG_ACTION_CLEAR.equals(xcmd))
      {
         getJTabbedPane().removeAll();
         runTestNumber = 0;
      }
      //-----------------------------------
      else if( TAG_TOOL_WIRESHARK.equals(xcmd))
      {
         // popup file chooser to define WireShark.exe
         String loc = wireSharkTextField.getText();
         JFileChooser fc = new JFileChooser( loc);
         FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "WireShark executable file", "exe");
         fc.setFileFilter( filter);
         try {
            fc.setSelectedFile( new File(loc));
         } catch(Exception ex) { }

         int ret = fc.showOpenDialog(null);
         if( ret == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            if( file != null) {
               wireSharkTextField.setText( file.getAbsolutePath());
               System.out.println( file.getAbsolutePath());

               String cmd= wireSharkTextField.getText() +" " +pcapTextField.getText();
               Exec.exec( cmd);
            }
         }

         //String cmd= wireSharkTextField.getText() +" " +pcapTextField.getText();
         //Exec.exec( cmd);
      }
      else if( TAG_TOOL_JPCAPDUMPER.equals(xcmd))
      {
         String cmd= "java -jar " + JPCAPDUMPER_JAR;
         Exec.exec( cmd);
      }
   }

   //=============================================================
   public static void main(String[] args) throws Exception
   {
      JFrame frame = new JFrame("TraceAnalyzerGUI - V1.2");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setIconImage(new ImageIcon(ISSILogoConstants.ISSI_TESTER_LOGO).getImage());

      TraceAnalyzerGUI panel = new TraceAnalyzerGUI();
      frame.setJMenuBar( panel.getJMenuBar());
      frame.getContentPane().add(panel);
      frame.setSize( 900, 740);
      frame.setVisible(true);
   }
}
