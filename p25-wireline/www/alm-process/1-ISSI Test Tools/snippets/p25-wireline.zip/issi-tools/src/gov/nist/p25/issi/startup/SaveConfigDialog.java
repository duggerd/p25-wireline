package gov.nist.p25.issi.startup;

import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

public class SaveConfigDialog {
	
	class SaveButtonActionListener implements ActionListener {
		public SaveButtonActionListener(ConfigTableModel tableModel,
				ISSITesterConfiguration config, TopologyConfig topologyConfig) {

			try {

				if (tableModel.getData("TesterTopology") != null) {
					String testerConfigString = config.toString();
					String fileName = tableModel
							.getDataAsString("TesterTopology");
					File file = new File(fileName);
					FileWriter fw = new FileWriter(file);
					PrintWriter pw = new PrintWriter(fw);
					pw.println(testerConfigString);
					pw.close();

				}

				if (tableModel.getData("SystemTopology") != null) {
					String configString = topologyConfig.exportSystemTopology();
					String fileName = tableModel
							.getDataAsString("SystemTopology");
					File file = new File(fileName);
					FileWriter fw = new FileWriter(file);
					PrintWriter pw = new PrintWriter(fw);
					pw.println(configString);
					pw.close();

				}

				if (tableModel.getData("GlobalTopology") != null) {
					String configString = topologyConfig.exportGlobalTopology();
					String fileName = tableModel
							.getDataAsString("GlobalTopology");
					File file = new File(fileName);
					FileWriter fw = new FileWriter(file);
					PrintWriter pw = new PrintWriter(fw);
					pw.println(configString);
					pw.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
		}
	}

	public SaveConfigDialog(ClusterConfigurationEditor clusterManager,
			String systemTopologyFileName, String globalTopologyFileName,
			String testerTopologyFileName) {

		ConfigTableModel tableModel = new ConfigTableModel("Save configuration");
		JTable jtable = new JTable(tableModel);

		jtable.setCellSelectionEnabled(true);
		TableColumn col = jtable.getColumnModel().getColumn(1);
		col.setPreferredWidth(400);
		col.setCellRenderer(new MyTableCellRenderer(tableModel));

		col = jtable.getColumnModel().getColumn(0);
		col.setPreferredWidth(200);

		tableModel.setData("SystemTopology", systemTopologyFileName);
		tableModel.setData("GlobalTopology", globalTopologyFileName);
		tableModel.setData("TesterTopology", testerTopologyFileName);

		JDialog dialog = new JDialog(clusterManager.getJFrame());
		dialog.setTitle("Save configuration files as ... ");

		dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Container contentPane = dialog.getContentPane();

		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

		contentPane.add(jtable);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout());
		JButton jbutton = new JButton("Save");
		buttonPanel.add(jbutton);

		jbutton.addActionListener(new SaveButtonActionListener(tableModel,
				clusterManager.getTesterConfig(), clusterManager
						.getTopologyConfig()));
		contentPane.add(buttonPanel);

		Rectangle rectangle = contentPane.getBounds();
		System.out.println("Rect = " + rectangle);

		int width = clusterManager.getJFrame().getWidth() / 2;
		int height = clusterManager.getJFrame().getHeight() / 2;
		rectangle.setLocation(clusterManager.getJFrame().getX() + width,
				clusterManager.getJFrame().getY() + height);

		rectangle.width = 600;
		dialog.setBounds(rectangle);
		dialog.setAlwaysOnTop(true);
		dialog.pack();

		dialog.setModal(true);
		dialog.setVisible(true);

	}

}
