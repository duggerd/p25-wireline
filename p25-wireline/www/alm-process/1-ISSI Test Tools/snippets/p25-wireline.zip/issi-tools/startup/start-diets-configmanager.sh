#!/bin/sh
$JAVA_HOME/bin/java -DclassName=gov.nist.p25.issi.startup.DietsStartup -jar diets-1.0.rc2.jar
