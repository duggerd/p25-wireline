//
package gov.nist.p25.issi.p25body.serviceprofile;

public enum GroupCallPermissionType {

   NONE(0, "No group permission","None"), 
   NON_EMERGENCY(1,
      "Non emergency group call permission","NonEmergency"),
   EMERGENCY(2,
      "Emergency group call permission","Emergency"),
   EMERGENCY_AND_NON_EMERGENCY(3,
      "Emergency and non-emergency permission","EmergencyAndNonEmergency");

   /*
    * ("None"|"NonEmergency" | "Emergency" |
             * "EmergencyAndNonEmergency" )
    */
   private int intValue;
   private String description;
   private String shortName;

   GroupCallPermissionType(int val, String descr, String shortName) {
      this.intValue = val;
      this.description = descr;
      this.shortName = shortName;
   }

   public int getIntValue() {
      return intValue;
   }

   public static GroupCallPermissionType getInstance(int intVal) {
      for (GroupCallPermissionType p : values()) {
         if (p.intValue == intVal)
            return p;
      }
      throw new IllegalArgumentException("Bad input arg: " + intVal);
   }

   @Override
   public String toString() {
      return description;
   }

   public static GroupCallPermissionType getInstance(String value) {
      for ( GroupCallPermissionType gcType : GroupCallPermissionType.values()) {
         if ( value.equals(gcType.shortName)) return gcType;
      }
      throw new IllegalArgumentException("Bad input arg: " + value);
   }

}
