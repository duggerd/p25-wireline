//
package gov.nist.p25.issi.packetmonitor;

import gov.nist.p25.issi.constants.DietsConfigProperties;
import gov.nist.p25.issi.issiconfig.PacketMonitorWebServerAddress;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.p25body.ContentList;
import gov.nist.p25.issi.p25payload.ISSIPacketType;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfigurationParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.text.ParseException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Properties;

import javax.sdp.MediaDescription;
import javax.sdp.SdpFactory;
import javax.sdp.SessionDescription;
import javax.sip.SipFactory;
import javax.sip.header.FromHeader;
import javax.sip.header.CallIdHeader;
import javax.sip.header.ToHeader;
import javax.sip.header.CSeqHeader;
import javax.sip.header.ContentTypeHeader;
import javax.sip.header.ViaHeader;
import javax.sip.message.MessageFactory;
import javax.sip.message.Request;
import javax.sip.message.Response;

import jpcap.JpcapCaptor;
import jpcap.NetworkInterface;
import jpcap.NetworkInterfaceAddress;
import jpcap.PacketReceiver;
import jpcap.packet.Packet;
import jpcap.packet.UDPPacket;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;
import org.mortbay.http.HttpContext;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.servlet.ServletHandler;

/**
 * This class implements an ISSI packet monitor.
 * 
 * @author mranga@nist.gov
 * @author steveq@nist.gov
 * @author niepin@nist.gov
 * @version $Revision: 1.61 $, $Date: 2008/04/07 04:34:47 $
 * @since 1.0
 */
public class PacketMonitor implements PacketReceiver {

   public static Logger logger = Logger.getLogger(PacketMonitor.class);
   static {
      try {
         logger.addAppender(new FileAppender(new SimpleLayout(),
               "logs/packetdebug.txt"));
         logger.setLevel(Level.DEBUG);
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
   public static void showln(String s) { System.out.println(s); }
   
   private static ISSITesterConfiguration configurations;   
   private static PacketMonitor currentInstance;
   private static NetworkInterface networkInterface;
   private static JpcapCaptor jpcap;

   public static boolean isEnabled = true;

   int packetNumber;
   private LinkedList<CapturedSipMessage> sipMessages = null;
   private Hashtable<String, MediaSession> pendingSessions;
   private HashSet<EndPoint> sipAddresses;
   private volatile LinkedList<CapturedPacket> capturedPackets;
   private Hashtable<String, MediaSession> pttSessionsByDestination;

   Hashtable<String, String> transactionTable;
   LinkedHashMap<String, LinkedList<CapturedSipMessage>> inviteTransactions;
   LinkedHashMap<String, LinkedList<CapturedSipMessage>> ackDialog;
   LinkedHashMap<Integer, CapturedPttMessage> pttSessions;

   private MessageFactory messageFactory;

   static TopologyConfig topologyConfig;

   private static MonitorWrapper monitorWrapper;
   private static PacketAnalyzer packetAnalyzer;
   private static HttpContext httpContext;
   private static Server httpServer;
   private static String testerConfigFile;
   private static Thread monitorThread;
   private static boolean configured;

   boolean errorFlag;
   String errorString;
   
   // M1017 Keep duplicate IMBE messages
   private boolean keepDuplicateMessage = false;
   public boolean getKeepDuplicateMessage() {
      return keepDuplicateMessage;
   }
   public void setKeepDuplicateMessage(boolean bflag) {
      keepDuplicateMessage = bflag;
   }
   
   // /////////////////////////////////////////////////////////////////////
   // Static configuration method.
   // /////////////////////////////////////////////////////////////////////

   public static void setTopologyConfig(TopologyConfig topologyConfig) {
      PacketMonitor.topologyConfig = topologyConfig;
   }

   public static void clear() {
      monitorWrapper.setActualMonitor( null);
   }

   /**
    * Check the local IP interfaces on the current machine and open the
    * applicable ones for packet capture. This method consults the tester
    * configuration file to see whether a packet monitor should be started on
    * the current machine and opens the applicable interfaces for using pacap.
    * 
    * @param testerConfig
    * @throws Exception
    */
   private static void configureInterfaces(ISSITesterConfiguration testerConfig)
         throws Exception {

      if (!isEnabled)
         return;

      jpcap.NetworkInterface[] devices = JpcapCaptor.getDeviceList();

      System.out.println("*************************************************");
      System.out.println("************ AVAILABLE INTERFACES ***************");
      System.out.println("*************************************************");

      for (int i = 0; i < devices.length; i++) {
         System.out.println(i + ": " + devices[i].name + "("
               + devices[i].description + ")");
         System.out.println("\tData link:" + devices[i].datalink_name + "("
               + devices[i].datalink_description + ")");
         System.out.print("\tMAC address:");

         for (byte b : devices[i].mac_address)
            System.out.print(Integer.toHexString(b & 0xff) + ":");

         System.out.println();

         for (NetworkInterfaceAddress a : devices[i].addresses)
            System.out.println("\tAddress:" + a.address + " " + a.subnet
                  + " " + a.broadcast);
      }

      PacketMonitorWebServerAddress packetMonitor = null;

      for (jpcap.NetworkInterface device : devices) {
         if (packetMonitor != null)
            break;
         PacketMonitor.networkInterface = device;
         for (int k = 0; k < device.addresses.length; k++) {
            System.out.println("Checking the address "
                  + device.addresses[k].address.getHostAddress());
            if ((packetMonitor = testerConfig
                  .getPacketMonitor(device.addresses[k].address
                        .getHostAddress())) != null)
               break;
         }

      }

      if (packetMonitor == null) {
         System.out.println("Here are the configured addresses ");
         for (PacketMonitorWebServerAddress config : testerConfig
               .getPacketMonitors()) {
            System.out.println("Host = " + config.getIpAddress());
            System.out.println("Port = " + config.getHttpPort());
         }

         testerConfig.printPacketMonitorTable();
         System.out
               .println("No Packet Montors found for configuration file "
                     + PacketMonitor.testerConfigFile);
         return;
      }
      if (PacketMonitor.monitorThread == null) {

         jpcap = JpcapCaptor.openDevice(networkInterface, 2000, true, 20);
         monitorWrapper = new MonitorWrapper();
         PacketMonitor.monitorThread = new Thread(new JPCapRunner(
               monitorWrapper, jpcap));
         PacketMonitor.configured = true;
         monitorThread.start();
      }
      Thread.sleep(1000);

   }

   /**
    * Return true if the PacketMonitor is configured.
    * 
    * @return true if the packet monitor is configured.
    */

   public static boolean isConfigured() {
      return PacketMonitor.configured;
   }

   /**
    * Set the unconfigured flag to false and stop the http context to talk to
    * the packet monitor.
    * 
    * @throws Exception
    */
   public static void unconfigure() throws Exception {
      // monitorThread.interrupt();
      // jpcap.close();
      if (PacketMonitor.isConfigured()) {
         PacketMonitor.configured = false;
         httpContext.stop();
         httpServer.removeContext(httpContext);
      }
   }

   // ////////////////////////////////////////////////////////////////////
   // Inner classes
   // ///////////////////////////////////////////////////////////////////
   enum PacketType {
      SIPREQUEST, SIPRESPONSE, SIPMESSAGE, PTT
   }

   /**
    * An end point represents an IP address and port where an RFSS gets SIP
    * Signaling.
    */
   public class EndPoint {
      String host;
      int port;

      public EndPoint(String host, int port) {
         this.host = host;
         this.port = port;

      }

      @Override
      public boolean equals(Object that) {
         return this.getClass().equals(that.getClass())
               && this.host.equals(((EndPoint) that).host)
               && this.port == ((EndPoint) that).port;

      }

      @Override
      public int hashCode() {
         return host.hashCode();
      }

      @Override
      public String toString() {
         return host + ":" + port;
      }

   }

   public PacketMonitor() {

      try {
         this.transactionTable = new Hashtable<String, String>();
         this.inviteTransactions = new LinkedHashMap<String, LinkedList<CapturedSipMessage>>();
         this.ackDialog = new LinkedHashMap<String, LinkedList<CapturedSipMessage>>();
         this.pttSessions = new LinkedHashMap<Integer, CapturedPttMessage>();
         this.pendingSessions = new Hashtable<String, MediaSession>();
         this.sipMessages = new LinkedList<CapturedSipMessage>();
         this.sipAddresses = new HashSet<EndPoint>();
         this.capturedPackets = new LinkedList<CapturedPacket>();
         this.pttSessionsByDestination = new Hashtable<String, MediaSession>();
         SipFactory sipFactory = SipFactory.getInstance();
         sipFactory.setPathName("gov.nist");
         this.messageFactory = sipFactory.createMessageFactory();
         packetAnalyzer = new PacketAnalyzer(this);

         Collection<RfssConfig> rfssCollection = topologyConfig
               .getRfssConfigurations();

         for (RfssConfig rfssConfig : rfssCollection) {

            String address = rfssConfig.getIpAddress();
            int port = rfssConfig.getSipPort();

            EndPoint hostPort = new EndPoint(address, port);
            this.sipAddresses.add(hostPort);

         }
         PacketMonitor.currentInstance = this;
      } catch (Exception ex) {
         logger.fatal("Unexpected exception parsing configuraiton file", ex);
         // System.exit(0);
      }
   }

   // ////////////////////////////////////////////////////////////////////
   // Private methods
   // ////////////////////////////////////////////////////////////////////

   private static void initializeContexts(Server httpServer) throws Exception {

      if (!PacketMonitor.isEnabled)
         throw new Exception("Packet Monitor is not enabled!");
      PacketMonitor.httpServer = httpServer;
      // PacketMonitor.packetAnalyzer = new
      // PacketAnalyzer(PacketMonitor.currentInstance);
      httpContext = new HttpContext();
      httpContext.setContextPath("/sniffer/*");
      ServletHandler servletHandler = new ServletHandler();
      httpContext.addHandler(servletHandler);
      servletHandler.addServlet("siptrace", "/siptrace", SipTraceGetter.class
            .getName());
      servletHandler.addServlet("ptttrace", "/ptttrace", PttTraceGetter.class
            .getName());
      servletHandler.addServlet("result", "/result", ResultGetter.class
            .getName());
      servletHandler.addServlet("control", "/controller",
            MonitorController.class.getName());
      httpServer.addContext(httpContext);
      httpContext.start();

   }

   // /////////////////////////////////////////////////////////////////////
   // Methods
   // /////////////////////////////////////////////////////////////////////

   /**
    * Starts the packet monitor. Call this after setting up the web server.
    * 
    */
   public static PacketMonitor startPacketMonitor(TopologyConfig testerConfig)
         throws Exception {
      logger.debug("Starting Packet Monitor ");

      PacketMonitor.topologyConfig = testerConfig;
      PacketMonitor packetMonitor = new PacketMonitor();
      PacketMonitor.currentInstance = packetMonitor;
      PacketMonitor.monitorWrapper.setActualMonitor( packetMonitor);
      httpContext.setAttribute("packetmonitor", packetMonitor);
      return packetMonitor;
   }
      
   /**
    * This method receives the raw Packet and stores them. At run time, there
    * is no time for packet sorting.
    * 
    */
   public synchronized void receivePacket(Packet packet) {
      if (!PacketMonitor.configured)
         return;
      // Raw capture of packet.
      if (packet instanceof UDPPacket) {
         CapturedPacket capturedPacket = new CapturedPacket(this, packet);
         this.capturedPackets.add(capturedPacket);

      }
   }

   /**
    * This method reads from a file and calls Receive packet iteratively.
    * 
    * @param fileName --
    *            the file name from which to read packets.
    * 
    */
   public void readTraceFromFile(String fileName) throws Exception {
      logger.debug("PacketMonitor : readTraceFromFile : " + fileName);
      JpcapCaptor captor = JpcapCaptor.openFile(fileName);
      Packet packet = captor.getPacket();
      while (packet != Packet.EOF) {
         if (packet instanceof UDPPacket) {
            logger.debug("got a packet ");
            CapturedPacket capturedPacket = new CapturedPacket(this, packet);
            this.capturedPackets.add(capturedPacket);
            
            // current TS + captured sec and micro-sec
            long ts = capturedPacket.getTimeStamp() + packet.sec*1000 + packet.usec/1000;
            capturedPacket.setTimeStamp( ts);
         }
         packet = captor.getPacket();
      }
      logger.debug("Done reading trace from file");
   }

   /**
    * This method sorts packets. It goes through the list of captured packets
    * pulls out the SIP Packets, identifies the SIP packets and from the SIP
    * packets, it pulls out the media sessions. It then associates the captured
    * PTT packets with the media sessions. This sorting step is done after the
    * packet capture is complete.
    * 
    * @param capturedPaket --
    *            the captured packet to sort.
    * 
    * @param packetType --
    *            the type of packet we are looking for.
    * 
    * 
    */
   public synchronized void sortPacket(CapturedPacket capturedPacket,
         PacketType packetType) {

      UDPPacket udpPacket = (UDPPacket) capturedPacket.getPacket();
      InetAddress destInetAddress = udpPacket.dst_ip;
      String host = destInetAddress.getHostAddress();
      int port = udpPacket.dst_port;
      EndPoint packetAddress = new EndPoint(host, port);

      byte[] data = udpPacket.data;

      logger.info("sortPacket: " + packetAddress  + " PacketType = " + packetType);
      logger.info("sortPacket : srcAddr " + udpPacket.src_ip.getHostAddress() +
		  " srcPort = " + udpPacket.src_port);

      /*if (errorFlag) {
         logger.error("Not sorting packet " + packetType
               + " because of previously detected error. ");
         return;
      }*/

      if (this.sipAddresses.contains(packetAddress)) {

         String messageString = new String(data);

         try {
            // SIP Responses start with the string SIP

            if ((!messageString.startsWith("SIP"))
                  && (packetType == PacketType.SIPREQUEST || 
                      packetType == PacketType.SIPMESSAGE)) {

               Request request = this.messageFactory
                     .createRequest(messageString);
               String transactionId = ((ViaHeader) request
                     .getHeader(ViaHeader.NAME)).getBranch();
               String radicalName = ((ViaHeader) (request
                     .getHeader(ViaHeader.NAME))).getHost();
               RfssConfig srcRfssConfig = topologyConfig
                     .getRfssConfig(radicalName);

               if (srcRfssConfig == null) {
                  logger.error("Could not find an RFSS configuration for "
                              + radicalName);
                  this.errorFlag = true;
                  return;
               }
               RfssConfig destinationRfss = topologyConfig.getRfssConfig(
                     host, port);
               if (destinationRfss == null) {
                  logger.error("Could not find an RFSS configuration for "
                              + host + " port " + port);
                  this.errorFlag = true;
                  return;
               }
               CapturedSipMessage captured = new CapturedSipMessage(this,
                     packetAddress, capturedPacket.getTimeStamp(), request);
               this.sipMessages.add(captured);

               // compute Dialog ID
               String fromTag = ((FromHeader) captured.getMesage()
                     .getHeader("From")).getTag();
               String toTag = ((ToHeader) captured.getMesage().getHeader(
                     "To")).getTag();
               String callid = ((CallIdHeader) captured.getMesage()
                     .getHeader("Call-ID")).getCallId();

               if (request.getMethod().equals(Request.INVITE)) {
                  // record INVITE transactions for measurements
                  if (!inviteTransactions.containsKey(transactionId))
                     this.inviteTransactions.put(transactionId,
                           new LinkedList<CapturedSipMessage>());

                  this.inviteTransactions.get(transactionId).add(captured);

                  byte[] contents = request.getRawContent();
                  if (contents == null) {
                     logger.error("Missing content in the INVITE");
                     errorFlag = true;
                     return;
                  }
                  SdpFactory sdpFactory = SdpFactory.getInstance();
                  try {
                     ContentTypeHeader contentTypeHeader = (ContentTypeHeader) request
                           .getHeader(ContentTypeHeader.NAME);
                     SessionDescription sdpAnnounce = null;
                     if (contentTypeHeader.getContentType().equals(
                           "application")
                           && contentTypeHeader.getContentSubType()
                                 .equals("sdp")) {
                        sdpAnnounce = sdpFactory
                              .createSessionDescription(new String(
                                    contents));
                     } else {
                        ContentList clist = ContentList
                              .getContentListFromMessage(request);
                        sdpAnnounce = clist.getSdpContent()
                              .getSessionDescription();
                     }
                     MediaDescription m = (MediaDescription) sdpAnnounce
                           .getMediaDescriptions(true).get(0);

                     String ipAddress = sdpAnnounce.getConnection()
                           .getAddress();

                     if (m.getConnection() != null) {
                        ipAddress = m.getConnection().getAddress();

                     }
                     EndPoint endPoint = new EndPoint(ipAddress, m
                           .getMedia().getMediaPort());

                     MediaSession pendingSession = new MediaSession(this,
                           endPoint);
                     pendingSession.owningRfss = destinationRfss;
                     pendingSession.remoteRfss = srcRfssConfig;
                     this.pttSessionsByDestination.put(endPoint
                           .toString(), pendingSession);

                     logger.info("add PttSession : " + endPoint);

                     this.pendingSessions.put(transactionId,
                           pendingSession);
                  } catch (Exception ex) {
                     logger.error("Error in parsing sdp ", ex);
                     logger.error("Here is the request ["
                           + messageString + "]");
                     this.errorFlag = true;
                     this.errorString = "Error in parsing sdp \n"
                           + "Here is the request [" + messageString
                           + "]";
                     return;
                  }
               } else if (request.getMethod().equals(Request.ACK)) {
                  // record ACK in the dialog
                  String dialogId = callid + fromTag + toTag;
                  if (ackDialog.containsKey(dialogId))
                     this.ackDialog.get(dialogId).add(captured);
               }
            } else if (messageString.startsWith("SIP")
                  && (packetType == PacketType.SIPRESPONSE || packetType == PacketType.SIPMESSAGE)) {

               Response response = this.messageFactory
                     .createResponse(messageString);
               CapturedSipMessage captured = new CapturedSipMessage(this,
                     packetAddress, capturedPacket.getTimeStamp(), response);
               //RfssConfig destinationRfss = topologyConfig.getRfssConfig(
               //      host, port);

               this.sipMessages.add(captured);

               // compute Dialog ID
               String fromTag = ((FromHeader) captured.getMesage()
                     .getHeader("From")).getTag();
               String toTag = ((ToHeader) captured.getMesage().getHeader(
                     "To")).getTag();
               String callid = ((CallIdHeader) captured.getMesage()
                     .getHeader("Call-ID")).getCallId();

               String method = ((CSeqHeader) response
                     .getHeader(CSeqHeader.NAME)).getMethod();
               if (response.getStatusCode() == Response.OK
                     && method.equals(Request.INVITE)) {
                  String transactionId = ((ViaHeader) response
                        .getHeader(ViaHeader.NAME)).getBranch();

                  // record INVITE transactions for measurements
                  if (inviteTransactions.containsKey(transactionId))
                     this.inviteTransactions.get(transactionId).add(
                           captured);

                  // record 200 OK in the dialog
                  String dialogId = callid + fromTag + toTag;
                  if (!ackDialog.containsKey(dialogId))
                     this.ackDialog.put(dialogId,
                           new LinkedList<CapturedSipMessage>());

                  this.ackDialog.get(dialogId).add(captured);

                  byte[] contents = response.getRawContent();
                  if (contents == null) {
                     logger.error("Missing content in the 200 OK ");
                     this.errorFlag = true;
                     this.errorString = "Error in parsing sdp \n"
                           + "Here is the response [" + messageString
                           + "]";

                     return;
                  }
                  SdpFactory sdpFactory = SdpFactory.getInstance();
                  try {
                     SessionDescription sdpAnnounce = null;
                     ContentTypeHeader contentTypeHeader = (ContentTypeHeader) response
                           .getHeader(ContentTypeHeader.NAME);
                     if (contentTypeHeader.getContentType().equals(
                           "application")
                           && contentTypeHeader.getContentSubType()
                                 .equals("sdp")) {
                        sdpAnnounce = sdpFactory
                              .createSessionDescription(new String(
                                    contents));
                     } else {
                        ContentList contentList = ContentList
                              .getContentListFromMessage(response);
                        sdpAnnounce = contentList.getSdpContent()
                              .getSessionDescription();
                     }
                     String ipAddress = sdpAnnounce.getConnection()
                           .getAddress();

                     MediaDescription m = (MediaDescription) sdpAnnounce
                           .getMediaDescriptions(true).get(0);

                     if (m.getConnection() != null) {
                        ipAddress = m.getConnection().getAddress();

                     }
                     EndPoint endPoint = new EndPoint(ipAddress, m
                           .getMedia().getMediaPort());
                     MediaSession session = this.pendingSessions
                           .get(transactionId);
                     if (session != null) {
                        session.setSource(endPoint);
                        MediaSession reversed = session.reverse();
                        reversed.destination = endPoint;
                        this.pttSessionsByDestination.put(endPoint
                              .toString(), reversed);
                        logger.info("process response : pttSession : "
                              + endPoint);
                     } else {
                        logger.error("Could not find transaction ID  "
                              + transactionId);
                        logger.error(this.pendingSessions.keySet());
                        this.errorFlag = true;
                        this.errorString = "Could not find transaction ID  "
                              + transactionId;
                        return;
                     }

                  } catch (Exception ex) {
                     this.errorFlag = true;
                     logger.error("Error in parsing sdp ", ex);
                     logger.error("Here is the response ["
                           + messageString + "]");
                  }
               }

            }
         } catch (ParseException ex) {
            logger.error("Error parsing message", ex);
            logger.error("Message : [" + messageString + "]");
         }

      } else if (this.pttSessionsByDestination.containsKey(packetAddress
            .toString())
            && packetType == PacketType.PTT) {
         logger.info("Adding PTT Packet headed for " + packetAddress);
         MediaSession session = this.pttSessionsByDestination
               .get(packetAddress.toString());
         CapturedPttMessage pttMsg = session.addPttMessage(data,
               capturedPacket.getTimeStamp());
         // store measurement required PTT messages
         if (pttMsg != null) {
            int type = pttMsg.p25Payload.getISSIPacketType().getPT();
            switch (type) {
            case ISSIPacketType.PTT_TRANSMIT_REQUEST:
            case ISSIPacketType.PTT_TRANSMIT_GRANT:
            case ISSIPacketType.PTT_TRANSMIT_START:
            case ISSIPacketType.HEARTBEAT_QUERY :
               if (!pttSessions.containsKey(type)) {
                  pttSessions.put(new Integer(type), pttMsg);
               }
               break;
            case ISSIPacketType.PTT_TRANSMIT_PROGRESS:
               logger.debug("PTT_TRANSMIT_PROGRESS SEEN");
               break;
            default:
               logger.debug("####Unknown PTT packet type: " + type);
               break;
            }

         }
      }  else {
         logger.debug("Dropping PTT packet " + packetAddress);
      }

   }

   /**
    * Get the accumlated SIP Messages and clear the SIP message list.
    * 
    * @return
    */
   public synchronized String getSipMessages() {
      logger.info("GetSipMessages" + this.capturedPackets.size());
      if (this.errorFlag) {
         logger.info("Cannot get SIP messages -- an error occured during capture.");
         return "";
      }
      this.sipMessages.clear();
      this.transactionTable.clear();
      this.inviteTransactions.clear();
      this.ackDialog.clear();
      this.pttSessionsByDestination.clear();
      for (CapturedPacket packet : this.capturedPackets) {
         this.sortPacket(packet, PacketType.SIPMESSAGE);
      }
      StringBuffer sbuf = new StringBuffer();
      for (CapturedSipMessage message : this.sipMessages) {
         sbuf.append(message.toString());
      }
      
      // Save to file for xmlbeans
//      try {
//         String xmlStr = "<sipmessages>\n"+sbuf.toString()+"\n</sipmessages>";
//         FileUtility.saveToFile("sipmessages.xml", xmlStr);
//      } catch(IOException ex) { }
      
      return sbuf.toString();
   }

   public synchronized String getPttMessages() {

      logger.info("GetPttMessages");
//showln("PM: getPttMessages(): capturedPackets.size="+capturedPackets.size());

      boolean incHex = true;
      StringBuffer sbuf = new StringBuffer();

      sipMessages.clear();
      inviteTransactions.clear();
      ackDialog.clear();
      pttSessionsByDestination.clear();
      if (errorFlag) {
         logger.info("Cannot get PTT Messages -- an error occured during capture");
         return "";
      }
      /*
       * for (CapturedPacket packet: capturedPackets) {
       * sortPacket(packet, PacketType.SIPREQUEST); }
       * for (CapturedPacket packet: this.capturedPackets) {
       * sortPacket(packet, PacketType.SIPRESPONSE); }
       */
      for (CapturedPacket packet: capturedPackets) {
         sortPacket(packet, PacketType.SIPMESSAGE);
      }
      logger.debug("pttSessionsByDestionation " + pttSessionsByDestination);

//showln("---------------------------");
//showln("PM: pttSessionsByDestination: "+pttSessionsByDestination);
//showln("---------------------------");
//showln("PM: values: "+pttSessionsByDestination.values());
//showln("---------------------------");
//
      for (CapturedPacket packet: capturedPackets) {
         sortPacket(packet, PacketType.PTT);
      }

      for (MediaSession mediaSession: pttSessionsByDestination.values()) {
         for (CapturedPttMessage capturedPacket: mediaSession.capturedPttMessages) {
//M2001
            sbuf.append(capturedPacket.toString(incHex));
         }
      }
      if (logger.isDebugEnabled())
         logger.debug("Returning " + sbuf);
      
      //showln("PM: getPttMessages(): sbuf=\n"+sbuf.toString());
      return sbuf.toString();
   }

   public synchronized String getResultTable() {
      logger.info("GetResultTable from PacketAnalyzer");
      if (this.errorFlag) {
         logger.info("Cannot get result -- an error occured during capture.");
         return "";
      }
      String result = packetAnalyzer.getResultString();
      this.inviteTransactions.clear();
      this.ackDialog.clear();
      packetAnalyzer.clear();

      return result;
   }

   public static int configure(Server httpServer, String configFileName)
         throws Exception {
      logger.info("Configuring Packet Montior");
      PacketMonitor.testerConfigFile = configFileName;
      PacketMonitor.configurations = new ISSITesterConfigurationParser(
            configFileName).parse();
      int count = 0;
      for (String ipAddress : configurations.getLocalAddresses()) {

         PacketMonitorWebServerAddress packetMonitorWebServerAddress = getConfigurations()
               .getPacketMonitor(ipAddress);
         if (packetMonitorWebServerAddress != null) {
            count++;
         }
      }
      if (count != 0) {
         PacketMonitor.configureInterfaces(configurations);
         PacketMonitor.initializeContexts(httpServer);
         PacketMonitor.configured = true;
      }
      return count;
   }

   public static PacketMonitor getCurrentInstance() {
      return currentInstance;
   }

   public static void setConfigurations(ISSITesterConfiguration configurations) {
      PacketMonitor.configurations = configurations;
   }

   public static ISSITesterConfiguration getConfigurations() {
      return configurations;
   }

   public boolean getErrorStatus() {
      return this.errorFlag;
   }

   public String getErrorMessage() {
      return this.errorString;
   }

   public void readTraceFromString(String fileName) throws Exception {
      jpcap = JpcapCaptor.openFile(fileName);
      jpcap.processPacket(-1, new MonitorWrapper(this));
   }

   /**
    * Use this method to start the packet monitor as a standalone monitoring
    * tool.
    */
   public static void main(String[] args) throws Exception {
      //String capfile = null;
      PropertyConfigurator.configure("log4j.properties");
      Properties props = new Properties();
      for (int i = 0; i < args.length; i++) {
         if (args[i].equals("-configuration")) {
            testerConfigFile = args[++i];
         } 
         else if (args[i].equals("-startup")) {
            String fileName = args[++i];
            InputStream inStream = new FileInputStream(new File(fileName));
            props.load(inStream);
         }
      }

      testerConfigFile = props.getProperty(
            DietsConfigProperties.DAEMON_CONFIG_PROPERTY, testerConfigFile);

      setConfigurations(new ISSITesterConfigurationParser(testerConfigFile)
            .parse());

      if (configurations == null)
         throw new Exception("missing required parameter -configuration   ");

      Server httpServer = new Server();
      configure(httpServer, testerConfigFile);
      httpServer.start();

   }
}
