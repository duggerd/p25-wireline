//
package gov.nist.p25.issi.setup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import gov.nist.p25.issi.issiconfig.DaemonWebServerAddress;
import gov.nist.p25.issi.issiconfig.GroupConfig;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.rfss.tester.ISSITesterConfiguration;

/**
 * Topology Configuration Helper.
 */
public class TopologyConfigHelper
{
   public static void showln(String s) { System.out.println(s); }

   private List<RfssConfigSetup> rfssList;
   private List<GroupConfigSetup> gcsList;
   private List<SuConfigSetup> scsList;
   private List<String> nameList;
   private Map<String,String> nameMap;

   // accessor
   public List<RfssConfigSetup> getRfssConfigSetupList() {
      return rfssList;
   }
   public List<GroupConfigSetup> getGroupConfigSetupList() {
      return gcsList;
   }
   public List<SuConfigSetup> getSuConfigSetupList() {
      return scsList;
   }
   public List<String> getRfssNameList() {
      return nameList;
   }
   public Map<String,String> getRfssNameMap()
   {
      return nameMap;
   }

   // constructor
   public TopologyConfigHelper()
   {
   }

   public List<String> getRfssNameList(TopologyConfig topologyConfig)
   {
      nameList = new ArrayList<String>();
      for (RfssConfig rfssConfig: topologyConfig.getRfssConfigurations())
      {
         String rname = rfssConfig.getRfssName();
         nameList.add( rname);
      }
      return nameList;
   }

   public void buildSetupLists(TopologyConfig topologyConfig)
   {
      HashMap<String,String> nodesMap = new HashMap<String, String>();
      String parent;
      String node;
 
      nameList = new ArrayList<String>();
      rfssList = new ArrayList<RfssConfigSetup>();
      scsList = new ArrayList<SuConfigSetup>();
      gcsList = new ArrayList<GroupConfigSetup>();

      // RFSS Configuration
      for (RfssConfig rfssConfig: topologyConfig.getRfssConfigurations())
      {
         String ipAddress = rfssConfig.getIpAddress();
         int port = rfssConfig.getSipPort();
         String rname = rfssConfig.getRfssName();
         int rid = rfssConfig.getRfssId();
         int wacnId = rfssConfig.getWacnId();
         int systemId = rfssConfig.getSystemId();
         boolean emulated = rfssConfig.isEmulated();

         RfssConfigSetup ep = new RfssConfigSetup(ipAddress,port,rname,
                  rid,systemId,wacnId,emulated);
         ep.setReference( rfssConfig);
         rfssList.add( ep);
         nameList.add( rname);

         nodesMap.put( rname, "RfssConfig:"+rid);
      }

      // GROUP Configuration
      for (GroupConfig groupConfig: topologyConfig.getGroupConfigurations())
      {
         String rname = groupConfig.getHomeRfss().getRfssName();
         parent = nodesMap.get( rname);
         if( parent==null) continue;

         String gname = groupConfig.getGroupName();
         int gid = groupConfig.getGroupId();
         //int gwacnId =  groupConfig.getSysConfig().getWacnId();
         //int gsystemId = groupConfig.getSysConfig().getSystemId();
         String grfss = groupConfig.getHomeRfss().getRfssName();

         // delay instantiation
         nodesMap.put( gname, "GroupConfig:"+gid);

         boolean firstName = true;
         StringBuffer gsu = new StringBuffer();
         for (Iterator<SuConfig> it= groupConfig.getSubscribers(); it.hasNext();)
         {
            SuConfig suConfig = it.next();

            String sname = suConfig.getSuName();
            int sid = suConfig.getSuId();
            int swacnId = suConfig.getWacnId();
            int ssystemId = suConfig.getSystemId();
            String homeRfss = suConfig.getHomeRfss().getRfssName();
            int homeRfssId = suConfig.getHomeRfss().getRfssId();
            String servRfss = suConfig.getInitialServingRfss().getRfssName();
            boolean emulated = suConfig.isEmulated();

            SuConfigSetup scs = new SuConfigSetup(sname,sid,homeRfss,servRfss,
                  homeRfssId,ssystemId,swacnId,emulated);
            scs.setReference( suConfig);
            scsList.add( scs);

            // group-su
            if( firstName) {
               firstName = false;
            } else {
               gsu.append(",");
            }
            gsu.append(sname);
            nodesMap.put( sname, "SuConfig:"+sid);
         }

         GroupConfigSetup gcs = new GroupConfigSetup(gname,gid,grfss,gsu.toString());
         gcs.setReference( groupConfig);
         gcsList.add( gcs);
      }

      // SU Configuration
      for (SuConfig suConfig: topologyConfig.getSuConfigurations())
      {
         String rname = suConfig.getHomeRfss().getRfssName();
         parent = nodesMap.get( rname);
         if( parent==null) continue;

         String sname = suConfig.getSuName();

         // check if it is in group
         node = nodesMap.get( sname);
         if( node != null) continue;

         int sid = suConfig.getSuId();
         int swacnId = suConfig.getWacnId();
         int ssystemId = suConfig.getSystemId();
         String homeRfss = suConfig.getHomeRfss().getRfssName();
         int homeRfssId = suConfig.getHomeRfss().getRfssId();
         String servRfss = suConfig.getInitialServingRfss().getRfssName();
         boolean emulated = suConfig.isEmulated();

         SuConfigSetup scs = new SuConfigSetup(sname,sid,homeRfss,servRfss,
               homeRfssId,ssystemId,swacnId,emulated);
         scs.setReference( suConfig);
         scsList.add( scs);

         nodesMap.put( rname, "SuConfig:"+sid);
      }
   }

   public boolean reconcile( List<RfssConfigSetup> rfssList,
      List<GroupConfigSetup> gcsList, List<SuConfigSetup> scsList) 
      throws IllegalArgumentException
   {
      showln("rfssList="+rfssList.size());
      showln("gcsList="+gcsList.size());
      showln("scsList="+scsList.size());

      // process chnages in RfssConfig
      if( rfssList != null)
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         RfssConfig rfssConfig = (RfssConfig)rfssSetup.getReference();
         String ipAddress = rfssConfig.getIpAddress();
         int port = rfssConfig.getSipPort();
         String rname = rfssConfig.getRfssName();
         int rid = rfssConfig.getRfssId();
         int wacnId = rfssConfig.getWacnId();
         int systemId = rfssConfig.getSystemId();
         boolean emulated = rfssConfig.isEmulated();

         rfssConfig.setIpAddress( rfssSetup.getIpAddress());
         rfssConfig.setSipPort( rfssSetup.getPort());
         rfssConfig.setRfssId( rfssSetup.getId());
         rfssConfig.setEmulated( rfssSetup.getEmulated());
         rfssConfig.setWacnId( rfssSetup.getWacnId());
         rfssConfig.setSystemId( rfssSetup.getSystemId());

         // propagate RfssName changes
         String newRfssName = rfssSetup.getName();
         if( !rname.equals( newRfssName)) {
            // fixup Group and SU
            rfssConfig.setRfssName( newRfssName);
         }
      }

     /*******  NOT USED
      if( gcsList != null)
      for( GroupConfigSetup gcsSetup: gcsList)
      {
         GroupConfig groupConfig = (GroupConfig)gcsSetup.getReference();

         String gname = groupConfig.getGroupName();
         int gid = groupConfig.getGroupId();
         int gwacnId =  groupConfig.getSysConfig().getWacnId();
         int gsystemId = groupConfig.getSysConfig().getSystemId();
         String grfss = groupConfig.getHomeRfss().getRfssName();

         showln("GROUP-homeRfss="+grfss);
         showln("GROUP-gwacnId="+gwacnId);
         showln("GROUP-gsystemId="+gsystemId);

         // only homeRfss
         //groupConfig.getHomeRfss().setRfssName( gcsSetup.getHomeRfssName());
      }

      if( scsList != null)
      for( SuConfigSetup scsSetup: scsList)
      {
         SuConfig suConfig = (SuConfig)scsSetup.getReference();
         int sid = suConfig.getSuId();
         int swacnId = suConfig.getWacnId();
         int ssystemId = suConfig.getSystemId();
         String homeRfss = suConfig.getHomeRfss().getRfssName();
         int homeRfssId = suConfig.getHomeRfss().getRfssId();
         String servRfss = suConfig.getInitialServingRfss().getRfssName();
         int servRfssId = suConfig.getInitialServingRfss().getRfssId();
         boolean emulated = suConfig.isEmulated();

         showln("SU-homeRfss="+homeRfss);
         showln("SU-servRfss="+servRfss);

         // only homeRfss and ServingRfss    
         //suConfig.getHomeRfss().setRfssName( scsSetup.getHomeRfssName());
         //suConfig.getInitialServingRfss().setRfssName( scsSetup.getServingRfssName());
      }
      *******/
      return true;
   }

   public boolean reconcileTesterConfiguration( ISSITesterConfiguration testerConfig,
      List<RfssConfigSetup> rfssList)
   {
      nameMap = getRfssNameMap( rfssList);

      // process changes in RfssConfig
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         RfssConfig rfssConfig = (RfssConfig)rfssSetup.getReference();
         // save a copy
         String ipAddress = rfssConfig.getIpAddress();
         int port = rfssConfig.getSipPort();
         String rname = rfssConfig.getRfssName();
         int rid = rfssConfig.getRfssId();
         int wacnId = rfssConfig.getWacnId();
         int systemId = rfssConfig.getSystemId();
         boolean emulated = rfssConfig.isEmulated();

         rfssConfig.setIpAddress( rfssSetup.getIpAddress());
         rfssConfig.setSipPort( rfssSetup.getPort());
         rfssConfig.setRfssId( rfssSetup.getId());
         rfssConfig.setEmulated( rfssSetup.getEmulated());
         rfssConfig.setWacnId( rfssSetup.getWacnId());
         rfssConfig.setSystemId( rfssSetup.getSystemId());

         // detect rfssName changes
         String newRfssName = rfssSetup.getName();
         String newIpAddress = rfssSetup.getIpAddress();
         showln("reconcileTesterConfig: rfssName="+rname+"  newRfssName="+newRfssName);
         if( !rname.equals( newRfssName)) {
            // fixup refid 
            for( DaemonWebServerAddress dwsa: testerConfig.getDaemonAddresses())
            {
               HashSet<String> tagSet = new HashSet<String>(dwsa.getRefIds());
               for( String tag: tagSet)
               {
                  showln("reconcileTesterConfig: tag="+tag);
                  String[] parts = tag.split("\\.");
                  if( parts.length==2 && rname.equals(parts[0]))
                  {
                     dwsa.removeRefId( tag);
                     String newTag = newRfssName +"." +parts[1];
                     showln("reconcileTesterConfig: newTag="+newTag);
                     dwsa.addRefId( newTag);
                  }
               }
            }
         }
         showln("reconcileTesterConfig: ipAddress="+ipAddress+"  newIpAddress="+newIpAddress);
         if( !ipAddress.equals( newIpAddress))
         {
            // fixup ipAddress 
            for( DaemonWebServerAddress dwsa: testerConfig.getDaemonAddresses())
            {
               if( ipAddress.equals( dwsa.getIpAddress()))
               {
                  showln("reconcileTesterConfig: replace "+dwsa.getIpAddress() 
                     + " with "+newIpAddress);
                  dwsa.setIpAddress( newIpAddress);
               }
            }
         }
      }
      return true;
   }

   public Map<String,String> getRfssNameMap( List<RfssConfigSetup> rfssList)
   {
      //showln("getRfssNameMap: rfssList="+rfssList.size());
      Map<String,String> map = new HashMap<String,String>();

      // build RfssName changes map
      if( rfssList != null)
      for( RfssConfigSetup rfssSetup: rfssList)
      {
         RfssConfig rfssConfig = (RfssConfig)rfssSetup.getReference();
         String rname = rfssConfig.getRfssName();

         String newRfssName = rfssSetup.getName();
         if( !rname.equals( newRfssName)) {
            map.put( new String(rname), newRfssName);
         }
      }
      return map;
   }

   //------------------------------------------------------------------------
   public void reconfigureDaemonTesterService(TopologyConfig topologyConfig,
      ISSITesterConfiguration testerConfig)
   {
      showln("reconfigureDaemonTesterService(): START...");
      List<String> rfssList = getRfssNameList(topologyConfig);
      for( DaemonWebServerAddress dwsa: testerConfig.getDaemonAddresses())
      {
	 dwsa.setTesterService( false);
         HashSet<String> tagSet = new HashSet<String>(dwsa.getRefIds());
         for( String tag: tagSet) {
            showln("reconfigureDaemontesterService: tag="+tag);
            String[] parts = tag.split("\\.");
            if( parts.length==2) {
               for( String rname: rfssList) {
                  if( rname.equals( parts[0])) {
                     showln("reconfigureDaemontesterService: matched="+rname);
                     dwsa.setTesterService(true);
                  }
               }
            }
         }
      }
      showln("reconfigureDaemonTesterService(): DONE...");
   }
   //------------------------------------------------------------------------
}
