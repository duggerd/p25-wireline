//
package gov.nist.p25.issi.traceviewer;

import java.util.Properties;

/**
 * This class adds functionality to SIP and PTT message data.
 *
 */
public class PttMessageData extends MessageData 
      implements Comparable<PttMessageData> {
   
   private String sequenceNumber;   
   private Properties properties;

   // accessor
   public String getSequenceNumber() {
      return sequenceNumber;
   }

   public Properties getProperties() {
      return properties;
   }
   
   // constructor
   public PttMessageData(
         String remoteRfssId,
         String myRfssId, 
         String myRtpRecvPort, 
         String remoteRtpRecvPort, 
         String messageType, 
         String data, 
         String time, 
         String sequenceNumber,
         String rtfData,               // not used
         boolean selected,
         boolean isSender,
         Properties props) {
      
      super(remoteRfssId, myRfssId, remoteRtpRecvPort, myRtpRecvPort, 
            messageType, data, time, messageType, selected,isSender);
      this.sequenceNumber = sequenceNumber;
      //this.rtfData = rtfData;
      this.properties = props;   
   }

   public int compareTo(PttMessageData m2) {
      PttMessageData m1 = this;
      try {
         long ts1 = Long.parseLong(m1.getTime());
         long ts2 = Long.parseLong(m2.getTime());
         if (ts1 < ts2)
            return -1;
         else if (ts1 > ts2)
            return 1;
         else {
            int sq1 = Integer.parseInt(m1.getSequenceNumber());
            int sq2 = Integer.parseInt(m2.getSequenceNumber());
            if ( sq1 < sq2) return -1;
            else if (sq1 > sq2) return 1;
            else return 0;            
         }
      } catch (NumberFormatException ex) {
         ex.printStackTrace();
         return 0;
      }
   }

   // Use by PttTraceVerifier only ?
   public boolean match(PttMessageData that) {

      for ( String name: that.getProperties().stringPropertyNames())
      {
         if ( getProperties().get(name) == null) 
            return false;
         if ( !getProperties().get(name).equals(that.getProperties().get(name)))
            return false;
      }
      return true;
   }
}
