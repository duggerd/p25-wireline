//
package gov.nist.p25.issi.packetmonitor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet handler for the packet monitor (gets the ptt traces).
 * 
 * @author mranga
 *
 */
public class PttTraceGetter extends HttpServlet {
   
   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(PttTraceGetter.class);
   
   public PttTraceGetter() {
   }

   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws IOException, ServletException {
      
      logger.debug("PacketMonitor: getting Ptt Traces ");

      PacketMonitor packetMonitor = PacketMonitor.getCurrentInstance();
      String retval = null;
      if ( packetMonitor == null ) {
         retval = "";
      } else {
         retval = packetMonitor.getPttMessages();
      }
      logger.debug("retrived ptt packets " + retval);
      response.getWriter().print(retval);
      response.getWriter().close();
   }
}
