//
package gov.nist.p25.issi.packetmonitor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet that GETs the measurement table result.
 * 
 * @author niepin@nist.gov
 * 
 */
public class ResultGetter extends HttpServlet {
   
   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ResultGetter.class);

   public ResultGetter() {
   }

   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws IOException, ServletException {
      try {
         logger.debug("PacketMonitor: getting results");

         PacketMonitor packetMonitor = PacketMonitor.getCurrentInstance();
         String retval = null;

         if (packetMonitor == null) {
            logger.debug("Packet monitor not started -- returning");
            retval = "";
         } else
            retval = packetMonitor.getResultTable();
         response.getWriter().print(retval);
         response.getWriter().close();
      } catch (Exception ex) {
         logger.error("Unexpected error fetching performance result ", ex);
         throw new ServletException ("Unexpected error fetching performance result",ex);
      }
   }
}
