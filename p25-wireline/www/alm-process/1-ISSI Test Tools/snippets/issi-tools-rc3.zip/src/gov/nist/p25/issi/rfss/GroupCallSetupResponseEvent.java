package gov.nist.p25.issi.rfss;

import javax.sip.ResponseEvent;

public class GroupCallSetupResponseEvent extends CallControlResponseEvent {

   private static final long serialVersionUID = -1L;

   public GroupCallSetupResponseEvent(GroupServing callSegment,
         ResponseEvent responseEvent) {
      super(callSegment);
      this.responseEvent = responseEvent;
   }

   public GroupServing getCallSegment() {
      return (GroupServing) getSource();
   }
}
