//
package gov.nist.p25.issi.constants;

public interface RtfConstants {
   
   // place constants in order
   public static final String END_MESSAGE = "{\\par}}\n";
   public static final String HEADER_END = "\\par }\n";   
   public static final String HEADER_START = "{\\insrsid15927085 ";
   public static final String HEADER_RESTART = "} " + HEADER_START;   

   public static final String IGNORED_FIELD = "}{\\i\\fs16\\insrsid15927085 ";
   public static final String LINE_FEED = "{\\par}\n";
   public static final String OPTIONAL_HEADER = "{\\i\\fs16\\insrsid15927085 ";

   public static final String PREAMBLE = "{\\pard\\plain \\s15\\ql \\li0"
         + "\\ri0\\widctlpar\\wrapdefault\\aspalpha\\aspnum\\faauto\\"
         + "adjustright\\rin0\\lin0\\itap0\\pararsid15927085 "
         + "\\f41\\fs20\\lang1033\\langfe1033\\cgrid"
         + "\\langnp1033\\langfenp1033 ";

}
