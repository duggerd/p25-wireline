//
package gov.nist.p25.issi.packetmonitor;

import jpcap.packet.Packet;

/**
 * Represents a raw captured packet. This is post processed to extract the
 * relevant information. This is the only class that is instatiated
 * during run time. It is timestamped when the packet is captured
 * and stored internally until the packet monitor is asked to 
 * sort and classify packets.
 * 
 */
public class CapturedPacket {
   
   private final PacketMonitor packetMonitor;
   private long timeStamp;
   private Packet packet;
   
   // accessor
   public long getTimeStamp() {
      return timeStamp;
   }
   public void setTimeStamp( long timeStamp) {
      this.timeStamp = timeStamp;
   }
   
   public Packet getPacket() {
      return packet;
   }
   public void setPacket(Packet packet) {
      this.packet = packet;
   }
   
   // accessor
   public PacketMonitor getPacketMonitor() {
      return packetMonitor;
   }

   CapturedPacket(PacketMonitor packetMonitor, Packet packet) {
      this.packetMonitor = packetMonitor;
      this.packet = packet;
      this.timeStamp = System.currentTimeMillis();

      // current TS + captured sec and micro-sec
      //this.timeStamp = System.currentTimeMillis()+packet.sec*1000+packet.usec/1000;
   }
}
