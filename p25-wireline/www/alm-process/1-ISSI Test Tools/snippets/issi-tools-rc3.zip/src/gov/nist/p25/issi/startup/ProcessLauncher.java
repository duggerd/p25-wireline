//
package gov.nist.p25.issi.startup;

import java.io.File;
import gov.nist.p25.common.util.FileUtility;

/**
 * A platform independent launcher that reads the eclipse .classpath and
 * generates a runtime classpath from it.
 * 
 */
public class ProcessLauncher {

   public static String TESTER_JAR = "./diets.jar";

   public static Process runCommand(String option, String className, String argument)
         throws Exception {

      String opts = " ";
      if( option != null && option.length() > 0)
          opts = option;

      //String classpath = new ParseDotClasspath().parseDotClassPath()
      //    + File.pathSeparator + TESTER_JAR;
      
      String classpath = System.getProperty("user.dir") + 
                         File.separator + "lib/*" +
                         File.pathSeparator + TESTER_JAR;

      String args = "";
      if( argument != null && argument.length() > 0)
          args = argument;

      System.out.println("ProcessLauncher: option="+option);
      System.out.println("ProcessLauncher: className="+className);
      System.out.println("ProcessLauncher: args="+args);

      //System.out.println("ProcessLauncher: classpath="+classpath);
      String program = System.getenv().get("JAVA_HOME") + "/bin/java";
      
      // -Djava.library.path=./bin/native/jpcap
      String libpath = "-Djava.library.path="+ System.getProperty("user.dir") +
                       "/bin/native/jpcap";

      //String commands[] = { "java", "-classpath", classpath, className };
      //String commands[] = { program, "-classpath", classpath, libpath, className };
      //return Runtime.getRuntime().exec(commands);
      //
      String cmd = program +" " +opts +" -classpath " +classpath +" "  +
                   libpath +" " +className +" " +args;

      // for debug only
      FileUtility.saveToFile( "logs/command.txt", cmd);

      // exec the command
      return Runtime.getRuntime().exec(cmd);
   }

   //=========================================================================
   public static void main(String[] argv) throws Exception {

      try {         
         String option = System.getProperty("option");
         String className = System.getProperty("className"); 
         String args = System.getProperty("args");

         Process p = runCommand( option, className, args);
         if( p!= null) {
            System.out.println("runCommand: exitValue="+p.exitValue());
         }
      } catch (Exception ex) {
         ex.printStackTrace();
	 System.out.println("ProcessLauncher: MAIN-"+ex);
      }
   }
}
