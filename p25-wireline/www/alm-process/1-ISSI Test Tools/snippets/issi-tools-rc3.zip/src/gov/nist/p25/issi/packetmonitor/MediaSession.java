//
package gov.nist.p25.issi.packetmonitor;

import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.packetmonitor.PacketMonitor.EndPoint;

import java.util.LinkedList;

/**
 * 
 * Represents a Media session. Media sessions
 * are inferred from the SDP information of the
 * SIP request and matching response pair. A media session
 * is an RTP session between two EndPoints. The owningRfss
 * field represents the RFSS that created the media session.
 *
 */
public class MediaSession {

   RfssConfig owningRfss;
   EndPoint source;
   EndPoint destination;
   LinkedList<CapturedPttMessage> capturedPttMessages;
   RfssConfig remoteRfss;
   PacketMonitor packetMonitor;
   
   private MediaSession() {
      this.capturedPttMessages = new LinkedList<CapturedPttMessage>();
   }

   public MediaSession(PacketMonitor packetMonitor, EndPoint destination) {

      this();
      this.packetMonitor = packetMonitor;
      if (destination == null)
         throw new NullPointerException("Null Arg!");
      this.destination = destination;
   }

   public void setSource(EndPoint source) {
      if (source == null)
         throw new NullPointerException("Null arg!");
      this.source = source;
   }

   public EndPoint getSource() {
      return source;
   }

   public EndPoint getDestination() {
      return destination;
   }

   public CapturedPttMessage addPttMessage(byte[] message, long time) {
      try {
         CapturedPttMessage newMessage = new CapturedPttMessage( message,
               time, this);
         if (this.capturedPttMessages.size() == 0)
            this.capturedPttMessages.add(newMessage);
         else {
            CapturedPttMessage previousMessage = this.capturedPttMessages.peekLast();
            if (previousMessage.match(newMessage)) {
               PacketMonitor.logger
                     .debug("Previous Ptt message matches current message -- dropping message");
               if( packetMonitor.getKeepDuplicateMessage()) {
                  capturedPttMessages.add(newMessage);                  
               }
            } else {
               this.capturedPttMessages.add(newMessage);
            }
         }
         return newMessage;
      } catch (Exception ex) {
         PacketMonitor.logger.error("Could not log packet", ex);
         return null;
      }
   }

   public MediaSession reverse() {
      MediaSession retval = new MediaSession();
      retval.source = this.destination;
      retval.destination = this.source;
      retval.owningRfss = this.remoteRfss;
      retval.remoteRfss = this.owningRfss;
      retval.packetMonitor = this.packetMonitor;
      return retval;
   }

   public String toString() {

      StringBuffer sbuf = new StringBuffer();
      sbuf.append("<ptt-session");
      sbuf.append("\n rfssId=\"" + (remoteRfss != null ? remoteRfss.getRfssId() : remoteRfss));
      sbuf.append("\"\n");
      sbuf.append(" myIpAddress=\"" + (destination != null ? destination.host : ""));
      sbuf.append("\"\n");
      sbuf.append(" myRtpRecvPort=\"" + (destination != null ? destination.port : -1));
      sbuf.append("\"\n");
      sbuf.append(" remoteIpAddress=\"" + (source != null ? source.host : ""));
      sbuf.append("\"\n");
      sbuf.append(" remoteRtpRecvPort=\"" +  (source != null ? source.port : -1 ));
      sbuf.append("\"\n");
      sbuf.append("/>\n");
      return sbuf.toString();
   }
}
