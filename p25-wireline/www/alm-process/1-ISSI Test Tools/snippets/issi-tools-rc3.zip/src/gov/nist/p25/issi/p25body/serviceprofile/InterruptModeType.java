//
package gov.nist.p25.issi.p25body.serviceprofile;

public enum InterruptModeType {

   //(NeverAllowed|PriorityBasedAllowed|AlwaysAllowd)
   AUDIO_INTERRRUPT_NEVER_ALLOWED(0, 
      "0: Audio Interrupt Never Allowed","NeverAllowed"),
   AUDIO_INTERRRUPT_BASED_ON_PRIORITY(1,
      "1: Audio Interrupt Based On Priority","PriorityInterruptAllowed"),
   AUDIO_INTERRRUPT_ALWAYS_ALLOWED(2,
      "2: Audio Interrupt Always Allowed","AlwaysAllowed");

   private int intValue;
   private String description;
   private String shortName;

   private InterruptModeType(int modeValue, String description, String shortName) {
      this.intValue = modeValue;
      this.description = description;
      this.shortName = shortName;
   }

   public int getIntValue() {
      return intValue;
   }

   @Override
   public String toString() {
      return description;
   }

   public static InterruptModeType getModeValues(int modeValue) {
      for (InterruptModeType mv : InterruptModeType.values()) {
         if (modeValue == mv.intValue)
            return mv;
      }
      throw new IllegalArgumentException("Illegal arg : " + modeValue);
   }

   /**
    * Find mode corresponding to xml attribute.
    * 
    * @param modeValue
    * @return
    */
   public static InterruptModeType getValue(String modeValue) {
      
      for (InterruptModeType mv : InterruptModeType.values()) {
         if (modeValue.equals(mv.shortName))
            return mv;
      }
      throw new IllegalArgumentException("Illegal arg : " + modeValue);
   }
}
