//
package gov.nist.p25.issi.p25body.serviceprofile;

/**
 * @author M. Ranganathan
 * 
 */
public enum CallSetupPreferenceType {

   CALLER_PREFERS_AVAILABILITY_CHECK(0,
      "Calling SU prefers Availability Check for the Called SU",
      "AvailabilityCheck"), 
   CALLER_PREFERS_DIRECT_CALL(1,
      "Calling SU prefers Direct Call for the Called SU",
      "DirectCall");

   /*
    * ("AvailabilityCheck" | "DirectCall" )
    *
    */
   private int intValue;
   private String shortName;
   private String description;

   CallSetupPreferenceType(int dup, String desc, String shortName) {
      this.intValue = dup;
      this.description = desc;
      this.shortName = shortName;
   }

   public int getIntValue() {
      return intValue;
   }

   @Override
   public String toString() {
      return description;
   }

   public static CallSetupPreferenceType getInstance(int intval) {
      for (CallSetupPreferenceType d : values())
         if (d.intValue == intval)
            return d;
      throw new IllegalArgumentException("Value out of range");
   }

   public static CallSetupPreferenceType getInstance(String value) {
      for (CallSetupPreferenceType d : values())
         if (d.shortName.equals(value))
            return d;
      throw new IllegalArgumentException("Value out of range " + value);
   }
}
