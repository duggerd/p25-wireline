package gov.nist.p25.issi.transctlmgr.ptt;

/**
 * Tagging interface for Ptt State.
 * 
 * @author M. Ranganathan
 *
 */
public interface PttState {

}
