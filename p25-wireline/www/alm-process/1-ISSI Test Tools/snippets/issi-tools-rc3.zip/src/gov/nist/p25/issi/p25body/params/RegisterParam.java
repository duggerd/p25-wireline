//
package gov.nist.p25.issi.p25body.params;

import java.text.ParseException;

import org.apache.log4j.Logger;

/**
 * @author M. Ranganathan
 * 
 */
public class RegisterParam {

   private static Logger logger = Logger.getLogger(RegisterParam.class);
   
   private static final String HEADER_START = "{\\insrsid15927085 ";
   private static final String IGNORED_FIELD = "}{\\i\\fs16\\insrsid15927085 ";
   private static final String HEADER_END = "\\par }\n";
   //private static final String HEADER_RESTART = "} " + HEADER_START;
   private static final String FORCE_REGISTER = "r-force";   
   private static final String CONFIRM_PRESENCE = "r-presence";
   private static final String CONFIRM_REGISTER = "r-confirm";


   /*
    * This parameter is used by the Home RFSS in the Home Registration Query
    * procedure. The Force qualifier indicates that the Serving RFSS has to
    * re-register the mobility object if it still has interest.
    */
   private boolean forceRegister = false;

   /*
    * This parameter is used by the Home RFSS in the Home Registration Query
    * procedure. The Confirm qualifier requests that the serving RFSS confirm
    * its interest for the mobility object.
    */
   private boolean confirmRegister = false;

   /*
    * SU Presence This parameter is used by the Serving RFSS in the
    * Registration procedure for an SU. The  Presence qualifier indicates
    * whether or not the Serving RFSS has actually confirmed the presence of
    * the SU at the Serving RFSS immediately prior to sending the Registration
    * request. See Section 5 for further details.
    * 
    */
   private boolean confirmPresence = false;

   private static boolean getBooleanFromString(String str)
         throws ParseException {
      if (str.equals("1"))
         return true;
      else if (str.equals("0"))
         return false;
      else
         throw new ParseException("bad token [" + str + "]", 0);
   }

   private static String getStringFromBoolean(boolean bool) {
      return (bool ? "1" : "0");
   }

   /**
    * Default constructor.
    * 
    * @return
    */
   public static RegisterParam createRegisterParam() {
      return new RegisterParam();
   }

   /**
    * Create a register param from a string.
    * 
    * @param registrationParam
    * @return
    * @throws ParseException
    */
   public static RegisterParam createRegisterParam(String registrationParam)
         throws ParseException {
      RegisterParam retval = new RegisterParam();

      logger.debug("createRegisterParam creating from String = "
            + registrationParam);

      String[] lines = registrationParam.split("\n");
      for (String line : lines) {
         String ln[] = line.trim().split(":");
         if (ln.length != 2)
            throw new ParseException("Invalid line [" + line + "]", 0);
         if (ln[0].equalsIgnoreCase("r-force")
               || ln[0].equalsIgnoreCase("r-f")) {
            String tok = ln[1];
            retval.forceRegister = getBooleanFromString(tok);

         } else if (ln[0].equalsIgnoreCase("r-confirm")
               || ln[0].equalsIgnoreCase("r-c")) {
            String tok = ln[1];
            retval.confirmRegister = getBooleanFromString(tok);
         } else if ( ln[0].equalsIgnoreCase("r-presence") ||
               ln[0].equalsIgnoreCase("r-p")) {
            String tok = ln[1];
            retval.confirmPresence = getBooleanFromString(tok);
         } else 
            throw new ParseException("Unexpected token [" + ln[0] + "]", 0);
      }
      logger.debug("createRegisterParam  created " + retval);
      return retval;
   }

   @Override
   public String toString() {
      StringBuffer retval =  new StringBuffer();
         if ( forceRegister) 
            retval.append(FORCE_REGISTER).append(":").append(
            getStringFromBoolean(forceRegister)).append("\r\n");
         
         if ( confirmRegister)
            retval.append(CONFIRM_REGISTER).append(":").append(
            getStringFromBoolean(confirmRegister)).append("\r\n");
         
         if ( confirmPresence)
             retval.append(CONFIRM_PRESENCE).append(":").append(
            getStringFromBoolean(confirmPresence)).append("\r\n");
         
      return retval.toString();
   }

   public String toRtfString() {
      StringBuffer retval = new StringBuffer();
      
      if ( forceRegister) retval.append(HEADER_START).append(FORCE_REGISTER)
            .append(": ").append(IGNORED_FIELD).append(
                  getStringFromBoolean(forceRegister)).append(HEADER_END).append("\r\n");
      
      if (confirmRegister)
         retval.append(HEADER_START).append(CONFIRM_REGISTER)
            .append(":").append(IGNORED_FIELD).append(
                  getStringFromBoolean(confirmRegister)).append(
                  HEADER_END).append("\r\n");
      if ( confirmPresence)
         retval.append(HEADER_START).append(CONFIRM_PRESENCE)
                  .append(":").append(IGNORED_FIELD).append(
                        getStringFromBoolean(confirmPresence)).append(
                        HEADER_END).append("\r\n");
      
      return retval.toString();
   }

   /**
    * @param forceRegister
    *            The forceRegister to set.
    */
   public void setForceRegister(boolean forceRegister) {
      this.forceRegister = forceRegister;
   }

   /**
    * @return Returns the forceRegister.
    */
   public boolean isForceRegister() {
      return forceRegister;
   }

   /**
    * @param confirmRegister
    *            The confirmRegister to set.
    */
   public void setConfirmRegister(boolean confirmRegister) {
      this.confirmRegister = confirmRegister;
   }
   
   public void setConfirmPresence (boolean confirmPresence) {
      this.confirmPresence = confirmPresence;
   }

   /**
    * @return Returns the confirmRegister.
    */
   public boolean isConfirmRegister() {
      return confirmRegister;
   }

   @Override
   public boolean equals(Object that) {
      if (!(that instanceof RegisterParam)) {

         logger.debug("class mismatch " + that.getClass());
         return false;
      }
      RegisterParam other = (RegisterParam) that;

      return other.confirmRegister == this.confirmRegister
            && other.forceRegister == this.forceRegister &&
            other.confirmPresence == this.confirmPresence;
   }

   public boolean isDefault() {
      return this.equals(new RegisterParam());
   }

   public boolean isConfirmPresence() {      
      return this.confirmPresence;
   }
}
