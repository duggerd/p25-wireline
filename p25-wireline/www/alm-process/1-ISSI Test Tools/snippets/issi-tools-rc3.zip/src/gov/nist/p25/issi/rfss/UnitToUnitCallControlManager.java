package gov.nist.p25.issi.rfss;

import gov.nist.javax.sdp.fields.OriginField;
import gov.nist.p25.issi.constants.ISSIConstants;
import gov.nist.p25.issi.issiconfig.CProtectedDisposition;
import gov.nist.p25.issi.issiconfig.RfssConfig;
import gov.nist.p25.issi.issiconfig.SuConfig;
import gov.nist.p25.issi.issiconfig.SystemConfig;
import gov.nist.p25.issi.issiconfig.TopologyConfig;
import gov.nist.p25.issi.p25body.CallParamContent;
import gov.nist.p25.issi.p25body.ContentList;
import gov.nist.p25.issi.p25body.SdpContent;
import gov.nist.p25.issi.p25body.params.CallParam;
import gov.nist.p25.issi.p25body.serviceprofile.AvailabilityCheckType;
import gov.nist.p25.issi.p25body.serviceprofile.CallPermissionType;
import gov.nist.p25.issi.p25body.serviceprofile.DuplexityType;
//import gov.nist.p25.issi.p25body.serviceprofile.user.Duplexity;
//import gov.nist.p25.issi.p25body.serviceprofile.user.UnitToUnitCallPermission;
import gov.nist.p25.issi.rfss.SipUtils;
import gov.nist.p25.issi.rfss.tester.SuToSuCallSetupScenario;
import gov.nist.p25.issi.rfss.tester.TestSU;
import gov.nist.p25.issi.transctlmgr.PttPointToMultipointSession;
import gov.nist.p25.issi.transctlmgr.TransmissionControlManager;
import gov.nist.p25.issi.transctlmgr.ptt.LinkType;
import gov.nist.p25.issi.transctlmgr.ptt.MmfSession;
import gov.nist.p25.issi.transctlmgr.ptt.PttSession;
import gov.nist.p25.issi.transctlmgr.ptt.SessionType;
import gov.nist.p25.issi.utils.ProtocolObjects;
import gov.nist.p25.issi.utils.WarningCodes;
import gov.nist.rtp.RtpException;

import java.util.LinkedList;

import javax.sdp.SdpFactory;
import javax.sdp.SessionDescription;
import javax.sip.ClientTransaction;
import javax.sip.Dialog;
import javax.sip.DialogState;
import javax.sip.DialogTerminatedEvent;
import javax.sip.IOExceptionEvent;
import javax.sip.RequestEvent;
import javax.sip.ResponseEvent;
import javax.sip.ServerTransaction;
import javax.sip.SipListener;
import javax.sip.SipProvider;
import javax.sip.TimeoutEvent;
import javax.sip.TransactionState;
import javax.sip.TransactionTerminatedEvent;
import javax.sip.address.Address;
import javax.sip.address.AddressFactory;
import javax.sip.address.SipURI;
import javax.sip.header.AcceptHeader;
import javax.sip.header.CSeqHeader;
import javax.sip.header.CallIdHeader;
import javax.sip.header.ContactHeader;
import javax.sip.header.ContentDispositionHeader;
import javax.sip.header.ContentTypeHeader;
import javax.sip.header.FromHeader;
import javax.sip.header.HeaderFactory;
import javax.sip.header.MaxForwardsHeader;
import javax.sip.header.PriorityHeader;
import javax.sip.header.RecordRouteHeader;
import javax.sip.header.RouteHeader;
import javax.sip.header.TimeStampHeader;
import javax.sip.header.ToHeader;
import javax.sip.header.ViaHeader;
import javax.sip.header.WarningHeader;
import javax.sip.message.MessageFactory;
import javax.sip.message.Request;
import javax.sip.message.Response;

import org.apache.log4j.Logger;

/**
 * The Call control manager - this is implemented as a Back to Back SIP User
 * Agent. This component handles all SIP Invites, SIP responses to Invites,
 * ACKs, BYEs etc. in other words, all the signaling having to do with SIP Call
 * setup. Note that as the requests go through this component, it interacts with
 * the Transmission control manager to set up RTP ports on which to listen and
 * it modifies the SDP announce accordingly. This is to force the media stream
 * to traverse the RFSSs as required by the ISSI specification.
 * 
 * @author M. Ranganathan <mranga@nist.gov>
 * 
 */
public class UnitToUnitCallControlManager implements SipListener {

   private static Logger logger = Logger.getLogger(UnitToUnitCallControlManager.class);
   //public static void showln(String s) { System.out.println(s); }

   static MessageFactory messageFactory = ProtocolObjects.messageFactory;
   static HeaderFactory headerFactory = ProtocolObjects.headerFactory;
   static AddressFactory addressFactory = ProtocolObjects.addressFactory;

   private SystemConfig sysConfig;
   private RfssConfig rfssConfig;
   private TopologyConfig topologyConfig;
   private SipProvider provider;
   private RFSS rfss;

   class PendingResponse {
      HomeAgentInterface su;
      int proceedure;
      UnitToUnitCall unitToUnitCall;
   }

   class PendingSDPAnswer {
      ServerTransaction serverTransaction;
      PttPointToMultipointSession pointToMultipointSession;
      PttSession pendingOutgoingSession;
      SessionDescription incomingSdpOffer;
      SessionDescription outgoingSdpOffer;
   }

   /**
    * Creates new Call Control Manager.
    */
   public UnitToUnitCallControlManager(RFSS rfss) {
      try {
         this.rfss = rfss;
         rfssConfig = rfss.getRfssConfig();
         provider = rfss.getProvider();
         sysConfig = rfssConfig.getSysConfig();
         topologyConfig = sysConfig.getTopologyConfig();
      } catch (Exception ex) {
         rfss.getTestHarness().fail(
               "Unexpected exception in UnitToUnitCallControlManagager", ex);
      }
   }

   TransmissionControlManager getTransmissionControlManager() {
      return rfssConfig.getRFSS().getTransmissionControlManager();
   }

   /**
    * Create and setup an outgoing client tx. This munges the SDP announce part
    * of the outgoing request
    * 
    * @param serverTransaction
    * @param newRequest
    * @return
    * @throws Exception
    */
   private ClientTransaction setupClientTransaction(
         ServerTransaction serverTransaction, Request newRequest, int suId,
         LinkType linkType, UnitToUnitCall unitToUnitCall) throws Exception {
      Request request = serverTransaction.getRequest();
      RouteHeader routeHeader = (RouteHeader) newRequest.getHeader(RouteHeader.NAME);
      String targetDomainName = ((SipURI) routeHeader.getAddress().getURI()).getHost();
      WarningHeader warningHeader = SipUtils.checkIncomingRequest(request);
      SuConfig calledSuConfig = unitToUnitCall.getCalledSuConfig();
      SuConfig callingSuConfig = unitToUnitCall.getCallingSuConfig();
      if (warningHeader != null) {
         Response response = messageFactory.createResponse( Response.BAD_REQUEST, request);
         warningHeader.setAgent("RFSS: " + rfssConfig.getRfssId());
         response.addHeader(warningHeader);
         serverTransaction.sendResponse(response);
         return null;
      }

      ContentList contentList = ContentList.getContentListFromMessage(request);
      SdpContent sdpContent = (SdpContent) ContentList.getContentByType(
            contentList, "application", "sdp");

      if (sdpContent == null) {
         Response response = messageFactory.createResponse(
               Response.BAD_REQUEST, request);
         warningHeader = headerFactory.createWarningHeader(rfssConfig
               .getDomainName(), WarningHeader.MISCELLANEOUS_WARNING,
               ISSIConstants.WARN_TEXT_MISSING_REQUIRED_SDP_ANNOUNCE);

         serverTransaction.sendResponse(response);
         return null;
      }

      if (linkType != LinkType.UNIT_TO_UNIT_CALLED_HOME_TO_CALLED_SERVING
            && linkType != LinkType.UNIT_TO_UNIT_CALLING_HOME_TO_CALLED_HOME)
         throw new IllegalArgumentException("Unexpected link type : " + linkType);

      SessionDescription sessionDescription = sdpContent.getSessionDescription();
      PendingSDPAnswer pendingAnswer = new PendingSDPAnswer();

      // deep clone is not suport for javax.sdp
      pendingAnswer.incomingSdpOffer = SdpFactory.getInstance()
            .createSessionDescription(sessionDescription.toString());
      String sessionId = SipUtils.getCallIdFromMessage(newRequest);

      /*
       * Here we are setting up an RTP Session where we listen for incoming
       * packets. From this we get the port and place it in the SDP announce
       * (OFFER) to send to the other end. The port is a randomly generated
       * even number where WE will be listening for incoming packets.
       */

      PttPointToMultipointSession ptToMpSession = null;

      if (linkType == LinkType.UNIT_TO_UNIT_CALLED_HOME_TO_CALLED_SERVING) {
         ptToMpSession = getTransmissionControlManager()
               .getPttPointToMultipointSession(sessionId, SessionType.CALLED_HOME);

         CallParamContent callParams = contentList.getCallParamContent();
         callParams.getCallParam().setCallingSuInitialTransmitter(
               rfssConfig.isCallingSuInitialTransmitter());
         /*
          * From 102 BACA page 128 The Called Home RFSS compares the received
          * preference with the Availability Check and the Direct Call
          * attributes of the called SU service profile to set the preference
          * parameter in the INVITE message sent to the Called Serving RFSS:
          * 
          * if the preference is set to Availability Check (1) and the SU
          * supports Availability Check in its USP, then the preference is
          * set to Availability Check (1).
          */
         logger.debug("isAvailCheckRequested = "
               + callParams.getCallParam().isAvailabilityCheckRequested());
         logger.debug("isAvailCheckSupported = "
               + calledSuConfig.getUserServiceProfile()
                     .getAvailabilityCheck().getAvailabilityCheckType());
         AvailabilityCheckType calledSuAvailCheckType = calledSuConfig
               .getUserServiceProfile().getAvailabilityCheck()
               .getAvailabilityCheckType();
         if (callParams.getCallParam().isAvailabilityCheckRequested()
               && (calledSuAvailCheckType != AvailabilityCheckType.DIRECT_CALL_ONLY)) {
            callParams.getCallParam().setAvailabilityCheckRequested(true);

         } else if (callParams.getCallParam().isAvailabilityCheckRequested()
               && calledSuAvailCheckType == AvailabilityCheckType.DIRECT_CALL_ONLY) {
            /*
             * if the preference is set to Availability Check (1) and the SU
             * supports only Direct Call in its USP, then the preference is
             * set to Direct Call (0).
             */
            callParams.getCallParam().setAvailabilityCheckRequested(false);
         } else if ((!callParams.getCallParam()
               .isAvailabilityCheckRequested())
               && calledSuAvailCheckType == AvailabilityCheckType.AVAIL_CHECK_ONLY) {
            /*
             * if the preference is set to Direct Call (0) and the SU
             * supports only Availability Check, in its USP, then the
             * preference is set to Availability Check (1).
             */
            callParams.getCallParam().setAvailabilityCheckRequested(true);
         } else if ((!callParams.getCallParam()
               .isAvailabilityCheckRequested())
               && calledSuAvailCheckType != AvailabilityCheckType.AVAIL_CHECK_ONLY) {
            /*
             * if the preference is set to Direct Call (0) and the SU
             * supports Direct Call then the preference is set to Direct
             * Call (0).
             */
            callParams.getCallParam().setAvailabilityCheckRequested(false);
         }

         /*
          * See if the protection bit needs to be cleared or forwarded.
          */
         if (callParams.getCallParam().isProtectedMode()
               && calledSuConfig.getCProtectedDisposition() == CProtectedDisposition.CLEAR_PROTECTED) {
            callParams.getCallParam().setProtectedMode(false);
         }

         /*
          * Adjust the duplexity of the call.
          */
         DuplexityType duplexity = calledSuConfig.getUserServiceProfile()
               .getDuplexity().getDuplex();
         if (callParams.getCallParam().isFullDuplexRequested()
               && duplexity == DuplexityType.HALF) {
            callParams.getCallParam().setFullDuplexRequested(false);
         }

      } else {
         ptToMpSession = getTransmissionControlManager()
               .getPttPointToMultipointSession(sessionId, SessionType.CALLING_HOME);
      }

      PttSession rtpSession = null;

      long newSessionId = new Long((long) (Math.random() * 100000));
      sessionDescription.getOrigin().setSessionId(newSessionId);

      try {
         if (linkType == LinkType.UNIT_TO_UNIT_CALLED_HOME_TO_CALLED_SERVING) {
            rtpSession = ptToMpSession.createMmfSession(linkType,
                  ((OriginField) sessionDescription.getOrigin()).getSessIdAsString());
            ((MmfSession) rtpSession)
                  .setSetIsNotInterestedInLosingAudio(rfssConfig.isNotInterestedInLosingAudio());
            rtpSession.setRemoteRfssDomainName(targetDomainName);
            // rtpSession.setRemoteRfssRadicalName(callingSuConfig.getHomeRfss().getDomainName());
         } else {
            // CALLING HOME TO CALLED HOME
            // This is a combined mmf/smf back to back session.
            rtpSession = ptToMpSession.createSmfSession(linkType,
                  ((OriginField) sessionDescription.getOrigin()).getSessIdAsString());
            // ((SmfSession) rtpSession).getSmfReceiver().addListener(
            // rfss.getCurrentTestCase());
            rtpSession.setRemoteRfssDomainName(calledSuConfig.getHomeRfss().getDomainName());
         }

      } catch (RtpException ex) {
         Response response = SipUtils.createErrorResponse(rfssConfig,
               request, WarningCodes.NO_RTP_RESOURCE);
         serverTransaction.sendResponse(response);
         return null;
      }
      rtpSession.getHeartbeatReceiver().setHeartbeatListener(unitToUnitCall);
      // fixupSdpAnnounce takes the incoming SessionDescription
      // (that was part of the ServerTransaction) and edits the information
      // to send to the next hop.

      CallControlManager.fixupSdpAnnounce(rfssConfig, rtpSession, sessionDescription);

      sdpContent.setSessionDescription(sessionDescription);
      ContentTypeHeader ctHeader = contentList.getContentTypeHeader();

      // The SPD has been modified and the port number
      // where we are listening has been placed in the origin field add it to
      // the outgoing SIP
      // INVITE
      unitToUnitCall.setCallParam(contentList.getCallParamContent());
      newRequest.setContent(contentList.toString(), ctHeader);
      ClientTransaction ct = provider.getNewClientTransaction(newRequest);
      pendingAnswer.pointToMultipointSession = ptToMpSession;
      pendingAnswer.pendingOutgoingSession = rtpSession;
      pendingAnswer.serverTransaction = serverTransaction;
      pendingAnswer.outgoingSdpOffer = sessionDescription;
      ct.setApplicationData(pendingAnswer);
      return ct;
   }

   /**
    * Create an in call roaming request
    * 
    * @param roamingSu
    */
   Request createInviteForInCallRoaming(SuConfig roamingSu,
         UnitToUnitCall unitToUnitCall) throws Exception {

      int priority = unitToUnitCall.getPriority();
      boolean isEmergency = unitToUnitCall.isEmergency();

      // create my SIP URI. This goes into the From Header.
      // String radicalName = roamingSu.getRadicalName();
      String radicalName = unitToUnitCall.getCallingSuConfig().getRadicalName();
      String domainName = "p25dr";
      SipURI callingSipURI = SipUtils.createSipURI(radicalName, domainName);
      callingSipURI.setParameter("user", ISSIConstants.TIA_P25_SU);
      Address fromAddress = addressFactory.createAddress(callingSipURI);
      
      String tag = SipUtils.createTag();
      FromHeader fromHeader = headerFactory.createFromHeader(fromAddress, tag);

      // Create the SIP URI for the Called RFSS.

      // SuConfig otherSu = roamingSu == unitToUnitCall.getCallingSuConfig() ?
      // unitToUnitCall .getCalledSuConfig()
      // : unitToUnitCall.getCallingSuConfig();
      SuConfig otherSu = unitToUnitCall.getCalledSuConfig();
      SipURI calledSipURI = SipUtils.createSipURI(otherSu.getRadicalName(), domainName);
      calledSipURI.setParameter("user", ISSIConstants.TIA_P25_SU);
      Address toAddress = addressFactory.createAddress(calledSipURI);
      ToHeader toHeader = headerFactory.createToHeader(toAddress, null);
      ContactHeader contactHeader = SipUtils.createContactHeaderForSU(
            rfssConfig, roamingSu);

      ViaHeader viaHeader = SipUtils.createViaHeaderForRfss(rfssConfig);
      LinkedList<ViaHeader> viaHeaders = new LinkedList<ViaHeader>();
      viaHeaders.add(viaHeader);

      CallIdHeader callIdHeader = ProtocolObjects.headerFactory
            .createCallIdHeader(unitToUnitCall.getCallID());
      CSeqHeader cseqHeader = headerFactory.createCSeqHeader(1L, Request.INVITE);
      MaxForwardsHeader maxForwardsHeader = headerFactory.createMaxForwardsHeader(70);
      SipURI requestURI = SipUtils.createSipURI(roamingSu.getRadicalName(), "p25dr");

      // create SIP request
      Request sipRequest = messageFactory.createRequest(requestURI,
            Request.INVITE, callIdHeader, cseqHeader, fromHeader, toHeader,
            viaHeaders, maxForwardsHeader);

      PriorityHeader priorityHeader = headerFactory
            .createPriorityHeader(new Integer(priority).toString() + ";"
                  + (isEmergency ? "e" : "a"));
      sipRequest.addHeader(priorityHeader);

      logger.debug(">>>>    Request = " + sipRequest);
      SipURI sipUri = (SipURI) rfssConfig.getRFSS()
            .getUnitToUnitMobilityManager().getRegisteredContactURI(
                  requestURI).clone();
      sipUri.setLrParam();
      sipUri.setParameter("remove", "true");
      RouteHeader routeHeader = headerFactory
            .createRouteHeader(addressFactory.createAddress(sipUri));
      sipRequest.addHeader(routeHeader);
      sipRequest.addHeader(contactHeader);
      sipRequest.addHeader( SipUtils.createTimeStampHeader());
      SipUtils.addAllowHeaders( sipRequest);
      
      //=============================
      // M1011 Content-Disposition ?
      //showln("UnitToUnitCall: createInviteForInCallRoaming - HAD Content-Disposition");
      //=============================

      AcceptHeader acceptHeader = headerFactory.createAcceptHeader(
            ISSIConstants.APPLICATION, "sdp");
      acceptHeader.setParameter("level", "1");
      sipRequest.addHeader(acceptHeader);
      sipRequest.addHeader(headerFactory.createAcceptHeader(
            ISSIConstants.APPLICATION, ISSIConstants.X_TIA_P25_ISSI));

      ContentDispositionHeader cd = headerFactory
            .createContentDispositionHeader(ContentDispositionHeader.SESSION);
      cd.setHandling("required");
      sipRequest.addHeader(cd);
      return sipRequest;
   }

   /**
    * Set up an outgoing invite
    * 
    * @param callingSu
    * @param calledSu
    * @return
    * @throws Exception
    */
   Request createInviteForU2UCall(SuToSuCallSetupScenario scenario)
         throws Exception {

      SuConfig callingSu = scenario.getCallingSuConfig();
      SuConfig calledSu = scenario.getCalledSuConfig();
      boolean isEmergency = scenario.isEmergency();
      int priority = scenario.getPriority();

      String radicalName = callingSu.getRadicalName();
      String domainName = "p25dr";
      SipURI callingSipURI = SipUtils.createSipURI(radicalName, domainName);
      callingSipURI.setParameter("user", ISSIConstants.TIA_P25_SU);
      
      String tag = SipUtils.createTag();
      Address fromAddress = addressFactory.createAddress(callingSipURI);
      FromHeader fromHeader = headerFactory.createFromHeader(fromAddress, tag);

      // Create the SIP URI for the Called RFSS.
      radicalName = calledSu.getRadicalName();
      domainName = "p25dr";
      SipURI calledSipURI = SipUtils.createSipURI(radicalName, domainName);
      calledSipURI.setParameter("user", ISSIConstants.TIA_P25_SU);
      Address toAddress = addressFactory.createAddress(calledSipURI);
      ToHeader toHeader = headerFactory.createToHeader(toAddress, null);
      ContactHeader contactHeader = SipUtils.createContactHeaderForSU( rfssConfig, callingSu);

      ViaHeader viaHeader = SipUtils.createViaHeaderForRfss(rfssConfig);
      LinkedList<ViaHeader> viaHeaders = new LinkedList<ViaHeader>();
      viaHeaders.add(viaHeader);

      // Get a new call ID header for the outgoing invite.
      CallIdHeader callIdHeader = provider.getNewCallId();
      CSeqHeader cseqHeader = headerFactory.createCSeqHeader(1L, Request.INVITE);
      MaxForwardsHeader maxForwardsHeader = headerFactory.createMaxForwardsHeader(70);

      Request sipRequest = messageFactory.createRequest(calledSipURI,
            Request.INVITE, callIdHeader, cseqHeader, fromHeader, toHeader,
            viaHeaders, maxForwardsHeader);

      PriorityHeader priorityHeader = headerFactory
            .createPriorityHeader(new Integer(priority).toString() + ";"
                  + (isEmergency ? "e" : "a"));
      sipRequest.addHeader(priorityHeader);

      if (callingSu.getHomeRfss() != rfssConfig) {
         RouteHeader routeHeader = SipUtils.createRouteToRfss(callingSu
               .getHomeRfss());
         SipURI sipUri = (SipURI) routeHeader.getAddress().getURI();
         sipUri.setUser(ISSIConstants.U2UORIG);
         sipRequest.addHeader(routeHeader);
      }
      if (calledSu.getHomeRfss() == rfssConfig) {

         SipURI sipUri = (SipURI) rfssConfig.getRFSS()
               .getUnitToUnitMobilityManager().getRegisteredContactURI(
                     sipRequest).clone();
         sipUri.setLrParam();
         sipUri.setParameter("remove", "true");
         RouteHeader routeHeader = headerFactory
               .createRouteHeader(addressFactory.createAddress(sipUri));
         sipRequest.addHeader(routeHeader);

      } else if (calledSu.getHomeRfss() != callingSu.getHomeRfss()) {
         RouteHeader routeHeader = SipUtils.createRouteToRfss(calledSu
               .getHomeRfss());
         SipURI sipUri = (SipURI) routeHeader.getAddress().getURI();
         sipUri.setUser(ISSIConstants.U2UDEST);
         sipRequest.addHeader(routeHeader);
      }
      sipRequest.addHeader(contactHeader);
      sipRequest.addHeader( SipUtils.createTimeStampHeader());
      SipUtils.addAllowHeaders(sipRequest);
      
      //=============================
      // M1011 Content-Disposition ?
      //showln("UnitToUnitCall: createInviteForU2UCall - need Content-Disposition");
      //=============================

      AcceptHeader acceptHeader = headerFactory.createAcceptHeader(
            ISSIConstants.APPLICATION, "sdp");
      acceptHeader.setParameter("level", "1");
      sipRequest.addHeader(acceptHeader);
      sipRequest.addHeader(headerFactory.createAcceptHeader(
            ISSIConstants.APPLICATION, ISSIConstants.X_TIA_P25_ISSI));

      ContentDispositionHeader cd = headerFactory
            .createContentDispositionHeader(ContentDispositionHeader.SESSION);
      cd.setHandling("required");
      sipRequest.addHeader(cd);
      return sipRequest;
   }

   /**
    * Setup and send a requestOut.
    * 
    * @param peerSu
    */
   public UnitToUnitCall setupRequest(Request inviteRequest,
         SuInterface callingSu, SuConfig calledSuConfig) throws Exception {

      SuConfig callingSuConfig = callingSu.getSuConfig();
      ServiceAccessPoints saps = callingSu.getServiceAccessPoints();
      CallControlSAP ccSap = saps.getCallControlSAP();
      PendingResponse pendingResponse = new PendingResponse();
      pendingResponse.su = callingSu;
      pendingResponse.proceedure = CallControlManager.CC_SETUP_SEND_REQUEST;
      ClientTransaction ct = provider.getNewClientTransaction(inviteRequest);

      ct.setApplicationData(pendingResponse);
      Dialog dialog = ct.getDialog();
      UnitToUnitCall unitToUnitCall = new UnitToUnitCall(callingSuConfig,
            calledSuConfig, provider);
      unitToUnitCall.setPriority(SipUtils.getPriorityValue(
            (PriorityHeader) inviteRequest.getHeader(PriorityHeader.NAME)));
      unitToUnitCall.setEmergency(SipUtils.isEmergency(
            (PriorityHeader) inviteRequest.getHeader(PriorityHeader.NAME)));
      unitToUnitCall.setClientTransaction(ct);
      dialog.setApplicationData(unitToUnitCall);
      ct.sendRequest();
      return unitToUnitCall;
   }

   /**
    * Send an in-call roaming request.
    * 
    * @param inviteRequest
    * @param unitToUnitCall
    * @param su
    * @throws Exception
    */
   public void setupInCallRoamingRequest(Request inviteRequest,
         UnitToUnitCall unitToUnitCall, SuInterface su) throws Exception {
      ServiceAccessPoints saps = su.getServiceAccessPoints();
      CallControlSAP ccSap = saps.getCallControlSAP();
      PendingResponse pendingResponse = new PendingResponse();
      pendingResponse.su = su;
      pendingResponse.proceedure = CallControlManager.CC_SETUP_SEND_REQUEST;
      ClientTransaction ct = provider.getNewClientTransaction(inviteRequest);
      ct.getDialog().setApplicationData(unitToUnitCall);
      ct.setApplicationData(pendingResponse);
      ct.sendRequest();
      unitToUnitCall.setClientTransaction(ct);

   }

   /**
    * Send a response to the Transaction. Remove the record route header
    * because we are structuring this whole thing as a B2BUA
    * 
    * @param callSetupRequestEvent
    * @param response
    * @throws Exception
    */
   public void sendResponse(CallSetupRequestEvent callSetupRequestEvent,
         Response response) throws Exception {
      ServerTransaction serverTx = callSetupRequestEvent.getServerTransaction();
      serverTx.sendResponse(response);
   }

   /**
    * Teardown a call segment.
    * 
    * @param unitToUnitCall --
    *            the call segment to tear down.
    */

   public void teardownRequest(HomeAgentInterface su,
         UnitToUnitCall unitToUnitCall, String radicalName) throws Exception {
      logger.debug("teardownRequest : radicalName = " + radicalName);
      Dialog dialog = unitToUnitCall.getDialog(radicalName);
      Request byeRequest = dialog.createRequest(Request.BYE);
      SipURI sipUri = (SipURI) byeRequest.getRequestURI();
      sipUri.setUserParam(ISSIConstants.TIA_P25_SU);
      ClientTransaction ct = unitToUnitCall.getProvider().getNewClientTransaction(byeRequest);
      PendingResponse pendingResponse = new PendingResponse();
      pendingResponse.proceedure = CallControlManager.CC_SETUP_TEARDOWN_REQUEST;
      pendingResponse.su = su;
      pendingResponse.unitToUnitCall = unitToUnitCall;
      ct.setApplicationData(pendingResponse);
      dialog.sendRequest(ct);
   }

   /**
    * Send a response to the BYE.
    * 
    * @param teardownRequest --
    *            incoming Teardown request.
    * @throws Exception --
    *             if something bad happened.
    */

   public void sendCallTeardownResponse(RequestEvent requestEvent)
         throws Exception {
      Request request = requestEvent.getRequest();
      Response response = messageFactory.createResponse(Response.OK, request);
      ServerTransaction st = requestEvent.getServerTransaction();
      st.sendResponse(response);
   }

   /*
    * The following are callbacks from JSIP
    */

   /**
    * The callback from the sip listener. This gets called when an incoming
    * request is received by the sip stack.
    */
   public void processRequest(RequestEvent requestEvent) {
      logger.info("Processing incoming request "
            + requestEvent.getRequest().getMethod()
            + " at "
            + rfssConfig.getHostPort()
            + " rfssId = "
            + rfssConfig.getRfssId()
            + " listening point = "
            + ((SipProvider) requestEvent.getSource()).getListeningPoint(
                  "udp").getPort());
      
      String method = requestEvent.getRequest().getMethod();      
      if (Request.INVITE.equals(method)) {
         processInvite(requestEvent);
      } 
      else if (Request.ACK.equals(method)) {
         processAck(requestEvent);
      }
      else if (Request.BYE.equals(method)) {
         processBye(requestEvent);
      }
      else if (Request.CANCEL.equals(method)) {
         processCancel(requestEvent);
      }

   }

   /**
    * Process an incoming CANCEL request.
    * 
    * @param requestEvent
    */
   private void processCancel(RequestEvent requestEvent) {
      try {
         // Get the Dialog from the incoming request event.
         // this will be the same as the Dialog assigned to the INVITE

         logger.debug("processCancel ");

         Dialog dialog = requestEvent.getServerTransaction().getDialog();
         UnitToUnitCall unitToUnitCall = (UnitToUnitCall) dialog
               .getApplicationData();

         logger.debug("cancelSialog = " + dialog);

         ServerTransaction cancelServerTransaction = requestEvent
               .getServerTransaction();
         Response cancelResponse = messageFactory.createResponse(
               Response.OK, cancelServerTransaction.getRequest());
         cancelServerTransaction.sendResponse(cancelResponse);
         ServerTransaction st = unitToUnitCall.getServerTransaction();

         if (st.getState() == TransactionState.PROCEEDING) {
            Response response = messageFactory.createResponse(
                  Response.REQUEST_TERMINATED, st.getRequest());
            st.sendResponse(response);
         }
         dialog = unitToUnitCall.getPeerDialog(dialog);
         if (dialog == null) {
            // this is the end of the line.
            ToHeader toHeader = (ToHeader) st.getRequest().getHeader(
                  ToHeader.NAME);
            SipURI sipUri = (SipURI) toHeader.getAddress().getURI();
            String radicalName = SipUtils.getRadicalName(sipUri);
            SuConfig suConfig = topologyConfig.getSuConfig(radicalName);
            TestSU testSu = (TestSU) suConfig.getSU();
            testSu.handleCancelIndicate(unitToUnitCall);
         } else if (dialog.getState() != DialogState.CONFIRMED
               && dialog.getState() != DialogState.TERMINATED) {
            ClientTransaction ct = unitToUnitCall.getClientTransaction();
            if (ct.getState() == TransactionState.PROCEEDING) {
               Request cancelRequest = ct.createCancel();
               ClientTransaction cancelTx = getProvider().getNewClientTransaction(cancelRequest);
               cancelTx.sendRequest();
            } else {
               logger
                     .debug("Cannot forward cancel -- already saw a final response");
            }
         }
      } catch (Exception ex) {
         rfss.getTestHarness().fail(
               "Unexpected exception processing cancel", ex);
      }

   }

   private void processBye(RequestEvent requestEvent) {
      try {
         Request request = requestEvent.getRequest();
         FromHeader fromHeader = (FromHeader) request
               .getHeader(FromHeader.NAME);
         ToHeader toHeader = (ToHeader) request.getHeader(ToHeader.NAME);
         SipURI toUri = (SipURI) toHeader.getAddress().getURI();

         String targetRadicalName = toUri.getUser();
         SuConfig targetSu = topologyConfig.getSuConfig(targetRadicalName);
         ServerTransaction serverTransaction = requestEvent.getServerTransaction();

         SipURI fromURI = (SipURI) fromHeader.getAddress().getURI();
         SuConfig sourceSu = topologyConfig.getSuConfig(fromURI.getUser());
         UnitToUnitCall callSegment = (UnitToUnitCall) serverTransaction
               .getDialog().getApplicationData();

         assert (callSegment.includesSU(targetSu) || callSegment
               .includesSU(sourceSu));
         if (callSegment.getPeerDialog(serverTransaction.getDialog()) == null) {
            if (callSegment.includesSU(targetSu)) {
               String sessionId = SipUtils.getCallIdFromMessage(request);

               rfss.getTransmissionControlManager().teardownRTPPointToMultipointSession(sessionId);
               sendCallTeardownResponse(requestEvent);
               targetSu.getSU().handleTeardownIndicate(
                     new CallTeardownIndicateEvent(callSegment,
                           requestEvent));
            } else {
               sourceSu.getSU().handleTeardownIndicate(
                     new CallTeardownIndicateEvent(callSegment, requestEvent));
            }
         }

         if (rfssConfig == sourceSu.getHomeRfss()) {
            HomeAgent homeAgent = rfss.getHomeAgent(sourceSu
                  .getRadicalName());
            homeAgent.handleTeardownIndicate(new CallTeardownIndicateEvent(
                  callSegment, requestEvent));
         } else if (rfssConfig == targetSu.getHomeRfss()) {
            HomeAgent homeAgent = rfss.getHomeAgent(targetSu.getRadicalName());
            homeAgent.handleTeardownIndicate(new CallTeardownIndicateEvent(
                  callSegment, requestEvent));
         }

         // BYE is handled hop by hop.

         Dialog dialog = serverTransaction.getDialog();
         Response response = messageFactory.createResponse(Response.OK,
               request);
         serverTransaction.sendResponse(response);
         Dialog peerDialog = ((UnitToUnitCall) dialog.getApplicationData())
               .getPeerDialog(dialog);
         if (peerDialog != null
               && peerDialog.getState() == DialogState.TERMINATED) {
            logger.debug("peerDialog null or terminated");
            logger.debug("peer dialog is " + peerDialog);
            if (peerDialog != null) {
               logger.debug("peer dialog state is "
                     + peerDialog.getState());
            }
            return;
         }
         if (peerDialog != null) {
            Request newRequest = peerDialog.createRequest(Request.BYE);
            SipURI sipUri = (SipURI) newRequest.getRequestURI();
            sipUri.setUserParam(ISSIConstants.TIA_P25_SU);
            ViaHeader viaHeader = SipUtils.createViaHeaderForRfss(rfssConfig);
            newRequest.setHeader(viaHeader);

            ClientTransaction ct = provider.getNewClientTransaction(newRequest);
            if (logger.isDebugEnabled()) {
               logger.debug("sending to peer dialog " + peerDialog);
            }
            peerDialog.sendRequest(ct);
         } else {
            logger.debug("Peer dialog is null -- not forwarding BYE");
         }

      } catch (Exception ex) {
         String s = "internal error - unexpected exception ";
         rfss.logError(s, ex);
         throw new RuntimeException(s, ex);

      }

   }

   private void processAck(RequestEvent requestEvent) {
      System.out.println("UnitToUnitCallControlManager(9): Processing ACK ");
      try {
         logger.debug("UnitToUnitCallControlManager: Processing ACK ");
         
         Request request = requestEvent.getRequest();
         ToHeader toHeader = (ToHeader) request.getHeader(ToHeader.NAME);
         SipURI toUri = (SipURI) toHeader.getAddress().getURI();

         String targetRadicalName = toUri.getUser();
         SuConfig targetSu = topologyConfig.getSuConfig(targetRadicalName);
         ServerTransaction serverTransaction = requestEvent.getServerTransaction();
         
         // I got the ACK - I can now start media flowing the other way.
         Dialog dialog = serverTransaction.getDialog();
         if (logger.isDebugEnabled()) {
            logger.debug("dialog = " + dialog);
         }

         UnitToUnitCall unitToUnitCall = (UnitToUnitCall) serverTransaction
               .getDialog().getApplicationData();
         ServerTransaction inviteTx = unitToUnitCall.getServerTransaction();
         String sessId = SipUtils.getSessionIdFromMessage(inviteTx
               .getRequest());

         if (unitToUnitCall.getPointToMultipointSession().getSessionType()
               .equals(SessionType.CALLED_HOME)) {

            PttSession pttSession = unitToUnitCall
                  .getPointToMultipointSession().getMmfSession(sessId);
            if (pttSession != null) {
               pttSession.getHeartbeatTransmitter().start();
            }
         } else if (unitToUnitCall.getPointToMultipointSession()
               .getSessionType().equals(SessionType.CALLING_HOME)) {
            PttSession pttSession = unitToUnitCall
                  .getPointToMultipointSession().getMmfSession(sessId);
            if (pttSession != null) {
               pttSession.getHeartbeatTransmitter().start();
            }
         } else if (unitToUnitCall.getPointToMultipointSession()
               .getSessionType().equals(SessionType.CALLED_SERVING)) {
            PttSession pttSession = unitToUnitCall
                  .getPointToMultipointSession().getSmfSession(sessId);
            if (pttSession != null) {
               pttSession.getHeartbeatTransmitter().start();
            }
         } else {
            logger.error("Unknown session type "
                  + unitToUnitCall.getPointToMultipointSession()
                        .getSessionType());
         }

         if (rfss.isSubscriberUnitServed(targetSu)) {
            targetSu.getSU().handleCallSetupConfirmEvent(
                  new CallSetupConfirmEvent(unitToUnitCall, requestEvent));
         } else {

            Dialog peerDialog = unitToUnitCall.getPeerDialog(dialog);
            CSeqHeader cseq = (CSeqHeader) request.getHeader(CSeqHeader.NAME);
            if (peerDialog != null) {
               Request newRequest = peerDialog.createAck(cseq.getSeqNumber());

               ClientTransaction ct = unitToUnitCall.getClientTransaction();
               Request invite = ct.getRequest();
               String sessionId = SipUtils.getSessionIdFromMessage(invite);

               PttSession pttSession = unitToUnitCall
                     .getPointToMultipointSession().getMmfSession( sessionId);
               if (pttSession != null) {
                  pttSession.getHeartbeatTransmitter().start();
               }
               
               // M1014
               newRequest.removeHeader(RouteHeader.NAME);
               SipUtils.checkContentLength( newRequest);
               //showln("UnitToUnitCallControlManager(9): sendAck: "+newRequest);
               peerDialog.sendAck(newRequest);
            }
         }

      } catch (Exception ex) {

         String s = "internal error - unexpected exception ";
         logger.error(s, ex);
         throw new RuntimeException(s, ex);
      }
   }

   /**
    * This function is called when processing an incoming invite. Right now it
    * only handles point to point calls
    * 
    * @param requestEvent --
    *            incoming SIP request event.
    * 
    */
   private void processInvite(RequestEvent requestEvent) {
      try {
         Request request = requestEvent.getRequest();
         FromHeader fromHeader = (FromHeader) request
               .getHeader(FromHeader.NAME);
         //ToHeader toHeader = (ToHeader) request.getHeader(ToHeader.NAME);
         //SipURI toUri = (SipURI) toHeader.getAddress().getURI();
         SipURI fromUri = (SipURI) fromHeader.getAddress().getURI();
         String radicalName = fromUri.getUser();

         SuConfig fromSu = topologyConfig.getSuConfig(radicalName);
         int fromUid = fromSu.getSuId();

         // String targetRadicalName = toUri.getUser();
         String targetRadicalName = ((SipURI) request.getRequestURI()).getUser();
         SuConfig targetSu = topologyConfig.getSuConfig(targetRadicalName);
         ServerTransaction serverTransaction = requestEvent.getServerTransaction();
         if (serverTransaction == null) {
            serverTransaction = provider.getNewServerTransaction(request);
         }

         logger.debug("inviteDialog " + serverTransaction.getDialog());
         ViaHeader viaHeader = SipUtils.createViaHeaderForRfss(rfssConfig);
         
         Request newRequest = (Request) request.clone();
         
         TimeStampHeader tsHeader = headerFactory
               .createTimeStampHeader((float) 0);
         tsHeader.setTime(System.currentTimeMillis());

         newRequest.removeFirst(RouteHeader.NAME);

         if (rfss.isSubscriberUnitServed(targetSu)) {
            // This must be the Serving RFSS of this SU. If so then call the
            // SU.
            logger
                  .debug("Reached the Serving RFSS of the Called SU -- invoking method");
            Dialog dialog = serverTransaction.getDialog();
            UnitToUnitCall unitToUnitCall = new UnitToUnitCall(fromSu,
                  targetSu, provider);
            unitToUnitCall.setPriority(SipUtils
                  .getPriorityValue((PriorityHeader) request
                        .getHeader(PriorityHeader.NAME)));
            unitToUnitCall.setEmergency(SipUtils
                  .isEmergency((PriorityHeader) request
                        .getHeader(PriorityHeader.NAME)));

            unitToUnitCall.setServerTransaction(serverTransaction);

            PriorityHeader priorityHeader = (PriorityHeader) request
                  .getHeader(PriorityHeader.NAME);
            // Record the priority of the call if a priority exists.
            if (priorityHeader != null) {
               int priorityValue = SipUtils
                     .getPriorityValue(priorityHeader);
               unitToUnitCall.setPriority(priorityValue);
               boolean emergency = SipUtils.isEmergency(priorityHeader);
               unitToUnitCall.setEmergency(emergency);
            }
            dialog.setApplicationData(unitToUnitCall);
            ContentList contentList = ContentList
                  .getContentListFromMessage(request);
            CallParamContent callParams = contentList.getCallParamContent();
            unitToUnitCall.setCallParam(callParams);

            targetSu.getSU().handeSetupIndicate(
                  new CallSetupRequestEvent(unitToUnitCall, requestEvent,
                        serverTransaction));

         } else if (fromSu.getHomeRfss() == rfssConfig) {

            if (!rfssConfig.isSubscriberUnitMine(fromSu)) {
               Response response = SipUtils.createErrorResponse(
                     rfssConfig, request,
                     WarningCodes.NOT_FOUND_UNKNOWN_CALLING_SU);
               serverTransaction.sendResponse(response);
               return;
            }

            // Calling Home RFSS checks if the unit is allowed to make a U2U
            if (fromSu.getUserServiceProfile()
                  .getUnitToUnitCallPermission().getPermission() == CallPermissionType.NONE
                  || fromSu.getUserServiceProfile()
                        .getUnitToUnitCallPermission().getPermission() == CallPermissionType.RECEIVE) {
               Response response = SipUtils.createErrorResponse(
                     rfssConfig, request,
                     WarningCodes.FORBIDDEN_CALLING_SU_NOT_AUTHORIZED);
               serverTransaction.sendResponse(response);
               return;
            }
            logger
                  .debug(request.getMethod()
                        + " homeRfss of the Caller -- forwarding to homeRfss of called");

            MaxForwardsHeader mf = (MaxForwardsHeader) newRequest
                  .getHeader(MaxForwardsHeader.NAME);
            mf.decrementMaxForwards();
            FromHeader newFromHeader = (FromHeader) newRequest
                  .getHeader(FromHeader.NAME);
            newFromHeader.removeParameter("tag");
            String newTag = SipUtils.createTag();
            newFromHeader.setTag(newTag);
            newRequest.addFirst(viaHeader);
            RecordRouteHeader rrHeader = SipUtils
                  .createRecordRouteHeaderForRfss(rfssConfig);
            newRequest.addFirst(rrHeader);
            // Setup the call segment for the hop
            UnitToUnitCall unitToUnitCall = new UnitToUnitCall(fromSu, targetSu, provider);

            unitToUnitCall.setPriority(SipUtils.getPriorityValue((PriorityHeader) request
                        .getHeader(PriorityHeader.NAME)));
            unitToUnitCall.setEmergency(SipUtils.isEmergency((PriorityHeader) request
                        .getHeader(PriorityHeader.NAME)));

            ClientTransaction ct = setupClientTransaction(
                  serverTransaction, newRequest, fromUid,
                  LinkType.UNIT_TO_UNIT_CALLING_HOME_TO_CALLED_HOME,
                  unitToUnitCall);
            if (ct == null) {
               logger.error("Client transaction setup returned an error --"
                           + " not creating call segment");
               return;
            }

            unitToUnitCall.setServerTransaction(serverTransaction);
            unitToUnitCall.setClientTransaction(ct);
            ContentList contentList = ContentList
                  .getContentListFromMessage(request);
            CallParamContent callParams = contentList.getCallParamContent();
            unitToUnitCall.setCallParam(callParams);

            serverTransaction.getDialog()
                  .setApplicationData(unitToUnitCall);
            ct.getDialog().setApplicationData(unitToUnitCall);
            PendingSDPAnswer pendingAnswer = (PendingSDPAnswer) ct
                  .getApplicationData();
            pendingAnswer.pendingOutgoingSession.getHeartbeatReceiver()
                  .setHeartbeatListener(unitToUnitCall);
            ct.sendRequest();
            
         } else if (targetSu.getHomeRfss().equals(rfssConfig)) {

            logger.debug(request.getMethod()
                        + ":  homeRfss of the called -- forwarding to servingRfss of called");

            // There should only be one serving RFSS for this URI

            if (!rfssConfig.isSubscriberUnitMine(targetSu)) {
               Response response = SipUtils.createErrorResponse(
                     rfssConfig, request,
                     WarningCodes.NOT_FOUND_UNKNOWN_CALLED_SU);
               serverTransaction.sendResponse(response);
               return;
            }

            if (targetSu.getUserServiceProfile()
                  .getUnitToUnitCallPermission().getPermission() == CallPermissionType.NONE
                  || targetSu.getUserServiceProfile()
                        .getUnitToUnitCallPermission().getPermission() == CallPermissionType.INITIATE) {
               Response response = SipUtils.createErrorResponse(
                     rfssConfig, request,
                     WarningCodes.FORBIDDEN_CALLED_SU_NOT_AUTHORIZED);
               serverTransaction.sendResponse(response);
               return;
            }
            // I am the targetSU home RFSS.
            // Get the registration record of which is the Serving RFSS.
            UnitToUnitMobilityManager mobilityManager = rfssConfig
                  .getRFSS().getUnitToUnitMobilityManager();

            SipURI nextUri = (SipURI) mobilityManager
                  .getRegisteredContactURI(request);
            if (nextUri == null) {
               // I dont know about this SU so send back a forbidden
               // response
               Response response = SipUtils.createErrorResponse(
                     rfssConfig, request,
                     WarningCodes.FORBIDDEN_CALLED_SU_NOT_REGISTERED);
               serverTransaction.sendResponse(response);
               return;
            }

            ContentList contentList = ContentList.getContentListFromMessage(request);

            if (contentList.getCallParamContent() != null) {
               CallParam callParams = contentList.getCallParamContent().getCallParam();
               if (callParams.isProtectedMode()) {
                  if (targetSu.getCProtectedDisposition() == CProtectedDisposition.CLEAR_PROTECTED) {
                     callParams.setProtectedMode(false);

                  } else if (targetSu.getCProtectedDisposition() == CProtectedDisposition.REJECT_PROTECTED) {
                     Response response = messageFactory.createResponse(
                           Response.FORBIDDEN, request);
                     serverTransaction.sendResponse(response);
                     return;
                  }
               } else {
                  if (targetSu.getCProtectedDisposition() == CProtectedDisposition.REJECT_UNPROTECTED) {
                     Response response = messageFactory.createResponse(
                           Response.FORBIDDEN, request);
                     serverTransaction.sendResponse(response);
                     return;
                  }
               }
            }
            if (logger.isDebugEnabled())
               logger.debug("routing to RFSS " + nextUri);

            nextUri.setLrParam();
            nextUri.setParameter("remove", "true");
            RouteHeader routeHeader = (RouteHeader) headerFactory
                  .createRouteHeader(addressFactory
                        .createAddress(nextUri));
            MaxForwardsHeader mf = (MaxForwardsHeader) newRequest
                  .getHeader(MaxForwardsHeader.NAME);
            mf.decrementMaxForwards();

            FromHeader newFromHeader = (FromHeader) newRequest
                  .getHeader(FromHeader.NAME);
            newFromHeader.removeParameter("tag");
            String newTag = SipUtils.createTag();
            newFromHeader.setTag(newTag);
            newRequest.addFirst(viaHeader);
            newRequest.setHeader(routeHeader);
            RecordRouteHeader rrHeader = SipUtils
                  .createRecordRouteHeaderForRfss(rfssConfig);
            newRequest.addFirst(rrHeader);
            // Setup the call segment for the hop
            UnitToUnitCall unitToUnitCall = new UnitToUnitCall(fromSu,
                  targetSu, provider);

            unitToUnitCall.setPriority(SipUtils
                  .getPriorityValue((PriorityHeader) request
                        .getHeader(PriorityHeader.NAME)));
            unitToUnitCall.setEmergency(SipUtils
                  .isEmergency((PriorityHeader) request
                        .getHeader(PriorityHeader.NAME)));

            ClientTransaction ct = setupClientTransaction(
                  serverTransaction, newRequest, fromUid,
                  LinkType.UNIT_TO_UNIT_CALLED_HOME_TO_CALLED_SERVING,
                  unitToUnitCall);
            if (ct == null) {
               logger.debug("Client tx setup returned null -- error condition.");
               return;
            }

            unitToUnitCall.setServerTransaction(serverTransaction);
            unitToUnitCall.setClientTransaction(ct);

            serverTransaction.getDialog().setApplicationData(unitToUnitCall);
            ct.getDialog().setApplicationData(unitToUnitCall);
            ct.sendRequest();

         } else {
            Response response = SipUtils.createErrorResponse(rfssConfig,
                  request, WarningCodes.NOT_FOUND_UNKNOWN_CALLED_SU);
            serverTransaction.sendResponse(response);
         }
      } catch (Throwable ex) {
         String s = "internal error - unexpected exception ";
         logger.fatal(s, ex);
         throw new RuntimeException(s, ex);
      }

   }

   /**
    * This gets called by the SIP listener when a response comes in.
    * 
    */
   public void processResponse(ResponseEvent responseEvent) {
      if (logger.isDebugEnabled()) {
         logger.debug(rfssConfig.getHostPort() + ": processResponse : "
               + responseEvent.getResponse().getStatusCode());
      }
      try {
         Response response = responseEvent.getResponse();

         String method = ((CSeqHeader) (response.getHeader(CSeqHeader.NAME)))
               .getMethod();

         ClientTransaction ct = responseEvent.getClientTransaction();
         if (ct == null) {
            logger.debug("Cannot find client transaction -- silently dropping response");
            return;
         }

         FromHeader from = (FromHeader) response.getHeader(FromHeader.NAME);

         String callingSuRadicalName = SipUtils.getRadicalName((SipURI) from
               .getAddress().getURI());
         SuConfig callingSuConfig = topologyConfig.getSuConfig(callingSuRadicalName);
         ToHeader to = (ToHeader) response.getHeader(ToHeader.NAME);
         String calledSuRadicalName = SipUtils.getRadicalName((SipURI) to
               .getAddress().getURI());
         SuConfig calledSuConfig = topologyConfig.getSuConfig(calledSuRadicalName);

         RfssConfig callingHomeRfss = callingSuConfig.getHomeRfss();
         RfssConfig calledHomeRfss = calledSuConfig.getHomeRfss();

         if (ct == null) {
            CSeqHeader cseq = (CSeqHeader) response
                  .getHeader(CSeqHeader.NAME);
            if (response.getStatusCode() == Response.OK
                  && cseq.getMethod().equals(Request.INVITE)) {
               logger.debug("Ct is null -- resending ACK");

               Dialog dialog = responseEvent.getDialog();
               if (dialog != null) {
                  Request ackRequest = dialog.createAck(cseq.getSeqNumber());
                  // M1014
                  ackRequest.removeHeader(RouteHeader.NAME);
                  SipUtils.checkContentLength( ackRequest);
                  System.out.println("UnitToUnitCallControlManager(8): sendAck: "+ackRequest);
                  dialog.sendAck(ackRequest);
               }
            } else {
               logger.debug("Ct is null -- returning");
            }

         } else {
            Dialog dialog = ct.getDialog();
            Object applicationData = ct.getApplicationData();

            if (logger.isDebugEnabled())
               logger.debug("UnitToUnitCall: processResponse: applicationData = "
                           + applicationData);

            if (applicationData != null
                  && applicationData instanceof PendingResponse) {
               // This is the sending end -- the end that originated the
               // invite
               // if this is the home of the caller add the call
               // segement to our table.
               UnitToUnitCall unitToUnitCall = (UnitToUnitCall) dialog
                     .getApplicationData();

               PendingResponse pendingResponse = (PendingResponse) applicationData;
               if (pendingResponse.proceedure == CallControlManager.CC_SETUP_SEND_REQUEST) {

                  UnitToUnitCallControlResponseEvent ccResponseEvent = 
                     new UnitToUnitCallControlResponseEvent(unitToUnitCall, responseEvent);
                  pendingResponse.su.handleCallSetupResponseEvent(ccResponseEvent);
                  if (response.getStatusCode() / 100 > 2) {
                     if (logger.isDebugEnabled()) {
                        logger.debug("response.statusCode == "
                              + response.getStatusCode());
                     }
                     Request request = ct.getRequest();
                     CallParam callParam = ContentList
                           .getContentListFromMessage(request)
                           .getCallParamContent().getCallParam();
                     if (callParam.isIncallRoaming()) {
                        FromHeader fromHeader = (FromHeader) request
                              .getHeader(FromHeader.NAME);
                        String radicalName = ((SipURI) fromHeader
                              .getAddress().getURI()).getUser();
                        teardownRequest(null, unitToUnitCall, radicalName);
                     } else {
                        logger.debug("callParam.isIncallRoaming ? " + false);
                     }
                  }
               } else if (pendingResponse.proceedure == CallControlManager.CC_SETUP_TEARDOWN_REQUEST) {
                  CallTeardownResponseEvent ccTeardownEvent = new CallTeardownResponseEvent(
                        unitToUnitCall, responseEvent);
                  HomeAgentInterface su = pendingResponse.su;
                  if (su != null) {
                     su.handleTeardownResponse(ccTeardownEvent);
                  }

               }
            } else if (applicationData != null) {
               PendingSDPAnswer pendingAnswer = (PendingSDPAnswer) applicationData;

               ServerTransaction st = pendingAnswer.serverTransaction;
               Request originalRequest = st.getRequest();

               if (response.getStatusCode() == 100) {
                  logger.debug("100 response -- not forwarded");
                  return;
               }
               Response newResponse = (Response) response.clone();
               
//               TimeStampHeader tsHeader = (TimeStampHeader) originalRequest
//                     .getHeader(TimeStampHeader.NAME);
//               newResponse.setHeader(tsHeader);
               newResponse.setHeader( SipUtils.createTimeStampHeader());
               
               newResponse.removeFirst(ViaHeader.NAME);

               if (((CSeqHeader) response.getHeader(CSeqHeader.NAME))
                     .getMethod().equals(Request.INVITE)) {
                  FromHeader fromHeader = (FromHeader) originalRequest
                        .getHeader(FromHeader.NAME);
                  FromHeader newFromHeader = (FromHeader) newResponse
                        .getHeader(FromHeader.NAME);
                  newFromHeader.setTag(fromHeader.getTag());

               }

               /*
                * Got a 200 OK -- so get the SDP listener going. This part
                * of the code gets involved in the forwarding of a
                * response. When the response is freceived.
                */
               if (((CSeqHeader) response.getHeader(CSeqHeader.NAME))
                     .getMethod().equals(Request.INVITE)) {
                  if (response.getStatusCode() == 100) {
                     logger.debug("Not forwarding the 100 response");
                  } else if (response.getStatusCode() == 200) {
                     /*
                      * Note that we stored the SDP offer in the pending
                      * answer during the time the request was forwarded.
                      * We add a media leg corresponding to the Sdp Offer
                      * now.
                      * 
                      * Add a media leg corresponding to the SdpAnswer
                      * now.
                      */

                     ContentList contentList = ContentList
                           .getContentListFromMessage(response);
                     SdpContent sdpAnswerContent = (SdpContent) contentList
                           .getContent("application", "sdp");
                     SessionDescription sdpAnswer = sdpAnswerContent
                           .getSessionDescription();

                     /*
                      * at this point, we have an answer from the other
                      * end to whom we originally forwarded the INVITE.
                      * we know what port the other end is listening at.
                      * So we put that information to our pending
                      * session. AddMeiaLeg simply fixes up the rtp
                      * session and inserts the information where the
                      * other end is listening. This media leg belongs to
                      * the host that sent us the request.
                      */

                     String senderDomainName;
                     if (rfssConfig == calledHomeRfss)
                        senderDomainName = SipUtils.getContactHost(response);
                     else
                        senderDomainName = calledHomeRfss.getDomainName();

                     rfss.getTransmissionControlManager().addMediaLeg(
                                 0,
                                 pendingAnswer.pendingOutgoingSession,
                                 sdpAnswer, senderDomainName);

                     /*
                      * Now we need to setup an RTP / PTT session to
                      * listen for the packets from the side that sent us
                      * the INVITE and for whom we are about to forward
                      * the response. For this We create an rtp session
                      * which will listen on a random even port. Here we
                      * are setting up a session for the end that sent us
                      * the invite.
                      */

                     LinkType linkType = null;
                     if (rfssConfig == calledHomeRfss) {
                        linkType = LinkType.UNIT_TO_UNIT_CALLED_HOME_TO_CALLING_HOME;
                     } else if (rfssConfig == callingHomeRfss) {
                        linkType = LinkType.UNIT_TO_UNIT_CALLING_HOME_TO_CALLING_SERVING;
                     }
                     MmfSession outgoingSession = null;
                     String sessId = ((OriginField) pendingAnswer.incomingSdpOffer
                           .getOrigin()).getSessIdAsString();

                     try {
                        outgoingSession = pendingAnswer.pointToMultipointSession
                              .createMmfSession(linkType, sessId);
                        outgoingSession.setSetIsNotInterestedInLosingAudio(rfssConfig
                                    .isNotInterestedInLosingAudio());
                        if (rfssConfig == calledHomeRfss) {
                           String remoteRfssDomainName = callingSuConfig
                                 .getHomeRfss().getDomainName();
                           outgoingSession
                                 .setRemoteRfssDomainName(remoteRfssDomainName);
                        } else {
                           String remoteRfssDomainName = SipUtils
                                 .getViaHost(pendingAnswer.serverTransaction
                                       .getRequest());

                           outgoingSession
                                 .setRemoteRfssDomainName(remoteRfssDomainName);
                        }

                     } catch (RtpException ex) {
                        Response errorResponse = SipUtils
                              .createErrorResponse(rfssConfig,
                                    pendingAnswer.serverTransaction
                                          .getRequest(),
                                    WarningCodes.NO_RTP_RESOURCE);
                        pendingAnswer.serverTransaction
                              .sendResponse(errorResponse);
                        pendingAnswer.pointToMultipointSession
                              .shutDown();
                        return;

                     }

                     /*
                      * this media leg belongs to the host that sent us
                      * the response
                      */

                     senderDomainName = SipUtils.getViaHost(pendingAnswer.serverTransaction
                                 .getRequest());

                     getTransmissionControlManager().addMediaLeg(0,
                           outgoingSession,
                           pendingAnswer.incomingSdpOffer,
                           senderDomainName);
                     CallControlManager.fixupSdpAnnounce( rfssConfig, outgoingSession,
                           pendingAnswer.incomingSdpOffer);

                     String body = pendingAnswer.incomingSdpOffer.toString();
                     SdpContent sdpContent = SdpContent.createSdpContent(body);
                     contentList.setContent("application", "sdp",
                           sdpContent);

                     /*
                      * copy the content type header from the incoming
                      * response note that we may be dealing with a
                      * multipart mime header here.
                      */

                     UnitToUnitCall unitToUnitCall = (UnitToUnitCall) dialog.getApplicationData();
                     unitToUnitCall.setPointToMultipointSession(pendingAnswer.pointToMultipointSession);
                     outgoingSession.getHeartbeatReceiver().setHeartbeatListener(unitToUnitCall);

                     if (rfssConfig == callingHomeRfss) {
                        /*
                         * Inform the calling home RFSS to add a new
                         * call segment to the HomeAgent there. if this
                         * is the home of the caller add the call
                         * segement to our table.
                         */

                        UnitToUnitCallControlResponseEvent ccResponseEvent = new UnitToUnitCallControlResponseEvent(
                              unitToUnitCall, responseEvent);
                        HomeAgentInterface homeAgent = rfss.getHomeAgent(callingSuConfig.getRadicalName());
                        homeAgent.handleCallSetupResponseEvent(ccResponseEvent);
                        CallParamContent callparamContent = contentList.getCallParamContent();
                        unitToUnitCall.setCallingSuInitrans(callparamContent.getCallParam()
                                    .isCallingSuInitialTransmitter());

                     } else if (rfssConfig == calledHomeRfss) {
                        /*
                         * Inform the called home RFSS to add a new call
                         * segment to the home agent there.
                         */

                        UnitToUnitCallControlResponseEvent ccResponseEvent = new UnitToUnitCallControlResponseEvent(
                              unitToUnitCall, responseEvent);
                        HomeAgentInterface homeAgent = rfss.getHomeAgent(calledSuConfig.getRadicalName());

                        homeAgent.handleCallSetupResponseEvent(ccResponseEvent);
                        /*
                         * If we are the called home RFSS we set up the
                         * c-initrans parameter for the 200 OK response.
                         */
                        CallParamContent callparamContent = contentList.getCallParamContent();
                        callparamContent.getCallParam().setCallingSuInitialTransmitter(
                                    rfssConfig.isCallingSuInitialTransmitter());
                        unitToUnitCall.setCallingSuInitrans(rfssConfig.isCallingSuInitialTransmitter());

                     }

                     if (logger.isDebugEnabled()) {
                        logger.debug("Saw a 200 OK. Here is the Transmission Control manager sessions");
                        logger.debug(rfss.getTransmissionControlManager().toString());
                        logger.debug("-------------------------------------------------");
                     }
                     newResponse.setContent(contentList.toString(), contentList.getContentTypeHeader());
                     st.sendResponse(newResponse);

                  } else if (response.getStatusCode() / 100 > 2) {

                     // Error response --- tear down the session.
                     // or do something else like that...TODO
                     if (st.getState() != TransactionState.TERMINATED
                           && st.getState() != TransactionState.CONFIRMED) {
                        logger.debug("Tx state is " + st.getState());
                        st.sendResponse(newResponse);
                     }

                  } else {
                     st.sendResponse(newResponse);
                  }
               }

            } else {

               UnitToUnitCall unitToUnitCall = (UnitToUnitCall) dialog.getApplicationData();

               if (method.equals(Request.BYE)) {
                  if (rfssConfig == calledHomeRfss) {
                     CallTeardownResponseEvent ccTeardownEvent = new CallTeardownResponseEvent(
                           unitToUnitCall, responseEvent);
                     HomeAgentInterface homeAgent = rfss.getHomeAgent(calledSuConfig.getRadicalName());
                     homeAgent.handleTeardownResponse(ccTeardownEvent);

                  } else if (rfssConfig == callingHomeRfss) {
                     CallTeardownResponseEvent ccTeardownEvent = new CallTeardownResponseEvent(
                           unitToUnitCall, responseEvent);
                     HomeAgentInterface homeAgent = rfss.getHomeAgent(callingSuConfig.getRadicalName());
                     homeAgent.handleTeardownResponse(ccTeardownEvent);
                  }
               } else if (method.equals(Request.CANCEL)) {
                  logger.debug("Got response from CANCEL -- not forwarding   ");
               }
               logger.debug("not forwarding the response " +
                  "-- this must be a point to point request (i.e. CANCEL or BYE)");
            }
         }
      } catch (Exception ex) {
         String s = "unexpected exception forwarding response";
         logger.error(s, ex);
         throw new RuntimeException(s, ex);
      }
   }

   public void processTimeout(TimeoutEvent arg0) {
   }

   public void processIOException(IOExceptionEvent arg0) {
   }

   public void processTransactionTerminated(
         TransactionTerminatedEvent transactionTerminatedEvent) {
   }

   public void processDialogTerminated(DialogTerminatedEvent dte) {

      Dialog dialog = dte.getDialog();
      UnitToUnitCall unitToUnitCall = (UnitToUnitCall) dialog.getApplicationData();
      PttPointToMultipointSession pttSession = unitToUnitCall.getPointToMultipointSession();
      if (pttSession != null) {
         pttSession.shutDown();
      } else {
         logger.debug("PttSession is null for " + unitToUnitCall);
      }
   }

   public SipProvider getProvider() {
      return provider;
   }

   /**
    * Drop all the calls that are known to this call control manager. This
    * method terminates all call segments for all served subscriber units.
    * 
    */
   public void dropAllCalls() {
      for (SuConfig suConfig : rfss.getServedSubscriberUnits()) {
         if (suConfig.getSU() != null) {
            TestSU testSu = (TestSU) suConfig.getSU();
            testSu.terminateUnitToUnitCall();
         }
      }
   }

   /**
    * Send a cancel for this client transaction.
    * 
    * @param ct
    * @throws Exception
    * @undocumented
    */
   public void sendCancel(ClientTransaction ct) throws Exception {
      Request cancelRequest = ct.createCancel();
      ClientTransaction cancelTx = provider.getNewClientTransaction(cancelRequest);
      cancelTx.sendRequest();
   }

   /**
    * Send the response via a server transaction .
    * 
    * @param serverTransaction --
    *            the server transaction to respond to.
    * @param responseCode --
    *            the response code.
    * @throws Exception
    */
   public void sendResponse(ServerTransaction serverTransaction,
         int responseCode) throws Exception {
      Response response = this.messageFactory.createResponse(responseCode,
            serverTransaction.getRequest());
      serverTransaction.sendResponse(response);
   }

   public void alertRfResourceChange(boolean resourceVal) {
      // TODO Auto-generated method stub
   }
}
