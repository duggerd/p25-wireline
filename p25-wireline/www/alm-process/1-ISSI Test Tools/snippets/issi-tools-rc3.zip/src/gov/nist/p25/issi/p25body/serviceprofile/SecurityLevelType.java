//
package gov.nist.p25.issi.p25body.serviceprofile;

public enum SecurityLevelType {

   // (ClearOnly|SecureOnly|ClearAndSecure)
   CLEAR_MODE_ONLY_CALLS(1, "1: Clear Mode Only","ClearOnly"),
   SECURE_MODE_ONLY_CALLS(2,"2: Secure Mode Only Calls","SecureOnly"), 
   SECURE_AND_CLEAR_CALLS(3,"3: Clear Mode and Secure mode calls","ClearAndSecure");

   private int intValue;
   private String description;
   private String shortName;

   private SecurityLevelType(int level, String description, String shortName) {
      this.intValue = level;
      this.description = description;
      this.shortName = shortName;
   }

   public int getIntValue() {
      return intValue;
   }

   public static SecurityLevelType getInstance(int level) {
      for (SecurityLevelType lev : SecurityLevelType.values()) {
         if (level == lev.intValue)
            return lev;
      }
      throw new IllegalArgumentException("Illegal arg :" + level);
   }

   @Override
   public String toString() {
      return description;
   }

   public static SecurityLevelType getInstance(String level) {
      for (SecurityLevelType lev : SecurityLevelType.values()) {
         if (level.equals(lev.shortName))
            return lev;
      }
      throw new IllegalArgumentException("Illegal arg :" + level);
   }
}
