//
package gov.nist.p25.issi.p25body.serviceprofile;

public enum AccessPermissionType {

   NO_ACCESS(0, "No access allowed","None"),
   FULL_ACCESS(1, "Full Access Allowed","Full"),
   EMERGENCY_ACCESS( 2, "Only Emergency Acccess Allowed","Emergency");

   private int intValue;
   private String description;
   private String shortDescr;

   AccessPermissionType(int val, String description, String shortDescr) {
      this.intValue = val;
      this.description = description;
      this.shortDescr = shortDescr;
   }

   public int getIntValue() {
      return this.intValue;
   }

   @Override
   public String toString() {
      return description;
   }

   public static AccessPermissionType getInstance(int access) {
      for (AccessPermissionType acc : AccessPermissionType.values())
         if (access == acc.intValue)
            return acc;
      throw new IllegalArgumentException("Bad access value");
   }

   public static AccessPermissionType getInstance(String accessPermission) {
      for ( AccessPermissionType ac : AccessPermissionType.values()) {
         if (ac.shortDescr.equals(accessPermission)) return ac;
      }
      throw new IllegalArgumentException("Bad access value : "  + accessPermission ) ;
   }
}
