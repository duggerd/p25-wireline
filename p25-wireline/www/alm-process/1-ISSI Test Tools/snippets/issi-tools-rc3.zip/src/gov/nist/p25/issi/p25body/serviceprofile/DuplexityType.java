//
package gov.nist.p25.issi.p25body.serviceprofile;

public enum DuplexityType {

   HALF(0, "full duplex"),
   FULL(1, "half duplex");

   private int intValue;
   private String description;

   DuplexityType(int dup, String desc) {
      this.intValue = dup;
      this.description = desc;
   }

   public int getIntValue() {
      return intValue;
   }

   @Override
   public String toString() {
      return description;
   }

   public static DuplexityType getInstance(int duplexInt) {
      for (DuplexityType d : DuplexityType.values())
         if (d.intValue == duplexInt)
            return d;
      throw new IllegalArgumentException("Value out of range: "+duplexInt);
   }
}
