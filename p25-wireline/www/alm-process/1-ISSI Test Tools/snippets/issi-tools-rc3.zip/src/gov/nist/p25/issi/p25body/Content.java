// 
package gov.nist.p25.issi.p25body;

import gov.nist.p25.issi.constants.ISSIConstants;
import gov.nist.p25.issi.utils.ProtocolObjects;

import java.text.ParseException;
import javax.sip.header.ContentTypeHeader;

/**
 * P25 content for sip signaling messages is multipart mime. Each part is
 * represented by one of these structures.
 * 
 * @author M. Ranganathan
 * 
 */
public abstract class Content {

   protected static final String HEADER_START = "{\\insrsid15927085 ";

   protected static final String IGNORED_FIELD = "}{\\i\\fs16\\insrsid15927085 ";

   protected static final String HEADER_END = "\\par }\n";
   
   protected static final String HEADER_RESTART = "} " + HEADER_START;
   
   protected static final String LINE_FEED ="{\\par}\n";

   /*
    * The content type header for P25 content.
    */
   protected static ContentTypeHeader p25ContentTypeHeader;

   /*
    * The content type header for sdp content;
    */
   protected static ContentTypeHeader sdpContentTypeHeader;

     
   String boundary;
   
   /*
    * The content type header for this chunk of content.
    */
   private ContentTypeHeader contentTypeHeader;

   private String content;

   static {
      try {
         p25ContentTypeHeader = ProtocolObjects.headerFactory
               .createContentTypeHeader(ISSIConstants.APPLICATION,
                     ISSIConstants.X_TIA_P25_ISSI);
         sdpContentTypeHeader = ProtocolObjects.headerFactory
               .createContentTypeHeader(ISSIConstants.APPLICATION,
                     ISSIConstants.SDP);
      } catch (ParseException ex) {
         throw new RuntimeException(ex);
      }
   }

   public Content(ContentTypeHeader ctHeader, String content) {
      this.content = content;
      this.contentTypeHeader = ctHeader;
      boundary = null;
   }

   public void setContent(String content) {
      this.content = content;
   }

   public ContentTypeHeader getContentTypeHeader() {
      return contentTypeHeader;
   }

   public String getBoundary() {
      return boundary;
   }

   /**
    * The default packing method. This packs the content to be appended to the
    * sip message.
    * 
    */
   public String toString() {
      // This is not part of a multipart message.
      if (boundary == null) {
         return content;
      } else {
         return boundary + "\r\n" + contentTypeHeader + "\r\n\r\n" + content.trim()+"\r\n";
      }
   }
   
   /**
    * Return true if this object has all default parameters set ( so it does not 
    * get converted to string when packing.
    */
   public abstract boolean isDefault();
   
   /**
    * Return an RTF formatted string 
    * @return
    */
   public abstract String toRtfString() ;
   
   /**
    * Match with a given content.
    */
   public abstract boolean match(Content template);

}
