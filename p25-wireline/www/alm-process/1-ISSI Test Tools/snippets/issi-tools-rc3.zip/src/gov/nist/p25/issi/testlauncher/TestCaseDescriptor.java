//
package gov.nist.p25.issi.testlauncher;

/**
 * This describes a stanza in the test case registry. Each test case has a
 * directory and is described by some text (based on the test document) and
 * has a test number which corresponds to the test document.
 * 
 */
public class TestCaseDescriptor {
   
   private String category;
   private String directoryName;
   private String testNumber;
   private String testDescription;   
   private String localTopologyName;

   // accessors
   public String getCategory() {
      return category;
   }

   public String getDirectoryName() {
      return directoryName;
   }
   public String getFileName() {
      return directoryName + "/testscript.xml";
   }

   public String getTestNumber() {
      return testNumber;
   }

   public String getTestDescription() {
      return testDescription + 
         "\nNOTE: ADDITIONAL SIGNALING FOR SETUP AND TEARDOWN\n" +
         "OF TEST IS INCLUDED IN CALL FLOW";
   }

   public void setTestDescription(String testDescription) {
      this.testDescription = testDescription.trim();
   }

   public String getTopologyFileName() {
      return directoryName + "/" + localTopologyName;
   }   

   // constructor
   public TestCaseDescriptor(String dir, String topologyName, String testNum,
      String category) {
      this.directoryName = dir;
      this.testNumber = testNum;
      this.category = category;
      this.localTopologyName = topologyName;   
   }

   public String toString() {
      return testNumber + " : " + directoryName;
   }
}
