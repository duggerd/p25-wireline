//
package gov.nist.p25.issi.constants;

/**
 * ISSI Logo Constants
 */
public interface ISSILogoConstants {

   // NOTE: this must match the iconFile in izpack xml files
   public static final String ISSI_TESTER_LOGO = "gfx/tester-icon.gif";

}
