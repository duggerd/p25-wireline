//
package gov.nist.p25.issi.traceviewer;

import java.awt.Dimension;

/**
 * This class serves as the base class for SIP and PTT Message data.
 *
 */
public abstract class MessageData {
      
   private int id = -1;
   private String fromRfssId;
   private String toRfssId;
   private String fromPort;
   private String toPort;
   private String messageType;

   private String textData = "";
   private String data;
   private String time;
   private int x;
   private int y;
   private Dimension dimension;
   private String colorMapKey;
   private String rawdata = "";
   private boolean selected = false;   
   private boolean isSender  = false;
   
   // constructor
   public MessageData(String fromRfssId, String toRfssId, String fromPort, 
         String toPort, String messageType,
         String data, String time, String colorMapKey, 
         boolean selected, boolean isSender)
   {
      this.fromRfssId = fromRfssId;
      this.toRfssId = toRfssId;
      this.fromPort = fromPort;
      this.toPort = toPort;
      this.messageType = messageType;
      this.data = data;
      this.time = time;
      this.id = -1;
      setColorMapKey(colorMapKey);
      setSelected(selected);
      setSender(isSender);
   }

   // accessors
   public String getFromRfssId() {
      return  !isSender() ? fromRfssId : toRfssId;
   }

   public String getToRfssId() {
      return !isSender() ? toRfssId : fromRfssId;   
   }

   public String getFromPort() {
      return !isSender() ? fromPort : toPort;
   }

   public String getToPort() {
      return !isSender() ? toPort : fromPort;
   }

   public String getMessageType() {
      return messageType;
   }

   public String getData() {
      return data;
   }

   public String getRawdata() {
      return rawdata;
   }
   public void setRawdata(String rawdata) {
      this.rawdata = rawdata;
   }
   
   // Uses to reformat data into ISSI Spec
   public String getTextData() {
      return textData;
   }
   public void setTextData(String textData) {
      this.textData = textData;
   }

   public String getTime() {
      return this.time;
   }

   public int getId() {
      return id;
   }
   public void setId(int id) {
      this.id = id;
   }
   
   public int getX() {
      return x;
   }
   public void setX(int x) {
      this.x = x;
   }

   public int getY() {
      return y;
   }
   public void setY(int y) {
      this.y = y;
   }

   public Dimension getDimension() {
      return dimension;
   }
   public void setDimension(Dimension dimension) {
      this.dimension = dimension;
   }

   public String getColorMapKey() {
      return colorMapKey;
   }
   private void setColorMapKey(String colorMapKey) {
      this.colorMapKey = colorMapKey;
   }

   public boolean isSelected() {
      return selected;
   }
   public boolean getSelected() {
      return selected;
   }
   public void setSelected(boolean selected) {
      this.selected = selected;
   }

   public boolean isSender() {
      return isSender;
   }
   public boolean getSender() {
      return isSender;
   }
   public void setSender(boolean isSender) {
      this.isSender = isSender;
   }
}
