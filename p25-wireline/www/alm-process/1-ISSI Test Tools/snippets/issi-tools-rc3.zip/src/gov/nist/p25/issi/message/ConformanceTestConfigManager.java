//
package gov.nist.p25.issi.message;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gov.nist.p25.common.util.FileUtility;
import gov.nist.p25.issi.message.XmlConformanceTestConfig;

import org.apache.log4j.Logger;


public class ConformanceTestConfigManager
{
   private static Logger logger = Logger.getLogger(ConformanceTestConfigManager.class);
   public static void showln(String s) { System.out.println(s); }

   private List<String> fileList;

   // accessor
   public List<String> getFileList() {
      return fileList;
   }

   // constructor
   public ConformanceTestConfigManager() {
   }

   public List<String> getFileList(File dir) throws IOException {
      fileList = new ArrayList<String>();
      visitAllFiles( dir);
      return fileList;
   }

   public List<String> reconcileRfssName(Map<String,String> nameMap, File dir,
      boolean save) throws Exception
   {
      List<String> modList = new ArrayList<String>();
      List<String> fileList = getFileList( dir);

      logger.debug("reconcileRfssName(): "+nameMap);
      for( String fullpath: fileList) {
         //showln(" -- "+fullpath);
         String xmlMsg = FileUtility.loadFromFileAsString(fullpath);
         XmlConformanceTestConfig xmldoc = new XmlConformanceTestConfig();
         xmldoc.loadConformanceTestConfig(xmlMsg);
         boolean mflag = xmldoc.reconcileRfssName( nameMap);
         if( mflag) {
            if( save) {
               logger.debug("Save: "+fullpath);
               xmldoc.saveConformanceTestConfig( fullpath);
            }
            modList.add( fullpath);
         }
      }
      logger.debug("modList.size(): "+modList.size());
      return modList;
   }

   // Visit all files under a given directory
   // dir:   testsuites/conformance/testscripts/
   // file:  su_registration_successful_presence/topology1.xml
   //
   protected void visitAllFiles(File dir) throws IOException {
      if (dir.isDirectory()) {
         String[] children = dir.list();
         for (int i=0; i<children.length; i++) {
            visitAllFiles(new File(dir, children[i]));
         }
      } else {
         process(dir);
      }
   }

   protected void process(File file) throws IOException {
      String name = file.getName();
      if(name.startsWith("topology") && name.endsWith(".xml")) {
         String fullpath = file.getCanonicalPath();
         fileList.add( fullpath);
      }
   }

   //=====================================================================
   public static void main(String[] args) throws Exception {

      String dirname = "testsuites/conformance/testscripts";
      File dir = new File( dirname);

      ConformanceTestConfigManager manager = new ConformanceTestConfigManager();
      List<String> fileList = manager.getFileList( dir);
      for( String filename: fileList) {
         showln("** process: "+filename);
      }

      showln("===============================");
      Map<String,String> nameMap = new HashMap<String,String>();
      nameMap.put("rfss_1", "Xrfss_1");
      boolean save = false;
      List<String> modList = manager.reconcileRfssName(nameMap, dir, save);
      for( String filename: modList) {
         showln("** mod: "+filename);
      }
      showln("** Total Topology size: "+fileList.size());
      showln("** Total Modified size: "+modList.size());
   }
}
