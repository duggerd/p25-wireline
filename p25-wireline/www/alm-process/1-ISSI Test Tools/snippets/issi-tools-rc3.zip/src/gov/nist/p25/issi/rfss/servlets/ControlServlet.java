//
package gov.nist.p25.issi.rfss.servlets;

import gov.nist.p25.issi.constants.ISSITesterConstants;
import gov.nist.p25.issi.rfss.tester.RfssController;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * The control servlet allows you to remotely control the RFSS via HTTP POST.
 * 
 * @author M. Ranganathan
 * 
 */
public class ControlServlet extends HttpServlet {

   private static final long serialVersionUID = -1L;
   private static Logger logger = Logger.getLogger(ControlServlet.class);

   static Collection<String> ipAddress;
   private RfssController rfssController = new RfssController(ipAddress);

   @Override
   public void doPost(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      String command = request.getParameter(ISSITesterConstants.COMMAND);

      if (command == null)
         throw new ServletException("Missing a required parameter : "
               + ISSITesterConstants.COMMAND);
      String testCase = request.getParameter(ISSITesterConstants.TEST_CASE);
      boolean interactive = request
            .getParameter(ISSITesterConstants.INTERACTIVE) == null ? false
            : request.getParameter(ISSITesterConstants.INTERACTIVE).equals(
                  "true");
      boolean evalPassFail = request.getParameter(ISSITesterConstants.EVALUATE_POST_CONDITION) == null ? true :
            request.getParameter(ISSITesterConstants.EVALUATE_POST_CONDITION).equals("true");

      String topology = request.getParameter(ISSITesterConstants.TEST_TOPOLOGY);
      String globalTopology = request.getParameter(ISSITesterConstants.GLOBAL_TOPOLOGY);
      String systemTopology = request.getParameter(ISSITesterConstants.SYSTEM_TOPOLOGY);
      
      logger.debug("globalTopology = " + globalTopology);
      String scenarioDir = request.getParameter(ISSITesterConstants.SCENARIO_DIR_KEY);
      String testNumber = request.getParameter(ISSITesterConstants.TEST_NUMBER);

      try {
         if (command.equals(ISSITesterConstants.LOAD)) {
            rfssController.loadTest(scenarioDir,testCase,testNumber,topology,globalTopology,
               systemTopology,interactive,evalPassFail);
         } else if (command.equals(ISSITesterConstants.RUN)) {
            rfssController.runTest();
         } else if (command.equals(ISSITesterConstants.GET_RFSS_STATUS_INFO)) {
            String retval = rfssController.getRfssPttSessionInfo();
            response.setContentLength(retval.length());
            response.getOutputStream().print(retval.toString());
            response.getOutputStream().flush();
         } else if (command.equals(ISSITesterConstants.EXECUTE_NEXT_SCENARIO)) {
            String scenario = request.getParameter(ISSITesterConstants.SCENARIO);
            rfssController.signalNextScenario(scenario);
         } else if (command.equals(ISSITesterConstants.TEAR_DOWN_TEST)) {
            rfssController.tearDownCurrentTest();
         } else if (command.equals(ISSITesterConstants.TEST_COMPLETED)) {
            rfssController.signalTestCompletion();
         } else if (command.equals(ISSITesterConstants.GET_TEST_RESULTS)) {
            boolean passed = rfssController.getTestResults();
            String retval = passed ? ISSITesterConstants.PASSED : ISSITesterConstants.FAILED;
            // logger.info("Writing out " + retval);
            response.setContentLength(retval.length());
            response.getOutputStream().print(retval);
            response.getOutputStream().flush();
         } else if (command.equals(ISSITesterConstants.GET_SIP_TRACE)) {
            String retval = rfssController.getStackSipLog();
            if (retval != null) {
               response.setContentLength(retval.length());
               response.getOutputStream().print(retval.toString());
               response.getOutputStream().flush();
            } else {
               response.setContentLength(0);
               response.getOutputStream().flush();
            }
         } else if (command.equals(ISSITesterConstants.GET_PTT_TRACE)) {
            String retval = rfssController.getStackPttLog();
            if (retval != null) {
               response.setContentLength(retval.length());
               response.getOutputStream().print(retval.toString());
               response.getOutputStream().flush();
            } else {
               response.setContentLength(0);
               response.getOutputStream().flush();
            }
         } else if (command.equals(ISSITesterConstants.GET_ERROR_LOG)) {
            String retval = rfssController.getErrorLog();
            if (retval != null) {
               response.setContentLength(retval.length());
               response.getOutputStream().print(retval.toString());
               response.getOutputStream().flush();
            } else {
               response.setContentLength(0);
               response.getOutputStream().flush();
            }
         } else if (command.equals(ISSITesterConstants.EXIT_EMULATOR)) {
            logger.info("Exitting emulated RFSS!");
            response.flushBuffer();
            response.getWriter().close();
            //System.exit(0);
         } else if ( command.equals(ISSITesterConstants.IS_TEST_COMPLETED)) {
            String retval = Boolean.toString(rfssController.isTestCompleted());
            response.setContentLength(retval.length());
            response.getOutputStream().print(retval.toString());
            response.getOutputStream().flush();
         }
      } catch (Exception ex) {
         logger.error("ControlServlet: Error in loading test case", ex);
         String exception = ex.getStackTrace().toString();
         response.getWriter().print(exception);
         response.sendError(HttpServletResponse.SC_BAD_REQUEST);
         response.flushBuffer();
         return;
      }
   }

   public static void setIpAddress(Collection<String> ipAddress) {
      ControlServlet.ipAddress = ipAddress;
   }
}
