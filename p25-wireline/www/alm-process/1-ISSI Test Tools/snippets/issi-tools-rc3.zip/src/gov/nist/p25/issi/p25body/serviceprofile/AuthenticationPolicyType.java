//
package gov.nist.p25.issi.p25body.serviceprofile;

/**
 * The Authentication Policy attribute specifies the authentication policy to be
 * applied to the unit.
 * 
 * @author M. Ranganathan
 * 
 */
public enum AuthenticationPolicyType {

   NONE(0, "No policy is required"), 
   REQUIRED(1, "authentication is required when the home is reachable"),
   REJECT_IF_NOT_CURRENT(
         2,
         "authentication is always required and authentication SHOULD be rejected "
               + "if the serving RFSS does not have the current parameters of the SU.");

   private String description;
   private int intValue;

   // constructor
   AuthenticationPolicyType(int dup, String desc) {
      this.intValue = dup;
      this.description = desc;
   }

   public int getIntValue() {
      return intValue;
   }

   @Override
   public String toString() {
      return description;
   }

   public static AuthenticationPolicyType getInstance(int intVal) {
      for (AuthenticationPolicyType d : AuthenticationPolicyType.values())
         if (d.intValue == intVal)
            return d;
      throw new IllegalArgumentException("Value out of range: "+intVal);
   }
}
