//
package gov.nist.p25.issi.analyzer.vo;

import jpcap.packet.Packet;

/**
 * Captured Packet
 */
public class CapturedPacket 
{
   private int packetNumber;
   private long timeStamp;
   private Packet packet;
   
   // accessor
   public int getPacketNumber() {
      return packetNumber;
   }
   public void setPacketNumber( int packetNumber) {
      this.packetNumber = packetNumber;
   }

   public long getTimeStamp() {
      return timeStamp;
   }
   public void setTimeStamp(long timeStamp) {
      this.timeStamp = timeStamp;
   }

   public Packet getPacket() {
      return packet;
   }
   public void setPacket(Packet packet) {
      this.packet = packet;
   }

   // constructor
   public CapturedPacket(Packet packet) {
      this( 0, packet);
   }
   public CapturedPacket(int packetNumber, Packet packet) {
      this.packetNumber = packetNumber;
      this.packet = packet;
      //this.timeStamp = System.currentTimeMillis();
      
      // current TS + captured sec and micro-sec
      this.timeStamp = System.currentTimeMillis()+packet.sec*1000+packet.usec/1000;

   }
}
