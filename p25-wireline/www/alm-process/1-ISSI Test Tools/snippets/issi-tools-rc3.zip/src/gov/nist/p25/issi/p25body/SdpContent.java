//
package gov.nist.p25.issi.p25body;

import gov.nist.javax.sdp.fields.AttributeField;
import gov.nist.javax.sdp.fields.OriginField;

import java.text.ParseException;

import javax.sdp.MediaDescription;
import javax.sdp.SdpFactory;
import javax.sdp.SdpParseException;
import javax.sdp.SessionDescription;
import javax.sip.header.ContentTypeHeader;

import org.apache.log4j.Logger;


public class SdpContent extends Content {

   private static Logger logger = Logger.getLogger(SdpContent.class);
   
   private SessionDescription sessionDescription;

   /**
    * TODO Validate the incoming SDP announce and return true if validation
    * passes.
    * 
    * @return
    */
   private boolean validate() {
      return true;
   }

   public SdpContent(ContentTypeHeader contentTypeHeader, String content)
         throws ParseException {
      super(contentTypeHeader, content);
      SdpFactory sdpFactory = SdpFactory.getInstance();
      try {
         this.sessionDescription = sdpFactory
               .createSessionDescription(content);
      } catch (SdpParseException ex) {
         throw new ParseException(content, 0);
      }
      if (!this.validate())
         throw new ParseException(
               "SDP announcement does not conform to standard ", 0);
   }

   public SdpContent(ContentTypeHeader contentTypeHeader) {
      super(contentTypeHeader, null);
   }

   public static SdpContent createSdpContent() {
      SdpContent retval = new SdpContent(sdpContentTypeHeader);
      return retval;
   }

   public static SdpContent createSdpContent(String sdpcontent)
         throws ParseException {
      return new SdpContent(sdpContentTypeHeader, sdpcontent);
   }

   public SessionDescription getSessionDescription() {
      return this.sessionDescription;
   }

   public void setSessionDescription(SessionDescription sessionDescription) {
      this.sessionDescription = sessionDescription;
   }

   public String toString() {

      if (super.boundary == null)
         return this.sessionDescription.toString();
      else {
         return new StringBuffer().append(
               super.boundary + "\r\n" + getContentTypeHeader() + "\r\n"
                     + this.sessionDescription.toString()).toString();
      }
   }

   private static String toRtfString(SessionDescription sd) {
      try {
         StringBuffer sb = new StringBuffer();
         sb.append(HEADER_START).append(sd.getVersion().toString()).append(
               HEADER_END);
         sb.append(HEADER_START).append("o=-").append(IGNORED_FIELD).append(
               ((OriginField) sd.getOrigin()).getSessIdAsString()).append(
               ((OriginField) sd.getOrigin()).getSessVersionAsString())
               .append(HEADER_RESTART).append(" IN IP4 ").append(
                     IGNORED_FIELD).append(sd.getOrigin().getAddress())
               .append(HEADER_END);
         sb.append(HEADER_START + sd.getSessionName() + HEADER_END);
         sb.append(HEADER_START + sd.getTimeDescriptions(false).get(0)
               + HEADER_END);
         sb.append(HEADER_START + "c=IN IP4 " + IGNORED_FIELD
               + sd.getConnection().getAddress() + HEADER_END);
         
         MediaDescription md = (MediaDescription) sd.getMediaDescriptions(
               false).get(0);
         sb.append(HEADER_START + "m=audio " + md.getMedia().getMediaPort()
               + HEADER_RESTART + "RTP/AVP 100" + HEADER_END);
         // append attributes if any ( there should be 1 at least(
         if (md.getAttributes(false).size() != 0) {
            sb.append(HEADER_START + md.getAttributes(false).get(0)
                  + HEADER_END);
         }
         return sb.toString();
      } catch (Exception ex) {
         logger.error(
               "Unexpected exception -- could not format as RTF string",
               ex);
         return null;
      }
   }

   @Override
   public String toRtfString() {
      if (super.boundary == null)
         return toRtfString(sessionDescription);
      else {
         return new StringBuffer().append(
               HEADER_START + super.boundary + HEADER_END + "\r\n"
                     + HEADER_START + getContentTypeHeader()
                     + HEADER_END + LINE_FEED + "\r\n"
                     + toRtfString(sessionDescription)).toString();
      }
   }

   @Override
   public boolean match(Content template) {
      if (!(template instanceof SdpContent))
         return false;
      try {
         SessionDescription matchSdp = ((SdpContent) template)
               .getSessionDescription();
         MediaDescription md1 = (MediaDescription) matchSdp
               .getMediaDescriptions(false).get(0);
         MediaDescription md2 = (MediaDescription) this.sessionDescription
               .getMediaDescriptions(false).get(0);
         if ( md2.getAttributes(false).size() == 0) return false;
         AttributeField af1 = (AttributeField) md1.getAttributes(false).get(0);
         AttributeField af2 = (AttributeField) md2.getAttributes(false).get(0);
         if ( ! af1.getAttribute().getValue().equals(af2.getAttribute().getValue())) {
            logger.debug("Could not match attribute " + af2 + " " + af1 );
            return false;
         }
               
         return matchSdp.getVersion().getVersion() == this.sessionDescription
               .getVersion().getVersion()
               && matchSdp.getSessionName().getValue().equalsIgnoreCase(
                     this.sessionDescription.getSessionName().getValue())
               && md1.getMedia().getMediaType().equalsIgnoreCase(
                     md2.getMedia().getMediaType())
               && md1.getMedia().getProtocol().equalsIgnoreCase(
                     md2.getMedia().getProtocol());
      } catch (Exception ex) {
         logger.error("Unexpected exception ", ex);
         return false;
      }
   }
   
   public boolean isDefault() {
      return false;
   }
}
